import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Clock, Users, Bookmark, Copy, CheckCircle, Heart, Utensils, Apple, Coffee, ArrowLeft } from "lucide-react";

interface Recipe {
  id: number;
  name: string;
  description: string;
  ingredients: string[];
  instructions: string[];
  sugarContent: number;
  prepTime: number;
  cookTime?: number;
  servings: number;
  mealType: string;
  category: string;
  dietaryTypes?: string[];
  healthFocus?: string[];
  benefits?: string;
  nutritionFacts?: {
    calories?: number;
    protein?: number;
    carbs?: number;
    fat?: number;
    fiber?: number;
  };
}

interface RecipeInteraction {
  id: number;
  userId: number;
  recipeId: number;
  isBookmarked: boolean;
  hasTriedIt: boolean;
  rating?: number;
  notes?: string;
}

export default function HealthyRecipes() {
  const [, setLocation] = useLocation();
  const [selectedMealType, setSelectedMealType] = useState<string>("all");
  const [selectedDietaryTypes, setSelectedDietaryTypes] = useState<string[]>([]);
  const [selectedHealthFocus, setSelectedHealthFocus] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch recipes with filters
  const { data: recipes = [], isLoading } = useQuery({
    queryKey: ['/api/recipes', selectedMealType, selectedDietaryTypes, selectedHealthFocus, currentPage],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedMealType && selectedMealType !== 'all') {
        params.append('mealType', selectedMealType);
      }
      if (selectedDietaryTypes.length > 0) {
        selectedDietaryTypes.forEach(type => params.append('dietaryTypes', type));
      }
      if (selectedHealthFocus.length > 0) {
        selectedHealthFocus.forEach(focus => params.append('healthFocus', focus));
      }
      params.append('limit', '12');
      params.append('offset', (currentPage * 12).toString());
      
      const response = await fetch(`/api/recipes?${params}`);
      if (!response.ok) throw new Error('Failed to fetch recipes');
      return response.json();
    },
  });

  // Recipe interaction mutations
  const bookmarkMutation = useMutation({
    mutationFn: async ({ recipeId, isBookmarked }: { recipeId: number; isBookmarked: boolean }) => {
      return apiRequest("POST", "/api/recipes/interactions", { recipeId, isBookmarked });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recipes'] });
      toast({ title: "Recipe bookmarked!", description: "Added to your saved recipes." });
    },
    onError: () => {
      toast({ title: "Authentication required", description: "Please sign in to bookmark recipes.", variant: "destructive" });
    }
  });

  const triedItMutation = useMutation({
    mutationFn: async ({ recipeId, hasTriedIt }: { recipeId: number; hasTriedIt: boolean }) => {
      return apiRequest("POST", "/api/recipes/interactions", { recipeId, hasTriedIt, triedAt: new Date() });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recipes'] });
      toast({ title: "Marked as tried!", description: "Great job trying a new healthy recipe!" });
    },
    onError: () => {
      toast({ title: "Authentication required", description: "Please sign in to track tried recipes.", variant: "destructive" });
    }
  });

  const copyIngredients = (ingredients: string[]) => {
    const ingredientsList = ingredients.join('\n• ');
    navigator.clipboard.writeText(`Ingredients:\n• ${ingredientsList}`);
    toast({ title: "Ingredients copied!", description: "Shopping list ready to go." });
  };

  const dietaryOptions = [
    { value: "plant-based", label: "Plant-Based" },
    { value: "gluten-free", label: "Gluten-Free" },
    { value: "mediterranean", label: "Mediterranean" },
    { value: "low-carb", label: "Low-Carb" }
  ];

  const healthFocusOptions = [
    { value: "heart-healthy", label: "Heart-Healthy" },
    { value: "diabetes-friendly", label: "Diabetes-Friendly" },
    { value: "anti-inflammatory", label: "Anti-Inflammatory" },
    { value: "cancer-fighting", label: "Cancer-Fighting" },
    { value: "general-wellness", label: "General Wellness" }
  ];

  const getMealTypeIcon = (mealType: string) => {
    switch (mealType) {
      case 'breakfast': return <Coffee className="h-4 w-4" />;
      case 'lunch': return <Utensils className="h-4 w-4" />;
      case 'dinner': return <Utensils className="h-4 w-4" />;
      case 'snack': return <Apple className="h-4 w-4" />;
      default: return <Utensils className="h-4 w-4" />;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl pb-20">
      <div className="flex items-center mb-8">
        <Button
          onClick={() => setLocation("/")}
          className="mr-4 text-muted-foreground p-0"
          variant="ghost"
        >
          <ArrowLeft size={24} />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold mb-2">Healthy Recipes</h1>
          <p className="text-muted-foreground">
            Discover 50 nutritious recipes designed to support your wellness journey
          </p>
        </div>
      </div>

      {/* Meal Type Filter Tabs */}
      <Tabs value={selectedMealType} onValueChange={setSelectedMealType} className="mb-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">All Recipes</TabsTrigger>
          <TabsTrigger value="breakfast">Breakfast</TabsTrigger>
          <TabsTrigger value="lunch">Lunch</TabsTrigger>
          <TabsTrigger value="dinner">Dinner</TabsTrigger>
          <TabsTrigger value="snack">Snacks</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Advanced Filters */}
      <div className="mb-6">
        <Button 
          variant="outline" 
          onClick={() => setShowFilters(!showFilters)}
          className="mb-4"
        >
          {showFilters ? "Hide" : "Show"} Advanced Filters
        </Button>
        
        {showFilters && (
          <Card className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Dietary Preferences */}
              <div>
                <h3 className="font-semibold mb-3">Dietary Preferences</h3>
                <div className="space-y-2">
                  {dietaryOptions.map((option) => (
                    <div key={option.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={option.value}
                        checked={selectedDietaryTypes.includes(option.value)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedDietaryTypes([...selectedDietaryTypes, option.value]);
                          } else {
                            setSelectedDietaryTypes(selectedDietaryTypes.filter(t => t !== option.value));
                          }
                        }}
                      />
                      <label htmlFor={option.value} className="text-sm">{option.label}</label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Health Goals */}
              <div>
                <h3 className="font-semibold mb-3">Health Goals</h3>
                <div className="space-y-2">
                  {healthFocusOptions.map((option) => (
                    <div key={option.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={option.value}
                        checked={selectedHealthFocus.includes(option.value)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedHealthFocus([...selectedHealthFocus, option.value]);
                          } else {
                            setSelectedHealthFocus(selectedHealthFocus.filter(f => f !== option.value));
                          }
                        }}
                      />
                      <label htmlFor={option.value} className="text-sm">{option.label}</label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-4 flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setSelectedDietaryTypes([]);
                  setSelectedHealthFocus([]);
                }}
              >
                Clear All Filters
              </Button>
            </div>
          </Card>
        )}
      </div>

      {/* Recipe Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <div className="h-48 bg-gray-200 rounded-t-lg"></div>
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mb-4"></div>
                <div className="flex justify-between">
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe: Recipe) => (
            <Card key={recipe.id} className="group hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2 mb-2">
                    {getMealTypeIcon(recipe.mealType)}
                    <Badge variant="secondary" className="text-xs">
                      {recipe.mealType}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => bookmarkMutation.mutate({ recipeId: recipe.id, isBookmarked: true })}
                  >
                    <Bookmark className="h-4 w-4" />
                  </Button>
                </div>
                <CardTitle className="text-lg leading-tight">{recipe.name}</CardTitle>
                <CardDescription className="text-sm">{recipe.description}</CardDescription>
              </CardHeader>
              
              <CardContent className="pt-0">
                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {recipe.healthFocus?.slice(0, 2).map((focus) => (
                    <Badge key={focus} variant="outline" className="text-xs">
                      <Heart className="h-3 w-3 mr-1" />
                      {focus.replace('-', ' ')}
                    </Badge>
                  ))}
                </div>

                {/* Recipe Info */}
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {recipe.prepTime + (recipe.cookTime || 0)} min
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {recipe.servings} serving{recipe.servings > 1 ? 's' : ''}
                  </div>
                  {recipe.nutritionFacts?.calories && (
                    <div className="text-xs">
                      {recipe.nutritionFacts.calories} cal
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="default" size="sm" className="flex-1">
                        View Recipe
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>{recipe.name}</DialogTitle>
                        <DialogDescription>{recipe.description}</DialogDescription>
                      </DialogHeader>
                      
                      <div className="space-y-4">
                        {/* Recipe Info */}
                        <div className="flex gap-4 text-sm">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            Prep: {recipe.prepTime} min
                          </div>
                          {recipe.cookTime && (
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              Cook: {recipe.cookTime} min
                            </div>
                          )}
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            Serves {recipe.servings}
                          </div>
                        </div>

                        {/* Health Benefits */}
                        {recipe.benefits && (
                          <div>
                            <h4 className="font-semibold mb-2">Health Benefits</h4>
                            <p className="text-sm text-muted-foreground">{recipe.benefits}</p>
                          </div>
                        )}

                        {/* Nutrition Facts */}
                        {recipe.nutritionFacts && (
                          <div>
                            <h4 className="font-semibold mb-2">Nutrition (per serving)</h4>
                            <div className="grid grid-cols-3 gap-2 text-sm">
                              {recipe.nutritionFacts.calories && (
                                <div>Calories: {recipe.nutritionFacts.calories}</div>
                              )}
                              {recipe.nutritionFacts.protein && (
                                <div>Protein: {recipe.nutritionFacts.protein}g</div>
                              )}
                              {recipe.nutritionFacts.carbs && (
                                <div>Carbs: {recipe.nutritionFacts.carbs}g</div>
                              )}
                              {recipe.nutritionFacts.fat && (
                                <div>Fat: {recipe.nutritionFacts.fat}g</div>
                              )}
                              {recipe.nutritionFacts.fiber && (
                                <div>Fiber: {recipe.nutritionFacts.fiber}g</div>
                              )}
                              {recipe.sugarContent && (
                                <div>Sugar: {recipe.sugarContent}g</div>
                              )}
                            </div>
                          </div>
                        )}

                        <Separator />

                        {/* Ingredients */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold">Ingredients</h4>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => copyIngredients(recipe.ingredients)}
                            >
                              <Copy className="h-3 w-3 mr-1" />
                              Copy List
                            </Button>
                          </div>
                          <ul className="space-y-1 text-sm">
                            {recipe.ingredients.map((ingredient, index) => (
                              <li key={index} className="flex items-start gap-2">
                                <span className="text-muted-foreground">•</span>
                                {ingredient}
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Instructions */}
                        <div>
                          <h4 className="font-semibold mb-2">Instructions</h4>
                          <ol className="space-y-2 text-sm">
                            {recipe.instructions.map((instruction, index) => (
                              <li key={index} className="flex gap-2">
                                <span className="font-medium text-primary">{index + 1}.</span>
                                {instruction}
                              </li>
                            ))}
                          </ol>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-2 pt-4">
                          <Button
                            variant="outline"
                            onClick={() => bookmarkMutation.mutate({ recipeId: recipe.id, isBookmarked: true })}
                            className="flex-1"
                          >
                            <Bookmark className="h-4 w-4 mr-2" />
                            Bookmark
                          </Button>
                          <Button
                            variant="default"
                            onClick={() => triedItMutation.mutate({ recipeId: recipe.id, hasTriedIt: true })}
                            className="flex-1"
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Mark as Tried
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyIngredients(recipe.ingredients)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => triedItMutation.mutate({ recipeId: recipe.id, hasTriedIt: true })}
                  >
                    <CheckCircle className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Load More Button */}
      {recipes.length >= 12 && (
        <div className="text-center mt-8">
          <Button 
            variant="outline"
            onClick={() => setCurrentPage(currentPage + 1)}
            disabled={isLoading}
          >
            Load More Recipes
          </Button>
        </div>
      )}

      {/* Disclaimer */}
      <Card className="mt-12 bg-muted/50">
        <CardContent className="p-6">
          <h3 className="font-semibold mb-2">Medical Disclaimer</h3>
          <p className="text-sm text-muted-foreground">
            These general recipe suggestions are not medical advice. Please consult a healthcare provider before making major dietary changes, 
            especially if you have any medical conditions, food allergies, or are taking medications. Individual nutritional needs may vary. 
            The nutritional information provided is approximate and should not be considered a substitute for professional nutritional counseling.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}