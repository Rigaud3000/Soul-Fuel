import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Heart, 
  Zap, 
  Timer, 
  Gamepad2, 
  Wind, 
  MessageCircle, 
  Droplets,
  Trophy,
  ArrowLeft
} from "lucide-react";
import { useLocation } from "wouter";
import BreathingOrb from "@/components/mini-games/breathing-orb";
import PuzzlePop from "@/components/mini-games/puzzle-pop";

const DOPAMINE_ACTIVITIES = [
  {
    id: 1,
    title: "Take a 5-minute walk",
    icon: "🚶‍♂️",
    duration: 5,
    description: "Get moving to release natural endorphins",
    type: "movement"
  },
  {
    id: 2,
    title: "Watch something funny",
    icon: "😄",
    duration: 3,
    description: "Laughter releases feel-good chemicals",
    type: "humor"
  },
  {
    id: 3,
    title: "Deep breathing session",
    icon: "🧘‍♀️",
    duration: 2,
    description: "Calm your mind and reduce stress",
    type: "breathing"
  },
  {
    id: 4,
    title: "Listen to music",
    icon: "🎶",
    duration: 4,
    description: "Music triggers dopamine release",
    type: "audio"
  },
  {
    id: 5,
    title: "Quick journal entry",
    icon: "📝",
    duration: 3,
    description: "Reflect on your feelings and thoughts",
    type: "mindfulness"
  },
  {
    id: 6,
    title: "Drink a glass of water",
    icon: "💧",
    duration: 1,
    description: "You might just be thirsty!",
    type: "hydration"
  }
];

const MINI_GAMES = [
  {
    id: 1,
    title: "Puzzle Pop",
    description: "Match healthy foods in 30 seconds",
    icon: Gamepad2,
    duration: "30s"
  },
  {
    id: 2,
    title: "Breathing Orb",
    description: "Follow the calming rhythm",
    icon: Wind,
    duration: "60s"
  },
  {
    id: 3,
    title: "Tap Challenge",
    description: "Quick reaction game",
    icon: Zap,
    duration: "45s"
  }
];

export default function CravingEmergency() {
  const [, setLocation] = useLocation();
  const [selectedActivity, setSelectedActivity] = useState<any>(null);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [completedActivities, setCompletedActivities] = useState<number[]>([]);
  const [cravingIntensity, setCravingIntensity] = useState(5);
  const [activeGame, setActiveGame] = useState<string | null>(null);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(timeRemaining - 1);
      }, 1000);
    } else if (timeRemaining === 0 && isActive) {
      setIsActive(false);
      setCompletedActivities(prev => [...prev, selectedActivity.id]);
    }
    return () => clearInterval(interval);
  }, [isActive, timeRemaining, selectedActivity]);

  const startActivity = (activity: any) => {
    setSelectedActivity(activity);
    setTimeRemaining(activity.duration * 60);
    setIsActive(true);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleComplete = () => {
    setIsActive(false);
    setTimeRemaining(0);
    if (selectedActivity) {
      setCompletedActivities(prev => [...prev, selectedActivity.id]);
    }
  };

  const handleGameComplete = () => {
    setActiveGame(null);
    setCompletedActivities(prev => [...prev, 999]); // Special ID for games
  };

  const handleGameExit = () => {
    setActiveGame(null);
  };

  // Render active game
  if (activeGame === 'breathing') {
    return <BreathingOrb onComplete={handleGameComplete} onExit={handleGameExit} />;
  }
  
  if (activeGame === 'puzzle') {
    return <PuzzlePop onComplete={handleGameComplete} onExit={handleGameExit} />;
  }

  if (selectedActivity && isActive) {
    return (
      <div className="min-h-screen bg-dark-900 text-white p-4 pb-20">
        <div className="max-w-md mx-auto">
          <Button
            onClick={() => setIsActive(false)}
            variant="ghost"
            className="mb-4 text-dark-400"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>

          <Card className="bg-dark-800 border-dark-700 text-center">
            <CardHeader>
              <div className="text-6xl mb-4">{selectedActivity.icon}</div>
              <CardTitle className="text-primary">{selectedActivity.title}</CardTitle>
              <p className="text-dark-400">{selectedActivity.description}</p>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold mb-4 text-primary">
                {formatTime(timeRemaining)}
              </div>
              <Progress 
                value={((selectedActivity.duration * 60 - timeRemaining) / (selectedActivity.duration * 60)) * 100} 
                className="mb-6"
              />
              <div className="space-y-3">
                <Button 
                  onClick={handleComplete}
                  className="w-full bg-primary hover:bg-primary/80"
                >
                  <Trophy className="mr-2 h-4 w-4" />
                  Mark Complete
                </Button>
                <Button 
                  onClick={() => setIsActive(false)}
                  variant="outline"
                  className="w-full"
                >
                  Choose Different Activity
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-white p-4 pb-20">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <div className="flex-1 text-center">
            <div className="text-4xl mb-2">🆘</div>
            <h1 className="text-2xl font-bold text-primary mb-2">Craving Emergency Kit</h1>
            <p className="text-dark-400">You're stronger than your craving. Let's ride it out together!</p>
          </div>
        </div>

        {/* Craving Intensity Selector */}
        <Card className="bg-dark-800 border-dark-700 mb-6">
          <CardHeader>
            <CardTitle className="text-sm">How intense is your craving? (1-10)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between mb-2">
              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                <Button
                  key={num}
                  size="sm"
                  variant={cravingIntensity === num ? "default" : "outline"}
                  onClick={() => setCravingIntensity(num)}
                  className="w-8 h-8 p-0"
                >
                  {num}
                </Button>
              ))}
            </div>
            <div className="flex justify-between text-xs text-dark-400">
              <span>Mild</span>
              <span>Intense</span>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Actions */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3 flex items-center">
            <Zap className="mr-2 h-5 w-5 text-primary" />
            Quick Actions
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {DOPAMINE_ACTIVITIES.slice(0, 4).map(activity => (
              <Card 
                key={activity.id}
                className={`bg-dark-800 border-dark-700 cursor-pointer transition-all hover:bg-dark-700 ${
                  completedActivities.includes(activity.id) ? 'border-primary/50' : ''
                }`}
                onClick={() => startActivity(activity)}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-2xl mb-2">{activity.icon}</div>
                  <h3 className="font-medium text-sm mb-1">{activity.title}</h3>
                  <div className="flex items-center justify-center text-xs text-dark-400">
                    <Timer className="mr-1 h-3 w-3" />
                    {activity.duration}m
                  </div>
                  {completedActivities.includes(activity.id) && (
                    <Badge variant="outline" className="mt-2 text-xs border-primary text-primary">
                      ✓ Done
                    </Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Mini Games */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3 flex items-center">
            <Gamepad2 className="mr-2 h-5 w-5 text-primary" />
            Distraction Games
          </h2>
          <div className="space-y-3">
            <Card 
              className="bg-dark-800 border-dark-700 cursor-pointer transition-all hover:bg-dark-700"
              onClick={() => setActiveGame('puzzle')}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Gamepad2 className="mr-3 h-5 w-5 text-primary" />
                    <div>
                      <h3 className="font-medium">Puzzle Pop</h3>
                      <p className="text-sm text-dark-400">Match healthy foods in 30 seconds</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    30s
                  </Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card 
              className="bg-dark-800 border-dark-700 cursor-pointer transition-all hover:bg-dark-700"
              onClick={() => setActiveGame('breathing')}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Wind className="mr-3 h-5 w-5 text-primary" />
                    <div>
                      <h3 className="font-medium">Breathing Orb</h3>
                      <p className="text-sm text-dark-400">Follow the calming rhythm</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    60s
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* More Activities */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3">More Activities</h2>
          <div className="space-y-2">
            {DOPAMINE_ACTIVITIES.slice(4).map(activity => (
              <Card 
                key={activity.id}
                className={`bg-dark-800 border-dark-700 cursor-pointer transition-all hover:bg-dark-700 ${
                  completedActivities.includes(activity.id) ? 'border-primary/50' : ''
                }`}
                onClick={() => startActivity(activity)}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className="text-xl mr-3">{activity.icon}</span>
                      <div>
                        <h3 className="font-medium text-sm">{activity.title}</h3>
                        <p className="text-xs text-dark-400">{activity.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Timer className="mr-1 h-3 w-3 text-dark-400" />
                      <span className="text-xs text-dark-400">{activity.duration}m</span>
                      {completedActivities.includes(activity.id) && (
                        <Badge variant="outline" className="ml-2 text-xs border-primary text-primary">
                          ✓
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* AI Coach & Emergency Chat */}
        <div className="space-y-3">
          <Button 
            onClick={() => setLocation('/coach')}
            className="w-full bg-primary hover:bg-primary/80"
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            Talk to AI Coach
          </Button>
          
          <Button 
            onClick={() => setLocation('/cravings')}
            variant="outline"
            className="w-full"
          >
            <Heart className="mr-2 h-4 w-4" />
            Log This Craving
          </Button>
        </div>

        {/* Stats */}
        {completedActivities.length > 0 && (
          <Card className="bg-dark-800 border-dark-700 mt-6">
            <CardContent className="p-4 text-center">
              <Trophy className="mx-auto h-8 w-8 text-primary mb-2" />
              <p className="text-sm text-dark-400">
                Great job! You completed {completedActivities.length} activity{completedActivities.length > 1 ? 'ies' : ''} today.
              </p>
              <Badge className="mt-2 bg-primary/20 text-primary">
                +{completedActivities.length * 10} XP
              </Badge>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}