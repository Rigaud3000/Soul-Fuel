import React from 'react';
import { DataExportManager } from '@/components/data-export/DataExportManager';

export default function DataExportPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Page Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl font-bold text-slate-800">Export Your Data</h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Download a complete copy of all your SOULFUEL data in a secure, readable format. 
            Perfect for backup, analysis, or compliance requirements.
          </p>
        </div>

        {/* Data Export Manager */}
        <DataExportManager />
      </div>
    </div>
  );
}