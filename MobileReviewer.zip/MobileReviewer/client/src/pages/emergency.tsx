import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  AlertTriangle,
  Heart,
  Timer,
  Brain,
  Gamepad2,
  Music,
  Zap,
  Target,
  CheckCircle,
  RotateCcw,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Shuffle
} from "lucide-react";

interface MiniGame {
  id: string;
  name: string;
  description: string;
  duration: number;
  type: 'puzzle' | 'breathing' | 'focus' | 'movement';
  difficulty: 'easy' | 'medium' | 'hard';
}

export default function Emergency() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [cravingIntensity, setCravingIntensity] = useState(7);
  const [selectedTechnique, setSelectedTechnique] = useState<string | null>(null);
  const [gameActive, setGameActive] = useState(false);
  const [gameScore, setGameScore] = useState(0);
  const [breathingActive, setBreathingActive] = useState(false);
  const [breathingPhase, setBreathingPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [breathingTimer, setBreathingTimer] = useState(4);
  const [puzzleGrid, setPuzzleGrid] = useState<string[]>([]);
  const [targetPattern, setTargetPattern] = useState<string[]>([]);
  const [completedTechniques, setCompletedTechniques] = useState<string[]>([]);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const { toast } = useToast();

  const miniGames: MiniGame[] = [
    {
      id: 'puzzle-pop',
      name: 'Puzzle Pop',
      description: 'Match colored patterns to distract your mind',
      duration: 120,
      type: 'puzzle',
      difficulty: 'easy'
    },
    {
      id: 'breathing-orb',
      name: 'Breathing Orb',
      description: 'Follow the orb to control your breathing',
      duration: 180,
      type: 'breathing',
      difficulty: 'easy'
    },
    {
      id: 'focus-target',
      name: 'Focus Target',
      description: 'Concentrate on moving targets to redirect attention',
      duration: 90,
      type: 'focus',
      difficulty: 'medium'
    },
    {
      id: 'body-shake',
      name: 'Body Shake',
      description: 'Quick movement exercises to release tension',
      duration: 60,
      type: 'movement',
      difficulty: 'easy'
    }
  ];

  const copingStrategies = [
    {
      id: 'water-trick',
      title: 'The Water Trick',
      description: 'Drink a large glass of cold water slowly. This can help reset your body and reduce cravings.',
      duration: '2 minutes',
      type: 'physical'
    },
    {
      id: 'timer-method',
      title: '10-Minute Timer',
      description: 'Set a timer for 10 minutes. Tell yourself you can have it after the timer goes off. Often, the craving will pass.',
      duration: '10 minutes',
      type: 'mental'
    },
    {
      id: 'distraction-list',
      title: 'Emergency Distraction',
      description: 'Call a friend, take a walk, brush your teeth, or do jumping jacks. Any physical activity helps.',
      duration: '5-15 minutes',
      type: 'behavioral'
    },
    {
      id: 'urge-surfing',
      title: 'Urge Surfing',
      description: 'Notice the craving without acting on it. Observe how it feels, knowing it will peak and then fade like a wave.',
      duration: '3-5 minutes',
      type: 'mindfulness'
    }
  ];

  // Initialize breathing exercise
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (breathingActive) {
      interval = setInterval(() => {
        setBreathingTimer(prev => {
          if (prev <= 1) {
            setBreathingPhase(current => {
              if (current === 'inhale') return 'hold';
              if (current === 'hold') return 'exhale';
              return 'inhale';
            });
            return breathingPhase === 'hold' ? 2 : 4; // Hold for 2s, inhale/exhale for 4s
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [breathingActive]);

  // Initialize puzzle game
  useEffect(() => {
    if (selectedTechnique === 'puzzle-pop') {
      generatePuzzle();
    }
  }, [selectedTechnique]);

  const generatePuzzle = () => {
    const colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
    const grid = Array(16).fill(null).map(() => colors[Math.floor(Math.random() * colors.length)]);
    const target = Array(4).fill(null).map(() => colors[Math.floor(Math.random() * colors.length)]);
    setPuzzleGrid(grid);
    setTargetPattern(target);
  };

  const handlePuzzleClick = (index: number) => {
    if (!gameActive) return;
    
    const newGrid = [...puzzleGrid];
    const colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
    const currentColorIndex = colors.indexOf(newGrid[index]);
    newGrid[index] = colors[(currentColorIndex + 1) % colors.length];
    setPuzzleGrid(newGrid);

    // Check if pattern matches (simplified)
    const topRow = newGrid.slice(0, 4);
    if (topRow.every((color, i) => color === targetPattern[i])) {
      setGameScore(prev => prev + 10);
      generatePuzzle();
      toast({
        title: "Pattern matched!",
        description: "+10 points",
      });
    }
  };

  const startTechnique = (techniqueId: string) => {
    setSelectedTechnique(techniqueId);
    
    if (techniqueId === 'breathing-orb') {
      setBreathingActive(true);
      setBreathingPhase('inhale');
      setBreathingTimer(4);
    } else if (techniqueId === 'puzzle-pop') {
      setGameActive(true);
      setGameScore(0);
      generatePuzzle();
    }
  };

  const completeTechnique = (techniqueId: string) => {
    setCompletedTechniques(prev => [...prev, techniqueId]);
    setSelectedTechnique(null);
    setGameActive(false);
    setBreathingActive(false);
    
    // Reduce craving intensity
    setCravingIntensity(prev => Math.max(1, prev - 2));
    
    toast({
      title: "Technique completed!",
      description: "Your craving intensity has decreased.",
    });
  };

  const getIntensityColor = (intensity: number) => {
    if (intensity <= 3) return 'text-green-400';
    if (intensity <= 6) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getIntensityMessage = (intensity: number) => {
    if (intensity <= 3) return 'Manageable - You\'re doing great!';
    if (intensity <= 6) return 'Moderate - Try some techniques';
    return 'Intense - Use emergency tools now';
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to access emergency toolkit</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setLocation("/")}
              variant="ghost"
              size="sm"
              className="text-dark-400 hover:text-dark-200"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
          <Button
            onClick={() => setSoundEnabled(!soundEnabled)}
            variant="outline"
            size="sm"
            className="border-dark-600"
          >
            {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <AlertTriangle className="h-8 w-8 text-red-400" />
            Emergency Toolkit
          </h1>
          <p className="text-dark-400">Immediate help for intense cravings</p>
        </div>

        {/* Craving Intensity Tracker */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <Heart className="h-5 w-5 text-red-400" />
              Current Craving Intensity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className={`text-4xl font-bold ${getIntensityColor(cravingIntensity)}`}>
                {cravingIntensity}/10
              </div>
              <div className="text-dark-400 text-sm mt-1">
                {getIntensityMessage(cravingIntensity)}
              </div>
            </div>
            <Progress value={cravingIntensity * 10} className="h-3" />
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                <Button
                  key={level}
                  onClick={() => setCravingIntensity(level)}
                  variant={cravingIntensity === level ? "default" : "outline"}
                  size="sm"
                  className={`w-8 h-8 p-0 ${
                    cravingIntensity === level 
                      ? "bg-primary" 
                      : "border-dark-600 hover:border-dark-500"
                  }`}
                >
                  {level}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Active Technique */}
        {selectedTechnique && (
          <Card className="bg-dark-800 border-dark-700 border-2 border-primary">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-dark-50">Active Technique</CardTitle>
                <Button
                  onClick={() => setSelectedTechnique(null)}
                  variant="outline"
                  size="sm"
                  className="border-dark-600"
                >
                  Stop
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {selectedTechnique === 'breathing-orb' && (
                <div className="text-center space-y-6">
                  <div className="relative w-32 h-32 mx-auto">
                    <div
                      className={`w-full h-full rounded-full border-4 transition-all duration-1000 ${
                        breathingPhase === 'inhale' ? 'scale-110 border-blue-400' :
                        breathingPhase === 'hold' ? 'scale-110 border-yellow-400' :
                        'scale-90 border-green-400'
                      }`}
                      style={{
                        background: `radial-gradient(circle, ${
                          breathingPhase === 'inhale' ? 'rgba(59, 130, 246, 0.3)' :
                          breathingPhase === 'hold' ? 'rgba(234, 179, 8, 0.3)' :
                          'rgba(34, 197, 94, 0.3)'
                        }, transparent)`
                      }}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="text-2xl font-bold text-dark-50 capitalize">
                      {breathingPhase}
                    </div>
                    <div className="text-lg text-dark-400">
                      {breathingTimer}s
                    </div>
                    <div className="text-sm text-dark-400">
                      {breathingPhase === 'inhale' ? 'Breathe in slowly...' :
                       breathingPhase === 'hold' ? 'Hold your breath...' :
                       'Breathe out slowly...'}
                    </div>
                  </div>
                  <Button
                    onClick={() => completeTechnique('breathing-orb')}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Complete Session
                  </Button>
                </div>
              )}

              {selectedTechnique === 'puzzle-pop' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="text-lg font-medium text-dark-50">Score: {gameScore}</div>
                    <div className="text-sm text-dark-400">Match the top row pattern</div>
                  </div>
                  
                  {/* Target Pattern */}
                  <div className="text-center">
                    <div className="text-sm text-dark-400 mb-2">Target Pattern:</div>
                    <div className="flex justify-center gap-1">
                      {targetPattern.map((color, i) => (
                        <div
                          key={i}
                          className="w-8 h-8 rounded border-2 border-white"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Game Grid */}
                  <div className="grid grid-cols-4 gap-2 max-w-xs mx-auto">
                    {puzzleGrid.map((color, i) => (
                      <button
                        key={i}
                        onClick={() => handlePuzzleClick(i)}
                        className="w-16 h-16 rounded border-2 border-dark-600 hover:border-primary transition-colors"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>

                  <div className="text-center">
                    <Button
                      onClick={() => completeTechnique('puzzle-pop')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Complete Game
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Mini Games */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <Gamepad2 className="h-5 w-5 text-primary" />
              Distraction Games
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {miniGames.map((game) => (
                <div
                  key={game.id}
                  className={`p-4 bg-dark-700 rounded-lg border ${
                    completedTechniques.includes(game.id) ? 'border-green-500' : 'border-dark-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-dark-50">{game.name}</h4>
                    <div className="flex gap-2">
                      <Badge className={`${
                        game.difficulty === 'easy' ? 'bg-green-500/20 text-green-400' :
                        game.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {game.difficulty}
                      </Badge>
                      {completedTechniques.includes(game.id) && (
                        <Badge className="bg-green-500/20 text-green-400">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Done
                        </Badge>
                      )}
                    </div>
                  </div>
                  <p className="text-dark-400 text-sm mb-3">{game.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-dark-400 text-sm flex items-center gap-1">
                      <Timer className="h-3 w-3" />
                      {game.duration}s
                    </span>
                    <Button
                      onClick={() => startTechnique(game.id)}
                      disabled={selectedTechnique !== null}
                      size="sm"
                      className="bg-primary hover:bg-primary/80"
                    >
                      <Play className="h-3 w-3 mr-1" />
                      Start
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Coping Strategies */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <Brain className="h-5 w-5 text-secondary" />
              Quick Coping Strategies
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {copingStrategies.map((strategy) => (
                <div key={strategy.id} className="p-4 bg-dark-700 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-dark-50">{strategy.title}</h4>
                    <Badge className="bg-blue-500/20 text-blue-400 text-xs">
                      {strategy.duration}
                    </Badge>
                  </div>
                  <p className="text-dark-400 text-sm mb-3">{strategy.description}</p>
                  <Button
                    onClick={() => {
                      toast({
                        title: "Strategy activated",
                        description: `Starting ${strategy.title}`,
                      });
                      // Could track usage here
                    }}
                    size="sm"
                    variant="outline"
                    className="border-dark-600"
                  >
                    Try This
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Progress Summary */}
        {completedTechniques.length > 0 && (
          <Card className="bg-dark-800 border-dark-700">
            <CardHeader>
              <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                <Target className="h-5 w-5 text-green-400" />
                Session Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-4">
                <div className="text-3xl font-bold text-green-400">
                  {completedTechniques.length}
                </div>
                <div className="text-dark-400">Techniques completed</div>
                <div className="text-sm text-dark-300">
                  You've reduced your craving intensity and built resilience. Keep going!
                </div>
                <Button
                  onClick={() => {
                    setCompletedTechniques([]);
                    setCravingIntensity(7);
                    toast({
                      title: "Session reset",
                      description: "Ready for a new emergency session",
                    });
                  }}
                  variant="outline"
                  className="border-dark-600"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset Session
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}