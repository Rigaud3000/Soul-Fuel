import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useAuthenticatedRequest } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import SugarChart from "@/components/chart";

export default function SugarTracker() {
  const [, setLocation] = useLocation();
  const { getAuthHeaders } = useAuthenticatedRequest();
  const [showAddForm, setShowAddForm] = useState(false);
  const [amount, setAmount] = useState("");
  const [mealType, setMealType] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
    queryFn: async () => {
      const response = await fetch("/api/analytics", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch analytics");
      return response.json();
    },
  });

  const addSugarMutation = useMutation({
    mutationFn: async (data: { amount: number; mealType: string }) => {
      return apiRequest("POST", "/api/sugar-entries", {
        ...data,
        date: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      toast({
        title: "Sugar intake logged",
        description: "Your sugar intake has been recorded successfully.",
      });
      setShowAddForm(false);
      setAmount("");
      setMealType("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to log sugar intake",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !mealType) return;
    
    addSugarMutation.mutate({
      amount: parseFloat(amount),
      mealType,
    });
  };

  const weeklyStats = analytics?.weeklyStats || {};
  const todaySugar = Math.round(weeklyStats.avgSugar || 0);
  const sugarGoal = 25;
  const progress = Math.min((todaySugar / sugarGoal) * 100, 100);

  // Generate mock weekly data for chart
  const getWeeklyData = () => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const today = new Date().getDay();
    
    return days.map((day, index) => {
      if (index < today) {
        return Math.floor(Math.random() * 30) + 10; // Random past data
      } else if (index === today) {
        return todaySugar;
      } else {
        return 0; // Future days
      }
    });
  };

  const weeklyData = getWeeklyData();

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Sugar Tracker</h2>
        </div>

        {/* Today's Input */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">Today's Sugar Intake</h3>
          <div className="flex items-center justify-center mb-4">
            <div className="text-center">
              <div className="text-4xl font-bold gradient-bg bg-clip-text text-transparent">
                {todaySugar}g
              </div>
              <div className="text-sm text-dark-400">of {sugarGoal}g daily goal</div>
            </div>
          </div>
          <div className="w-full bg-dark-700 rounded-full h-3 mb-4">
            <div 
              className="gradient-bg h-3 rounded-full transition-all duration-300" 
              style={{ width: `${progress}%` }}
            />
          </div>
          
          {!showAddForm ? (
            <Button
              onClick={() => setShowAddForm(true)}
              className="w-full bg-primary text-white py-3 rounded-xl font-semibold hover:bg-primary/90"
            >
              <Plus size={20} className="mr-2" />
              Add Sugar Intake
            </Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="flex space-x-3">
                <Input
                  type="number"
                  placeholder="Amount (g)"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="flex-1 bg-dark-700 border-dark-600 text-dark-50"
                  required
                />
                <Select value={mealType} onValueChange={setMealType} required>
                  <SelectTrigger className="flex-1 bg-dark-700 border-dark-600 text-dark-50">
                    <SelectValue placeholder="Meal type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast">Breakfast</SelectItem>
                    <SelectItem value="lunch">Lunch</SelectItem>
                    <SelectItem value="dinner">Dinner</SelectItem>
                    <SelectItem value="snack">Snack</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex space-x-3">
                <Button
                  type="submit"
                  disabled={addSugarMutation.isPending}
                  className="flex-1 bg-primary text-white"
                >
                  {addSugarMutation.isPending ? "Adding..." : "Add"}
                </Button>
                <Button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  variant="outline"
                  className="flex-1 border-dark-600 text-dark-400"
                >
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </Card>

        {/* Weekly Overview */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">This Week</h3>
          <div className="grid grid-cols-7 gap-2 mb-4">
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, index) => {
              const value = weeklyData[index];
              const isToday = index === new Date().getDay() - 1;
              const color = value <= 20 ? 'bg-green-500' : value <= 30 ? 'bg-yellow-500' : 'bg-red-500';
              
              return (
                <div key={index} className="text-center">
                  <div className="text-xs text-dark-400 mb-1">{day}</div>
                  <div className={`w-8 h-8 ${isToday ? 'bg-secondary' : color} rounded-full flex items-center justify-center text-xs font-semibold text-white`}>
                    {value > 0 ? value : ''}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="text-center text-sm text-dark-400">
            Weekly Average: {Math.round(weeklyStats.avgSugar || 0)}g (Goal: {sugarGoal}g)
          </div>
        </Card>

        {/* Chart */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">Weekly Chart</h3>
          <SugarChart entries={analytics?.entries?.sugar || []} />
        </Card>

        {/* Insights */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">AI Insights</h3>
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
            <p className="text-sm text-dark-50">
              {todaySugar < sugarGoal ? 
                "🎉 Great job! You're staying within your daily sugar goal. Keep up the excellent work!" :
                "⚠️ You're approaching your daily sugar limit. Consider choosing lower-sugar options for your next meal."
              }
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
