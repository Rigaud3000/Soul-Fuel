import { WearableIntegration } from "@/components/wearable-integration";

export default function WearableDevices() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Health App & Wearable Integration</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Connect your fitness trackers, smartwatches, and health apps to get comprehensive wellness insights.
        </p>
      </div>
      
      <WearableIntegration />
    </div>
  );
}