import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useAuthenticatedRequest } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { Camera, Smile, User, Trophy, Flame, AlertTriangle, Zap, TrendingUp, Target, Plus, Activity, Award } from "lucide-react";
import SugarChart from "@/components/chart";
import VoiceLogger from "@/components/voice-food-logger";
import IntelligentNotifications from "@/components/intelligent-notifications";
import LanguageSelector from "@/components/language-selector";
import { useTranslation } from "@/contexts/LanguageContext";
import soulFuelLogo from "/src/assets/soulfuel-logo-final.png";


export default function Dashboard() {
  const { user } = useAuth();
  const { getAuthHeaders } = useAuthenticatedRequest();
  const [, setLocation] = useLocation();
  const { t } = useTranslation();

  const { data: analytics, isLoading } = useQuery({
    queryKey: ["/api/analytics"],
    queryFn: async () => {
      const response = await fetch("/api/analytics", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch analytics");
      return response.json();
    },
  });

  const { data: foodAnalyses } = useQuery({
    queryKey: ["/api/food-analyses"],
    queryFn: async () => {
      const response = await fetch("/api/food-analyses", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch food analyses");
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="p-6 min-h-screen bg-dark-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const weeklyStats = analytics?.weeklyStats || {};
  const todaySugar = Math.round(weeklyStats.avgSugar || 0);
  const todayMood = weeklyStats.moodCheckIns > 0 ? "😊" : "🤷";
  const goalsCompleted = Math.round((weeklyStats.moodCheckIns / 7) * 100);
  const sugarGoal = 25;
  const sugarProgress = Math.min((todaySugar / sugarGoal) * 100, 100);
  const moodProgress = Math.min((weeklyStats.moodCheckIns / 7) * 100, 100);

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      {/* Header */}
      <div className="p-6 soul-gradient relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent animate-pulse"></div>
        <div className="relative z-10">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <img 
                src={soulFuelLogo} 
                alt="SOULFUEL" 
                className="w-16 h-16 mr-4 emerald-glow filter drop-shadow-lg"
              />
              <div>
                <h2 className="font-bold text-dark-50 text-[21px]">
                  {t("dashboard.greeting", { 
                    time: new Date().getHours() < 12 ? t("common.morning") : new Date().getHours() < 18 ? t("common.afternoon") : t("common.evening"),
                    name: user?.username || ""
                  })}
                </h2>
                <p className="text-dark-300">{t("dashboard.tagline")}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <LanguageSelector />
              <div className="w-12 h-12 glass-effect rounded-full flex items-center justify-center">
                <User className="text-primary" size={20} />
              </div>
            </div>
          </div>
        </div>

        {/* Emergency Craving Button */}
        <Button
          onClick={() => setLocation('/emergency')}
          className="w-full mb-4 bg-destructive hover:bg-destructive/80 text-dark-50 font-semibold py-3 rounded-xl coral-glow"
        >
          <AlertTriangle className="mr-2 h-5 w-5" />
{t('dashboard.cravingHelp')}
        </Button>

        {/* Quick Stats & Gamification */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="glass-effect rounded-xl p-3 text-center">
            <div className="text-xl font-bold text-dark-50">{todaySugar}g</div>
            <div className="text-xs text-dark-300">{t('dashboard.sugarToday')}</div>
          </div>
          <div className="glass-effect rounded-xl p-3 text-center">
            <div className="text-xl font-bold text-dark-50">{todayMood}</div>
            <div className="text-xs text-dark-300">{t('dashboard.mood')}</div>
          </div>
          <div className="glass-effect rounded-xl p-3 text-center">
            <div className="text-xl font-bold text-dark-50 flex items-center justify-center">
              <Flame className="mr-1 h-5 w-5 text-secondary" />
              3
            </div>
            <div className="text-xs text-dark-300">{t('dashboard.dayStreak')}</div>
          </div>
        </div>

        {/* Gamification Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-blue-100">{t('dashboard.xpProgress')}</span>
              <Badge className="bg-yellow-500/20 text-yellow-400 text-xs">
                {t('dashboard.level')} 2
              </Badge>
            </div>
            <Progress value={65} className="h-2" />
            <div className="text-xs text-blue-100 mt-1">320/500 XP</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-blue-100">{t('dashboard.badges')}</span>
              <Trophy className="h-4 w-4 text-yellow-400" />
            </div>
            <div className="flex space-x-1">
              <span className="text-lg">🏃</span>
              <span className="text-lg">💧</span>
              <span className="text-lg">🥬</span>
            </div>
            <div className="text-xs text-blue-100 mt-1">3 {t('dashboard.earned')}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
            <div className="text-xl font-bold text-white">{weeklyStats.moodCheckIns || 0}/7</div>
            <div className="text-xs text-blue-100">{t('dashboard.checkIns')}</div>
          </div>
        </div>
      </div>
      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Quick Actions */}
        <div>
          <h3 className="text-lg font-semibold mb-4 text-dark-50">{t('dashboard.quickActions')}</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <Button
              onClick={() => setLocation("/scanner")}
              className="bg-dark-800 border border-dark-700 rounded-xl p-5 text-center card-hover h-auto flex-col space-y-3 hover:bg-dark-700"
              variant="ghost"
            >
              <Camera className="text-primary" size={24} />
              <div className="text-sm font-medium text-dark-50">{t('dashboard.scanFood')}</div>
            </Button>
            <Button
              onClick={() => setLocation("/mood")}
              className="bg-dark-800 border border-dark-700 rounded-xl p-5 text-center card-hover h-auto flex-col space-y-3 hover:bg-dark-700"
              variant="ghost"
            >
              <Smile className="text-secondary" size={24} />
              <div className="text-sm font-medium text-dark-50">{t('dashboard.logMood')}</div>
            </Button>
          </div>
          <div className="space-y-3">
            <Button
              onClick={() => setLocation("/healthy-recipes")}
              className="bg-gradient-to-r from-green-800 to-green-700 border border-green-600 rounded-xl p-4 text-center card-hover h-auto flex-row space-x-3 hover:from-green-700 hover:to-green-600 w-full"
              variant="ghost"
            >
              <div className="bg-green-500/20 p-2 rounded-lg">
                <span className="text-xl">🥗</span>
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-white">{t('dashboard.healthyRecipes')}</div>
                <div className="text-xs text-green-100">{t('dashboard.diabetesFriendlyMeals')}</div>
              </div>
            </Button>

            <Button
              onClick={() => setLocation("/predictive-wellness")}
              className="bg-gradient-to-r from-blue-800 to-purple-700 border border-purple-600 rounded-xl p-4 text-center card-hover h-auto flex-row space-x-3 hover:from-blue-700 hover:to-purple-600 w-full"
              variant="ghost"
            >
              <div className="bg-blue-500/20 p-2 rounded-lg">
                <span className="text-xl">🧠</span>
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-white">Smart Craving Prediction</div>
                <div className="text-xs text-blue-100">AI-powered wellness insights</div>
              </div>
            </Button>

            <Button
              onClick={() => setLocation("/crave-clock")}
              className="bg-gradient-to-r from-orange-800 to-red-700 border border-orange-600 rounded-xl p-4 text-center card-hover h-auto flex-row space-x-3 hover:from-orange-700 hover:to-red-600 w-full"
              variant="ghost"
            >
              <div className="bg-orange-500/20 p-2 rounded-lg">
                <span className="text-xl">⏰</span>
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-white">CraveClock™ Timeline</div>
                <div className="text-xs text-orange-100">Predict craving surge times</div>
              </div>
            </Button>

            <Button
              onClick={() => setLocation("/voice-soul-talk")}
              className="bg-gradient-to-r from-purple-800 to-pink-700 border border-purple-600 rounded-xl p-4 text-center card-hover h-auto flex-row space-x-3 hover:from-purple-700 hover:to-pink-600 w-full"
              variant="ghost"
            >
              <div className="bg-purple-500/20 p-2 rounded-lg">
                <span className="text-xl">🎤</span>
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-white">Voice Soul Talk</div>
                <div className="text-xs text-purple-100">Speak to your AI companion</div>
              </div>
            </Button>

            <Button
              onClick={() => setLocation("/crisis-mode")}
              className="bg-gradient-to-r from-red-800 to-orange-700 border border-red-600 rounded-xl p-4 text-center card-hover h-auto flex-row space-x-3 hover:from-red-700 hover:to-orange-600 w-full"
              variant="ghost"
            >
              <div className="bg-red-500/20 p-2 rounded-lg">
                <span className="text-xl">🚨</span>
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-white">Crisis Support</div>
                <div className="text-xs text-red-100">3-tier emergency response</div>
              </div>
            </Button>

            <Button
              onClick={() => setLocation("/knowledge-scrolls")}
              className="bg-gradient-to-r from-yellow-800 to-orange-700 border border-yellow-600 rounded-xl p-4 text-center card-hover h-auto flex-row space-x-3 hover:from-yellow-700 hover:to-orange-600 w-full"
              variant="ghost"
            >
              <div className="bg-yellow-500/20 p-2 rounded-lg">
                <span className="text-xl">📜</span>
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-white">Knowledge Scrolls</div>
                <div className="text-xs text-yellow-100">Wisdom for your healing journey</div>
              </div>
            </Button>

          </div>
        </div>

        {/* Weekly Progress */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-5 mt-6">
          <h3 className="text-lg font-semibold mb-4 text-dark-50">{t('dashboard.weeklyProgress')}</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1 text-dark-50">
                <span>{t('dashboard.sugarReduction')}</span>
                <span>{Math.round(100 - sugarProgress)}%</span>
              </div>
              <Progress value={100 - sugarProgress} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1 text-dark-50">
                <span>{t('dashboard.moodCheckIns')}</span>
                <span>{weeklyStats.moodCheckIns || 0}/7</span>
              </div>
              <Progress value={moodProgress} className="h-2" />
            </div>
          </div>
        </Card>

        {/* Sugar Intake Chart */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-5 mt-6">
          <h3 className="text-lg font-semibold mb-4 text-dark-50">{t('dashboard.sugarIntakeChart')}</h3>
          <SugarChart entries={analytics?.entries?.sugar || []} />
          <p className="text-sm text-dark-400 mt-2">
            {t('dashboard.average')}: {Math.round(weeklyStats.avgSugar || 0)}g/day ({t('dashboard.goal')}: {sugarGoal}g)
          </p>
        </Card>

        {/* Recent Meals */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">{t('dashboard.recentMeals')}</h3>
          <div className="space-y-3">
            {foodAnalyses && foodAnalyses.length > 0 ? (
              foodAnalyses.slice(0, 2).map((analysis: any) => (
                <div key={analysis.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                      <span className="text-primary font-semibold text-xs">
                        {analysis.foodName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <div className="font-medium text-dark-50">{analysis.foodName}</div>
                      <div className="text-xs text-dark-400">
                        {Math.round(analysis.sugarContent)}g sugar
                      </div>
                    </div>
                  </div>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    analysis.isHealthy === 'healthy' ? 'bg-green-500' :
                    analysis.isHealthy === 'moderate' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}>
                    <span className="text-white text-xs">✓</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-4">
                <p className="text-dark-400 text-sm">{t('dashboard.noMealsYet')}</p>
                <Button
                  onClick={() => setLocation("/scanner")}
                  className="mt-2 text-primary"
                  variant="ghost"
                  size="sm"
                >
                  {t('dashboard.startScanning')}
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* Intelligent Notifications */}
        <IntelligentNotifications
          weeklyStats={{
            totalSugar: weeklyStats.totalSugar || 0,
            avgMood: weeklyStats.avgMood || 0,
            moodCheckIns: weeklyStats.moodCheckIns || 0,
            cravingIntensity: weeklyStats.cravingIntensity || 0,
            streakDays: weeklyStats.streakDays || 0
          }}
          userTier={user?.subscriptionTier || 'silver'}
          onActionClick={(url) => setLocation(url)}
        />

        {/* Voice Food Logger */}
        <VoiceLogger 
          onFoodLogged={(food) => {
            // Automatically redirect to food scanner with the food description
            setLocation(`/scanner?voice=${encodeURIComponent(food)}`);
          }}
        />

        {/* Advanced Analytics */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
          <h3 className="text-lg font-semibold mb-3 text-dark-50 flex items-center gap-2">
            <TrendingUp className="text-primary" size={20} />
            {t('tracking.advancedAnalytics')}
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-dark-700 rounded-lg p-3">
              <div className="text-2xl font-bold text-secondary">{weeklyStats.avgMood || 'N/A'}</div>
              <div className="text-xs text-dark-400">{t('tracking.avgMoodScore')}</div>
              <div className="text-xs text-primary mt-1">
                {weeklyStats.avgMood > 3 ? `↗ ${t('dashboard.improving')}` : weeklyStats.avgMood < 3 ? `↘ ${t('dashboard.declining')}` : `→ ${t('tracking.stable')}`}
              </div>
            </div>
            <div className="bg-dark-700 rounded-lg p-3">
              <div className="text-2xl font-bold text-accent">{Math.round((weeklyStats.totalSugar || 0) / 7)}g</div>
              <div className="text-xs text-dark-400">{t('tracking.dailySugarAvg')}</div>
              <div className="text-xs text-secondary mt-1">
                {weeklyStats.totalSugar < 175 ? `✓ ${t('tracking.underTarget')}` : `⚠ ${t('tracking.overTarget')}`}
              </div>
            </div>
          </div>
          <div className="mt-3 p-3 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
            <div className="text-sm font-medium text-dark-50 mb-1">{t('tracking.healthInsights')}</div>
            <div className="text-xs text-dark-300">
              {weeklyStats.totalSugar > 175 
                ? t('tracking.reduceSugarIntake')
                : weeklyStats.moodCheckIns > 5
                ? t('tracking.greatJobTracking')
                : t('tracking.moodTrackingHelps')
              }
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
