import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Watch,
  Activity,
  Heart,
  Moon,
  Footprints,
  Zap,
  TrendingUp,
  Wifi,
  WifiOff,
  Smartphone
} from "lucide-react";

interface WearableDevice {
  id: string;
  name: string;
  type: 'smartwatch' | 'fitness_tracker' | 'smartphone';
  brand: string;
  connected: boolean;
  lastSync: string;
  batteryLevel?: number;
  supportedMetrics: string[];
}

interface HealthMetrics {
  steps: number;
  heartRate: number;
  sleepHours: number;
  calories: number;
  activeMinutes: number;
  stressLevel: number;
  timestamp: string;
}

export default function Wearables() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Mock data for demonstration
  const connectedDevices: WearableDevice[] = [
    {
      id: 'apple-watch-1',
      name: 'Apple Watch Series 9',
      type: 'smartwatch',
      brand: 'Apple',
      connected: true,
      lastSync: new Date().toISOString(),
      batteryLevel: 85,
      supportedMetrics: ['heartRate', 'steps', 'sleep', 'calories', 'stress']
    },
    {
      id: 'fitbit-1',
      name: 'Fitbit Charge 5',
      type: 'fitness_tracker',
      brand: 'Fitbit',
      connected: false,
      lastSync: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      batteryLevel: 42,
      supportedMetrics: ['steps', 'heartRate', 'sleep', 'calories']
    }
  ];

  const todayMetrics: HealthMetrics = {
    steps: 8547,
    heartRate: 72,
    sleepHours: 7.2,
    calories: 2247,
    activeMinutes: 45,
    stressLevel: 35,
    timestamp: new Date().toISOString()
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'smartwatch': return <Watch className="h-5 w-5" />;
      case 'fitness_tracker': return <Activity className="h-5 w-5" />;
      case 'smartphone': return <Smartphone className="h-5 w-5" />;
      default: return <Watch className="h-5 w-5" />;
    }
  };

  const connectDevice = (deviceId: string) => {
    toast({
      title: "Connecting device...",
      description: "Please follow the setup instructions on your device",
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to connect wearables</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            size="sm"
            className="text-dark-400 hover:text-dark-200"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <Watch className="h-8 w-8 text-primary" />
            Wearable Integration
          </h1>
          <p className="text-dark-400">Connect your devices for comprehensive health tracking</p>
        </div>

        {/* Today's Metrics */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50">Today's Health Data</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-dark-700 rounded-lg">
                <Footprints className="h-6 w-6 text-blue-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-blue-400">{todayMetrics.steps.toLocaleString()}</div>
                <div className="text-sm text-dark-400">Steps</div>
              </div>
              <div className="text-center p-4 bg-dark-700 rounded-lg">
                <Heart className="h-6 w-6 text-red-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-red-400">{todayMetrics.heartRate}</div>
                <div className="text-sm text-dark-400">BPM</div>
              </div>
              <div className="text-center p-4 bg-dark-700 rounded-lg">
                <Moon className="h-6 w-6 text-purple-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-purple-400">{todayMetrics.sleepHours}h</div>
                <div className="text-sm text-dark-400">Sleep</div>
              </div>
              <div className="text-center p-4 bg-dark-700 rounded-lg">
                <Zap className="h-6 w-6 text-orange-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-orange-400">{todayMetrics.calories}</div>
                <div className="text-sm text-dark-400">Calories</div>
              </div>
              <div className="text-center p-4 bg-dark-700 rounded-lg">
                <Activity className="h-6 w-6 text-green-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-green-400">{todayMetrics.activeMinutes}</div>
                <div className="text-sm text-dark-400">Active Min</div>
              </div>
              <div className="text-center p-4 bg-dark-700 rounded-lg">
                <TrendingUp className="h-6 w-6 text-yellow-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-yellow-400">{todayMetrics.stressLevel}%</div>
                <div className="text-sm text-dark-400">Stress Level</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Connected Devices */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50">Connected Devices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {connectedDevices.map((device) => (
                <div key={device.id} className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${device.connected ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                      {getDeviceIcon(device.type)}
                    </div>
                    <div>
                      <h4 className="font-medium text-dark-50">{device.name}</h4>
                      <p className="text-dark-400 text-sm">{device.brand}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {device.connected ? (
                      <Badge className="bg-green-500/20 text-green-400">
                        <Wifi className="h-3 w-3 mr-1" />
                        Connected
                      </Badge>
                    ) : (
                      <Badge className="bg-gray-500/20 text-gray-400">
                        <WifiOff className="h-3 w-3 mr-1" />
                        Disconnected
                      </Badge>
                    )}
                    {device.batteryLevel && (
                      <div className="text-sm text-dark-400">
                        {device.batteryLevel}% battery
                      </div>
                    )}
                    <Button
                      onClick={() => connectDevice(device.id)}
                      variant={device.connected ? "outline" : "default"}
                      size="sm"
                      className={device.connected ? "border-dark-600" : "bg-primary hover:bg-primary/80"}
                    >
                      {device.connected ? 'Sync' : 'Connect'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Health Correlations */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50">Health Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-blue-500/10 to-green-500/10 rounded-lg border border-blue-500/20">
                <h4 className="font-medium text-dark-50 mb-2">Sleep & Sugar Correlation</h4>
                <p className="text-dark-300 text-sm">
                  Your 7.2 hours of sleep correlates with 15% lower sugar cravings compared to days with less than 6 hours.
                </p>
              </div>
              <div className="p-4 bg-gradient-to-r from-red-500/10 to-orange-500/10 rounded-lg border border-red-500/20">
                <h4 className="font-medium text-dark-50 mb-2">Activity & Mood</h4>
                <p className="text-dark-300 text-sm">
                  45+ active minutes consistently improve your mood scores by an average of 1.8 points.
                </p>
              </div>
              <div className="p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-lg border border-purple-500/20">
                <h4 className="font-medium text-dark-50 mb-2">Heart Rate Variability</h4>
                <p className="text-dark-300 text-sm">
                  Lower stress levels (below 40%) align with better food choice patterns and reduced impulse eating.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Setup Instructions */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50">Setup New Device</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-dark-400 text-sm">
                To connect a new wearable device:
              </div>
              <ol className="list-decimal list-inside space-y-2 text-dark-300 text-sm">
                <li>Ensure your device is charged and nearby</li>
                <li>Open your device's companion app</li>
                <li>Enable health data sharing</li>
                <li>Grant SOULFUEL permission to access health data</li>
                <li>Click "Connect" to sync your data</li>
              </ol>
              <div className="text-xs text-dark-400 mt-4">
                Supported devices: Apple Watch, Fitbit, Garmin, Samsung Galaxy Watch, Google Pixel Watch, and most fitness trackers.
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}