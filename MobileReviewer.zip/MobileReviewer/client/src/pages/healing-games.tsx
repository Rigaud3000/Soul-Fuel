import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  RotateCcw, 
  Star, 
  Heart,
  Zap,
  TreePine,
  Flower,
  Sword,
  Shield,
  Palette
} from "lucide-react";
import { useLocation } from "wouter";

export default function HealingGames() {
  const [, setLocation] = useLocation();
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [gameProgress, setGameProgress] = useState({
    cravingSudoku: 0,
    soulMatch: 0,
    breatheBuild: 0,
    demonWarrior: 0,
    colorReset: 0
  });
  const { toast } = useToast();

  const games = [
    {
      id: "cravingSudoku",
      title: "Craving Slayer Sudoku",
      description: "Classic sudoku with calming music and brain-rewiring progression",
      icon: <Star className="text-yellow-400" size={24} />,
      color: "from-yellow-600/20 to-yellow-500/10",
      borderColor: "border-yellow-500/30"
    },
    {
      id: "soulMatch",
      title: "SoulMatch",
      description: "Memory match with affirmations and mindful rewards",
      icon: <Heart className="text-pink-400" size={24} />,
      color: "from-pink-600/20 to-pink-500/10",
      borderColor: "border-pink-500/30"
    },
    {
      id: "breatheBuild",
      title: "Breathe & Build",
      description: "Box breathing that grows a beautiful garden visualization",
      icon: <TreePine className="text-green-400" size={24} />,
      color: "from-green-600/20 to-green-500/10",
      borderColor: "border-green-500/30"
    },
    {
      id: "demonWarrior",
      title: "Sugar Demon vs Soul Warrior",
      description: "Tap-to-defeat impulse monsters with light of discipline",
      icon: <Sword className="text-red-400" size={24} />,
      color: "from-red-600/20 to-red-500/10",
      borderColor: "border-red-500/30"
    },
    {
      id: "colorReset",
      title: "Color Reset Puzzle",
      description: "Mindful match-3 with calming palettes for visual reset",
      icon: <Palette className="text-purple-400" size={24} />,
      color: "from-purple-600/20 to-purple-500/10",
      borderColor: "border-purple-500/30"
    }
  ];

  const handleGameComplete = (gameId: string, score: number) => {
    setGameProgress(prev => ({
      ...prev,
      [gameId]: prev[gameId as keyof typeof prev] + score
    }));
    
    // Store progress locally for now
    localStorage.setItem('healingGamesProgress', JSON.stringify({
      ...gameProgress,
      [gameId]: gameProgress[gameId as keyof typeof gameProgress] + score
    }));
    
    toast({
      title: "Brain Rewiring Complete! 🧠✨",
      description: `+${score} neural pathway points earned`,
    });
  };

  // Load progress from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('healingGamesProgress');
    if (saved) {
      try {
        setGameProgress(JSON.parse(saved));
      } catch (e) {
        console.log('Failed to load saved progress');
      }
    }
  }, []);

  if (activeGame) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-dark-900 to-dark-800 p-4">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Button
              onClick={() => setActiveGame(null)}
              variant="ghost"
              size="sm"
              className="text-gray-400 hover:text-white"
            >
              <ArrowLeft size={20} />
            </Button>
            <h1 className="text-xl font-bold text-white">
              {games.find(g => g.id === activeGame)?.title}
            </h1>
          </div>

          {activeGame === "cravingSudoku" && (
            <CravingSudoku onComplete={(score) => handleGameComplete("cravingSudoku", score)} />
          )}
          {activeGame === "soulMatch" && (
            <SoulMatch onComplete={(score) => handleGameComplete("soulMatch", score)} />
          )}
          {activeGame === "breatheBuild" && (
            <BreatheBuild onComplete={(score) => handleGameComplete("breatheBuild", score)} />
          )}
          {activeGame === "demonWarrior" && (
            <DemonWarrior onComplete={(score) => handleGameComplete("demonWarrior", score)} />
          )}
          {activeGame === "colorReset" && (
            <ColorReset onComplete={(score) => handleGameComplete("colorReset", score)} />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-dark-900 to-dark-800 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Button
            onClick={() => setLocation("/tracking")}
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white"
          >
            <ArrowLeft size={20} />
          </Button>
          <h1 className="text-2xl font-bold text-white">Healing Games</h1>
        </div>

        <Card className="bg-dark-800/50 border border-emerald-500/20 mb-6">
          <CardContent className="p-4">
            <div className="text-center">
              <Zap className="text-emerald-400 mx-auto mb-2" size={32} />
              <h3 className="text-white font-semibold mb-1">Brain Rewiring Progress</h3>
              <p className="text-gray-400 text-sm mb-3">
                Train your brain to rise above cravings through therapeutic gameplay
              </p>
              <div className="space-y-2">
                {Object.entries(gameProgress).map(([gameId, progress]) => {
                  const game = games.find(g => g.id === gameId);
                  return (
                    <div key={gameId} className="flex items-center gap-3">
                      <span className="text-sm text-gray-300 flex-1 text-left">
                        {game?.title}
                      </span>
                      <Badge variant="secondary" className="bg-emerald-900/30 text-emerald-300">
                        {progress} pts
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {games.map((game) => (
            <Card
              key={game.id}
              className={`bg-gradient-to-r ${game.color} border ${game.borderColor} hover:scale-105 transition-transform cursor-pointer`}
              onClick={() => setActiveGame(game.id)}
            >
              <CardContent className="p-4 bg-[#1c9c36d9]">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-dark-900/30 rounded-lg">
                    {game.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-semibold mb-1">{game.title}</h3>
                    <p className="text-gray-300 text-sm">{game.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="secondary" className="bg-dark-900/30 text-gray-300">
                        {gameProgress[game.id as keyof typeof gameProgress]} points
                      </Badge>
                    </div>
                  </div>
                  <Play className="text-white" size={20} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

// Individual Game Components
function CravingSudoku({ onComplete }: { onComplete: (score: number) => void }) {
  const [grid, setGrid] = useState<number[][]>(() => 
    Array(9).fill(null).map(() => Array(9).fill(0))
  );
  const [selectedCell, setSelectedCell] = useState<{row: number, col: number} | null>(null);
  const [completedNumbers, setCompletedNumbers] = useState(0);

  const samplePuzzle = [
    [5, 3, 0, 0, 7, 0, 0, 0, 0],
    [6, 0, 0, 1, 9, 5, 0, 0, 0],
    [0, 9, 8, 0, 0, 0, 0, 6, 0],
    [8, 0, 0, 0, 6, 0, 0, 0, 3],
    [4, 0, 0, 8, 0, 3, 0, 0, 1],
    [7, 0, 0, 0, 2, 0, 0, 0, 6],
    [0, 6, 0, 0, 0, 0, 2, 8, 0],
    [0, 0, 0, 4, 1, 9, 0, 0, 5],
    [0, 0, 0, 0, 8, 0, 0, 7, 9]
  ];

  useEffect(() => {
    setGrid(samplePuzzle);
  }, []);

  const handleCellClick = (row: number, col: number) => {
    if (samplePuzzle[row][col] === 0) {
      setSelectedCell({ row, col });
    }
  };

  const handleNumberInput = (num: number) => {
    if (selectedCell) {
      const newGrid = [...grid];
      newGrid[selectedCell.row][selectedCell.col] = num;
      setGrid(newGrid);
      
      setCompletedNumbers(prev => prev + 1);
      
      if (completedNumbers > 10) {
        onComplete(50);
      }
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-dark-800/50 border border-yellow-500/20">
        <CardHeader>
          <CardTitle className="text-white text-center">Brain Rewiring Sudoku</CardTitle>
          <p className="text-gray-400 text-center text-sm">
            Focus your mind, rewire neural pathways
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-9 gap-1 mb-4">
            {grid.map((row, rowIndex) =>
              row.map((cell, colIndex) => (
                <button
                  key={`${rowIndex}-${colIndex}`}
                  onClick={() => handleCellClick(rowIndex, colIndex)}
                  className={`
                    w-8 h-8 text-sm font-semibold rounded
                    ${samplePuzzle[rowIndex][colIndex] !== 0 
                      ? 'bg-yellow-600/30 text-yellow-200 cursor-not-allowed' 
                      : 'bg-dark-700 text-white hover:bg-dark-600'
                    }
                    ${selectedCell?.row === rowIndex && selectedCell?.col === colIndex 
                      ? 'ring-2 ring-yellow-400' 
                      : ''
                    }
                  `}
                >
                  {cell || ''}
                </button>
              ))
            )}
          </div>
          
          <div className="grid grid-cols-5 gap-2">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
              <Button
                key={num}
                onClick={() => handleNumberInput(num)}
                className="bg-yellow-600/20 hover:bg-yellow-600/30 text-yellow-200"
                size="sm"
              >
                {num}
              </Button>
            ))}
          </div>
          
          <Progress value={completedNumbers * 2} className="mt-4" />
          <p className="text-center text-gray-400 text-sm mt-2">
            Neural pathways strengthening: {completedNumbers}/45
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function SoulMatch({ onComplete }: { onComplete: (score: number) => void }) {
  const affirmations = [
    "Gratitude", "Growth", "Strength", "Peace", "Wisdom", "Love",
    "Courage", "Hope", "Joy", "Freedom", "Balance", "Trust"
  ];
  
  const [cards, setCards] = useState<{text: string, isFlipped: boolean, isMatched: boolean}[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matches, setMatches] = useState(0);

  useEffect(() => {
    const shuffledAffirmations = [...affirmations, ...affirmations]
      .sort(() => Math.random() - 0.5)
      .map(text => ({ text, isFlipped: false, isMatched: false }));
    setCards(shuffledAffirmations);
  }, []);

  const handleCardClick = (index: number) => {
    if (cards[index].isFlipped || cards[index].isMatched || flippedCards.length === 2) return;

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);
    
    const newFlipped = [...flippedCards, index];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setTimeout(() => {
        const [first, second] = newFlipped;
        if (cards[first].text === cards[second].text) {
          newCards[first].isMatched = true;
          newCards[second].isMatched = true;
          setMatches(prev => prev + 1);
          
          if (matches >= 5) {
            onComplete(30);
          }
        } else {
          newCards[first].isFlipped = false;
          newCards[second].isFlipped = false;
        }
        setCards([...newCards]);
        setFlippedCards([]);
      }, 1000);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-dark-800/50 border border-pink-500/20">
        <CardHeader>
          <CardTitle className="text-white text-center">SoulMatch</CardTitle>
          <p className="text-gray-400 text-center text-sm">
            Match affirmations to strengthen your soul energy
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-2 mb-4">
            {cards.map((card, index) => (
              <button
                key={index}
                onClick={() => handleCardClick(index)}
                className={`
                  h-16 rounded-lg text-xs font-semibold transition-all
                  ${card.isFlipped || card.isMatched
                    ? 'bg-pink-600/30 text-pink-200'
                    : 'bg-dark-700 text-gray-500 hover:bg-dark-600'
                  }
                  ${card.isMatched ? 'ring-2 ring-pink-400' : ''}
                `}
              >
                {card.isFlipped || card.isMatched ? card.text : '?'}
              </button>
            ))}
          </div>
          
          <div className="text-center">
            <Badge className="bg-pink-900/30 text-pink-300">
              Matches: {matches}/12
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function BreatheBuild({ onComplete }: { onComplete: (score: number) => void }) {
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'hold1' | 'exhale' | 'hold2'>('inhale');
  const [breathCount, setBreathCount] = useState(0);
  const [gardenGrowth, setGardenGrowth] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout>();

  const breathCycle = {
    inhale: { duration: 4000, next: 'hold1' as const },
    hold1: { duration: 4000, next: 'exhale' as const },
    exhale: { duration: 4000, next: 'hold2' as const },
    hold2: { duration: 4000, next: 'inhale' as const }
  };

  const startBreathing = () => {
    setIsActive(true);
    runBreathCycle();
  };

  const stopBreathing = () => {
    setIsActive(false);
    if (intervalRef.current) {
      clearTimeout(intervalRef.current);
    }
  };

  const runBreathCycle = () => {
    const currentPhase = breathPhase;
    const { duration, next } = breathCycle[currentPhase];
    
    intervalRef.current = setTimeout(() => {
      setBreathPhase(next);
      setBreathCount(prev => {
        const newCount = prev + 1;
        if (newCount % 4 === 0) {
          setGardenGrowth(prev => Math.min(prev + 10, 100));
          if (newCount >= 20) {
            onComplete(40);
          }
        }
        return newCount;
      });
      
      if (isActive) {
        runBreathCycle();
      }
    }, duration);
  };

  const getPhaseText = () => {
    switch (breathPhase) {
      case 'inhale': return 'Breathe In...';
      case 'hold1': return 'Hold...';
      case 'exhale': return 'Breathe Out...';
      case 'hold2': return 'Hold...';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-dark-800/50 border border-green-500/20">
        <CardHeader>
          <CardTitle className="text-white text-center">Breathe & Build</CardTitle>
          <p className="text-gray-400 text-center text-sm">
            Grow your inner garden through mindful breathing
          </p>
        </CardHeader>
        <CardContent className="text-center">
          <div className="relative mb-6">
            <div className={`
              w-32 h-32 mx-auto rounded-full transition-all duration-4000 ease-in-out
              ${breathPhase === 'inhale' ? 'scale-125 bg-green-400/30' : 'scale-100 bg-green-600/20'}
            `}>
              <div className="flex items-center justify-center h-full">
                <TreePine 
                  className="text-green-400" 
                  size={gardenGrowth > 50 ? 64 : 48} 
                />
              </div>
            </div>
          </div>
          
          <h3 className="text-xl text-white mb-2">{getPhaseText()}</h3>
          
          <div className="space-y-4">
            <Button
              onClick={isActive ? stopBreathing : startBreathing}
              className="bg-green-600/20 hover:bg-green-600/30 text-green-200"
            >
              {isActive ? <Pause size={20} /> : <Play size={20} />}
              {isActive ? 'Pause' : 'Start'}
            </Button>
            
            <div className="space-y-2">
              <Progress value={gardenGrowth} className="h-2" />
              <p className="text-green-300 text-sm">Garden Growth: {gardenGrowth}%</p>
              <p className="text-gray-400 text-sm">Breath Count: {Math.floor(breathCount / 4)}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DemonWarrior({ onComplete }: { onComplete: (score: number) => void }) {
  const [demons, setDemons] = useState<{id: number, x: number, y: number, hp: number}[]>([]);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const spawnDemon = () => {
    const newDemon = {
      id: Date.now(),
      x: Math.random() * 80 + 10,
      y: Math.random() * 60 + 20,
      hp: 3
    };
    setDemons(prev => [...prev, newDemon]);
  };

  const attackDemon = (demonId: number) => {
    setDemons(prev => prev.map(demon => 
      demon.id === demonId 
        ? { ...demon, hp: demon.hp - 1 }
        : demon
    ).filter(demon => {
      if (demon.hp <= 1) {
        setScore(prevScore => {
          const newScore = prevScore + 10;
          if (newScore >= 100) {
            onComplete(60);
          }
          return newScore;
        });
        return false;
      }
      return true;
    }));
  };

  useEffect(() => {
    if (!isPlaying) return;
    
    const spawnInterval = setInterval(spawnDemon, 2000);
    return () => clearInterval(spawnInterval);
  }, [isPlaying]);

  return (
    <div className="space-y-6">
      <Card className="bg-dark-800/50 border border-red-500/20">
        <CardHeader>
          <CardTitle className="text-white text-center">Sugar Demon vs Soul Warrior</CardTitle>
          <p className="text-gray-400 text-center text-sm">
            Defeat impulse demons with your light of discipline
          </p>
        </CardHeader>
        <CardContent>
          <div className="relative h-64 bg-dark-900/30 rounded-lg mb-4 overflow-hidden">
            {demons.map(demon => (
              <button
                key={demon.id}
                onClick={() => attackDemon(demon.id)}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 animate-pulse"
                style={{ left: `${demon.x}%`, top: `${demon.y}%` }}
              >
                <div className="relative">
                  <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-500 transition-colors">
                    <span className="text-white text-lg">👹</span>
                  </div>
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                    <div className="flex gap-1">
                      {Array(demon.hp).fill(0).map((_, i) => (
                        <Heart key={i} className="text-red-400" size={8} />
                      ))}
                    </div>
                  </div>
                </div>
              </button>
            ))}
            
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
              <div className="w-16 h-16 bg-gradient-to-t from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <Sword className="text-white" size={24} />
              </div>
            </div>
          </div>
          
          <div className="flex justify-between items-center mb-4">
            <Badge className="bg-red-900/30 text-red-300">
              Score: {score}
            </Badge>
            <Button
              onClick={() => setIsPlaying(!isPlaying)}
              className="bg-red-600/20 hover:bg-red-600/30 text-red-200"
            >
              {isPlaying ? 'Stop' : 'Start Battle'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ColorReset({ onComplete }: { onComplete: (score: number) => void }) {
  const colors = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899'];
  const [grid, setGrid] = useState<string[][]>(() => 
    Array(8).fill(null).map(() => 
      Array(8).fill(null).map(() => colors[Math.floor(Math.random() * colors.length)])
    )
  );
  const [selectedCells, setSelectedCells] = useState<{row: number, col: number}[]>([]);
  const [matches, setMatches] = useState(0);

  const handleCellClick = (row: number, col: number) => {
    const isSelected = selectedCells.some(cell => cell.row === row && cell.col === col);
    
    if (isSelected) {
      setSelectedCells(prev => prev.filter(cell => !(cell.row === row && cell.col === col)));
    } else if (selectedCells.length < 3) {
      setSelectedCells(prev => [...prev, { row, col }]);
    }
  };

  const checkMatch = () => {
    if (selectedCells.length === 3) {
      const colors = selectedCells.map(cell => grid[cell.row][cell.col]);
      if (colors.every(color => color === colors[0])) {
        // Remove matched cells
        const newGrid = [...grid];
        selectedCells.forEach(cell => {
          newGrid[cell.row][cell.col] = colors[Math.floor(Math.random() * colors.length)];
        });
        setGrid(newGrid);
        setMatches(prev => {
          const newMatches = prev + 1;
          if (newMatches >= 10) {
            onComplete(45);
          }
          return newMatches;
        });
      }
      setSelectedCells([]);
    }
  };

  useEffect(() => {
    checkMatch();
  }, [selectedCells]);

  return (
    <div className="space-y-6">
      <Card className="bg-dark-800/50 border border-purple-500/20">
        <CardHeader>
          <CardTitle className="text-white text-center">Color Reset Puzzle</CardTitle>
          <p className="text-gray-400 text-center text-sm">
            Match 3 colors to reset visual overstimulation
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-8 gap-1 mb-4">
            {grid.map((row, rowIndex) =>
              row.map((cellColor, colIndex) => {
                const isSelected = selectedCells.some(cell => 
                  cell.row === rowIndex && cell.col === colIndex
                );
                return (
                  <button
                    key={`${rowIndex}-${colIndex}`}
                    onClick={() => handleCellClick(rowIndex, colIndex)}
                    className={`
                      w-8 h-8 rounded-lg transition-all
                      ${isSelected ? 'ring-2 ring-white scale-110' : ''}
                    `}
                    style={{ backgroundColor: cellColor }}
                  />
                );
              })
            )}
          </div>
          
          <div className="text-center space-y-2">
            <Badge className="bg-purple-900/30 text-purple-300">
              Matches: {matches}
            </Badge>
            <p className="text-gray-400 text-sm">
              Selected: {selectedCells.length}/3
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}