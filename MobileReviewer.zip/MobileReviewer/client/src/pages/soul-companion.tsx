import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { 
  Heart, 
  Send, 
  Sparkles, 
  Sunrise, 
  Moon, 
  Gamepad2,
  Mic,
  MicOff,
  Activity,
  Lightbulb,
  MessageCircle,
  Target,
  Brain
} from "lucide-react";

interface SoulMessage {
  id: string;
  type: 'user' | 'soul' | 'affirmation' | 'suggestion';
  content: string;
  timestamp: Date;
  emotionalState?: {
    mood: string;
    intensity: number;
  };
  responseType?: string;
  suggestedActions?: string[];
  journalPrompt?: string;
  breathingExercise?: string;
}

export default function SoulCompanion() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<SoulMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showJournal, setShowJournal] = useState(false);
  const [journalEntry, setJournalEntry] = useState("");
  const [aiStatus, setAiStatus] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    checkAIStatus();
    loadGreeting();
  }, []);

  const checkAIStatus = async () => {
    try {
      const response = await fetch("/api/ai-coaching-status", {
        headers: { "X-Firebase-UID": user?.firebaseUid || "" }
      });
      const status = await response.json();
      setAiStatus(status);
    } catch (error) {
      console.error("Failed to check AI status:", error);
    }
  };

  const loadGreeting = () => {
    const hour = new Date().getHours();
    let greeting = "";
    let timeOfDay = "";

    if (hour >= 5 && hour < 12) {
      greeting = "Good morning, soul warrior 🌞. Before the world pulls at you, I'm here for you. How's your soul feeling today?";
      timeOfDay = "morning";
    } else if (hour >= 12 && hour < 17) {
      greeting = "Hello, beautiful soul. How are you navigating this part of your day? I'm here to listen and support you.";
      timeOfDay = "afternoon";
    } else if (hour >= 17 && hour < 21) {
      greeting = "Good evening. As the day winds down, how is your heart feeling? Let's check in together.";
      timeOfDay = "evening";
    } else {
      greeting = "Welcome back. You made it through another day — and that matters. Let's slow the soul and find some peace together.";
      timeOfDay = "night";
    }

    setMessages([{
      id: Date.now().toString(),
      type: 'soul',
      content: greeting,
      timestamp: new Date(),
      responseType: timeOfDay
    }]);
  };

  const handleSoulCheckIn = async (message: string, timeOfDay?: string) => {
    if (!message.trim()) return;

    // Check AI session limits
    if (aiStatus && !aiStatus.canUseAI) {
      toast({
        title: "Weekly Service Limit Reached",
        description: `You've used all 4 free services this week. Upgrade to Pro for unlimited access.`,
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    // Add user message
    const userMessage: SoulMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: message,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage("");

    try {
      const response = await fetch("/api/soul-checkin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Firebase-UID": user?.firebaseUid || ""
        },
        body: JSON.stringify({ message, timeOfDay })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Soul companion unavailable");
      }

      const soulResponse = await response.json();

      // Add soul response
      const soulMessage: SoulMessage = {
        id: (Date.now() + 1).toString(),
        type: 'soul',
        content: soulResponse.response,
        timestamp: new Date(),
        emotionalState: soulResponse.emotionalState,
        responseType: soulResponse.responseType,
        suggestedActions: soulResponse.suggestedActions,
        journalPrompt: soulResponse.journalPrompt,
        breathingExercise: soulResponse.breathingExercise
      };
      setMessages(prev => [...prev, soulMessage]);

      // Add affirmation if provided
      if (soulResponse.dailyAffirmation) {
        const affirmationMessage: SoulMessage = {
          id: (Date.now() + 2).toString(),
          type: 'affirmation',
          content: soulResponse.dailyAffirmation,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, affirmationMessage]);
      }

      // Add suggested actions
      if (soulResponse.suggestedActions && soulResponse.suggestedActions.length > 0) {
        const suggestionMessage: SoulMessage = {
          id: (Date.now() + 3).toString(),
          type: 'suggestion',
          content: "Here are some soul-nurturing actions you might try:",
          timestamp: new Date(),
          suggestedActions: soulResponse.suggestedActions
        };
        setMessages(prev => [...prev, suggestionMessage]);
      }

      // Update AI status
      await checkAIStatus();

    } catch (error: any) {
      console.error("Soul check-in error:", error);
      toast({
        title: "Connection Issue",
        description: error.message || "Unable to connect with your soul companion right now.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const startVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      toast({
        title: "Voice Not Supported",
        description: "Voice input is not supported in this browser.",
        variant: "destructive"
      });
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setCurrentMessage(transcript);
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
      toast({
        title: "Voice Recognition Error",
        description: "Could not process voice input. Please try again.",
        variant: "destructive"
      });
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const handleQuickAction = (action: string) => {
    const quickResponses = {
      "tired": "I'm feeling really tired today",
      "hopeful": "I'm feeling hopeful and positive",
      "struggling": "I'm struggling with cravings right now",
      "grateful": "I'm feeling grateful today",
      "anxious": "I'm feeling anxious and overwhelmed",
      "strong": "I'm feeling strong and empowered"
    };

    const message = quickResponses[action as keyof typeof quickResponses];
    if (message) {
      handleSoulCheckIn(message);
    }
  };

  const openJournal = (prompt?: string) => {
    setJournalEntry(prompt || "");
    setShowJournal(true);
  };

  const saveJournalEntry = () => {
    // Journal entry would be saved to database
    toast({
      title: "Journal Saved",
      description: "Your soul reflection has been saved to your private journal.",
    });
    setShowJournal(false);
    setJournalEntry("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Sparkles className="text-white" size={24} />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Soul Companion
            </h1>
          </div>
          <p className="text-dark-300">Your empathetic AI guide for emotional wellness and soul growth</p>
          
          {aiStatus && (
            <div className="mt-3">
              {aiStatus.subscriptionTier === 'free' ? (
                <Badge variant="outline" className="text-accent">
                  {aiStatus.sessionsRemaining} free sessions remaining
                </Badge>
              ) : (
                <Badge className="bg-primary text-white">Unlimited Access</Badge>
              )}
            </div>
          )}
        </div>

        {/* Quick Mood Check-ins */}
        <Card className="bg-dark-800 border-dark-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Heart className="text-primary" size={20} />
              Quick Soul Check-in
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {[
                { key: "tired", label: "Tired", icon: Moon },
                { key: "hopeful", label: "Hopeful", icon: Sunrise },
                { key: "struggling", label: "Struggling", icon: Target },
                { key: "grateful", label: "Grateful", icon: Heart },
                { key: "anxious", label: "Anxious", icon: Activity },
                { key: "strong", label: "Strong", icon: Brain }
              ].map(({ key, label, icon: Icon }) => (
                <Button
                  key={key}
                  onClick={() => handleQuickAction(key)}
                  variant="outline"
                  className="border-dark-600 hover:border-primary text-white h-auto p-3 flex-col gap-1"
                >
                  <Icon size={20} className="text-primary" />
                  <span className="text-xs">{label}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Chat Interface */}
        <Card className="bg-dark-800 border-dark-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <MessageCircle className="text-primary" size={20} />
              Soul Conversation
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-96 p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.type === 'user'
                          ? 'bg-primary text-white'
                          : message.type === 'affirmation'
                          ? 'bg-gradient-to-r from-accent/20 to-secondary/20 border border-accent/30 text-accent'
                          : message.type === 'suggestion'
                          ? 'bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/30 text-primary'
                          : 'bg-dark-700 text-white'
                      }`}
                    >
                      <p className="text-sm leading-relaxed whitespace-pre-line">
                        {message.content}
                      </p>
                      
                      {message.suggestedActions && (
                        <div className="mt-3 space-y-2">
                          {message.suggestedActions.map((action, index) => (
                            <Button
                              key={index}
                              size="sm"
                              variant="outline"
                              className="w-full text-left justify-start border-primary/30 text-primary hover:bg-primary/10"
                              onClick={() => {
                                if (action.includes('Journal')) openJournal(message.journalPrompt);
                                if (action.includes('game')) window.location.href = '/emergency';
                                if (action.includes('breathing')) window.location.href = '/emergency';
                              }}
                            >
                              <Lightbulb size={14} className="mr-2" />
                              {action}
                            </Button>
                          ))}
                        </div>
                      )}
                      
                      {message.emotionalState && (
                        <div className="mt-2 text-xs opacity-75">
                          Mood: {message.emotionalState.mood} (intensity: {message.emotionalState.intensity}/10)
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-dark-700 text-white rounded-lg p-3 max-w-[80%]">
                      <div className="flex items-center gap-2">
                        <div className="animate-pulse">Soul companion is thinking...</div>
                        <div className="flex space-x-1">
                          <div className="w-1 h-1 bg-primary rounded-full animate-bounce"></div>
                          <div className="w-1 h-1 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-1 h-1 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div ref={messagesEndRef} />
            </ScrollArea>
            
            {/* Message Input */}
            <div className="p-4 border-t border-dark-700">
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <Input
                    value={currentMessage}
                    onChange={(e) => setCurrentMessage(e.target.value)}
                    placeholder="Share what's in your heart..."
                    className="bg-dark-700 border-dark-600 text-white pr-10"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSoulCheckIn(currentMessage);
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    className={`absolute right-1 top-1 h-8 w-8 p-0 ${isListening ? 'text-red-400' : 'text-dark-400'}`}
                    onClick={startVoiceInput}
                    disabled={isListening}
                  >
                    {isListening ? <MicOff size={16} /> : <Mic size={16} />}
                  </Button>
                </div>
                <Button
                  onClick={() => handleSoulCheckIn(currentMessage)}
                  disabled={!currentMessage.trim() || isLoading}
                  className="bg-primary hover:bg-primary/90"
                >
                  <Send size={16} />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Soul Journal Modal */}
        {showJournal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 w-full max-w-md">
              <CardHeader>
                <CardTitle className="text-white">Soul Journal</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={journalEntry}
                  onChange={(e) => setJournalEntry(e.target.value)}
                  placeholder="What's in your heart right now?"
                  className="bg-dark-700 border-dark-600 text-white min-h-32"
                />
                <div className="flex gap-2">
                  <Button onClick={saveJournalEntry} className="flex-1 bg-primary">
                    Save Entry
                  </Button>
                  <Button onClick={() => setShowJournal(false)} variant="outline" className="border-dark-600">
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}