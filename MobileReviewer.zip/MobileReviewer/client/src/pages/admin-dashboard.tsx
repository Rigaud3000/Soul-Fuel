import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Users, 
  Download, 
  Shield, 
  AlertCircle, 
  CheckCircle,
  Search,
  FileText,
  Clock,
  Database,
  ExternalLink
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";

interface CustomerExportResult {
  success: boolean;
  exportId: string;
  downloadUrl: string;
  totalDataPoints: number;
  categories: string[];
  generatedAt: string;
}

export default function AdminDashboard() {
  const [userId, setUserId] = useState('');
  const [requestedBy, setRequestedBy] = useState('');
  const [exportResult, setExportResult] = useState<CustomerExportResult | null>(null);
  const { toast } = useToast();

  // Customer data export mutation
  const exportMutation = useMutation({
    mutationFn: async ({ userId, requestedBy }: { userId: string; requestedBy: string }) => {
      const response = await fetch('/api/admin/export-customer-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: parseInt(userId),
          requestedBy
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Export failed');
      }
      
      return response.json();
    },
    onSuccess: (data: CustomerExportResult) => {
      setExportResult(data);
      toast({
        title: "Customer Data Export Complete",
        description: `Generated export for User ID ${userId} with ${data.totalDataPoints} data points`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Export Failed",
        description: error.message || "Failed to export customer data",
        variant: "destructive",
      });
    }
  });

  const handleExport = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userId.trim() || !requestedBy.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide both User ID and your email address",
        variant: "destructive",
      });
      return;
    }

    exportMutation.mutate({ userId: userId.trim(), requestedBy: requestedBy.trim() });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-blue-500 rounded-lg">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-800">Admin Dashboard</h1>
          </div>
          <p className="text-lg text-slate-600">
            Customer service data export and user management tools
          </p>
        </div>

        {/* Security Warning */}
        <Alert className="border-orange-200 bg-orange-50">
          <AlertCircle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800">
            <strong>Admin Access:</strong> This dashboard provides access to customer data. 
            Only use for legitimate customer service requests. All exports are logged for audit purposes.
          </AlertDescription>
        </Alert>

        {/* Customer Data Export */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="w-5 h-5 mr-2" />
              Customer Data Export
            </CardTitle>
            <CardDescription>
              Generate a comprehensive data export for customer service purposes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleExport} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="userId">Customer User ID</Label>
                  <Input
                    id="userId"
                    type="number"
                    placeholder="e.g. 12345"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    className="w-full"
                  />
                  <p className="text-xs text-slate-500">
                    The numeric user ID from the customer's account
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="requestedBy">Requested By (Your Email)</Label>
                  <Input
                    id="requestedBy"
                    type="email"
                    placeholder="support@soulfuel.com"
                    value={requestedBy}
                    onChange={(e) => setRequestedBy(e.target.value)}
                    className="w-full"
                  />
                  <p className="text-xs text-slate-500">
                    Your email address for audit trail purposes
                  </p>
                </div>
              </div>

              <Button 
                type="submit" 
                disabled={exportMutation.isPending}
                className="w-full bg-blue-500 hover:bg-blue-600"
              >
                {exportMutation.isPending ? (
                  <>
                    <div className="animate-spin w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                    Generating Export...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Export Customer Data
                  </>
                )}
              </Button>
            </form>

            {/* Export Result */}
            {exportResult && (
              <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div className="flex-1 space-y-3">
                    <div>
                      <p className="font-medium text-green-800">Export Generated Successfully</p>
                      <p className="text-sm text-green-700">
                        Customer data export completed with {exportResult.totalDataPoints.toLocaleString()} data points
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium text-green-800">Export ID:</span>
                        <p className="text-green-700 font-mono">{exportResult.exportId}</p>
                      </div>
                      <div>
                        <span className="font-medium text-green-800">Generated:</span>
                        <p className="text-green-700">{new Date(exportResult.generatedAt).toLocaleString()}</p>
                      </div>
                    </div>

                    <div>
                      <span className="font-medium text-green-800">Data Categories:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {exportResult.categories.map((category) => (
                          <Badge key={category} variant="outline" className="text-xs border-green-300 text-green-700">
                            {category}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      asChild
                      className="w-full border-green-300 text-green-700 hover:bg-green-100"
                    >
                      <a 
                        href={exportResult.downloadUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center justify-center"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Open Customer Data Export
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Search className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-800">User Lookup</p>
                  <p className="text-sm text-slate-500">Search user by ID or email</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <FileText className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-800">Export Logs</p>
                  <p className="text-sm text-slate-500">View all data exports</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Database className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-800">System Health</p>
                  <p className="text-sm text-slate-500">Monitor platform status</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Information */}
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-blue-800 flex items-center">
              <Shield className="w-5 h-5 mr-2" />
              Data Export Information
            </CardTitle>
          </CardHeader>
          <CardContent className="text-blue-700 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-medium mb-2">Export Includes:</h4>
                <ul className="space-y-1">
                  <li>• User profile and subscription details</li>
                  <li>• Last 90 days of activity data</li>
                  <li>• Health tracking entries</li>
                  <li>• AI conversation history</li>
                  <li>• Food analysis results</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Security Features:</h4>
                <ul className="space-y-1">
                  <li>• Secure Google Sheets export</li>
                  <li>• Access logs for audit trail</li>
                  <li>• 30-day link expiration</li>
                  <li>• GDPR/CCPA compliant format</li>
                  <li>• No sensitive data exposure</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}