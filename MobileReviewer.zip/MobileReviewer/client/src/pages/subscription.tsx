import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Crown, Zap, Gem, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function Subscription() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSubscribe = async (tier: string) => {
    setLoading(true);
    try {
      // Placeholder for Stripe integration
      toast({
        title: "Coming Soon",
        description: `${tier} subscription will be available soon!`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process subscription",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const tiers = [
    {
      name: "Silver",
      subtitle: "Free Tier",
      price: "$0",
      period: "month",
      description: "Perfect for beginners starting their wellness journey",
      icon: Star,
      color: "bg-gray-100 text-gray-900",
      features: [
        "Daily check-in tracker (mood, cravings, sugar intake)",
        "Weekly progress summary",
        "Food scanner (basic image recognition only)",
        "Access to 3 AI health tips per week",
        "Basic dashboard analytics",
        "Access to SoulFuel community (read-only)"
      ]
    },
    {
      name: "Gold",
      price: "$20",
      period: "month",
      description: "Ideal for users seeking guided improvement",
      icon: Zap,
      color: "bg-yellow-100 text-yellow-900",
      popular: true,
      features: [
        "Everything in Silver, plus:",
        "Advanced food scanner with sugar & processed food detection",
        "Real-time healthy/unhealthy meal labeling",
        "Personalized weekly reports & insights",
        "Full access to community + ability to post and engage",
        "Up to 10 AI health tips per week",
        "Save meal logs and get basic recommendations",
        "Limited meditation and motivation audio library"
      ]
    },
    {
      name: "Platinum",
      price: "$40",
      period: "month",
      description: "Designed for serious users aiming for lifestyle transformation",
      icon: Crown,
      color: "bg-blue-100 text-blue-900",
      features: [
        "Everything in Gold, plus:",
        "Unlimited food scans with nutritional analysis",
        "Full meal tracker with daily habit scoring",
        "Mood & craving prediction with AI insights",
        "Unlimited AI tips and daily personalized suggestions",
        "Access to premium challenges & rewards",
        "Full access to expert-led audio and video content",
        "Priority support and health consultation scheduler"
      ]
    },
    {
      name: "Diamond",
      price: "$100",
      period: "month",
      description: "Ultimate access for wellness achievers and professionals",
      icon: Gem,
      color: "bg-purple-100 text-purple-900",
      premium: true,
      features: [
        "Everything in Platinum, plus:",
        "Personal AI health coach with voice chat (24/7)",
        "Custom dietary roadmap with macros & goals",
        "Weekly 1-on-1 session with a certified wellness expert",
        "Track multiple users/family accounts (up to 4 profiles)",
        "Early access to new features + invite-only events",
        "Exclusive merchandise discounts & monthly gift box",
        "Analytics export & integration with wearables (Fitbit, Apple Health, etc.)"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 to-dark-900 pb-20">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Choose Your Plan</h2>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-3">
            Transform Your Wellness Journey
          </h1>
          <p className="text-dark-300 text-lg max-w-2xl mx-auto">
            From basic tracking to personal AI coaching - find the plan that fits your goals
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {tiers.map((tier) => {
            const IconComponent = tier.icon;
            return (
              <Card 
                key={tier.name} 
                className={`relative ${
                  tier.popular ? 'ring-2 ring-yellow-500 scale-105' : 
                  tier.premium ? 'ring-2 ring-purple-500' : ''
                } bg-dark-800 border-dark-700 flex flex-col`}
              >
                {tier.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-500 text-black">
                    Most Popular
                  </Badge>
                )}
                {tier.premium && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-500 text-white">
                    Ultimate
                  </Badge>
                )}
                
                <CardHeader className="text-center pb-4">
                  <div className={`w-12 h-12 mx-auto rounded-full ${tier.color} flex items-center justify-center mb-4`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-xl text-white">
                    {tier.name}
                    {tier.subtitle && <div className="text-sm text-dark-300 font-normal mt-1">({tier.subtitle})</div>}
                  </CardTitle>
                  <CardDescription className="text-dark-300 text-sm">{tier.description}</CardDescription>
                  <div className="text-center">
                    <span className="text-3xl font-bold text-white">{tier.price}</span>
                    <span className="text-dark-300">/{tier.period}</span>
                  </div>
                </CardHeader>

                <CardContent className="flex-1 flex flex-col">
                  <div className="flex-1">
                    <ul className="space-y-2">
                      {tier.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2 text-dark-200">
                          <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button 
                    className={`w-full mt-6 ${
                      tier.name === 'Silver' 
                        ? 'bg-gray-600 hover:bg-gray-500' 
                        : tier.name === 'Gold'
                        ? 'bg-yellow-600 hover:bg-yellow-700'
                        : tier.name === 'Platinum'
                        ? 'bg-blue-600 hover:bg-blue-700'
                        : 'bg-purple-600 hover:bg-purple-700'
                    }`}
                    onClick={() => handleSubscribe(tier.name)}
                    disabled={loading}
                  >
                    {tier.name === 'Silver' ? 'Current Plan' : `Subscribe to ${tier.name}`}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6 text-center">
          <h3 className="text-xl font-semibold text-white mb-2">Need Help Choosing?</h3>
          <p className="text-dark-300 mb-4">
            Start with our free Silver plan and upgrade anytime as your wellness journey evolves.
          </p>
          <p className="text-sm text-dark-400">
            All paid plans come with a 7-day free trial. Cancel anytime, no questions asked.
          </p>
        </div>
      </div>
    </div>
  );
}