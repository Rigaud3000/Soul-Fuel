import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/contexts/LanguageContext";
import { 
  ArrowLeft, 
  Users, 
  Trophy, 
  MessageSquare, 
  Heart,
  Share2,
  Calendar,
  Target,
  Crown,
  Flame,
  ThumbsUp,
  Send
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ForumPost {
  id: number;
  title: string;
  content: string;
  author: string;
  authorLevel: number;
  timestamp: string;
  likes: number;
  replies: number;
  category: 'motivation' | 'recipes' | 'tips' | 'success-stories' | 'questions';
  isLiked?: boolean;
}

interface Challenge {
  id: number;
  title: string;
  description: string;
  duration: number; // days
  participants: number;
  reward: string;
  category: 'sugar-free' | 'whole-foods' | 'meal-prep' | 'mindful-eating';
  startDate: string;
  endDate: string;
  isJoined?: boolean;
}

interface AccountabilityPartner {
  id: number;
  username: string;
  level: number;
  streak: number;
  goals: string[];
  lastActive: string;
  isMatched?: boolean;
}

export default function Community() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("forum");
  const [newPostTitle, setNewPostTitle] = useState("");
  const [newPostContent, setNewPostContent] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<ForumPost['category']>('motivation');
  const { toast } = useToast();
  const { t } = useTranslation();
  const queryClient = useQueryClient();

  // Fetch forum posts
  const { data: forumPosts = [] } = useQuery({
    queryKey: ["/api/community/forum"],
    queryFn: async () => {
      // Mock data for demonstration
      return [
        {
          id: 1,
          title: "30 days sugar-free! Here's what helped me",
          content: "Just hit my 30-day milestone! The key was having healthy snacks ready and using the craving emergency games...",
          author: "HealthyJourney",
          authorLevel: 15,
          timestamp: "2 hours ago",
          likes: 24,
          replies: 8,
          category: 'success-stories' as const,
          isLiked: false
        },
        {
          id: 2,
          title: "Best sugar alternatives for baking?",
          content: "Looking for recommendations on natural sweeteners that actually work well in cookies and cakes...",
          author: "BakeWithLove",
          authorLevel: 8,
          timestamp: "5 hours ago",
          likes: 12,
          replies: 15,
          category: 'recipes' as const,
          isLiked: true
        },
        {
          id: 3,
          title: "Struggling with afternoon cravings",
          content: "Every day around 3 PM I get intense sugar cravings. What strategies work for you?",
          author: "CravingWarrior",
          authorLevel: 3,
          timestamp: "1 day ago",
          likes: 8,
          replies: 22,
          category: 'questions' as const,
          isLiked: false
        }
      ] as ForumPost[];
    },
  });

  // Fetch challenges
  const { data: challenges = [] } = useQuery({
    queryKey: ["/api/community/challenges"],
    queryFn: async () => {
      return [
        {
          id: 1,
          title: "7-Day Sugar Detox",
          description: "Eliminate all added sugars for one week",
          duration: 7,
          participants: 124,
          reward: "Sugar Slayer Badge + 100 XP",
          category: 'sugar-free' as const,
          startDate: "2025-01-01",
          endDate: "2025-01-07",
          isJoined: false
        },
        {
          id: 2,
          title: "Whole Foods January",
          description: "Eat only unprocessed, whole foods for the entire month",
          duration: 31,
          participants: 89,
          reward: "Whole Food Hero Badge + 300 XP",
          category: 'whole-foods' as const,
          startDate: "2025-01-01",
          endDate: "2025-01-31",
          isJoined: true
        },
        {
          id: 3,
          title: "Meal Prep Sundays",
          description: "Prep healthy meals every Sunday for 4 weeks",
          duration: 28,
          participants: 67,
          reward: "Prep Master Badge + 200 XP",
          category: 'meal-prep' as const,
          startDate: "2025-01-05",
          endDate: "2025-02-02",
          isJoined: false
        }
      ] as Challenge[];
    },
  });

  // Create forum post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData: { title: string; content: string; category: string }) => {
      return apiRequest("POST", "/api/community/forum", postData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/forum"] });
      setNewPostTitle("");
      setNewPostContent("");
      toast({
        title: "Post created",
        description: "Your post has been shared with the community.",
      });
    },
  });

  // Join challenge mutation
  const joinChallengeMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      return apiRequest("POST", `/api/community/challenges/${challengeId}/join`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/challenges"] });
      toast({
        title: "Challenge joined!",
        description: "You're now part of this challenge. Good luck!",
      });
    },
  });

  // Like post mutation
  const likePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      return apiRequest("POST", `/api/community/forum/${postId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/forum"] });
    },
  });

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostTitle.trim() || !newPostContent.trim()) return;
    
    createPostMutation.mutate({
      title: newPostTitle,
      content: newPostContent,
      category: selectedCategory
    });
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      'motivation': 'bg-blue-500/20 text-blue-400',
      'recipes': 'bg-green-500/20 text-green-400',
      'tips': 'bg-yellow-500/20 text-yellow-400',
      'success-stories': 'bg-purple-500/20 text-purple-400',
      'questions': 'bg-orange-500/20 text-orange-400'
    };
    return colors[category] || 'bg-gray-500/20 text-gray-400';
  };

  const getChallengeIcon = (category: string) => {
    const icons = {
      'sugar-free': Flame,
      'whole-foods': Target,
      'meal-prep': Calendar,
      'mindful-eating': Heart
    };
    return icons[category] || Target;
  };

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">{t('community.title')}</h2>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 bg-dark-800 mb-6">
            <TabsTrigger value="forum" className="data-[state=active]:bg-primary">
              <MessageSquare className="mr-2 h-4 w-4" />
              {t('community.forum')}
            </TabsTrigger>
            <TabsTrigger value="challenges" className="data-[state=active]:bg-primary">
              <Trophy className="mr-2 h-4 w-4" />
              {t('community.challenges')}
            </TabsTrigger>
            <TabsTrigger value="partners" className="data-[state=active]:bg-primary">
              <Users className="mr-2 h-4 w-4" />
              {t('community.partners')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="forum" className="space-y-4">
            {/* Create Post Form */}
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50">{t('community.shareWithCommunity')}</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreatePost} className="space-y-4">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {(['motivation', 'recipes', 'tips', 'success-stories', 'questions'] as const).map((category) => (
                      <Button
                        key={category}
                        type="button"
                        onClick={() => setSelectedCategory(category)}
                        variant={selectedCategory === category ? "default" : "outline"}
                        size="sm"
                        className={`text-xs px-3 py-1 whitespace-nowrap ${selectedCategory === category ? "bg-primary" : ""}`}
                      >
                        {category.replace('-', ' ')}
                      </Button>
                    ))}
                  </div>
                  <Input
                    placeholder={t('community.postTitlePlaceholder')}
                    value={newPostTitle}
                    onChange={(e) => setNewPostTitle(e.target.value)}
                    className="bg-dark-700 border-dark-600 text-dark-50"
                  />
                  <Textarea
                    placeholder={t('community.postContentPlaceholder')}
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    className="bg-dark-700 border-dark-600 text-dark-50"
                    rows={3}
                  />
                  <Button
                    type="submit"
                    disabled={createPostMutation.isPending}
                    className="w-full bg-primary hover:bg-primary/80"
                  >
                    <Send className="mr-2 h-4 w-4" />
                    {t('community.sharePost')}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Forum Posts */}
            <div className="space-y-4">
              {forumPosts.map((post) => (
                <Card key={post.id} className="bg-dark-800 border-dark-700">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 mr-3">
                          <AvatarFallback className="bg-primary text-white text-sm">
                            {post.author[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center">
                            <span className="text-dark-50 font-medium">{post.author}</span>
                            <Badge variant="outline" className="ml-2 text-xs">
                              Level {post.authorLevel}
                            </Badge>
                          </div>
                          <span className="text-dark-400 text-xs">{post.timestamp}</span>
                        </div>
                      </div>
                      <Badge className={getCategoryColor(post.category)}>
                        {post.category.replace('-', ' ')}
                      </Badge>
                    </div>
                    
                    <h3 className="text-dark-50 font-semibold mb-2">{post.title}</h3>
                    <p className="text-dark-300 text-sm mb-4">{post.content}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Button
                          onClick={() => likePostMutation.mutate(post.id)}
                          variant="ghost"
                          size="sm"
                          className={`text-xs ${post.isLiked ? 'text-red-400' : 'text-dark-400'}`}
                        >
                          <ThumbsUp className="mr-1 h-3 w-3" />
                          {post.likes}
                        </Button>
                        <Button variant="ghost" size="sm" className="text-xs text-dark-400">
                          <MessageSquare className="mr-1 h-3 w-3" />
                          {post.replies} replies
                        </Button>
                      </div>
                      <Button variant="ghost" size="sm" className="text-xs text-dark-400">
                        <Share2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="challenges" className="space-y-4">
            {challenges.map((challenge) => {
              const Icon = getChallengeIcon(challenge.category);
              return (
                <Card key={challenge.id} className="bg-dark-800 border-dark-700">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center">
                        <div className="bg-primary/20 p-2 rounded-lg mr-3">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-dark-50 font-semibold">{challenge.title}</h3>
                          <p className="text-dark-400 text-sm">{challenge.duration} days</p>
                        </div>
                      </div>
                      {challenge.isJoined && (
                        <Badge className="bg-green-500/20 text-green-400">Joined</Badge>
                      )}
                    </div>
                    
                    <p className="text-dark-300 text-sm mb-4">{challenge.description}</p>
                    
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center text-dark-400 text-sm">
                        <Users className="mr-1 h-4 w-4" />
                        {challenge.participants} participants
                      </div>
                      <div className="flex items-center text-dark-400 text-sm">
                        <Crown className="mr-1 h-4 w-4" />
                        {challenge.reward}
                      </div>
                    </div>
                    
                    {!challenge.isJoined ? (
                      <Button
                        onClick={() => joinChallengeMutation.mutate(challenge.id)}
                        disabled={joinChallengeMutation.isPending}
                        className="w-full bg-primary hover:bg-primary/80"
                      >
                        Join Challenge
                      </Button>
                    ) : (
                      <div className="text-center text-green-400 text-sm">
                        ✓ You're participating in this challenge
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </TabsContent>

          <TabsContent value="partners" className="space-y-4">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50">Find Accountability Partner</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-dark-300 text-sm mb-4">
                  Get matched with someone who shares your goals and can help keep you motivated.
                </p>
                <Button className="w-full bg-primary hover:bg-primary/80">
                  <Users className="mr-2 h-4 w-4" />
                  Find My Partner
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50">Your Partners</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center text-dark-400 text-sm py-8">
                  No accountability partners yet. Find your first partner above!
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}