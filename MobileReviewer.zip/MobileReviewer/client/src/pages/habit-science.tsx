import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Brain,
  Target,
  Link,
  Repeat,
  TrendingUp,
  CheckCircle,
  Plus,
  Calendar,
  Clock,
  Zap,
  Eye,
  AlertTriangle,
  Trophy,
  Lightbulb,
  Activity,
  Users,
  ArrowDown
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface HabitStack {
  id: number;
  name: string;
  description: string;
  triggerHabit: string;
  newHabit: string;
  frequency: string;
  successRate: number;
  streakDays: number;
  totalAttempts: number;
  isActive: boolean;
  createdDate: string;
  category: 'nutrition' | 'mindfulness' | 'movement' | 'social';
}

interface EnvironmentalCue {
  id: number;
  name: string;
  description: string;
  type: 'visual' | 'auditory' | 'location' | 'social' | 'time';
  trigger: string;
  desiredResponse: string;
  effectiveness: number;
  timesTriggered: number;
  successfulResponses: number;
  isActive: boolean;
  settings?: {
    reminderTime?: string;
    location?: string;
    visualPrompt?: string;
  };
}

interface HabitAnalytics {
  weeklyCompletion: number;
  bestPerformingTime: string;
  worstPerformingTime: string;
  environmentalFactors: {
    factor: string;
    impact: 'positive' | 'negative' | 'neutral';
    strength: number;
  }[];
  patterns: {
    pattern: string;
    frequency: number;
    recommendation: string;
  }[];
  nextRecommendation: string;
}

export default function HabitScience() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<'stacks' | 'cues' | 'analytics'>('stacks');
  const [showStackForm, setShowStackForm] = useState(false);
  const [showCueForm, setShowCueForm] = useState(false);
  const [stackForm, setStackForm] = useState({
    name: '',
    description: '',
    triggerHabit: '',
    newHabit: '',
    frequency: 'daily',
    category: 'nutrition'
  });
  const [cueForm, setCueForm] = useState({
    name: '',
    description: '',
    type: 'visual',
    trigger: '',
    desiredResponse: '',
    reminderTime: '',
    location: '',
    visualPrompt: ''
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch habit stacks
  const { data: habitStacks = [], isLoading: stacksLoading } = useQuery<HabitStack[]>({
    queryKey: ["/api/habit-stacks"],
    enabled: !!user,
  });

  // Fetch environmental cues
  const { data: environmentalCues = [], isLoading: cuesLoading } = useQuery<EnvironmentalCue[]>({
    queryKey: ["/api/environmental-cues"],
    enabled: !!user,
  });

  // Fetch habit analytics
  const { data: analytics } = useQuery<HabitAnalytics>({
    queryKey: ["/api/habit-analytics"],
    enabled: !!user,
  });

  // Create habit stack mutation
  const createStackMutation = useMutation({
    mutationFn: async (data: typeof stackForm) => {
      const response = await apiRequest("POST", "/api/habit-stacks", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habit-stacks"] });
      setShowStackForm(false);
      setStackForm({
        name: '',
        description: '',
        triggerHabit: '',
        newHabit: '',
        frequency: 'daily',
        category: 'nutrition'
      });
      toast({
        title: "Habit stack created",
        description: "Your new habit stack is ready to use",
      });
    },
  });

  // Create environmental cue mutation
  const createCueMutation = useMutation({
    mutationFn: async (data: typeof cueForm) => {
      const response = await apiRequest("POST", "/api/environmental-cues", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/environmental-cues"] });
      setShowCueForm(false);
      setCueForm({
        name: '',
        description: '',
        type: 'visual',
        trigger: '',
        desiredResponse: '',
        reminderTime: '',
        location: '',
        visualPrompt: ''
      });
      toast({
        title: "Environmental cue created",
        description: "Your environment is now optimized for success",
      });
    },
  });

  // Toggle habit stack status
  const toggleStackMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      const response = await apiRequest("PATCH", `/api/habit-stacks/${id}`, { isActive });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habit-stacks"] });
    },
  });

  // Toggle environmental cue status
  const toggleCueMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      const response = await apiRequest("PATCH", `/api/environmental-cues/${id}`, { isActive });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/environmental-cues"] });
    },
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'nutrition': return 'bg-green-500/20 text-green-400';
      case 'mindfulness': return 'bg-purple-500/20 text-purple-400';
      case 'movement': return 'bg-blue-500/20 text-blue-400';
      case 'social': return 'bg-pink-500/20 text-pink-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getCueTypeIcon = (type: string) => {
    switch (type) {
      case 'visual': return <Eye className="h-4 w-4" />;
      case 'auditory': return <Activity className="h-4 w-4" />;
      case 'location': return <Target className="h-4 w-4" />;
      case 'social': return <Users className="h-4 w-4" />;
      case 'time': return <Clock className="h-4 w-4" />;
      default: return <Zap className="h-4 w-4" />;
    }
  };

  const getEffectivenessColor = (effectiveness: number) => {
    if (effectiveness >= 80) return 'text-green-400';
    if (effectiveness >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to access habit science</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            size="sm"
            className="text-dark-400 hover:text-dark-200"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            Habit Science Lab
          </h1>
          <p className="text-dark-400">Advanced behavioral pattern optimization</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center">
          <div className="grid grid-cols-3 bg-dark-800 rounded-lg p-1">
            <Button
              onClick={() => setActiveTab('stacks')}
              variant={activeTab === 'stacks' ? 'default' : 'ghost'}
              className={activeTab === 'stacks' ? 'bg-primary' : ''}
            >
              <Link className="h-4 w-4 mr-2" />
              Habit Stacks
            </Button>
            <Button
              onClick={() => setActiveTab('cues')}
              variant={activeTab === 'cues' ? 'default' : 'ghost'}
              className={activeTab === 'cues' ? 'bg-primary' : ''}
            >
              <Eye className="h-4 w-4 mr-2" />
              Environment
            </Button>
            <Button
              onClick={() => setActiveTab('analytics')}
              variant={activeTab === 'analytics' ? 'default' : 'ghost'}
              className={activeTab === 'analytics' ? 'bg-primary' : ''}
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Analytics
            </Button>
          </div>
        </div>

        {/* Habit Stacks Tab */}
        {activeTab === 'stacks' && (
          <div className="space-y-6">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                    <Link className="h-5 w-5 text-primary" />
                    Habit Stacking
                  </CardTitle>
                  <Button
                    onClick={() => setShowStackForm(true)}
                    className="bg-primary hover:bg-primary/80"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create Stack
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-dark-400 text-sm mb-4">
                  Chain new habits to existing ones for automatic behavior formation.
                </div>
                {stacksLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto" />
                  </div>
                ) : habitStacks.length === 0 ? (
                  <div className="text-center py-8">
                    <Brain className="h-16 w-16 text-dark-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-dark-50 mb-2">No habit stacks yet</h3>
                    <p className="text-dark-400 mb-4">Create your first habit stack to start building powerful routines</p>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {habitStacks.map((stack) => (
                      <Card key={stack.id} className="bg-dark-700 border-dark-600">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="font-medium text-dark-50 mb-1">{stack.name}</h4>
                              <p className="text-dark-400 text-sm mb-2">{stack.description}</p>
                              <Badge className={getCategoryColor(stack.category)}>
                                {stack.category}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge className={`${stack.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                                {stack.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                              <Button
                                onClick={() => toggleStackMutation.mutate({ id: stack.id, isActive: !stack.isActive })}
                                variant="outline"
                                size="sm"
                                className="border-dark-600"
                              >
                                {stack.isActive ? 'Deactivate' : 'Activate'}
                              </Button>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <div className="bg-dark-800 rounded-lg p-3">
                              <div className="text-xs text-dark-400 mb-1">TRIGGER HABIT</div>
                              <div className="text-dark-50 text-sm">{stack.triggerHabit}</div>
                            </div>
                            <div className="flex items-center justify-center">
                              <ArrowDown className="h-4 w-4 text-primary" />
                            </div>
                            <div className="bg-dark-800 rounded-lg p-3">
                              <div className="text-xs text-dark-400 mb-1">NEW HABIT</div>
                              <div className="text-dark-50 text-sm">{stack.newHabit}</div>
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-dark-600">
                            <div className="text-center">
                              <div className="text-lg font-bold text-primary">{stack.successRate}%</div>
                              <div className="text-xs text-dark-400">Success Rate</div>
                            </div>
                            <div className="text-center">
                              <div className="text-lg font-bold text-secondary">{stack.streakDays}</div>
                              <div className="text-xs text-dark-400">Current Streak</div>
                            </div>
                            <div className="text-center">
                              <div className="text-lg font-bold text-accent">{stack.totalAttempts}</div>
                              <div className="text-xs text-dark-400">Total Attempts</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Environmental Cues Tab */}
        {activeTab === 'cues' && (
          <div className="space-y-6">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                    <Eye className="h-5 w-5 text-secondary" />
                    Environmental Design
                  </CardTitle>
                  <Button
                    onClick={() => setShowCueForm(true)}
                    className="bg-secondary hover:bg-secondary/80"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Cue
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-dark-400 text-sm mb-4">
                  Design your environment to automatically trigger healthy behaviors.
                </div>
                {cuesLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-8 h-8 border-2 border-secondary border-t-transparent rounded-full mx-auto" />
                  </div>
                ) : environmentalCues.length === 0 ? (
                  <div className="text-center py-8">
                    <Target className="h-16 w-16 text-dark-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-dark-50 mb-2">No environmental cues</h3>
                    <p className="text-dark-400 mb-4">Set up cues in your environment to trigger healthy habits</p>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {environmentalCues.map((cue) => (
                      <Card key={cue.id} className="bg-dark-700 border-dark-600">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-start gap-3">
                              <div className="p-2 bg-secondary/20 rounded-lg text-secondary">
                                {getCueTypeIcon(cue.type)}
                              </div>
                              <div>
                                <h4 className="font-medium text-dark-50 mb-1">{cue.name}</h4>
                                <p className="text-dark-400 text-sm mb-2">{cue.description}</p>
                                <Badge className="bg-secondary/20 text-secondary text-xs">
                                  {cue.type}
                                </Badge>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className={`text-lg font-bold ${getEffectivenessColor(cue.effectiveness)}`}>
                                {cue.effectiveness}%
                              </div>
                              <Button
                                onClick={() => toggleCueMutation.mutate({ id: cue.id, isActive: !cue.isActive })}
                                variant="outline"
                                size="sm"
                                className="border-dark-600"
                              >
                                {cue.isActive ? 'Disable' : 'Enable'}
                              </Button>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div className="bg-dark-800 rounded-lg p-3">
                              <div className="text-xs text-dark-400 mb-1">TRIGGER</div>
                              <div className="text-dark-50 text-sm">{cue.trigger}</div>
                            </div>
                            <div className="bg-dark-800 rounded-lg p-3">
                              <div className="text-xs text-dark-400 mb-1">DESIRED RESPONSE</div>
                              <div className="text-dark-50 text-sm">{cue.desiredResponse}</div>
                            </div>
                          </div>

                          <div className="flex justify-between text-xs text-dark-400 mt-3">
                            <span>Triggered {cue.timesTriggered} times</span>
                            <span>Successful {cue.successfulResponses} times</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && analytics && (
          <div className="space-y-6">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-accent" />
                  Behavioral Analytics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Performance Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-dark-700 border-dark-600">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-primary">{analytics.weeklyCompletion}%</div>
                      <div className="text-sm text-dark-400">Weekly Completion</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-dark-700 border-dark-600">
                    <CardContent className="p-4 text-center">
                      <div className="text-lg font-bold text-green-400">{analytics.bestPerformingTime}</div>
                      <div className="text-sm text-dark-400">Best Time</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-dark-700 border-dark-600">
                    <CardContent className="p-4 text-center">
                      <div className="text-lg font-bold text-red-400">{analytics.worstPerformingTime}</div>
                      <div className="text-sm text-dark-400">Worst Time</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Environmental Factors */}
                <div>
                  <h4 className="font-medium text-dark-50 mb-3">Environmental Impact</h4>
                  <div className="space-y-2">
                    {analytics.environmentalFactors.map((factor, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                        <span className="text-dark-50">{factor.factor}</span>
                        <div className="flex items-center gap-2">
                          <Progress value={factor.strength} className="w-20 h-2" />
                          <Badge className={`text-xs ${
                            factor.impact === 'positive' ? 'bg-green-500/20 text-green-400' :
                            factor.impact === 'negative' ? 'bg-red-500/20 text-red-400' :
                            'bg-gray-500/20 text-gray-400'
                          }`}>
                            {factor.impact}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Patterns & Recommendations */}
                <div>
                  <h4 className="font-medium text-dark-50 mb-3">Detected Patterns</h4>
                  <div className="space-y-3">
                    {analytics.patterns.map((pattern, index) => (
                      <Card key={index} className="bg-dark-700 border-dark-600">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h5 className="font-medium text-dark-50">{pattern.pattern}</h5>
                            <Badge className="bg-blue-500/20 text-blue-400 text-xs">
                              {pattern.frequency}x/week
                            </Badge>
                          </div>
                          <p className="text-dark-400 text-sm">{pattern.recommendation}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Next Recommendation */}
                <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Lightbulb className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <h4 className="font-medium text-dark-50 mb-2">AI Recommendation</h4>
                        <p className="text-dark-300 text-sm">{analytics.nextRecommendation}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Create Habit Stack Modal */}
        {showStackForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 w-full max-w-lg">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Create Habit Stack</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Stack Name</label>
                  <Input
                    value={stackForm.name}
                    onChange={(e) => setStackForm(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Morning Wellness Stack"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Description</label>
                  <Textarea
                    value={stackForm.description}
                    onChange={(e) => setStackForm(prev => ({ ...prev, description: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Link healthy habits together..."
                    rows={2}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Trigger Habit (What you already do)</label>
                  <Input
                    value={stackForm.triggerHabit}
                    onChange={(e) => setStackForm(prev => ({ ...prev, triggerHabit: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="After I brush my teeth..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">New Habit (What you want to add)</label>
                  <Input
                    value={stackForm.newHabit}
                    onChange={(e) => setStackForm(prev => ({ ...prev, newHabit: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="I will drink a glass of water"
                  />
                </div>
                <div className="flex justify-end gap-3">
                  <Button
                    onClick={() => setShowStackForm(false)}
                    variant="outline"
                    className="border-dark-600"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => createStackMutation.mutate(stackForm)}
                    disabled={createStackMutation.isPending}
                    className="bg-primary hover:bg-primary/80"
                  >
                    Create Stack
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Create Environmental Cue Modal */}
        {showCueForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 w-full max-w-lg">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Create Environmental Cue</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Cue Name</label>
                  <Input
                    value={cueForm.name}
                    onChange={(e) => setCueForm(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Water Bottle Reminder"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Trigger</label>
                  <Input
                    value={cueForm.trigger}
                    onChange={(e) => setCueForm(prev => ({ ...prev, trigger: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Place water bottle on desk"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Desired Response</label>
                  <Input
                    value={cueForm.desiredResponse}
                    onChange={(e) => setCueForm(prev => ({ ...prev, desiredResponse: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Drink water every hour"
                  />
                </div>
                <div className="flex justify-end gap-3">
                  <Button
                    onClick={() => setShowCueForm(false)}
                    variant="outline"
                    className="border-dark-600"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => createCueMutation.mutate(cueForm)}
                    disabled={createCueMutation.isPending}
                    className="bg-secondary hover:bg-secondary/80"
                  >
                    Create Cue
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}