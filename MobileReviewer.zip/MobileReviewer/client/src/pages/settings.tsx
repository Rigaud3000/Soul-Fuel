import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Bell, Wifi, Palette, Brain, Shield, Download } from 'lucide-react';
import { AIPersonalizationEngine } from "@/components/ai-personalization-engine";
import { OfflineNotificationSettings } from "@/components/offline-notification-settings";
import { SoulStreakTracker } from "@/components/soul-streak-tracker";
import { SimpleReminderSettings } from "@/components/simple-reminder-settings";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('personalization');

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
          Settings & Preferences
        </h1>
        <p className="text-muted-foreground mt-2">
          Customize your SOULFUEL experience to match your wellness journey
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="personalization" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            AI Companion
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="offline" className="flex items-center gap-2">
            <Wifi className="h-4 w-4" />
            Offline Mode
          </TabsTrigger>
          <TabsTrigger value="data" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Data Export
          </TabsTrigger>
          <TabsTrigger value="progress" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Progress
          </TabsTrigger>
        </TabsList>

        <TabsContent value="personalization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-purple-600" />
                AI Companion Personalization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AIPersonalizationEngine />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <OfflineNotificationSettings />
          <SimpleReminderSettings />
        </TabsContent>

        <TabsContent value="offline" className="space-y-6">
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-800">
                <Wifi className="h-5 w-5" />
                Offline Mode Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-blue-800 mb-3">✅ Available Offline</h4>
                  <ul className="space-y-2 text-sm text-blue-700">
                    <li>• Sugar intake tracking</li>
                    <li>• Mood logging with notes</li>
                    <li>• Craving intensity tracking</li>
                    <li>• Emergency toolkit access</li>
                    <li>• Mini-games and breathing exercises</li>
                    <li>• Progress viewing (cached data)</li>
                    <li>• Basic AI emergency responses</li>
                    <li>• Personalization settings</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-amber-800 mb-3">🌐 Requires Internet</h4>
                  <ul className="space-y-2 text-sm text-amber-700">
                    <li>• Advanced AI conversations</li>
                    <li>• Food photo analysis</li>
                    <li>• Real-time craving predictions</li>
                    <li>• Community features</li>
                    <li>• Recipe recommendations</li>
                    <li>• Health app integrations</li>
                    <li>• Data synchronization</li>
                    <li>• Push notifications</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-white/70 p-4 rounded-lg border border-blue-200">
                <h4 className="font-semibold text-blue-800 mb-2">🔄 Smart Sync Technology</h4>
                <p className="text-sm text-blue-700">
                  Your data is automatically saved locally when offline and seamlessly synced 
                  when you reconnect. No data loss, ever. Continue your wellness journey 
                  anywhere, anytime.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-600" />
                Secure Data Export
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Export all your SOULFUEL data in a secure, readable format. 
                  Perfect for backup, analysis, or compliance requirements.
                </p>
                <div className="flex gap-4">
                  <button 
                    onClick={() => window.location.href = '/data-export'}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    Export My Data
                  </button>
                </div>
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <p className="text-xs text-blue-800">
                    <Shield className="w-3 h-3 inline mr-1" />
                    Your data is exported to a secure Google Sheet that only you can access. 
                    Complies with GDPR and CCPA regulations.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-emerald-600" />
                Progress & Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <SoulStreakTracker />
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-emerald-800">
                <Shield className="h-5 w-5" />
                Privacy & Data Control
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-white/70 rounded-lg">
                  <div>
                    <div className="font-medium text-emerald-800">Data Encryption</div>
                    <div className="text-sm text-emerald-600">All offline data is encrypted with AES-256</div>
                  </div>
                  <div className="text-emerald-600 font-medium">Enabled</div>
                </div>

                <div className="flex items-center justify-between p-3 bg-white/70 rounded-lg">
                  <div>
                    <div className="font-medium text-emerald-800">Data Export</div>
                    <div className="text-sm text-emerald-600">Download your complete wellness data</div>
                  </div>
                  <button className="text-emerald-600 font-medium hover:underline">
                    Export Data
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 bg-white/70 rounded-lg">
                  <div>
                    <div className="font-medium text-emerald-800">Account Deletion</div>
                    <div className="text-sm text-emerald-600">Permanently delete all data (GDPR compliant)</div>
                  </div>
                  <button className="text-red-600 font-medium hover:underline">
                    Delete Account
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}