import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthenticatedRequest } from "@/hooks/use-auth";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/contexts/LanguageContext";
import { useLocation } from "wouter";
import { 
  Heart, 
  TrendingUp, 
  Trophy, 
  Target, 
  Zap, 
  AlertTriangle,
  Calendar,
  Star,
  Award,
  Flame,
  Activity,
  Plus,
  BarChart3,
  Clock,
  Brain,
  Smile,
  Frown,
  Meh,
  Users,
  Gamepad2,
  Camera
} from "lucide-react";

export default function UnifiedTracking() {
  const { user } = useAuth();
  const { getAuthHeaders } = useAuthenticatedRequest();
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form states
  const [sugarAmount, setSugarAmount] = useState("");
  const [mealType, setMealType] = useState("");
  const [selectedMood, setSelectedMood] = useState(0);
  const [moodNotes, setMoodNotes] = useState("");
  const [cravingIntensity, setCravingIntensity] = useState([5]);
  const [cravingTrigger, setCravingTrigger] = useState("");
  const [cravingNotes, setCravingNotes] = useState("");
  
  // View states
  const [activeSection, setActiveSection] = useState<'overview' | 'sugar' | 'mood' | 'cravings' | 'progress'>('overview');

  // Fetch all tracking data
  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
    enabled: !!user,
  });

  const { data: sugarEntries } = useQuery({
    queryKey: ["/api/sugar-entries"],
    enabled: !!user,
  });

  const { data: moodEntries } = useQuery({
    queryKey: ["/api/mood-entries"],
    enabled: !!user,
  });

  const { data: cravingEntries } = useQuery({
    queryKey: ["/api/craving-entries"],
    enabled: !!user,
  });

  const weeklyStats = (analytics as any)?.weeklyStats || {
    avgMood: 0,
    totalSugar: 0,
    moodCheckIns: 0,
    streakDays: 0,
    cravingIntensity: 0
  };

  // Mutations
  const addSugarMutation = useMutation({
    mutationFn: async (data: { amount: number; mealType: string }) => {
      const response = await fetch("/api/sugar-entries", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(user ? getAuthHeaders() : {}),
        } as HeadersInit,
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to add sugar entry");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sugar-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      setSugarAmount("");
      setMealType("");
      toast({ title: "Sugar entry added successfully!" });
    },
  });

  const addMoodMutation = useMutation({
    mutationFn: async (data: { mood: number; notes?: string }) => {
      const response = await fetch("/api/mood-entries", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(user ? getAuthHeaders() : {}),
        } as HeadersInit,
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to add mood entry");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      setSelectedMood(0);
      setMoodNotes("");
      toast({ title: "Mood logged successfully!" });
    },
  });

  const addCravingMutation = useMutation({
    mutationFn: async (data: { intensity: number; trigger?: string; notes?: string }) => {
      const response = await fetch("/api/craving-entries", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(user ? getAuthHeaders() : {}),
        } as HeadersInit,
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to add craving entry");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/craving-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      setCravingIntensity([5]);
      setCravingTrigger("");
      setCravingNotes("");
      toast({ title: "Craving logged successfully!" });
    },
  });

  const handleSugarSubmit = () => {
    if (!sugarAmount || !mealType) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }
    addSugarMutation.mutate({
      amount: parseFloat(sugarAmount),
      mealType,
    });
  };

  const handleMoodSubmit = () => {
    if (selectedMood === 0) {
      toast({ title: "Please select a mood", variant: "destructive" });
      return;
    }
    addMoodMutation.mutate({
      mood: selectedMood,
      notes: moodNotes || undefined,
    });
  };

  const handleCravingSubmit = () => {
    addCravingMutation.mutate({
      intensity: cravingIntensity[0],
      trigger: cravingTrigger || undefined,
      notes: cravingNotes || undefined,
    });
  };

  const moodEmojis = ["😢", "😞", "😐", "😊", "😁"];
  const moodLabels = ["Very Bad", "Bad", "Neutral", "Good", "Excellent"];

  const navigationItems = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'sugar', label: 'Sugar', icon: Zap },
    { id: 'mood', label: 'Mood', icon: Heart },
    { id: 'cravings', label: 'Cravings', icon: Target },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-950">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-dark-900/95 backdrop-blur-lg border-b border-dark-700/50">
        <div className="max-w-md mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-white">{t('tracking.title')}</h1>
          <p className="text-dark-400 text-sm">{t('tracking.subtitle')}</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto px-6 pb-24 space-y-6">
        
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-dark-800 border border-dark-700 rounded-xl p-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                <Heart className="text-primary" size={24} />
              </div>
              <div>
                <div className="text-xs text-dark-400 uppercase tracking-wide">Avg Mood</div>
                <div className="text-xl font-bold text-white">{weeklyStats.avgMood || 'N/A'}</div>
              </div>
            </div>
          </Card>
          <Card className="bg-dark-800 border border-dark-700 rounded-xl p-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center">
                <Zap className="text-secondary" size={24} />
              </div>
              <div>
                <div className="text-xs text-dark-400 uppercase tracking-wide">Daily Sugar</div>
                <div className="text-xl font-bold text-white">{Math.round((weeklyStats.totalSugar || 0) / 7)}g</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Weekly Progress */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-5 flex items-center gap-2">
            <TrendingUp className="text-primary" size={20} />
            Weekly Progress
          </h3>
          <div className="space-y-5">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-dark-300">Sugar Target</span>
                <span className="text-white font-medium">{weeklyStats.totalSugar || 0}/175g</span>
              </div>
              <Progress value={Math.min((weeklyStats.totalSugar || 0) / 175 * 100, 100)} className="h-3" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-dark-300">Mood Check-ins</span>
                <span className="text-white font-medium">{weeklyStats.moodCheckIns || 0}/7</span>
              </div>
              <Progress value={((weeklyStats.moodCheckIns || 0) / 7) * 100} className="h-3" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-dark-300">Weekly Streak</span>
                <span className="text-white font-medium">{weeklyStats.streakDays || 0} days</span>
              </div>
              <Progress value={Math.min((weeklyStats.streakDays || 0) / 7 * 100, 100)} className="h-3" />
            </div>
          </div>
        </Card>

        {/* This Week's Stats */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-5 flex items-center gap-2">
            <BarChart3 className="text-primary" size={20} />
            This Week's Stats
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-dark-700 rounded-lg p-4">
              <div className="text-2xl font-bold text-primary mb-1">{weeklyStats.moodCheckIns || 0}</div>
              <div className="text-sm text-dark-300">Mood Entries</div>
            </div>
            <div className="bg-dark-700 rounded-lg p-4">
              <div className="text-2xl font-bold text-secondary mb-1">{Math.round(weeklyStats.totalSugar || 0)}g</div>
              <div className="text-sm text-dark-300">Total Sugar</div>
            </div>
            <div className="bg-dark-700 rounded-lg p-4">
              <div className="text-2xl font-bold text-accent mb-1">{weeklyStats.streakDays || 0}</div>
              <div className="text-sm text-dark-300">Day Streak</div>
            </div>
            <div className="bg-dark-700 rounded-lg p-4">
              <div className="text-2xl font-bold text-yellow-500 mb-1">{weeklyStats.cravingIntensity || 'N/A'}</div>
              <div className="text-sm text-dark-300">Avg Craving</div>
            </div>
          </div>
        </Card>

        {/* Achievements */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-5 flex items-center gap-2">
            <Award className="text-yellow-500" size={20} />
            Achievements
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                  <span className="text-yellow-500 text-lg">🏆</span>
                </div>
                <div>
                  <div className="text-sm font-medium text-white">First Week Complete</div>
                  <div className="text-xs text-dark-400">Track mood for 7 days</div>
                </div>
              </div>
              <Badge variant={weeklyStats.moodCheckIns >= 7 ? "default" : "secondary"} className="text-xs">
                {weeklyStats.moodCheckIns >= 7 ? "Completed" : "In Progress"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <span className="text-green-500 text-lg">💪</span>
                </div>
                <div>
                  <div className="text-sm font-medium text-white">Sugar Warrior</div>
                  <div className="text-xs text-dark-400">Stay under 25g daily sugar</div>
                </div>
              </div>
              <Badge variant={(weeklyStats.totalSugar || 0) < 175 ? "default" : "secondary"} className="text-xs">
                {(weeklyStats.totalSugar || 0) < 175 ? "Completed" : "In Progress"}
              </Badge>
            </div>
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-5">Recent Activity</h3>
          <div className="space-y-4">
            {(sugarEntries as any)?.slice(0, 3).map((entry: any) => (
              <div key={entry.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                    <Zap className="text-secondary" size={20} />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white">{entry.amount}g sugar</div>
                    <div className="text-xs text-dark-400 capitalize">{entry.mealType}</div>
                  </div>
                </div>
                <div className="text-xs text-dark-400">
                  {new Date(entry.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
            {(!(sugarEntries as any) || (sugarEntries as any)?.length === 0) && (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-dark-700 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Activity className="text-dark-400" size={24} />
                </div>
                <p className="text-dark-400 text-sm">No entries yet. Start tracking!</p>
              </div>
            )}
          </div>
        </Card>

        {/* Emergency Toolkit */}
        <Card className="bg-gradient-to-br from-red-900/20 to-orange-900/20 border border-red-800/30 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="text-red-400" size={20} />
            <h3 className="text-lg font-semibold text-red-400">Craving Emergency Toolkit</h3>
          </div>
          <p className="text-sm text-dark-300 mb-4">
            Feeling overwhelmed by cravings? Try these quick techniques to get through the moment:
          </p>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <Button
              onClick={() => setLocation("/healing-games")}
              className="bg-gradient-to-r from-red-600/20 to-red-500/10 border border-red-500/30 hover:from-red-600/30 hover:to-red-500/20 text-white h-auto p-4 flex-col gap-2"
              variant="ghost"
            >
              <Gamepad2 className="text-red-400" size={24} />
              <span className="text-sm">Healing Games</span>
            </Button>
            <Button
              onClick={() => setLocation("/soul-companion")}
              className="bg-gradient-to-r from-blue-600/20 to-blue-500/10 border border-blue-500/30 hover:from-blue-600/30 hover:to-blue-500/20 text-white h-auto p-4 flex-col gap-2"
              variant="ghost"
            >
              <Brain className="text-blue-400" size={24} />
              <span className="text-sm">Soul Companion</span>
            </Button>
          </div>
          <div className="text-center">
            <Button
              onClick={() => setLocation("/emergency")}
              className="bg-gradient-to-r from-purple-600/20 to-indigo-600/10 border border-purple-500/30 hover:from-purple-600/30 hover:to-indigo-600/20 text-white px-6 py-2"
              variant="ghost"
            >
              <Activity className="mr-2" size={18} />
              Breathing Exercises
            </Button>
          </div>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-5 flex items-center gap-2">
            <Plus className="text-primary" size={20} />
            Quick Log
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => setLocation("/scanner")}
              className="bg-gradient-to-r from-secondary/20 to-secondary/10 border border-secondary/30 hover:from-secondary/30 hover:to-secondary/20 text-white h-auto p-4 flex-col gap-2"
              variant="ghost"
            >
              <Camera className="text-secondary" size={24} />
              <span className="text-sm">Scan Food</span>
            </Button>
            <Button
              onClick={() => setLocation("/mood")}
              className="bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/30 hover:from-primary/30 hover:to-primary/20 text-white h-auto p-4 flex-col gap-2"
              variant="ghost"
            >
              <Heart className="text-primary" size={24} />
              <span className="text-sm">Log Mood</span>
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3 mt-3">
            <Button
              onClick={() => setLocation("/cravings")}
              className="bg-gradient-to-r from-accent/20 to-accent/10 border border-accent/30 hover:from-accent/30 hover:to-accent/20 text-white h-auto p-4 flex-col gap-2"
              variant="ghost"
            >
              <Target className="text-accent" size={24} />
              <span className="text-sm">Log Craving</span>
            </Button>
            <Button
              onClick={() => setLocation("/wearables")}
              className="bg-gradient-to-r from-blue-600/20 to-purple-600/10 border border-blue-500/30 hover:from-blue-600/30 hover:to-purple-600/20 text-white h-auto p-4 flex-col gap-2"
              variant="ghost"
            >
              <Activity className="text-blue-400" size={24} />
              <span className="text-sm">Health Apps</span>
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}