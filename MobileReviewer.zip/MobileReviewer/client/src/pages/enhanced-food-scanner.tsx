import { useState, useRef, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Camera, 
  Upload, 
  Crown, 
  ScanLine, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Info,
  Lightbulb,
  Zap,
  Eye
} from "lucide-react";
import ARFoodScanner from "@/components/ar-food-scanner";
import { apiRequest } from "@/lib/queryClient";

interface FoodAnalysis {
  foodName: string;
  brandOwner?: string;
  healthScore: 'A' | 'B' | 'C' | 'D' | 'F';
  isUltraProcessed: boolean;
  redFlags: string[];
  recommendations: string[];
  coachingMessage: string;
  confidence: number;
  nutritionFacts?: {
    calories?: number;
    totalSugars?: number;
    addedSugars?: number;
    sodium?: number;
    saturatedFat?: number;
    fiber?: number;
    protein?: number;
  };
  ingredients?: string[];
}

interface ScanUsage {
  canScan: boolean;
  scansRemaining: number;
  isPro: boolean;
  scansUsed: number;
}

export default function EnhancedFoodScanner() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [foodDescription, setFoodDescription] = useState("");
  const [barcodeInput, setBarcodeInput] = useState("");
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<FoodAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [showARScanner, setShowARScanner] = useState(false);
  const [batchScans, setBatchScans] = useState<(FoodAnalysis & { barcode: string })[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [activeTab, setActiveTab] = useState("camera");

  // Fetch scan usage for free tier users
  const { data: scanUsage, isLoading: scanUsageLoading } = useQuery<ScanUsage>({
    queryKey: ["/api/scan-usage"],
    enabled: !!user,
  });

  const isPro = user?.subscriptionTier === "pro" || scanUsage?.isPro;
  const canScan = scanUsage?.canScan ?? true;
  const scansRemaining = scanUsage?.scansRemaining ?? 4;
  const scansUsed = scanUsage?.scansUsed ?? 0;

  // Text analysis mutation
  const analyzeTextMutation = useMutation({
    mutationFn: async (description: string) => {
      const response = await fetch("/api/analyze-food-text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ foodDescription: description })
      });
      if (!response.ok) throw new Error("Analysis failed");
      const data = await response.json();
      return data.analysis;
    },
    onSuccess: (result) => {
      setAnalysisResult(result);
      queryClient.invalidateQueries({ queryKey: ["/api/food-analyses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scan-usage"] });
      toast({
        title: "Food analyzed successfully",
        description: `Health Score: ${result.healthScore}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Analysis failed",
        description: error.message || "Failed to analyze food",
        variant: "destructive",
      });
    },
  });

  // Barcode analysis mutation
  const analyzeBarcodeMutation = useMutation({
    mutationFn: async (barcode: string) => {
      const response = await fetch("/api/analyze-food-barcode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ barcode })
      });
      if (!response.ok) throw new Error("Barcode analysis failed");
      const data = await response.json();
      return { ...data.analysis, barcode };
    },
    onSuccess: (result) => {
      // Add to batch or show single result based on active tab
      if (activeTab === "barcode" && batchScans.length >= 0) {
        setBatchScans(prev => [...prev, result]);
        setBarcodeInput(""); // Clear input for next scan
        toast({
          title: "Product added to batch",
          description: `${result.foodName} - Health Score: ${result.healthScore}`,
        });
      } else {
        setAnalysisResult(result);
        toast({
          title: "Product analyzed successfully",
          description: `Health Score: ${result.healthScore}`,
        });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/food-analyses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scan-usage"] });
    },
    onError: (error: any) => {
      toast({
        title: "Barcode analysis failed",
        description: error.message || "Product not found",
        variant: "destructive",
      });
    },
  });

  // Image analysis mutation
  const analyzeImageMutation = useMutation({
    mutationFn: async (imageFile: File) => {
      const formData = new FormData();
      formData.append("foodImage", imageFile);
      
      const response = await fetch("/api/analyze-food-image", {
        method: "POST",
        body: formData
      });
      if (!response.ok) throw new Error("Image analysis failed");
      const data = await response.json();
      return data.analysis;
    },
    onSuccess: (result) => {
      setAnalysisResult(result);
      queryClient.invalidateQueries({ queryKey: ["/api/food-analyses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scan-usage"] });
      toast({
        title: "Image analyzed successfully",
        description: `Health Score: ${result.healthScore}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Image analysis failed",
        description: error.message || "Failed to analyze image",
        variant: "destructive",
      });
    },
  });

  // Camera functionality
  const startCamera = async () => {
    // Check if browser supports camera
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast({
        title: "Camera not supported",
        description: "Your browser doesn't support camera access. Try uploading an image instead.",
        variant: "destructive",
      });
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment' // Use back camera on mobile
        } 
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setShowCamera(true);
    } catch (error: any) {
      let title = "Camera access denied";
      let description = "Please allow camera access to scan food";
      
      if (error.name === 'NotFoundError') {
        description = "No camera found on this device";
      } else if (error.name === 'NotAllowedError') {
        description = "Camera access was denied. Please check browser permissions.";
      } else if (error.name === 'NotSupportedError') {
        description = "Camera is not supported on this device";
      }
      
      toast({
        title,
        description,
        variant: "destructive",
      });
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setShowCamera(false);
    setCapturedPhoto(null);
  };

  const capturePhoto = () => {
    console.log('Capture photo clicked, canScan:', canScan, 'scansRemaining:', scansRemaining);
    
    if (!canScan) {
      toast({
        title: "Scan limit reached",
        description: "You have reached your weekly scan limit. Upgrade to Pro for unlimited scans.",
        variant: "destructive",
      });
      return;
    }
    
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context?.drawImage(video, 0, 0);
      
      const photoDataUrl = canvas.toDataURL('image/jpeg', 0.8);
      setCapturedPhoto(photoDataUrl);
      
      console.log('Photo captured, starting analysis...');
      
      // Convert data URL to blob for analysis
      canvas.toBlob((blob) => {
        if (blob) {
          console.log('Converting to file for analysis...');
          const file = new File([blob], 'captured-food.jpg', { type: 'image/jpeg' });
          analyzeImageMutation.mutate(file);
        }
      }, 'image/jpeg', 0.8);
      
      stopCamera();
    }
  };

  const retakePhoto = () => {
    setCapturedPhoto(null);
    startCamera();
  };

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleTextAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodDescription.trim()) return;
    
    if (user?.subscriptionTier !== 'pro') {
      toast({
        title: "Premium feature",
        description: "AI food analysis requires a Pro subscription",
        variant: "destructive",
      });
      return;
    }
    
    analyzeTextMutation.mutate(foodDescription);
  };

  const handleBarcodeAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeInput.trim()) return;
    
    if (!canScan) {
      toast({
        title: "Scan limit reached",
        description: "You have reached your weekly scan limit. Upgrade to Pro for unlimited scans.",
        variant: "destructive",
      });
      return;
    }
    
    analyzeBarcodeMutation.mutate(barcodeInput);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!canScan) {
      toast({
        title: "Scan limit reached",
        description: "You have reached your weekly scan limit. Upgrade to Pro for unlimited scans.",
        variant: "destructive",
      });
      return;
    }

    setSelectedImage(file);
    analyzeImageMutation.mutate(file);
  };

  const getHealthScoreColor = (score: string) => {
    switch (score) {
      case 'A': return 'bg-green-500';
      case 'B': return 'bg-green-400';
      case 'C': return 'bg-yellow-500';
      case 'D': return 'bg-orange-500';
      case 'F': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getHealthScoreIcon = (score: string) => {
    if (score === 'A' || score === 'B') return CheckCircle;
    if (score === 'C') return Info;
    return XCircle;
  };

  const isLoading = analyzeTextMutation.isPending || analyzeBarcodeMutation.isPending || analyzeImageMutation.isPending;

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Food Scanner</h2>
          
          {/* AR Mode Button */}
          <Button
            onClick={() => setShowARScanner(true)}
            className="ml-auto mr-2 bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80 text-white font-semibold px-4 py-2"
            disabled={!canScan}
          >
            <Eye className="mr-2 h-4 w-4" />
            AR Mode
          </Button>
          
          {user?.subscriptionTier === 'pro' && (
            <Badge className="bg-yellow-500/20 text-yellow-400">
              <Crown className="mr-1 h-3 w-3" />
              Pro
            </Badge>
          )}
        </div>

        {/* Scan Usage for Free Tier */}
        {!isPro && (
          <Card className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-700/50 rounded-xl p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-blue-400 flex items-center">
                  <ScanLine className="mr-2 h-5 w-5" />
                  Weekly Scans {canScan ? `(${scansRemaining} remaining)` : '(Limit Reached)'}
                </h3>
                <div className="mt-2">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm text-blue-300">Progress: {scansUsed}/4 scans used</span>
                  </div>
                  <Progress 
                    value={(scansUsed / 4) * 100} 
                    className="h-2 bg-blue-900/50"
                  />
                </div>
                {!canScan && (
                  <p className="text-sm text-orange-300 mt-2">
                    Weekly limit reached. Upgrade for unlimited scans or wait for reset.
                  </p>
                )}
              </div>
              <Button 
                onClick={() => setLocation("/subscription")}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 ml-4"
              >
                <Crown className="mr-1 h-4 w-4" />
                Upgrade
              </Button>
            </div>
          </Card>
        )}

        {/* Analysis Methods */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="grid w-full grid-cols-4 bg-dark-800">
            <TabsTrigger value="camera" className="data-[state=active]:bg-primary">
              <Camera className="mr-1 h-4 w-4" />
              Camera
            </TabsTrigger>
            <TabsTrigger value="text" className="data-[state=active]:bg-primary">
              <Info className="mr-1 h-4 w-4" />
              Text
            </TabsTrigger>
            <TabsTrigger value="barcode" className="data-[state=active]:bg-primary">
              <ScanLine className="mr-1 h-4 w-4" />
              Barcode
            </TabsTrigger>
            <TabsTrigger value="image" className="data-[state=active]:bg-primary">
              <Upload className="mr-1 h-4 w-4" />
              Upload
            </TabsTrigger>
          </TabsList>

          <TabsContent value="camera">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50">Camera Food Scanner</CardTitle>
                <p className="text-dark-400 text-sm">Point your camera at food for instant AI analysis</p>
              </CardHeader>
              <CardContent className="space-y-4">
                {!showCamera && !capturedPhoto && (
                  <div className="text-center py-8">
                    <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Camera className="h-10 w-10 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-dark-50 mb-2">Ready to Scan</h3>
                    <p className="text-dark-400 mb-6">Take a photo of your food for instant nutritional analysis</p>
                    <Button
                      onClick={startCamera}
                      className="bg-primary hover:bg-primary/80 px-8 py-3"
                      disabled={!canScan}
                    >
                      <Camera className="mr-2 h-5 w-5" />
                      Start Camera
                    </Button>
                    {!canScan && !isPro && (
                      <p className="text-xs text-yellow-400 mt-3">
                        <Crown className="inline h-3 w-3 mr-1" />
                        Weekly scan limit reached. Upgrade for unlimited scans.
                      </p>
                    )}
                  </div>
                )}

                {showCamera && (
                  <div className="space-y-4">
                    <div className="relative bg-black rounded-lg overflow-hidden">
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        className="w-full h-64 object-cover"
                      />
                      <div className="absolute inset-0 border-2 border-primary/50 rounded-lg">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                          <div className="w-32 h-32 border-2 border-primary rounded-lg"></div>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <Button
                        onClick={capturePhoto}
                        className="flex-1 bg-primary hover:bg-primary/80"
                        disabled={analyzeImageMutation.isPending || (!isPro && !canScan)}
                      >
                        <Camera className="mr-2 h-4 w-4" />
                        Capture & Analyze
                      </Button>
                      <Button
                        onClick={stopCamera}
                        variant="outline"
                        className="border-dark-600 text-dark-300"
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}

                {capturedPhoto && (
                  <div className="space-y-4">
                    <div className="relative">
                      <img
                        src={capturedPhoto}
                        alt="Captured food"
                        className="w-full h-64 object-cover rounded-lg"
                      />
                      {analyzeImageMutation.isPending && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-lg">
                          <div className="text-center text-white">
                            <div className="animate-spin w-8 h-8 border-2 border-white border-t-transparent rounded-full mx-auto mb-2" />
                            <p>Analyzing your food...</p>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-3">
                      <Button
                        onClick={retakePhoto}
                        variant="outline"
                        className="flex-1 border-dark-600 text-dark-300"
                        disabled={analyzeImageMutation.isPending}
                      >
                        Retake Photo
                      </Button>
                    </div>
                  </div>
                )}

                {/* Hidden canvas for photo capture */}
                <canvas ref={canvasRef} className="hidden" />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="text">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50">Describe Your Food</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleTextAnalyze} className="space-y-4">
                  <Input
                    type="text"
                    placeholder="e.g., Coca-Cola, McDonald's Big Mac, organic apples..."
                    value={foodDescription}
                    onChange={(e) => setFoodDescription(e.target.value)}
                    className="bg-dark-700 border-dark-600 text-dark-50"
                    disabled={isLoading}
                  />
                  <Button
                    type="submit"
                    disabled={isLoading || !foodDescription.trim() || (!isPro && !canScan)}
                    className="w-full bg-primary hover:bg-primary/80"
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Zap className="mr-2 h-4 w-4" />
                        Analyze Food
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="barcode">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50">Batch Barcode Scanner</CardTitle>
                <p className="text-dark-400 text-sm">Scan multiple products during shopping</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handleBarcodeAnalyze} className="space-y-4">
                  <Input
                    type="text"
                    placeholder="Enter barcode number (UPC/EAN)"
                    value={barcodeInput}
                    onChange={(e) => setBarcodeInput(e.target.value)}
                    className="bg-dark-700 border-dark-600 text-dark-50"
                    disabled={isLoading}
                  />
                  <div className="flex gap-3">
                    <Button
                      type="submit"
                      disabled={isLoading || !barcodeInput.trim() || (!isPro && !canScan)}
                      className="flex-1 bg-primary hover:bg-primary/80"
                    >
                      {isLoading ? (
                        <>
                          <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                          Scanning...
                        </>
                      ) : (
                        <>
                          <ScanLine className="mr-2 h-4 w-4" />
                          Add to Batch
                        </>
                      )}
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setBatchScans([])}
                      variant="outline"
                      className="border-dark-600 text-dark-300"
                      disabled={batchScans.length === 0}
                    >
                      Clear
                    </Button>
                  </div>
                </form>
                
                {batchScans.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-dark-50">Shopping Cart ({batchScans.length})</h4>
                      <Badge className="bg-primary/20 text-primary">
                        Batch Mode
                      </Badge>
                    </div>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {batchScans.map((item, index) => (
                        <div key={index} className="flex items-center justify-between bg-dark-700 rounded-lg p-3">
                          <div>
                            <div className="font-medium text-dark-50 text-sm">{item.foodName}</div>
                            <div className="text-xs text-dark-400">{item.barcode}</div>
                          </div>
                          <Badge className={`text-xs ${
                            item.healthScore === 'A' ? 'bg-green-500/20 text-green-400' :
                            item.healthScore === 'B' ? 'bg-blue-500/20 text-blue-400' :
                            item.healthScore === 'C' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {item.healthScore}
                          </Badge>
                        </div>
                      ))}
                    </div>
                    <Button
                      onClick={() => {
                        toast({
                          title: "Shopping analysis complete!",
                          description: `${batchScans.filter(item => ['A', 'B'].includes(item.healthScore)).length} healthy items out of ${batchScans.length}`,
                        });
                      }}
                      className="w-full bg-secondary hover:bg-secondary/80"
                    >
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Analyze Shopping Cart
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="image">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50">Upload Food Image</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    disabled={isLoading}
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isLoading}
                    className="w-full bg-primary hover:bg-primary/80"
                    variant="outline"
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full mr-2" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Choose Image
                      </>
                    )}
                  </Button>
                  {selectedImage && (
                    <p className="text-sm text-dark-400 text-center">
                      Selected: {selectedImage.name}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Analysis Results */}
        {analysisResult && (
          <Card className="bg-dark-800 border-dark-700 mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-dark-50">{analysisResult.foodName}</CardTitle>
                <div className="flex items-center space-x-2">
                  <Badge className={`${getHealthScoreColor(analysisResult.healthScore)} text-white`}>
                    {analysisResult.healthScore} Grade
                  </Badge>
                  {analysisResult.isUltraProcessed && (
                    <Badge variant="destructive">Ultra-Processed</Badge>
                  )}
                </div>
              </div>
              {analysisResult.brandOwner && (
                <p className="text-dark-400">by {analysisResult.brandOwner}</p>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Confidence Score */}
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-dark-400">Analysis Confidence</span>
                  <span className="text-dark-50">{Math.round(analysisResult.confidence * 100)}%</span>
                </div>
                <Progress value={analysisResult.confidence * 100} className="h-2" />
              </div>

              {/* AI Coaching Message */}
              <div className="bg-dark-700 rounded-lg p-4">
                <div className="flex items-start">
                  <Lightbulb className="h-5 w-5 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <p className="text-dark-50 text-sm">{analysisResult.coachingMessage}</p>
                </div>
              </div>

              {/* Red Flags */}
              {analysisResult.redFlags.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-red-400 mb-2 flex items-center">
                    <AlertTriangle className="mr-1 h-4 w-4" />
                    Health Concerns
                  </h4>
                  <div className="space-y-1">
                    {analysisResult.redFlags.map((flag, index) => (
                      <div key={index} className="text-sm text-red-300 bg-red-900/20 rounded px-2 py-1">
                        • {flag}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recommendations */}
              {analysisResult.recommendations.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-green-400 mb-2 flex items-center">
                    <CheckCircle className="mr-1 h-4 w-4" />
                    Healthier Alternatives
                  </h4>
                  <div className="space-y-1">
                    {analysisResult.recommendations.map((rec, index) => (
                      <div key={index} className="text-sm text-green-300 bg-green-900/20 rounded px-2 py-1">
                        • {rec}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Nutrition Facts */}
              {analysisResult.nutritionFacts && (
                <div>
                  <h4 className="text-sm font-semibold text-dark-50 mb-2">Nutrition Facts</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {analysisResult.nutritionFacts.calories && (
                      <div className="flex justify-between">
                        <span className="text-dark-400">Calories:</span>
                        <span className="text-dark-50">{analysisResult.nutritionFacts.calories}</span>
                      </div>
                    )}
                    {analysisResult.nutritionFacts.totalSugars && (
                      <div className="flex justify-between">
                        <span className="text-dark-400">Total Sugar:</span>
                        <span className="text-dark-50">{analysisResult.nutritionFacts.totalSugars}g</span>
                      </div>
                    )}
                    {analysisResult.nutritionFacts.addedSugars && (
                      <div className="flex justify-between">
                        <span className="text-dark-400">Added Sugar:</span>
                        <span className="text-dark-50">{analysisResult.nutritionFacts.addedSugars}g</span>
                      </div>
                    )}
                    {analysisResult.nutritionFacts.sodium && (
                      <div className="flex justify-between">
                        <span className="text-dark-400">Sodium:</span>
                        <span className="text-dark-50">{analysisResult.nutritionFacts.sodium}mg</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Ingredients */}
              {analysisResult.ingredients && analysisResult.ingredients.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-dark-50 mb-2">Ingredients</h4>
                  <p className="text-sm text-dark-300 bg-dark-700 rounded p-2">
                    {analysisResult.ingredients.join(', ')}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* AR Scanner Modal */}
      {showARScanner && (
        <ARFoodScanner
          onClose={() => setShowARScanner(false)}
          onAnalysisComplete={(data) => {
            setAnalysisResult({
              ...data,
              ingredients: [],
              nutritionFacts: {
                calories: data.calories,
                totalSugars: data.sugar,
              },
              brandOwner: '',
              recommendations: [],
              coachingMessage: `Great! I detected ${data.foodName}. This food has a health grade of ${data.healthScore}.`
            });
            setShowARScanner(false);
            queryClient.invalidateQueries({ queryKey: ["/api/food-analyses"] });
            queryClient.invalidateQueries({ queryKey: ["/api/scan-usage"] });
          }}
        />
      )}
    </div>
  );
}