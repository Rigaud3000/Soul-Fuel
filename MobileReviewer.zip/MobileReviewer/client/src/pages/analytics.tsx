import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  ArrowLeft, 
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Activity,
  Target,
  Calendar,
  Brain,
  Heart,
  Zap,
  AlertTriangle
} from "lucide-react";

export default function AdvancedAnalytics() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Fetch analytics data
  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
    enabled: !!user,
  });

  // Mock advanced analytics data
  const advancedMetrics = {
    healthScore: 78,
    trendDirection: 'up',
    weeklyImprovement: 12,
    predictedOutcome: 'Excellent progress toward sugar-free lifestyle',
    riskFactors: [
      { name: 'Weekend Patterns', risk: 'medium', confidence: 85 },
      { name: 'Stress Eating', risk: 'low', confidence: 72 },
      { name: 'Social Triggers', risk: 'high', confidence: 91 }
    ],
    behavioralInsights: [
      {
        category: 'Timing Patterns',
        insight: 'You have 73% fewer cravings when you eat protein within 1 hour of waking',
        actionable: true,
        impact: 'high'
      },
      {
        category: 'Environmental Cues',
        insight: 'Kitchen visits after 8 PM correlate with 89% of sugar consumption episodes',
        actionable: true,
        impact: 'medium'
      },
      {
        category: 'Emotional States',
        insight: 'Mood scores below 6/10 predict sugar cravings within 2-3 hours with 82% accuracy',
        actionable: true,
        impact: 'high'
      }
    ],
    healthPredictions: {
      next7Days: {
        cravingIntensity: 'low',
        energyLevels: 'stable',
        moodStability: 'improving',
        weightTrend: 'slight decrease'
      },
      next30Days: {
        habitStrength: 'strong',
        riskOfRelapse: 'very low',
        expectedMilestones: ['30-day sugar-free streak', 'Stable energy patterns']
      }
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to view analytics</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-7xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            size="sm"
            className="text-dark-400 hover:text-dark-200"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <BarChart3 className="h-8 w-8 text-primary" />
            Advanced Analytics Dashboard
          </h1>
          <p className="text-dark-400">Comprehensive health insights and predictions powered by AI</p>
        </div>

        {/* Health Score Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-dark-800 border-dark-700 md:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                Overall Health Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="text-4xl font-bold text-primary">{advancedMetrics.healthScore}</div>
                <div className="flex items-center gap-2">
                  {advancedMetrics.trendDirection === 'up' ? (
                    <TrendingUp className="h-5 w-5 text-green-400" />
                  ) : (
                    <TrendingDown className="h-5 w-5 text-red-400" />
                  )}
                  <span className="text-green-400">+{advancedMetrics.weeklyImprovement}% this week</span>
                </div>
              </div>
              <Progress value={advancedMetrics.healthScore} className="h-3 mb-4" />
              <p className="text-dark-300 text-sm">{advancedMetrics.predictedOutcome}</p>
            </CardContent>
          </Card>

          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-4 text-center">
              <Activity className="h-8 w-8 text-blue-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-400">92%</div>
              <div className="text-sm text-dark-400">Pattern Recognition</div>
            </CardContent>
          </Card>

          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-4 text-center">
              <Brain className="h-8 w-8 text-purple-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-400">87%</div>
              <div className="text-sm text-dark-400">Prediction Accuracy</div>
            </CardContent>
          </Card>
        </div>

        {/* Risk Factors Analysis */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-400" />
              Risk Factor Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {advancedMetrics.riskFactors.map((factor, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
                  <div>
                    <h4 className="font-medium text-dark-50">{factor.name}</h4>
                    <p className="text-dark-400 text-sm">{factor.confidence}% confidence level</p>
                  </div>
                  <Badge className={`${
                    factor.risk === 'high' ? 'bg-red-500/20 text-red-400' :
                    factor.risk === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    {factor.risk} risk
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Behavioral Insights */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <Brain className="h-5 w-5 text-primary" />
              AI-Powered Behavioral Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {advancedMetrics.behavioralInsights.map((insight, index) => (
                <div key={index} className="border-l-4 border-primary pl-4">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-dark-50">{insight.category}</h4>
                    <div className="flex gap-2">
                      <Badge className={`${
                        insight.impact === 'high' ? 'bg-red-500/20 text-red-400' :
                        insight.impact === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>
                        {insight.impact} impact
                      </Badge>
                      {insight.actionable && (
                        <Badge className="bg-green-500/20 text-green-400">
                          Actionable
                        </Badge>
                      )}
                    </div>
                  </div>
                  <p className="text-dark-300">{insight.insight}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Predictions Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-dark-800 border-dark-700">
            <CardHeader>
              <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-400" />
                7-Day Predictions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-dark-300">Craving Intensity</span>
                  <Badge className="bg-green-500/20 text-green-400">
                    {advancedMetrics.healthPredictions.next7Days.cravingIntensity}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-dark-300">Energy Levels</span>
                  <Badge className="bg-blue-500/20 text-blue-400">
                    {advancedMetrics.healthPredictions.next7Days.energyLevels}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-dark-300">Mood Stability</span>
                  <Badge className="bg-purple-500/20 text-purple-400">
                    {advancedMetrics.healthPredictions.next7Days.moodStability}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-dark-300">Weight Trend</span>
                  <Badge className="bg-yellow-500/20 text-yellow-400">
                    {advancedMetrics.healthPredictions.next7Days.weightTrend}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-dark-800 border-dark-700">
            <CardHeader>
              <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-400" />
                30-Day Outlook
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-dark-50 mb-2">Habit Strength</h4>
                  <div className="flex items-center gap-2">
                    <Progress value={95} className="flex-1" />
                    <span className="text-green-400 text-sm">Strong</span>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-dark-50 mb-2">Relapse Risk</h4>
                  <div className="flex items-center gap-2">
                    <Progress value={15} className="flex-1" />
                    <span className="text-green-400 text-sm">Very Low</span>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-dark-50 mb-2">Expected Milestones</h4>
                  <div className="space-y-2">
                    {advancedMetrics.healthPredictions.next30Days.expectedMilestones.map((milestone, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-dark-300">
                        <Target className="h-3 w-3 text-primary" />
                        {milestone}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Data Sources & Methodology */}
        <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <PieChart className="h-6 w-6 text-primary mt-1" />
              <div>
                <h3 className="text-lg font-semibold text-dark-50 mb-2">Advanced Analytics Methodology</h3>
                <p className="text-dark-300 text-sm mb-3">
                  Our AI analyzes over 47 data points including food logs, mood patterns, sleep quality, 
                  activity levels, and environmental factors to generate personalized insights and predictions.
                </p>
                <div className="grid md:grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">47+</div>
                    <div className="text-xs text-dark-400">Data Points</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-secondary">ML</div>
                    <div className="text-xs text-dark-400">Machine Learning</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">24/7</div>
                    <div className="text-xs text-dark-400">Continuous Analysis</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}