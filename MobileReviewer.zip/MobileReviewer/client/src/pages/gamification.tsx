import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Trophy, 
  Crown, 
  Flame,
  Target,
  Star,
  Award,
  TrendingUp,
  Calendar,
  Zap,
  Shield,
  Heart,
  Leaf,
  CheckCircle
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface UserStats {
  level: number;
  currentXP: number;
  xpToNext: number;
  totalXP: number;
  currentStreak: number;
  longestStreak: number;
  sugarFreeDays: number;
  badges: Badge[];
  rank: number;
  totalUsers: number;
}

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: string;
  progress?: number;
  target?: number;
}

interface LeaderboardEntry {
  rank: number;
  username: string;
  level: number;
  xp: number;
  streak: number;
  badges: number;
  isCurrentUser?: boolean;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  badgeReward?: string;
  isCompleted: boolean;
  progress: number;
  target: number;
  category: 'streak' | 'sugar-free' | 'community' | 'learning' | 'health';
}

export default function Gamification() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch user stats
  const { data: userStats } = useQuery({
    queryKey: ["/api/gamification/stats"],
    queryFn: async () => {
      return {
        level: 12,
        currentXP: 750,
        xpToNext: 250,
        totalXP: 2750,
        currentStreak: 18,
        longestStreak: 25,
        sugarFreeDays: 45,
        badges: [
          { id: 'first-week', name: 'First Week', description: '7 days sugar-free', icon: 'calendar', rarity: 'common' as const, unlockedAt: '2024-12-01' },
          { id: 'streak-master', name: 'Streak Master', description: '21 day streak', icon: 'fire', rarity: 'rare' as const, unlockedAt: '2024-12-15' },
          { id: 'community-helper', name: 'Community Helper', description: 'Helped 10 people', icon: 'heart', rarity: 'epic' as const, unlockedAt: '2024-12-20' }
        ],
        rank: 23,
        totalUsers: 1247
      } as UserStats;
    },
  });

  // Fetch leaderboard
  const { data: leaderboard = [] } = useQuery({
    queryKey: ["/api/gamification/leaderboard"],
    queryFn: async () => {
      return [
        { rank: 1, username: "HealthWarrior", level: 28, xp: 8950, streak: 45, badges: 12, isCurrentUser: false },
        { rank: 2, username: "SugarSlayer", level: 25, xp: 7200, streak: 38, badges: 10, isCurrentUser: false },
        { rank: 3, username: "WellnessQueen", level: 23, xp: 6800, streak: 41, badges: 9, isCurrentUser: false },
        { rank: 22, username: "CleanEater92", level: 13, xp: 2950, streak: 19, badges: 6, isCurrentUser: false },
        { rank: 23, username: "You", level: 12, xp: 2750, streak: 18, badges: 5, isCurrentUser: true },
        { rank: 24, username: "HealthyLife", level: 12, xp: 2600, streak: 15, badges: 4, isCurrentUser: false }
      ] as LeaderboardEntry[];
    },
  });

  // Fetch achievements
  const { data: achievements = [] } = useQuery({
    queryKey: ["/api/gamification/achievements"],
    queryFn: async () => {
      return [
        {
          id: 'sugar-free-30',
          title: '30 Days Strong',
          description: 'Go 30 days without added sugar',
          xpReward: 500,
          badgeReward: 'Sugar Slayer',
          isCompleted: false,
          progress: 18,
          target: 30,
          category: 'streak' as const
        },
        {
          id: 'whole-foods-week',
          title: 'Whole Foods Week',
          description: 'Eat only whole foods for 7 days',
          xpReward: 200,
          badgeReward: 'Whole Food Hero',
          isCompleted: false,
          progress: 3,
          target: 7,
          category: 'health' as const
        },
        {
          id: 'community-posts',
          title: 'Community Contributor',
          description: 'Share 10 helpful posts in the community',
          xpReward: 300,
          badgeReward: 'Community Star',
          isCompleted: false,
          progress: 4,
          target: 10,
          category: 'community' as const
        },
        {
          id: 'scan-foods',
          title: 'Food Detective',
          description: 'Scan 50 food items',
          xpReward: 250,
          badgeReward: 'Food Scanner',
          isCompleted: true,
          progress: 50,
          target: 50,
          category: 'learning' as const
        }
      ] as Achievement[];
    },
  });

  const getBadgeIcon = (iconName: string) => {
    const icons = {
      calendar: Calendar,
      fire: Flame,
      heart: Heart,
      star: Star,
      shield: Shield,
      leaf: Leaf,
      target: Target,
      award: Award
    };
    return icons[iconName] || Award;
  };

  const getBadgeColor = (rarity: string) => {
    const colors = {
      common: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
      rare: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      epic: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      legendary: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
    };
    return colors[rarity] || colors.common;
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      streak: Flame,
      'sugar-free': Target,
      community: Heart,
      learning: Star,
      health: Leaf
    };
    return icons[category] || Target;
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      streak: 'text-orange-400',
      'sugar-free': 'text-red-400',
      community: 'text-blue-400',
      learning: 'text-purple-400',
      health: 'text-green-400'
    };
    return colors[category] || 'text-gray-400';
  };

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Your Progress</h2>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 bg-dark-800 mb-6">
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary text-xs">
              Overview
            </TabsTrigger>
            <TabsTrigger value="badges" className="data-[state=active]:bg-primary text-xs">
              Badges
            </TabsTrigger>
            <TabsTrigger value="achievements" className="data-[state=active]:bg-primary text-xs">
              Goals
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="data-[state=active]:bg-primary text-xs">
              Leaderboard
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {userStats && (
              <>
                {/* Level and XP */}
                <Card className="bg-gradient-to-r from-primary/20 to-blue-600/20 border-primary/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center">
                        <div className="bg-primary/20 p-3 rounded-full mr-4">
                          <Crown className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-dark-50">Level {userStats.level}</h3>
                          <p className="text-dark-300">{userStats.currentXP} / {userStats.currentXP + userStats.xpToNext} XP</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">{userStats.totalXP}</p>
                        <p className="text-dark-400 text-sm">Total XP</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-dark-400">Progress to Level {userStats.level + 1}</span>
                        <span className="text-dark-50">{userStats.xpToNext} XP needed</span>
                      </div>
                      <Progress 
                        value={(userStats.currentXP / (userStats.currentXP + userStats.xpToNext)) * 100} 
                        className="h-2" 
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-dark-800 border-dark-700">
                    <CardContent className="p-4 text-center">
                      <div className="bg-orange-500/20 p-3 rounded-full w-fit mx-auto mb-2">
                        <Flame className="h-6 w-6 text-orange-400" />
                      </div>
                      <p className="text-2xl font-bold text-dark-50">{userStats.currentStreak}</p>
                      <p className="text-dark-400 text-sm">Current Streak</p>
                      <p className="text-orange-400 text-xs mt-1">Best: {userStats.longestStreak} days</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-dark-800 border-dark-700">
                    <CardContent className="p-4 text-center">
                      <div className="bg-green-500/20 p-3 rounded-full w-fit mx-auto mb-2">
                        <Target className="h-6 w-6 text-green-400" />
                      </div>
                      <p className="text-2xl font-bold text-dark-50">{userStats.sugarFreeDays}</p>
                      <p className="text-dark-400 text-sm">Sugar-Free Days</p>
                      <p className="text-green-400 text-xs mt-1">Total achieved</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-dark-800 border-dark-700">
                    <CardContent className="p-4 text-center">
                      <div className="bg-purple-500/20 p-3 rounded-full w-fit mx-auto mb-2">
                        <Award className="h-6 w-6 text-purple-400" />
                      </div>
                      <p className="text-2xl font-bold text-dark-50">{userStats.badges.length}</p>
                      <p className="text-dark-400 text-sm">Badges Earned</p>
                      <p className="text-purple-400 text-xs mt-1">Keep collecting!</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-dark-800 border-dark-700">
                    <CardContent className="p-4 text-center">
                      <div className="bg-blue-500/20 p-3 rounded-full w-fit mx-auto mb-2">
                        <TrendingUp className="h-6 w-6 text-blue-400" />
                      </div>
                      <p className="text-2xl font-bold text-dark-50">#{userStats.rank}</p>
                      <p className="text-dark-400 text-sm">Global Rank</p>
                      <p className="text-blue-400 text-xs mt-1">of {userStats.totalUsers} users</p>
                    </CardContent>
                  </Card>
                </div>
              </>
            )}
          </TabsContent>

          <TabsContent value="badges" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {userStats?.badges.map((badge) => {
                const Icon = getBadgeIcon(badge.icon);
                return (
                  <Card key={badge.id} className={`border ${getBadgeColor(badge.rarity)}`}>
                    <CardContent className="p-4 text-center">
                      <div className="bg-primary/20 p-3 rounded-full w-fit mx-auto mb-3">
                        <Icon className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-dark-50 font-semibold mb-1">{badge.name}</h3>
                      <p className="text-dark-400 text-xs mb-2">{badge.description}</p>
                      <Badge className={getBadgeColor(badge.rarity)}>
                        {badge.rarity}
                      </Badge>
                      {badge.unlockedAt && (
                        <p className="text-dark-500 text-xs mt-2">
                          Unlocked {new Date(badge.unlockedAt).toLocaleDateString()}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-4">
            {achievements.map((achievement) => {
              const Icon = getCategoryIcon(achievement.category);
              const progressPercentage = (achievement.progress / achievement.target) * 100;
              
              return (
                <Card key={achievement.id} className="bg-dark-800 border-dark-700">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center">
                        <div className="bg-primary/20 p-2 rounded-lg mr-3">
                          <Icon className={`h-5 w-5 ${getCategoryColor(achievement.category)}`} />
                        </div>
                        <div>
                          <h3 className="text-dark-50 font-semibold">{achievement.title}</h3>
                          <p className="text-dark-400 text-sm">{achievement.description}</p>
                        </div>
                      </div>
                      {achievement.isCompleted && (
                        <CheckCircle className="h-5 w-5 text-green-400" />
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-dark-400">Progress</span>
                        <span className="text-dark-50">
                          {achievement.progress} / {achievement.target}
                        </span>
                      </div>
                      <Progress value={progressPercentage} className="h-2" />
                    </div>
                    
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center text-dark-400 text-sm">
                        <Zap className="mr-1 h-4 w-4" />
                        {achievement.xpReward} XP
                      </div>
                      {achievement.badgeReward && (
                        <div className="flex items-center text-dark-400 text-sm">
                          <Award className="mr-1 h-4 w-4" />
                          {achievement.badgeReward}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-4">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-dark-50 flex items-center">
                  <Trophy className="mr-2 h-5 w-5 text-yellow-400" />
                  Global Leaderboard
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {leaderboard.map((entry, index) => (
                  <div 
                    key={entry.rank} 
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      entry.isCurrentUser ? 'bg-primary/20 border border-primary/30' : 'bg-dark-700'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                        entry.rank <= 3 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-dark-600 text-dark-300'
                      }`}>
                        {entry.rank <= 3 ? (
                          <Crown className="h-4 w-4" />
                        ) : (
                          <span className="text-sm font-bold">#{entry.rank}</span>
                        )}
                      </div>
                      <div>
                        <p className={`font-semibold ${entry.isCurrentUser ? 'text-primary' : 'text-dark-50'}`}>
                          {entry.username}
                        </p>
                        <div className="flex items-center text-dark-400 text-sm">
                          <span>Level {entry.level}</span>
                          <span className="mx-2">•</span>
                          <span>{entry.streak} day streak</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-dark-50 font-semibold">{entry.xp.toLocaleString()} XP</p>
                      <p className="text-dark-400 text-sm">{entry.badges} badges</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}