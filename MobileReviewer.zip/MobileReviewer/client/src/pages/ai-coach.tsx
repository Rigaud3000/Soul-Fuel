import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useAuthenticatedRequest } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Send, Bot, Crown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const coachTypes = [
  {
    id: 'fitness',
    name: 'Fitness Coach',
    icon: '💪',
    description: 'Exercise, workouts & fitness goals',
    color: 'bg-red-500',
    suggestions: [
      "Plan my workout routine",
      "I'm feeling lazy to exercise",
      "Post-workout meal advice",
      "How to stay motivated?"
    ]
  },
  {
    id: 'eating',
    name: 'Eating Coach',
    icon: '🥗',
    description: 'Healthy eating & nutrition habits',
    color: 'bg-green-500',
    suggestions: [
      "I'm craving junk food",
      "What should I eat today?",
      "I broke my diet",
      "Healthy snack ideas"
    ]
  },
  {
    id: 'shopping',
    name: 'Shopping Coach',
    icon: '🛒',
    description: 'Smart grocery shopping & meal prep',
    color: 'bg-blue-500',
    suggestions: [
      "Help me make a shopping list",
      "Budget-friendly healthy foods",
      "How to read food labels?",
      "Meal prep for the week"
    ]
  },
  {
    id: 'mindset',
    name: 'Mindset Coach',
    icon: '🧠',
    description: 'Mental health & emotional eating',
    color: 'bg-purple-500',
    suggestions: [
      "I'm stress eating",
      "Boost my confidence",
      "Breaking bad habits",
      "Mindful eating tips"
    ]
  },
  {
    id: 'wellness',
    name: 'Wellness Coach',
    icon: '🌟',
    description: 'Sleep, hydration & lifestyle balance',
    color: 'bg-yellow-500',
    suggestions: [
      "Better sleep for health",
      "Daily wellness routine",
      "Staying hydrated",
      "Work-life balance tips"
    ]
  },
  {
    id: 'recovery',
    name: 'Recovery Coach',
    icon: '🎯',
    description: 'Addiction recovery & sugar detox',
    color: 'bg-pink-500',
    suggestions: [
      "Sugar withdrawal help",
      "I'm having cravings",
      "Recovery motivation",
      "Breaking food addiction"
    ]
  }
];

export default function AICoach() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { getAuthHeaders } = useAuthenticatedRequest();
  const [message, setMessage] = useState("");
  const [selectedCoach, setSelectedCoach] = useState<any>(null);
  const [showCoachSelection, setShowCoachSelection] = useState(true);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: aiStatus } = useQuery({
    queryKey: ["/api/ai-coaching-status"],
    queryFn: async () => {
      const response = await fetch("/api/ai-coaching-status", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch AI status");
      return response.json();
    },
  });

  const { data: chatHistory, isLoading } = useQuery({
    queryKey: ["/api/chat-history", selectedCoach?.id],
    queryFn: async () => {
      const coachType = selectedCoach?.id || '';
      const url = coachType ? `/api/chat-history?coachType=${coachType}` : '/api/chat-history';
      const response = await fetch(url, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch chat history");
      return response.json();
    },
    enabled: Boolean((aiStatus?.canUseAI || user?.subscriptionTier === 'pro') && selectedCoach),
  });

  const sendMessageMutation = useMutation({
    mutationFn: (message: string) => {
      const coachContext = selectedCoach ? `As a ${selectedCoach.name.toLowerCase()}, ` : "";
      const fullMessage = coachContext + message;
      return apiRequest("POST", "/api/ai-chat", { 
        message: fullMessage,
        coachType: selectedCoach?.id || 'general'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat-history", selectedCoach?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/ai-coaching-status"] });
      setMessage("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    if (!aiStatus?.canUseAI) {
      toast({
        title: "Weekly Service Limit Reached",
        description: "You have used all 4 free services this week. Upgrade to Pro for unlimited access.",
        variant: "destructive",
      });
      return;
    }
    
    sendMessageMutation.mutate(message);
  };

  const handleQuickSuggestion = (suggestion: string) => {
    if (!aiStatus?.canUseAI) {
      toast({
        title: "Weekly Service Limit Reached",
        description: "You have used all 4 free services this week. Upgrade to Pro for unlimited access.",
        variant: "destructive",
      });
      return;
    }
    
    sendMessageMutation.mutate(suggestion);
  };

  const selectCoach = (coach: any) => {
    setSelectedCoach(coach);
    setShowCoachSelection(false);
  };

  const changeCoach = () => {
    setSelectedCoach(null);
    setShowCoachSelection(true);
  };

  // Show upgrade banner for free tier users who have used all sessions
  const showUpgradeBanner = user?.subscriptionTier === 'free' && !aiStatus?.canUseAI;

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => showCoachSelection ? setLocation("/") : changeCoach()}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">
            {showCoachSelection ? "AI Coach" : selectedCoach?.name}
          </h2>
          {user?.subscriptionTier === 'free' && !showCoachSelection && (
            <div className="ml-auto text-right">
              <div className="text-xs text-dark-400">
                {aiStatus?.sessionsRemaining !== undefined && aiStatus.sessionsRemaining >= 0
                  ? `${aiStatus.sessionsRemaining}/4 free services left`
                  : 'Loading...'}
              </div>
            </div>
          )}
        </div>

        {/* Coach Selection Screen */}
        {showCoachSelection && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h3 className="text-xl font-semibold text-dark-50 mb-2">Choose Your AI Coach</h3>
              <p className="text-dark-400 text-sm">Select the type of coaching you need today</p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {coachTypes.map((coach) => (
                <Card
                  key={coach.id}
                  onClick={() => selectCoach(coach)}
                  className="bg-dark-800 border border-dark-700 rounded-xl p-4 cursor-pointer hover:bg-dark-700 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 ${coach.color} rounded-full flex items-center justify-center text-2xl`}>
                      {coach.icon}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold text-dark-50">{coach.name}</h4>
                      <p className="text-sm text-dark-400">{coach.description}</p>
                    </div>
                    <div className="text-dark-400">
                      <ArrowLeft className="rotate-180" size={20} />
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Chat Interface */}
        {!showCoachSelection && selectedCoach && (
          <div className="space-y-6">
            {/* Selected Coach Info */}
            <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 ${selectedCoach.color} rounded-full flex items-center justify-center text-xl`}>
                  {selectedCoach.icon}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-dark-50">{selectedCoach.name}</h4>
                  <p className="text-xs text-dark-400">{selectedCoach.description}</p>
                </div>
                <Button
                  onClick={changeCoach}
                  variant="ghost"
                  className="text-dark-400 text-xs px-3 py-1"
                >
                  Change
                </Button>
              </div>
            </Card>

            {/* Upgrade Banner for Free Users Who Used All Sessions */}
            {showUpgradeBanner && (
              <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
                <div className="flex items-center space-x-4">
                  <Crown className="w-8 h-8 text-yellow-500 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="text-sm font-semibold text-dark-50">Free Sessions Used</h3>
                    <p className="text-xs text-dark-400">
                      You've used all 3 free AI coaching sessions. Upgrade to Pro for unlimited access.
                    </p>
                  </div>
                  <Button 
                    onClick={() => setLocation('/subscription')}
                    className="bg-primary hover:bg-primary/80 text-white px-4 py-2 text-sm"
                  >
                    Upgrade
                  </Button>
                </div>
              </Card>
            )}

            {/* Chat Messages */}
            <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
              {/* Welcome Message */}
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 ${selectedCoach.color} rounded-full flex items-center justify-center flex-shrink-0 text-lg`}>
                  {selectedCoach.icon}
                </div>
                <Card className="bg-dark-800 border border-dark-700 rounded-xl p-3 max-w-xs">
                  <p className="text-sm text-dark-50">
                    Hello! I'm your {selectedCoach.name.toLowerCase()}. I'm here to help you with {selectedCoach.description.toLowerCase()}. How can I assist you today?
                  </p>
                </Card>
              </div>

              {/* Chat History */}
              {isLoading ? (
                <div className="text-center text-dark-400">Loading chat history...</div>
              ) : (
                chatHistory?.map((chat: any) => (
                  <div key={chat.id} className="space-y-3">
                    {/* User Message */}
                    <div className="flex justify-end">
                      <Card className="bg-primary text-white rounded-xl p-3 max-w-xs">
                        <p className="text-sm">{chat.message}</p>
                      </Card>
                    </div>
                    
                    {/* AI Response */}
                    <div className="flex items-start space-x-3">
                      <div className={`w-8 h-8 ${selectedCoach.color} rounded-full flex items-center justify-center flex-shrink-0 text-lg`}>
                        {selectedCoach.icon}
                      </div>
                      <Card className="bg-dark-800 border border-dark-700 rounded-xl p-3 max-w-xs">
                        <p className="text-sm text-dark-50">{chat.response}</p>
                      </Card>
                    </div>
                  </div>
                ))
              )}

              {/* Current Response */}
              {sendMessageMutation.isPending && (
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 ${selectedCoach.color} rounded-full flex items-center justify-center flex-shrink-0 text-lg`}>
                    {selectedCoach.icon}
                  </div>
                  <Card className="bg-dark-800 border border-dark-700 rounded-xl p-3 max-w-xs">
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
                      <span className="text-sm text-dark-400">Thinking...</span>
                    </div>
                  </Card>
                </div>
              )}
            </div>

            {/* Quick Suggestions */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              {selectedCoach.suggestions.map((suggestion: string, index: number) => (
                <Button
                  key={index}
                  onClick={() => handleQuickSuggestion(suggestion)}
                  disabled={sendMessageMutation.isPending}
                  className="bg-dark-800 border border-dark-700 rounded-xl p-3 text-sm text-left text-dark-50 hover:bg-dark-700 h-auto"
                  variant="ghost"
                >
                  "{suggestion}"
                </Button>
              ))}
            </div>

            {/* Message Input */}
            <form onSubmit={handleSubmit} className="flex space-x-3">
              <Input
                type="text"
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                disabled={sendMessageMutation.isPending}
                className="flex-1 p-3 bg-dark-800 border border-dark-700 rounded-xl text-dark-50 placeholder-dark-400 focus:border-primary"
              />
              <Button
                type="submit"
                disabled={sendMessageMutation.isPending || !message.trim()}
                className="w-12 h-12 bg-primary text-white rounded-xl flex items-center justify-center hover:bg-primary/90"
              >
                <Send size={20} />
              </Button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}