import { PredictiveWellness } from "@/components/predictive-wellness";

export default function PredictiveWellnessPage() {
  return <PredictiveWellness />;
}