import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Sparkles, Zap, Target, Users, TrendingUp, Brain, Heart, ShoppingCart, Calendar, Award, Bell } from "lucide-react";
import SoulFuelHeader from "@/components/soulfuel-header";

interface FeatureSuggestion {
  id: string;
  title: string;
  description: string;
  category: 'AI' | 'Social' | 'Health' | 'Shopping' | 'Gamification' | 'Analytics';
  impact: 'High' | 'Medium' | 'Low';
  effort: 'Quick' | 'Medium' | 'Complex';
  icon: any;
  benefits: string[];
  status: 'Suggested' | 'In Progress' | 'Completed';
}

const suggestions: FeatureSuggestion[] = [
  {
    id: 'offline-mode',
    title: 'Offline Mode & Sync',
    description: 'Work offline and sync data when connected. Cache recipes, AI insights, and allow tracking without internet',
    category: 'Analytics',
    impact: 'High',
    effort: 'Complex',
    icon: Zap,
    benefits: [
      'Works anywhere without internet',
      'Improved app performance',
      'Better user experience',
      'Data syncs when online'
    ],
    status: 'Suggested'
  },
  {
    id: 'voice-logging',
    title: 'Voice Food Logging',
    description: 'Say "I ate a banana" and AI logs your food automatically using speech recognition',
    category: 'AI',
    impact: 'High',
    effort: 'Medium',
    icon: Brain,
    benefits: [
      'Hands-free food logging',
      'Faster data entry',
      'Natural interaction',
      'Works while cooking'
    ],
    status: 'Suggested'
  },
  {
    id: 'barcode-batch',
    title: 'Batch Barcode Scanner',
    description: 'Scan multiple products at once during grocery shopping with smart product suggestions',
    category: 'Shopping',
    impact: 'Medium',
    effort: 'Quick',
    icon: ShoppingCart,
    benefits: [
      'Faster grocery scanning',
      'Smart shopping lists',
      'Healthier product discovery',
      'Time-saving workflows'
    ],
    status: 'Suggested'
  },
  {
    id: 'nutrition-trends',
    title: 'Advanced Analytics Dashboard',
    description: 'Comprehensive analytics with trends, correlations, and predictive insights about your health patterns',
    category: 'Analytics',
    impact: 'High',
    effort: 'Complex',
    icon: TrendingUp,
    benefits: [
      'Deep health insights',
      'Pattern recognition',
      'Data-driven decisions',
      'Progress visualization'
    ],
    status: 'Suggested'
  },
  {
    id: 'smart-meal-planning',
    title: 'AI Smart Meal Planning',
    description: 'AI-powered weekly meal plans based on your health goals, dietary restrictions, and preferences',
    category: 'AI',
    impact: 'High',
    effort: 'Medium',
    icon: Brain,
    benefits: [
      'Personalized nutrition recommendations',
      'Automatic grocery list generation',
      'Budget-friendly meal suggestions',
      'Reduces decision fatigue'
    ],
    status: 'Suggested'
  },
  {
    id: 'social-challenges',
    title: 'Community Challenges',
    description: 'Weekly group challenges like "Sugar-Free September" or "Whole Foods Week" with leaderboards',
    category: 'Social',
    impact: 'High',
    effort: 'Medium',
    icon: Users,
    benefits: [
      'Increased motivation through competition',
      'Community support and accountability',
      'Group achievement rewards',
      'Social proof for healthy choices'
    ],
    status: 'Suggested'
  },
  {
    id: 'health-predictions',
    title: 'Health Trend Predictions',
    description: 'AI predicts your energy levels, mood, and cravings based on eating patterns',
    category: 'AI',
    impact: 'High',
    effort: 'Complex',
    icon: TrendingUp,
    benefits: [
      'Proactive health management',
      'Personalized intervention timing',
      'Better understanding of food impact',
      'Preventive wellness approach'
    ],
    status: 'Suggested'
  },
  {
    id: 'smart-grocery',
    title: 'Smart Grocery Assistant',
    description: 'Scan barcodes while shopping to get instant health scores and better alternatives',
    category: 'Shopping',
    impact: 'High',
    effort: 'Quick',
    icon: ShoppingCart,
    benefits: [
      'Real-time shopping guidance',
      'Healthier product discovery',
      'Price comparison for healthy options',
      'Reduces impulse purchases'
    ],
    status: 'Suggested'
  },
  {
    id: 'biometric-integration',
    title: 'Wearable Integration',
    description: 'Connect with fitness trackers to correlate food choices with sleep, heart rate, and activity',
    category: 'Health',
    impact: 'High',
    effort: 'Complex',
    icon: Heart,
    benefits: [
      'Complete health picture',
      'Data-driven insights',
      'Automatic activity tracking',
      'Better habit correlation'
    ],
    status: 'Suggested'
  },
  {
    id: 'habit-streaks',
    title: 'Advanced Streak System',
    description: 'Multiple streak types: sugar-free days, whole food meals, water intake, exercise consistency',
    category: 'Gamification',
    impact: 'Medium',
    effort: 'Quick',
    icon: Award,
    benefits: [
      'Multiple motivation pathways',
      'Flexible goal setting',
      'Visual progress tracking',
      'Habit reinforcement'
    ],
    status: 'Suggested'
  },
  {
    id: 'smart-notifications',
    title: 'Intelligent Notifications',
    description: 'Context-aware reminders based on location, time, and past behavior patterns',
    category: 'AI',
    impact: 'Medium',
    effort: 'Medium',
    icon: Bell,
    benefits: [
      'Timely intervention',
      'Reduced notification fatigue',
      'Personalized timing',
      'Behavior change support'
    ],
    status: 'Suggested'
  },
  {
    id: 'meal-prep-planner',
    title: 'Meal Prep Calendar',
    description: 'Visual calendar for planning and tracking meal prep sessions with batch cooking suggestions',
    category: 'Health',
    impact: 'Medium',
    effort: 'Medium',
    icon: Calendar,
    benefits: [
      'Better meal preparation',
      'Time and money savings',
      'Consistent healthy eating',
      'Reduced food waste'
    ],
    status: 'Suggested'
  }
];

export default function SuggestionsPage() {
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedFeature, setSelectedFeature] = useState<FeatureSuggestion | null>(null);

  const categories = ['All', 'AI', 'Social', 'Health', 'Shopping', 'Gamification', 'Analytics'];
  
  const filteredSuggestions = selectedCategory === 'All' 
    ? suggestions 
    : suggestions.filter(s => s.category === selectedCategory);

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'High': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'Medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'Low': return 'bg-green-500/20 text-green-400 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getEffortColor = (effort: string) => {
    switch (effort) {
      case 'Quick': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'Medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'Complex': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'AI': return Brain;
      case 'Social': return Users;
      case 'Health': return Heart;
      case 'Shopping': return ShoppingCart;
      case 'Gamification': return Award;
      case 'Analytics': return TrendingUp;
      default: return Sparkles;
    }
  };

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <SoulFuelHeader 
            subtitle="Feature Suggestions" 
            showGreeting={false}
          />
        </div>

        {/* Feature Overview */}
        <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20 rounded-xl p-6 mb-6">
          <div className="flex items-center mb-4">
            <Sparkles className="mr-3 h-6 w-6 text-primary" />
            <h2 className="text-xl font-bold text-dark-50">Exciting New Features Coming Soon</h2>
          </div>
          <p className="text-dark-300 mb-4">
            Based on user feedback and wellness trends, here are powerful new features we can add to SOULFUEL.
            Each feature is designed to enhance your health journey with cutting-edge technology.
          </p>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{suggestions.length}</div>
              <div className="text-sm text-dark-400">Total Features</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-secondary">{suggestions.filter(s => s.impact === 'High').length}</div>
              <div className="text-sm text-dark-400">High Impact</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-accent">{suggestions.filter(s => s.effort === 'Quick').length}</div>
              <div className="text-sm text-dark-400">Quick Wins</div>
            </div>
          </div>
        </Card>

        {/* Category Filter */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {categories.map((category) => {
            const Icon = getCategoryIcon(category);
            return (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                variant={selectedCategory === category ? "default" : "outline"}
                className={`flex items-center gap-2 whitespace-nowrap ${
                  selectedCategory === category 
                    ? 'bg-primary text-white' 
                    : 'border-dark-600 text-dark-300 hover:bg-dark-700'
                }`}
              >
                <Icon size={16} />
                {category}
              </Button>
            );
          })}
        </div>

        {/* Feature Grid */}
        <div className="grid gap-4">
          {filteredSuggestions.map((suggestion) => {
            const Icon = suggestion.icon;
            return (
              <Card 
                key={suggestion.id}
                className="bg-dark-800 border-dark-700 hover:border-primary/50 transition-all cursor-pointer"
                onClick={() => setSelectedFeature(suggestion)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-primary/20">
                        <Icon size={24} className="text-primary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-dark-50">{suggestion.title}</h3>
                        <p className="text-sm text-dark-400">{suggestion.category}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Badge className={getImpactColor(suggestion.impact)}>
                        {suggestion.impact} Impact
                      </Badge>
                      <Badge className={getEffortColor(suggestion.effort)}>
                        {suggestion.effort}
                      </Badge>
                    </div>
                  </div>
                  
                  <p className="text-dark-300 mb-4">{suggestion.description}</p>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-dark-50">Key Benefits:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {suggestion.benefits.slice(0, 4).map((benefit, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Zap size={12} className="text-primary" />
                          <span className="text-xs text-dark-400">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full mt-4 bg-primary/20 hover:bg-primary/30 text-primary border-primary/30"
                    variant="outline"
                  >
                    View Details
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Feature Detail Modal */}
        {selectedFeature && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-lg bg-primary/20">
                      <selectedFeature.icon size={32} className="text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-xl text-dark-50">{selectedFeature.title}</CardTitle>
                      <p className="text-dark-400">{selectedFeature.category} Feature</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => setSelectedFeature(null)}
                    variant="ghost"
                    size="sm"
                    className="text-dark-400"
                  >
                    ✕
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-dark-50 mb-2">Description</h3>
                    <p className="text-dark-300">{selectedFeature.description}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-dark-50 mb-2">Impact Level</h4>
                      <Badge className={getImpactColor(selectedFeature.impact)}>
                        {selectedFeature.impact} Impact
                      </Badge>
                    </div>
                    <div>
                      <h4 className="font-medium text-dark-50 mb-2">Development Effort</h4>
                      <Badge className={getEffortColor(selectedFeature.effort)}>
                        {selectedFeature.effort} to Build
                      </Badge>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-dark-50 mb-3">Key Benefits</h3>
                    <div className="space-y-2">
                      {selectedFeature.benefits.map((benefit, index) => (
                        <div key={index} className="flex items-center gap-3">
                          <Zap size={16} className="text-primary" />
                          <span className="text-dark-300">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <Button className="flex-1 bg-primary hover:bg-primary/80">
                      Request This Feature
                    </Button>
                    <Button variant="outline" className="flex-1 border-dark-600 text-dark-300">
                      Share Feedback
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}