import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Brain, 
  Zap, 
  Heart,
  Activity,
  Clock,
  TrendingUp,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface WithdrawalSymptom {
  id: number;
  symptomType: 'craving' | 'mood' | 'energy' | 'physical';
  intensity: number;
  description: string;
  duration?: number;
  triggers?: string[];
  copingStrategies?: string[];
  timestamp: string;
}

const SYMPTOM_TYPES = [
  { id: 'craving', label: 'Craving', icon: Brain, color: 'text-orange-400' },
  { id: 'mood', label: 'Mood Changes', icon: Heart, color: 'text-blue-400' },
  { id: 'energy', label: 'Energy Levels', icon: Zap, color: 'text-yellow-400' },
  { id: 'physical', label: 'Physical Symptoms', icon: Activity, color: 'text-red-400' }
];

const COMMON_SYMPTOMS = {
  craving: [
    'Sugar cravings',
    'Junk food thoughts',
    'Intense hunger',
    'Food fantasies',
    'Urges to eat processed food'
  ],
  mood: [
    'Irritability',
    'Anxiety',
    'Mood swings',
    'Feeling depressed',
    'Restlessness'
  ],
  energy: [
    'Fatigue',
    'Energy crashes',
    'Difficulty concentrating',
    'Mental fog',
    'Lack of motivation'
  ],
  physical: [
    'Headaches',
    'Nausea',
    'Digestive issues',
    'Sleep problems',
    'Muscle aches'
  ]
};

export default function WithdrawalTracker() {
  const [, setLocation] = useLocation();
  const [selectedType, setSelectedType] = useState<'craving' | 'mood' | 'energy' | 'physical'>('craving');
  const [intensity, setIntensity] = useState([5]);
  const [description, setDescription] = useState("");
  const [duration, setDuration] = useState("");
  const [triggers, setTriggers] = useState("");
  const [copingStrategies, setCopingStrategies] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch withdrawal symptoms
  const { data: symptoms = [] } = useQuery({
    queryKey: ["/api/withdrawal-symptoms"],
    queryFn: async () => {
      const response = await fetch("/api/withdrawal-symptoms");
      if (!response.ok) throw new Error("Failed to fetch symptoms");
      return response.json();
    },
  });

  // Add withdrawal symptom mutation
  const addSymptomMutation = useMutation({
    mutationFn: async (symptomData: any) => {
      return apiRequest("POST", "/api/withdrawal-symptoms", symptomData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/withdrawal-symptoms"] });
      toast({
        title: "Symptom logged",
        description: "Your withdrawal symptom has been recorded.",
      });
      // Reset form
      setIntensity([5]);
      setDescription("");
      setDuration("");
      setTriggers("");
      setCopingStrategies("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to log symptom",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      toast({
        title: "Missing information",
        description: "Please describe your symptom",
        variant: "destructive",
      });
      return;
    }

    const symptomData = {
      symptomType: selectedType,
      intensity: intensity[0],
      description: description.trim(),
      duration: duration ? parseInt(duration) : undefined,
      triggers: triggers ? triggers.split(',').map(t => t.trim()) : [],
      copingStrategies: copingStrategies ? copingStrategies.split(',').map(s => s.trim()) : [],
      timestamp: new Date().toISOString()
    };

    addSymptomMutation.mutate(symptomData);
  };

  const handleQuickSymptom = (symptomDesc: string) => {
    setDescription(symptomDesc);
  };

  const getIntensityColor = (level: number) => {
    if (level <= 3) return 'text-green-400';
    if (level <= 6) return 'text-yellow-400';
    if (level <= 8) return 'text-orange-400';
    return 'text-red-400';
  };

  const getSymptomTypeIcon = (type: string) => {
    const symptomType = SYMPTOM_TYPES.find(t => t.id === type);
    return symptomType ? symptomType.icon : Activity;
  };

  const getTimeSince = (timestamp: string) => {
    const now = new Date();
    const then = new Date(timestamp);
    const diffMs = now.getTime() - then.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 0) return `${diffHours}h ${diffMins}m ago`;
    return `${diffMins}m ago`;
  };

  const recentSymptoms = symptoms.slice(0, 5);

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Withdrawal Tracker</h2>
        </div>

        {/* Info Card */}
        <Card className="bg-dark-800 border-dark-700 mb-6">
          <CardContent className="p-4">
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-semibold text-primary mb-1">About Withdrawal Symptoms</h3>
                <p className="text-sm text-dark-300">
                  When quitting ultra-processed foods and sugar, your body may experience withdrawal symptoms as it adjusts. 
                  Tracking these helps understand your patterns and recovery progress.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Symptom Type Selection */}
        <Card className="bg-dark-800 border-dark-700 mb-6">
          <CardHeader>
            <CardTitle className="text-dark-50">Log Withdrawal Symptom</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Type Selection */}
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">
                Symptom Type
              </label>
              <div className="grid grid-cols-2 gap-2">
                {SYMPTOM_TYPES.map((type) => {
                  const Icon = type.icon;
                  return (
                    <Button
                      key={type.id}
                      onClick={() => setSelectedType(type.id as any)}
                      variant={selectedType === type.id ? "default" : "outline"}
                      className={`h-12 ${selectedType === type.id ? 'bg-primary' : 'bg-dark-700'}`}
                    >
                      <Icon className={`mr-2 h-4 w-4 ${type.color}`} />
                      {type.label}
                    </Button>
                  );
                })}
              </div>
            </div>

            {/* Quick Symptoms */}
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">
                Quick Select (optional)
              </label>
              <div className="flex flex-wrap gap-2">
                {COMMON_SYMPTOMS[selectedType].map((symptom, index) => (
                  <Button
                    key={index}
                    onClick={() => handleQuickSymptom(symptom)}
                    variant="outline"
                    size="sm"
                    className="text-xs bg-dark-700 hover:bg-dark-600"
                  >
                    {symptom}
                  </Button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Intensity */}
              <div>
                <div className="flex justify-between text-sm text-dark-400 mb-2">
                  <span>Intensity</span>
                  <span className={`font-semibold ${getIntensityColor(intensity[0])}`}>
                    {intensity[0]}/10
                  </span>
                </div>
                <Slider
                  value={intensity}
                  onValueChange={setIntensity}
                  max={10}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-dark-500 mt-1">
                  <span>Mild</span>
                  <span>Severe</span>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Describe the symptom
                </label>
                <Textarea
                  placeholder="How are you feeling? What symptoms are you experiencing?"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="bg-dark-700 border-dark-600 text-dark-50"
                  rows={3}
                />
              </div>

              {/* Duration */}
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Duration (minutes, optional)
                </label>
                <Input
                  type="number"
                  placeholder="How long did this last?"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  className="bg-dark-700 border-dark-600 text-dark-50"
                />
              </div>

              {/* Triggers */}
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Triggers (optional)
                </label>
                <Input
                  type="text"
                  placeholder="What might have triggered this? (separate with commas)"
                  value={triggers}
                  onChange={(e) => setTriggers(e.target.value)}
                  className="bg-dark-700 border-dark-600 text-dark-50"
                />
              </div>

              {/* Coping Strategies */}
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  What helped? (optional)
                </label>
                <Input
                  type="text"
                  placeholder="Coping strategies that worked (separate with commas)"
                  value={copingStrategies}
                  onChange={(e) => setCopingStrategies(e.target.value)}
                  className="bg-dark-700 border-dark-600 text-dark-50"
                />
              </div>

              <Button
                type="submit"
                disabled={addSymptomMutation.isPending}
                className="w-full bg-primary hover:bg-primary/80"
              >
                {addSymptomMutation.isPending ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Logging...
                  </>
                ) : (
                  'Log Symptom'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Recent Symptoms */}
        {recentSymptoms.length > 0 && (
          <Card className="bg-dark-800 border-dark-700">
            <CardHeader>
              <CardTitle className="text-dark-50 flex items-center">
                <TrendingUp className="mr-2 h-5 w-5" />
                Recent Symptoms
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentSymptoms.map((symptom: WithdrawalSymptom) => {
                const Icon = getSymptomTypeIcon(symptom.symptomType);
                return (
                  <div key={symptom.id} className="bg-dark-700 rounded-lg p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center">
                        <Icon className="h-4 w-4 text-primary mr-2" />
                        <span className="text-sm font-medium text-dark-50 capitalize">
                          {symptom.symptomType}
                        </span>
                        <Badge 
                          variant="outline" 
                          className={`ml-2 text-xs ${getIntensityColor(symptom.intensity)}`}
                        >
                          {symptom.intensity}/10
                        </Badge>
                      </div>
                      <div className="flex items-center text-xs text-dark-400">
                        <Clock className="h-3 w-3 mr-1" />
                        {getTimeSince(symptom.timestamp)}
                      </div>
                    </div>
                    <p className="text-sm text-dark-300 mb-2">{symptom.description}</p>
                    {symptom.copingStrategies && symptom.copingStrategies.length > 0 && (
                      <div className="flex items-center">
                        <CheckCircle className="h-3 w-3 text-green-400 mr-1" />
                        <span className="text-xs text-green-400">
                          Helped: {symptom.copingStrategies.join(', ')}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}