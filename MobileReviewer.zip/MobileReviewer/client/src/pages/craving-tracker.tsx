import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthenticatedRequest } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, AlertTriangle, Zap } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function CravingTracker() {
  const [, setLocation] = useLocation();
  const { getAuthHeaders } = useAuthenticatedRequest();
  const [intensity, setIntensity] = useState([40]);
  const [trigger, setTrigger] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cravingEntries } = useQuery({
    queryKey: ["/api/craving-entries"],
    queryFn: async () => {
      const response = await fetch("/api/craving-entries", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch craving entries");
      return response.json();
    },
  });

  const addCravingMutation = useMutation({
    mutationFn: async (data: { intensity: number; trigger?: string }) => {
      return apiRequest("POST", "/api/craving-entries", {
        ...data,
        date: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/craving-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      toast({
        title: "Craving logged",
        description: "Your craving has been recorded successfully.",
      });
      setShowAddForm(false);
      setIntensity([40]);
      setTrigger("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to log craving",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addCravingMutation.mutate({
      intensity: intensity[0],
      trigger: trigger || undefined,
    });
  };

  // Get this week's craving data for chart
  const getWeeklyTrends = () => {
    if (!cravingEntries) return [];
    
    const now = new Date();
    const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
    
    return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
      const dayEntries = cravingEntries.filter((entry: any) => {
        const entryDate = new Date(entry.date);
        return entryDate.getDay() === (index + 1) % 7;
      });
      
      const avgIntensity = dayEntries.length > 0 
        ? dayEntries.reduce((sum: number, entry: any) => sum + entry.intensity, 0) / dayEntries.length
        : 0;
        
      return {
        day,
        intensity: Math.round(avgIntensity),
        height: avgIntensity > 0 ? `${(avgIntensity / 100) * 100}%` : '0%'
      };
    });
  };

  const weeklyTrends = getWeeklyTrends();
  const avgIntensity = cravingEntries ? 
    Math.round(cravingEntries.reduce((sum: number, entry: any) => sum + entry.intensity, 0) / Math.max(cravingEntries.length, 1)) 
    : 0;

  // Common triggers analysis
  const getCommonTriggers = () => {
    if (!cravingEntries) return [];
    
    const triggerCounts: { [key: string]: number } = {};
    cravingEntries.forEach((entry: any) => {
      if (entry.trigger) {
        triggerCounts[entry.trigger] = (triggerCounts[entry.trigger] || 0) + 1;
      }
    });
    
    return Object.entries(triggerCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([trigger, count]) => ({
        trigger,
        count,
        level: count > 5 ? 'High' : count > 2 ? 'Medium' : 'Low',
        color: count > 5 ? 'text-orange-500' : count > 2 ? 'text-yellow-500' : 'text-green-500'
      }));
  };

  const commonTriggers = getCommonTriggers();

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Craving Tracker</h2>
        </div>

        {/* Emergency Action */}
        <Card className="text-card-foreground shadow-sm from-red-900/30 to-orange-900/30 border border-red-700/50 rounded-xl p-4 mb-4 bg-[#ffffff00]">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-red-400 flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5" />
                Having a Craving Right Now?
              </h3>
              <p className="text-sm text-red-300 mt-1">Get immediate help to overcome it</p>
            </div>
            <Button
              onClick={() => setLocation('/emergency')}
              className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6"
            >
              <Zap className="mr-2 h-4 w-4" />
              Emergency Kit
            </Button>
          </div>
        </Card>

        {/* Craving Input */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">Log a Craving</h3>
          
          {!showAddForm ? (
            <Button
              onClick={() => setShowAddForm(true)}
              className="w-full bg-primary text-white py-3 rounded-xl font-semibold hover:bg-primary/90"
            >
              + Log Craving
            </Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <div className="flex justify-between text-sm text-dark-400 mb-2">
                  <span>Mild</span>
                  <span>Intense</span>
                </div>
                <Slider
                  value={intensity}
                  onValueChange={setIntensity}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="text-center mt-2">
                  <div className="text-2xl font-bold gradient-bg bg-clip-text text-transparent">
                    {intensity[0]}/100
                  </div>
                  <div className="text-sm text-dark-400">Intensity level</div>
                </div>
              </div>
              
              <Input
                type="text"
                placeholder="What triggered this craving? (optional)"
                value={trigger}
                onChange={(e) => setTrigger(e.target.value)}
                className="bg-dark-700 border-dark-600 text-dark-50"
              />
              
              <div className="flex space-x-3">
                <Button
                  type="submit"
                  disabled={addCravingMutation.isPending}
                  className="flex-1 bg-primary text-white"
                >
                  {addCravingMutation.isPending ? "Logging..." : "Log Craving"}
                </Button>
                <Button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  variant="outline"
                  className="flex-1 border-dark-600 text-dark-400"
                >
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </Card>

        {/* Craving Trends */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">Weekly Trends</h3>
          <div className="flex items-end justify-between h-32 mb-2">
            {weeklyTrends.map((data, index) => (
              <div key={index} className="flex flex-col items-center">
                <div 
                  className="w-6 bg-gradient-to-t from-red-500 to-orange-500 chart-bar mb-1 transition-all duration-300" 
                  style={{ height: data.height }}
                />
                <span className="text-xs text-dark-400">{data.day}</span>
              </div>
            ))}
          </div>
          <p className="text-sm text-dark-400">Average intensity: {avgIntensity}/100</p>
        </Card>

        {/* Triggers */}
        {commonTriggers.length > 0 && (
          <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
            <h3 className="text-lg font-semibold mb-3 text-dark-50">Common Triggers</h3>
            <div className="space-y-2">
              {commonTriggers.map((trigger, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-dark-700 rounded-lg">
                  <span className="text-sm text-dark-50">{trigger.trigger}</span>
                  <span className={`text-xs ${trigger.color}`}>{trigger.level}</span>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Insights */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">AI Insights</h3>
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
            <p className="text-sm text-dark-50">
              {avgIntensity < 30 ? 
                "🌟 Your cravings are well-managed! Keep up the great work with your mindful eating practices." :
                avgIntensity < 60 ?
                "💪 Your cravings are moderate. Try identifying triggers and practicing mindful breathing when they arise." :
                "🤝 High craving intensity detected. Consider speaking with a nutritionist and practicing stress-reduction techniques."
              }
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
