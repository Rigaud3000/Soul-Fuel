import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Bell,
  BellRing,
  Clock,
  Target,
  Heart,
  TrendingUp,
  MessageCircle,
  Settings,
  CheckCircle,
  X,
  Calendar,
  Activity
} from "lucide-react";

interface Notification {
  id: string;
  type: 'coaching' | 'reminder' | 'achievement' | 'health_alert' | 'social';
  title: string;
  message: string;
  timestamp: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  read: boolean;
  actionable: boolean;
  context?: {
    category: string;
    relatedData?: any;
  };
}

export default function IntelligentNotifications() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<'notifications' | 'settings'>('notifications');
  const { toast } = useToast();

  // Mock intelligent notifications
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 'notif-1',
      type: 'coaching',
      title: 'Perfect Timing for Protein!',
      message: 'Based on your energy patterns, having a protein snack now could prevent the afternoon sugar craving that typically hits at 3 PM.',
      timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      priority: 'medium',
      read: false,
      actionable: true,
      context: {
        category: 'preventive_coaching',
        relatedData: { confidence: 87, timeframe: '2 hours' }
      }
    },
    {
      id: 'notif-2',
      type: 'achievement',
      title: '7-Day Streak Complete! 🎉',
      message: 'Congratulations! You\'ve successfully avoided processed sugar for 7 days straight. Your energy levels have improved by 23%.',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      priority: 'high',
      read: false,
      actionable: false,
      context: {
        category: 'milestone_achievement'
      }
    },
    {
      id: 'notif-3',
      type: 'health_alert',
      title: 'Stress Pattern Detected',
      message: 'Your heart rate variability suggests elevated stress. This typically leads to sugar cravings within 2-3 hours. Consider trying a 5-minute breathing exercise.',
      timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
      priority: 'high',
      read: true,
      actionable: true,
      context: {
        category: 'predictive_health'
      }
    },
    {
      id: 'notif-4',
      type: 'social',
      title: 'Challenge Update',
      message: 'Sarah just completed day 5 of the Sugar-Free January challenge! You\'re currently in 2nd place.',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      priority: 'low',
      read: true,
      actionable: false,
      context: {
        category: 'social_motivation'
      }
    },
    {
      id: 'notif-5',
      type: 'reminder',
      title: 'Meal Prep Reminder',
      message: 'Sunday meal prep time! Preparing healthy snacks now can reduce your weekday sugar temptations by 64%.',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      priority: 'medium',
      read: true,
      actionable: true,
      context: {
        category: 'behavioral_optimization'
      }
    }
  ]);

  const notificationSettings = {
    coachingTips: true,
    healthAlerts: true,
    achievements: true,
    socialUpdates: false,
    reminderNotifications: true,
    quietHours: { enabled: true, start: '22:00', end: '08:00' },
    frequency: 'contextual', // immediate, hourly, daily, contextual
    priorities: ['urgent', 'high', 'medium'] // only show these priorities
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'coaching': return <MessageCircle className="h-5 w-5 text-blue-400" />;
      case 'achievement': return <Target className="h-5 w-5 text-yellow-400" />;
      case 'health_alert': return <Heart className="h-5 w-5 text-red-400" />;
      case 'social': return <Activity className="h-5 w-5 text-green-400" />;
      case 'reminder': return <Clock className="h-5 w-5 text-purple-400" />;
      default: return <Bell className="h-5 w-5" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'high': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'low': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  };

  const dismissNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== notificationId));
    toast({
      title: "Notification dismissed",
      description: "This notification has been removed",
    });
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  // Simulate receiving new notifications
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.9) { // 10% chance every 10 seconds
        const newNotification: Notification = {
          id: `notif-${Date.now()}`,
          type: 'coaching',
          title: 'Hydration Reminder',
          message: 'You haven\'t logged water intake in 2 hours. Staying hydrated helps reduce false hunger signals.',
          timestamp: new Date().toISOString(),
          priority: 'low',
          read: false,
          actionable: true,
          context: {
            category: 'behavioral_coaching'
          }
        };
        setNotifications(prev => [newNotification, ...prev]);
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to view notifications</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setLocation("/")}
              variant="ghost"
              size="sm"
              className="text-dark-400 hover:text-dark-200"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <BellRing className="h-5 w-5 text-primary" />
            {unreadCount > 0 && (
              <Badge className="bg-red-500/20 text-red-400">
                {unreadCount} unread
              </Badge>
            )}
          </div>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <Bell className="h-8 w-8 text-primary" />
            Intelligent Notifications
          </h1>
          <p className="text-dark-400">Context-aware alerts and personalized coaching messages</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center">
          <div className="grid grid-cols-2 bg-dark-800 rounded-lg p-1">
            <Button
              onClick={() => setActiveTab('notifications')}
              variant={activeTab === 'notifications' ? 'default' : 'ghost'}
              className={activeTab === 'notifications' ? 'bg-primary' : ''}
            >
              <Bell className="h-4 w-4 mr-2" />
              Notifications
            </Button>
            <Button
              onClick={() => setActiveTab('settings')}
              variant={activeTab === 'settings' ? 'default' : 'ghost'}
              className={activeTab === 'settings' ? 'bg-primary' : ''}
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="space-y-4">
            {notifications.length === 0 ? (
              <Card className="bg-dark-800 border-dark-700 p-8 text-center">
                <CheckCircle className="h-16 w-16 text-green-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-dark-50 mb-2">All Caught Up!</h3>
                <p className="text-dark-400">No new notifications at this time.</p>
              </Card>
            ) : (
              <div className="space-y-3">
                {notifications.map((notification) => (
                  <Card 
                    key={notification.id} 
                    className={`border-2 transition-all ${
                      notification.read 
                        ? 'bg-dark-800 border-dark-700 opacity-75' 
                        : 'bg-dark-800 border-primary/30'
                    } ${getPriorityColor(notification.priority)}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          <div className={`p-2 rounded-lg ${
                            notification.read ? 'bg-dark-700' : 'bg-primary/20'
                          }`}>
                            {getNotificationIcon(notification.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className={`font-medium ${
                                notification.read ? 'text-dark-300' : 'text-dark-50'
                              }`}>
                                {notification.title}
                              </h4>
                              <Badge className={getPriorityColor(notification.priority)}>
                                {notification.priority}
                              </Badge>
                              {!notification.read && (
                                <div className="w-2 h-2 bg-primary rounded-full" />
                              )}
                            </div>
                            <p className={`text-sm mb-2 ${
                              notification.read ? 'text-dark-400' : 'text-dark-300'
                            }`}>
                              {notification.message}
                            </p>
                            <div className="flex items-center gap-4 text-xs text-dark-400">
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {new Date(notification.timestamp).toLocaleTimeString()}
                              </span>
                              <span className="capitalize">{notification.type.replace('_', ' ')}</span>
                              {notification.context?.category && (
                                <span>{notification.context.category.replace('_', ' ')}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2 ml-4">
                          {!notification.read && (
                            <Button
                              onClick={() => markAsRead(notification.id)}
                              variant="outline"
                              size="sm"
                              className="border-dark-600"
                            >
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Mark Read
                            </Button>
                          )}
                          <Button
                            onClick={() => dismissNotification(notification.id)}
                            variant="outline"
                            size="sm"
                            className="border-dark-600"
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Notification Types</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">AI Coaching Tips</h4>
                      <p className="text-dark-400 text-sm">Personalized suggestions based on your patterns</p>
                    </div>
                    <Switch checked={notificationSettings.coachingTips} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Health Alerts</h4>
                      <p className="text-dark-400 text-sm">Important health-related notifications</p>
                    </div>
                    <Switch checked={notificationSettings.healthAlerts} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Achievement Celebrations</h4>
                      <p className="text-dark-400 text-sm">Milestone and streak achievements</p>
                    </div>
                    <Switch checked={notificationSettings.achievements} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Social Updates</h4>
                      <p className="text-dark-400 text-sm">Community challenges and friend activity</p>
                    </div>
                    <Switch checked={notificationSettings.socialUpdates} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Smart Reminders</h4>
                      <p className="text-dark-400 text-sm">Context-aware reminders for logging and habits</p>
                    </div>
                    <Switch checked={notificationSettings.reminderNotifications} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Timing & Frequency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Quiet Hours</h4>
                      <p className="text-dark-400 text-sm">
                        No notifications between {notificationSettings.quietHours.start} - {notificationSettings.quietHours.end}
                      </p>
                    </div>
                    <Switch checked={notificationSettings.quietHours.enabled} />
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-dark-50 mb-2">Notification Frequency</h4>
                    <div className="text-dark-300">
                      Current setting: <span className="text-primary capitalize">{notificationSettings.frequency}</span>
                    </div>
                    <p className="text-dark-400 text-xs mt-1">
                      Contextual mode sends notifications based on your activity patterns and optimal timing
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <TrendingUp className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-dark-50 mb-2">Smart Notification Technology</h3>
                    <p className="text-dark-300 text-sm mb-3">
                      Our AI learns your daily patterns, stress levels, and behavioral triggers to send notifications 
                      at the optimal moments when you're most receptive to positive change.
                    </p>
                    <div className="grid md:grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-primary">87%</div>
                        <div className="text-xs text-dark-400">Action Rate</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-secondary">2.3x</div>
                        <div className="text-xs text-dark-400">More Effective</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-accent">AI</div>
                        <div className="text-xs text-dark-400">Powered Timing</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}