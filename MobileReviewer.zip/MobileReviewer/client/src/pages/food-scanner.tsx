import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Camera, 
  Upload, 
  Crown, 
  ScanLine, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Info,
  Lightbulb
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface FoodAnalysis {
  foodName: string;
  brandOwner?: string;
  healthScore: 'A' | 'B' | 'C' | 'D' | 'F';
  isUltraProcessed: boolean;
  redFlags: string[];
  recommendations: string[];
  coachingMessage: string;
  confidence: number;
  nutritionFacts?: {
    calories?: number;
    totalSugars?: number;
    addedSugars?: number;
    sodium?: number;
    saturatedFat?: number;
    fiber?: number;
    protein?: number;
  };
  ingredients?: string[];
}

export default function FoodScanner() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [analysisMethod, setAnalysisMethod] = useState<'text' | 'image' | 'barcode'>('text');
  const [foodDescription, setFoodDescription] = useState("");
  const [barcodeInput, setBarcodeInput] = useState("");
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<FoodAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const analyzeFoodMutation = useMutation({
    mutationFn: async (description: string) => {
      const response = await apiRequest("POST", "/api/analyze-food", {
        foodDescription: description,
      });
      return response.json();
    },
    onSuccess: (result) => {
      setAnalysisResult(result);
      queryClient.invalidateQueries({ queryKey: ["/api/food-analyses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      toast({
        title: "Food analyzed",
        description: "Your food has been analyzed successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to analyze food",
        variant: "destructive",
      });
    },
  });

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodDescription.trim()) return;
    
    if (user?.subscriptionTier !== 'pro') {
      toast({
        title: "Upgrade Required",
        description: "Food analysis requires Pro subscription",
        variant: "destructive",
      });
      return;
    }
    
    analyzeFoodMutation.mutate(foodDescription);
  };

  const mockCameraAction = () => {
    if (user?.subscriptionTier !== 'pro') {
      toast({
        title: "Upgrade Required",
        description: "Food scanner requires Pro subscription",
        variant: "destructive",
      });
      return;
    }
    
    // Simulate camera functionality by pre-filling with sample food
    setFoodDescription("Grilled salmon with quinoa and steamed broccoli");
    toast({
      title: "Camera simulation",
      description: "Camera captured sample food. Edit description and analyze.",
    });
  };

  if (user?.subscriptionTier !== 'pro') {
    return (
      <div className="pb-20 bg-dark-900 min-h-screen">
        <div className="p-6">
          <div className="flex items-center mb-6">
            <Button
              onClick={() => setLocation("/")}
              className="mr-4 text-dark-400 p-0"
              variant="ghost"
            >
              <ArrowLeft size={24} />
            </Button>
            <h2 className="text-2xl font-bold text-dark-50">Food Scanner</h2>
          </div>

          <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6 text-center">
            <Crown className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
            <h3 className="text-xl font-bold text-dark-50 mb-2">Upgrade to Pro</h3>
            <p className="text-dark-400 mb-4">
              Unlock food scanning and AI-powered nutritional analysis with our Pro subscription.
            </p>
            <Button className="gradient-bg text-white px-6 py-2 rounded-lg font-semibold">
              Upgrade Now
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Food Scanner</h2>
        </div>

        {/* Scanner Interface */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <div className="aspect-square bg-dark-700 rounded-xl mb-4 flex items-center justify-center relative overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" 
              alt="Healthy food plate" 
              className="w-full h-full object-cover rounded-xl"
            />
            <div className="absolute inset-0 border-2 border-dashed border-primary rounded-xl"></div>
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <p className="text-white text-center px-4">
                Camera simulation - describe your food below
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={mockCameraAction}
              className="bg-primary text-white py-3 rounded-xl font-semibold flex items-center justify-center space-x-2 hover:bg-primary/90"
            >
              <Camera size={20} />
              <span>Take Photo</span>
            </Button>
            <Button
              onClick={mockCameraAction}
              className="bg-dark-700 text-dark-50 py-3 rounded-xl font-semibold flex items-center justify-center space-x-2 hover:bg-dark-600"
              variant="ghost"
            >
              <Upload size={20} />
              <span>Upload</span>
            </Button>
          </div>
        </Card>

        {/* Food Description Input */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">Describe Your Food</h3>
          <form onSubmit={handleAnalyze} className="space-y-3">
            <Input
              type="text"
              placeholder="e.g., Grilled chicken salad with mixed vegetables"
              value={foodDescription}
              onChange={(e) => setFoodDescription(e.target.value)}
              className="bg-dark-700 border-dark-600 text-dark-50"
              required
            />
            <Button
              type="submit"
              disabled={analyzeFoodMutation.isPending || !foodDescription.trim()}
              className="w-full bg-primary text-white py-3 rounded-xl font-semibold hover:bg-primary/90"
            >
              {analyzeFoodMutation.isPending ? "Analyzing..." : "Analyze Food"}
            </Button>
          </form>
        </Card>

        {/* Analysis Results */}
        {analysisResult && (
          <>
            <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
              <h3 className="text-lg font-semibold mb-3 text-dark-50">Analysis Results</h3>
              <div className="space-y-3">
                <div className={`flex justify-between items-center p-3 rounded-lg border ${
                  analysisResult.isHealthy === 'healthy' 
                    ? 'bg-green-500/10 border-green-500/20' 
                    : analysisResult.isHealthy === 'moderate'
                    ? 'bg-yellow-500/10 border-yellow-500/20'
                    : 'bg-red-500/10 border-red-500/20'
                }`}>
                  <div>
                    <div className={`font-medium ${
                      analysisResult.isHealthy === 'healthy' ? 'text-green-400' : 
                      analysisResult.isHealthy === 'moderate' ? 'text-yellow-400' : 'text-red-400'
                    }`}>
                      {analysisResult.foodName}
                    </div>
                    <div className="text-sm text-dark-400">
                      {analysisResult.isHealthy === 'healthy' ? 'Healthy choice' :
                       analysisResult.isHealthy === 'moderate' ? 'Moderate choice' : 'Consider alternatives'}
                    </div>
                  </div>
                  <div className={
                    analysisResult.isHealthy === 'healthy' ? 'text-green-400' : 
                    analysisResult.isHealthy === 'moderate' ? 'text-yellow-400' : 'text-red-400'
                  }>
                    {analysisResult.isHealthy === 'healthy' ? '✓' : 
                     analysisResult.isHealthy === 'moderate' ? '⚠' : '✗'}
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-3 text-center text-sm">
                  <div>
                    <div className="font-semibold text-orange-400">
                      {Math.round(analysisResult.sugarContent)}g
                    </div>
                    <div className="text-dark-400">Sugar</div>
                  </div>
                  <div>
                    <div className="font-semibold text-primary">
                      {analysisResult.analysis?.protein || 'N/A'}
                    </div>
                    <div className="text-dark-400">Protein</div>
                  </div>
                  <div>
                    <div className="font-semibold text-secondary">
                      {analysisResult.analysis?.fiber || 'N/A'}
                    </div>
                    <div className="text-dark-400">Fiber</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* AI Recommendations */}
            <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
              <h3 className="text-lg font-semibold mb-3 text-dark-50">AI Recommendations</h3>
              <div className={`rounded-lg p-3 border ${
                analysisResult.isHealthy === 'healthy' 
                  ? 'bg-primary/10 border-primary/20' 
                  : 'bg-yellow-500/10 border-yellow-500/20'
              }`}>
                <p className="text-sm text-dark-50">
                  {analysisResult.isHealthy === 'healthy'
                    ? "🌟 Excellent choice! This meal aligns well with your nutrition goals."
                    : analysisResult.isHealthy === 'moderate' 
                    ? "⚖️ This is a moderate choice. Consider adding more vegetables or reducing portions."
                    : "⚠️ This food is high in sugar/processed ingredients. Try healthier alternatives next time."
                  }
                </p>
              </div>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
