import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Users,
  UserPlus,
  Crown,
  Shield,
  Eye,
  Settings,
  TrendingUp,
  Calendar,
  Target,
  Activity,
  Mail
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface FamilyMember {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'parent' | 'child';
  joinedDate: string;
  status: 'active' | 'pending' | 'suspended';
  permissions: {
    viewProgress: boolean;
    setGoals: boolean;
    manageRestrictions: boolean;
    accessReports: boolean;
  };
  currentStreak: number;
  totalPoints: number;
  age?: number;
}

interface FamilyChallenge {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  participants: string[];
  progress: Record<string, number>;
  prize: string;
  status: 'active' | 'completed' | 'upcoming';
}

export default function FamilyManagement() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showInviteForm, setShowInviteForm] = useState(false);
  const [showChallengeForm, setShowChallengeForm] = useState(false);
  const [inviteForm, setInviteForm] = useState({
    email: '',
    role: 'child',
    name: '',
    age: ''
  });
  const [challengeForm, setChallengeForm] = useState({
    name: '',
    description: '',
    endDate: '',
    prize: ''
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock data for demonstration
  const familyMembers: FamilyMember[] = [
    {
      id: 'member-1',
      name: 'Sarah Johnson',
      email: 'sarah@email.com',
      role: 'admin',
      joinedDate: '2024-12-01',
      status: 'active',
      permissions: {
        viewProgress: true,
        setGoals: true,
        manageRestrictions: true,
        accessReports: true
      },
      currentStreak: 15,
      totalPoints: 2840
    },
    {
      id: 'member-2',
      name: 'Alex Johnson',
      email: 'alex@email.com',
      role: 'child',
      joinedDate: '2024-12-01',
      status: 'active',
      permissions: {
        viewProgress: true,
        setGoals: false,
        manageRestrictions: false,
        accessReports: false
      },
      currentStreak: 8,
      totalPoints: 1250,
      age: 14
    },
    {
      id: 'member-3',
      name: 'Emma Johnson',
      email: 'emma@email.com',
      role: 'child',
      joinedDate: '2024-12-15',
      status: 'active',
      permissions: {
        viewProgress: true,
        setGoals: false,
        manageRestrictions: false,
        accessReports: false
      },
      currentStreak: 3,
      totalPoints: 420,
      age: 12
    }
  ];

  const familyChallenges: FamilyChallenge[] = [
    {
      id: 'challenge-1',
      name: 'Sugar-Free January',
      description: 'Complete the month with minimal processed sugar intake',
      startDate: '2025-01-01',
      endDate: '2025-01-31',
      participants: ['member-1', 'member-2', 'member-3'],
      progress: {
        'member-1': 85,
        'member-2': 72,
        'member-3': 68
      },
      prize: 'Family movie night + healthy snacks',
      status: 'active'
    }
  ];

  // Send invitation mutation
  const sendInviteMutation = useMutation({
    mutationFn: async (data: typeof inviteForm) => {
      const response = await apiRequest("POST", "/api/family/invite", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/family/members"] });
      setShowInviteForm(false);
      setInviteForm({ email: '', role: 'child', name: '', age: '' });
      toast({
        title: "Invitation sent",
        description: "Family member will receive an email invitation",
      });
    },
  });

  // Create challenge mutation
  const createChallengeMutation = useMutation({
    mutationFn: async (data: typeof challengeForm) => {
      const response = await apiRequest("POST", "/api/family/challenges", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/family/challenges"] });
      setShowChallengeForm(false);
      setChallengeForm({ name: '', description: '', endDate: '', prize: '' });
      toast({
        title: "Challenge created",
        description: "All family members have been notified",
      });
    },
  });

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="h-4 w-4 text-yellow-400" />;
      case 'parent': return <Shield className="h-4 w-4 text-blue-400" />;
      case 'child': return <Users className="h-4 w-4 text-green-400" />;
      default: return <Users className="h-4 w-4" />;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-yellow-500/20 text-yellow-400';
      case 'parent': return 'bg-blue-500/20 text-blue-400';
      case 'child': return 'bg-green-500/20 text-green-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to manage family accounts</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setLocation("/")}
              variant="ghost"
              size="sm"
              className="text-dark-400 hover:text-dark-200"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
          <Button
            onClick={() => setShowInviteForm(true)}
            className="bg-primary hover:bg-primary/80"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Invite Member
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <Users className="h-8 w-8 text-primary" />
            Family Account Management
          </h1>
          <p className="text-dark-400">Manage your family's wellness journey together</p>
        </div>

        {/* Family Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{familyMembers.length}</div>
              <div className="text-sm text-dark-400">Family Members</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-400">
                {Math.round(familyMembers.reduce((sum, member) => sum + member.currentStreak, 0) / familyMembers.length)}
              </div>
              <div className="text-sm text-dark-400">Avg Streak</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-secondary">
                {familyMembers.reduce((sum, member) => sum + member.totalPoints, 0)}
              </div>
              <div className="text-sm text-dark-400">Total Points</div>
            </CardContent>
          </Card>
        </div>

        {/* Family Members */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50">Family Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {familyMembers.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-dark-50">{member.name}</h4>
                        <Badge className={getRoleColor(member.role)}>
                          {getRoleIcon(member.role)}
                          {member.role}
                        </Badge>
                        {member.age && (
                          <Badge className="bg-gray-500/20 text-gray-400 text-xs">
                            Age {member.age}
                          </Badge>
                        )}
                      </div>
                      <p className="text-dark-400 text-sm">{member.email}</p>
                      <div className="flex items-center gap-4 text-xs text-dark-400 mt-1">
                        <span>{member.currentStreak} day streak</span>
                        <span>{member.totalPoints} points</span>
                        <span>Joined {new Date(member.joinedDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className={`${
                      member.status === 'active' ? 'bg-green-500/20 text-green-400' :
                      member.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      {member.status}
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-dark-600"
                    >
                      <Settings className="h-3 w-3 mr-1" />
                      Manage
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Family Challenges */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg text-dark-50">Family Challenges</CardTitle>
              <Button
                onClick={() => setShowChallengeForm(true)}
                variant="outline"
                size="sm"
                className="border-dark-600"
              >
                <Target className="h-4 w-4 mr-2" />
                Create Challenge
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {familyChallenges.map((challenge) => (
                <Card key={challenge.id} className="bg-dark-700 border-dark-600">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-medium text-dark-50 mb-1">{challenge.name}</h4>
                        <p className="text-dark-400 text-sm mb-2">{challenge.description}</p>
                        <div className="flex items-center gap-4 text-xs text-dark-400">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(challenge.startDate).toLocaleDateString()} - {new Date(challenge.endDate).toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {challenge.participants.length} participants
                          </span>
                        </div>
                      </div>
                      <Badge className={`${
                        challenge.status === 'active' ? 'bg-green-500/20 text-green-400' :
                        challenge.status === 'completed' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {challenge.status}
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <div className="text-sm font-medium text-dark-50">Progress:</div>
                      {Object.entries(challenge.progress).map(([memberId, progress]) => {
                        const member = familyMembers.find(m => m.id === memberId);
                        return (
                          <div key={memberId} className="flex items-center justify-between">
                            <span className="text-dark-300 text-sm">{member?.name}</span>
                            <div className="flex items-center gap-2">
                              <div className="w-24 h-2 bg-dark-600 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-primary transition-all"
                                  style={{ width: `${progress}%` }}
                                />
                              </div>
                              <span className="text-dark-400 text-xs w-8">{progress}%</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <div className="mt-3 pt-3 border-t border-dark-600">
                      <div className="text-sm text-dark-400">
                        <strong>Prize:</strong> {challenge.prize}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Parental Controls */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-400" />
              Parental Controls
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                <div>
                  <h4 className="font-medium text-dark-50">Content Filtering</h4>
                  <p className="text-dark-400 text-sm">Filter inappropriate food content for children</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                <div>
                  <h4 className="font-medium text-dark-50">Progress Sharing</h4>
                  <p className="text-dark-400 text-sm">Allow children to share progress with family</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                <div>
                  <h4 className="font-medium text-dark-50">Goal Setting Restrictions</h4>
                  <p className="text-dark-400 text-sm">Require parent approval for new goals</p>
                </div>
                <Switch />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Invite Member Modal */}
        {showInviteForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 w-full max-w-lg">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Invite Family Member</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Name</label>
                  <Input
                    value={inviteForm.name}
                    onChange={(e) => setInviteForm(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Full name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Email</label>
                  <Input
                    type="email"
                    value={inviteForm.email}
                    onChange={(e) => setInviteForm(prev => ({ ...prev, email: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Role</label>
                  <Select value={inviteForm.role} onValueChange={(value) => setInviteForm(prev => ({ ...prev, role: value }))}>
                    <SelectTrigger className="bg-dark-700 border-dark-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-dark-700 border-dark-600">
                      <SelectItem value="parent">Parent</SelectItem>
                      <SelectItem value="child">Child</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {inviteForm.role === 'child' && (
                  <div>
                    <label className="block text-sm font-medium text-dark-50 mb-2">Age (Optional)</label>
                    <Input
                      type="number"
                      value={inviteForm.age}
                      onChange={(e) => setInviteForm(prev => ({ ...prev, age: e.target.value }))}
                      className="bg-dark-700 border-dark-600"
                      placeholder="12"
                    />
                  </div>
                )}
                <div className="flex justify-end gap-3">
                  <Button
                    onClick={() => setShowInviteForm(false)}
                    variant="outline"
                    className="border-dark-600"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => sendInviteMutation.mutate(inviteForm)}
                    disabled={sendInviteMutation.isPending}
                    className="bg-primary hover:bg-primary/80"
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Send Invitation
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Create Challenge Modal */}
        {showChallengeForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 w-full max-w-lg">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Create Family Challenge</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Challenge Name</label>
                  <Input
                    value={challengeForm.name}
                    onChange={(e) => setChallengeForm(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Sugar-Free February"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Description</label>
                  <Input
                    value={challengeForm.description}
                    onChange={(e) => setChallengeForm(prev => ({ ...prev, description: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Challenge description..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">End Date</label>
                  <Input
                    type="date"
                    value={challengeForm.endDate}
                    onChange={(e) => setChallengeForm(prev => ({ ...prev, endDate: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Prize/Reward</label>
                  <Input
                    value={challengeForm.prize}
                    onChange={(e) => setChallengeForm(prev => ({ ...prev, prize: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Family movie night"
                  />
                </div>
                <div className="flex justify-end gap-3">
                  <Button
                    onClick={() => setShowChallengeForm(false)}
                    variant="outline"
                    className="border-dark-600"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => createChallengeMutation.mutate(challengeForm)}
                    disabled={createChallengeMutation.isPending}
                    className="bg-primary hover:bg-primary/80"
                  >
                    Create Challenge
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}