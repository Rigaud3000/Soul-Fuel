import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { Plus, TrendingUp, Target, Activity, Award, Heart, Zap } from "lucide-react";
import { useTranslation } from "@/contexts/LanguageContext";

export default function Tracking() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { t } = useTranslation();

  // Fetch analytics data
  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
    enabled: !!user,
  });

  const weeklyStats = analytics?.weeklyStats || {};

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-950">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-dark-900/95 backdrop-blur-lg border-b border-dark-700/50">
        <div className="max-w-md mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-white">{t('tracking.title')}</h1>
          <p className="text-dark-400 text-sm">{t('tracking.subtitle')}</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-6 space-y-6">
        
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                <Heart className="text-primary" size={20} />
              </div>
              <div>
                <div className="text-xs text-dark-400">{t('tracking.avgMood')}</div>
                <div className="text-lg font-bold text-white">{weeklyStats.avgMood || 'N/A'}</div>
              </div>
            </div>
          </Card>
          <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                <Zap className="text-secondary" size={20} />
              </div>
              <div>
                <div className="text-xs text-dark-400">{t('tracking.dailySugar')}</div>
                <div className="text-lg font-bold text-white">{Math.round((weeklyStats.totalSugar || 0) / 7)}g</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Sugar Tracking */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Zap className="text-secondary" size={20} />
              {t('tracking.sugarIntake')}
            </h3>
            <Button
              onClick={() => setLocation("/sugar")}
              size="sm"
              className="bg-secondary/20 text-secondary hover:bg-secondary/30"
            >
              <Plus size={16} className="mr-1" />
              {t('tracking.logSugar')}
            </Button>
          </div>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-dark-300">{t('tracking.weeklyTarget')}</span>
                <span className="text-white">{weeklyStats.totalSugar || 0}/175g</span>
              </div>
              <Progress value={Math.min((weeklyStats.totalSugar || 0) / 175 * 100, 100)} className="h-2" />
            </div>
            <div className="text-xs text-dark-400">
              {weeklyStats.totalSugar < 175 
                ? t('tracking.onTrack') 
                : t('tracking.overTarget')
              }
            </div>
          </div>
        </Card>

        {/* Mood Tracking */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Heart className="text-primary" size={20} />
              {t('tracking.moodTracking')}
            </h3>
            <Button
              onClick={() => setLocation("/mood")}
              size="sm"
              className="bg-primary/20 text-primary hover:bg-primary/30"
            >
              <Plus size={16} className="mr-1" />
              {t('tracking.logMood')}
            </Button>
          </div>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-dark-300">{t('tracking.checkInsThisWeek')}</span>
                <span className="text-white">{weeklyStats.moodCheckIns || 0}/7</span>
              </div>
              <Progress value={((weeklyStats.moodCheckIns || 0) / 7) * 100} className="h-2" />
            </div>
            <div className="text-xs text-dark-400">
              {weeklyStats.moodCheckIns > 5 
                ? t('tracking.excellentTracking')
                : t('tracking.keepGoing')
              }
            </div>
          </div>
        </Card>

        {/* Cravings */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Target className="text-accent" size={20} />
              {t('tracking.cravings')}
            </h3>
            <Button
              onClick={() => setLocation("/cravings")}
              size="sm"
              className="bg-accent/20 text-accent hover:bg-accent/30"
            >
              <Plus size={16} className="mr-1" />
              {t('tracking.logCraving')}
            </Button>
          </div>
          <div className="space-y-3">
            <div className="text-sm text-dark-300">
              {t('tracking.avgIntensity')}: <span className="text-white font-medium">{weeklyStats.cravingIntensity || 'N/A'}/10</span>
            </div>
            <div className="text-xs text-dark-400">
              {weeklyStats.cravingIntensity < 5 
                ? t('tracking.managingWell')
                : t('tracking.stayStrong')
              }
            </div>
          </div>
        </Card>

        {/* Weekly Progress */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <TrendingUp className="text-primary" size={20} />
            {t('tracking.weeklyProgress')}
          </h3>
          <div className="space-y-4">
            <div className="bg-dark-700 rounded-lg p-4">
              <div className="text-2xl font-bold text-secondary mb-1">{weeklyStats.streakDays || 0}</div>
              <div className="text-sm text-dark-300">{t('tracking.dayStreak')}</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-dark-700 rounded-lg p-3">
                <div className="text-lg font-bold text-primary">{weeklyStats.moodCheckIns || 0}</div>
                <div className="text-xs text-dark-400">{t('tracking.moodEntries')}</div>
              </div>
              <div className="bg-dark-700 rounded-lg p-3">
                <div className="text-lg font-bold text-accent">{Math.round(weeklyStats.totalSugar || 0)}g</div>
                <div className="text-xs text-dark-400">{t('tracking.sugarWeek')}</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Achievement Progress */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Award className="text-yellow-500" size={20} />
            {t('tracking.achievements')}
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                  <span className="text-yellow-500 text-sm">🏆</span>
                </div>
                <div>
                  <div className="text-sm font-medium text-white">{t('tracking.firstWeek')}</div>
                  <div className="text-xs text-dark-400">{t('tracking.completeFirstWeek')}</div>
                </div>
              </div>
              <Badge variant={weeklyStats.moodCheckIns >= 7 ? "default" : "secondary"} className="text-xs">
                {weeklyStats.moodCheckIns >= 7 ? t('tracking.completed') : t('tracking.inProgress')}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <span className="text-green-500 text-sm">💪</span>
                </div>
                <div>
                  <div className="text-sm font-medium text-white">{t('tracking.sugarWarrior')}</div>
                  <div className="text-xs text-dark-400">{t('tracking.stayUnder25g')}</div>
                </div>
              </div>
              <Badge variant={(weeklyStats.totalSugar || 0) < 175 ? "default" : "secondary"} className="text-xs">
                {(weeklyStats.totalSugar || 0) < 175 ? t('tracking.completed') : t('tracking.inProgress')}
              </Badge>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}