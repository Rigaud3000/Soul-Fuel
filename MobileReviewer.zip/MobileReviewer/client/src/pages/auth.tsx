import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { Apple, Mail } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import SoulFuelHeader from "@/components/soulfuel-header";

export default function AuthPage() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const { signIn, signUp, signInWithGoogle, signInWithApple } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isSignUp) {
        await signUp(email, password, username);
        toast({
          title: "Welcome to SoulFuel!",
          description: "Your account has been created successfully.",
        });
      } else {
        await signIn(email, password);
        toast({
          title: "Welcome back!",
          description: "You've successfully signed in.",
        });
      }
    } catch (error: any) {
      toast({
        title: "Authentication Error",
        description: error.message || "Please check your credentials and try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 min-h-screen flex flex-col justify-center bg-dark-900">
      <div className="text-center mb-8">
        <div className="w-20 h-20 gradient-bg rounded-full mx-auto mb-4 flex items-center justify-center">
          <Leaf className="text-2xl text-white" size={32} />
        </div>
        <h1 className="text-3xl font-bold gradient-bg bg-clip-text text-transparent">
          SoulFuel
        </h1>
        <p className="text-dark-400 mt-2">Your mindful eating companion</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 mb-6">
        <div>
          <Input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-4 bg-dark-800 border border-dark-700 rounded-xl text-dark-50 placeholder-dark-400 focus:border-primary"
            required
          />
        </div>
        
        {isSignUp && (
          <div>
            <Input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-4 bg-dark-800 border border-dark-700 rounded-xl text-dark-50 placeholder-dark-400 focus:border-primary"
              required
            />
          </div>
        )}
        
        <div>
          <Input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-4 bg-dark-800 border border-dark-700 rounded-xl text-dark-50 placeholder-dark-400 focus:border-primary"
            required
          />
        </div>

        <Button
          type="submit"
          disabled={loading}
          className="w-full gradient-bg text-white py-4 rounded-xl font-semibold hover:opacity-90 transition-opacity"
        >
          {loading ? "Please wait..." : isSignUp ? "Sign Up" : "Sign In"}
        </Button>
      </form>

      <div className="text-center">
        <span className="text-dark-400">
          {isSignUp ? "Already have an account? " : "Don't have an account? "}
        </span>
        <button
          type="button"
          onClick={() => setIsSignUp(!isSignUp)}
          className="text-primary font-semibold"
        >
          {isSignUp ? "Sign In" : "Sign Up"}
        </button>
      </div>
    </div>
  );
}
