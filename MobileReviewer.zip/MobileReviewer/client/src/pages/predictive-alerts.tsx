import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  AlertTriangle,
  Brain,
  TrendingUp,
  Calendar,
  Clock,
  Target,
  Heart,
  Moon,
  Activity,
  Zap,
  Bell,
  Settings,
  CheckCircle,
  XCircle
} from "lucide-react";

interface PredictiveAlert {
  id: string;
  type: 'craving' | 'mood_drop' | 'energy_crash' | 'sleep_disruption' | 'stress_spike';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  prediction: string;
  confidence: number;
  timeframe: string;
  triggers: string[];
  recommendations: string[];
  status: 'active' | 'dismissed' | 'resolved';
  createdAt: string;
  estimatedImpact: number;
}

interface HealthPattern {
  id: string;
  name: string;
  description: string;
  frequency: string;
  accuracy: number;
  lastDetected: string;
  enabled: boolean;
}

export default function PredictiveAlerts() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<'alerts' | 'patterns' | 'settings'>('alerts');
  const { toast } = useToast();

  // Mock data for demonstration
  const predictiveAlerts: PredictiveAlert[] = [
    {
      id: 'alert-1',
      type: 'craving',
      severity: 'high',
      title: 'High Sugar Craving Risk',
      description: 'Based on your current stress levels and sleep pattern, you\'re likely to experience intense sugar cravings in the next 2-4 hours.',
      prediction: '85% chance of strong sugar craving between 3-5 PM today',
      confidence: 85,
      timeframe: '2-4 hours',
      triggers: ['Elevated stress (heart rate)', 'Poor sleep quality last night', 'Skipped morning protein'],
      recommendations: [
        'Have a protein-rich snack now',
        'Practice 5-minute breathing exercise',
        'Stay hydrated - drink 16oz water',
        'Avoid trigger environments (break room, vending machines)'
      ],
      status: 'active',
      createdAt: new Date().toISOString(),
      estimatedImpact: 7
    },
    {
      id: 'alert-2',
      type: 'energy_crash',
      severity: 'medium',
      title: 'Energy Dip Predicted',
      description: 'Your energy levels are likely to drop significantly around 2 PM based on your meal timing and glucose patterns.',
      prediction: '72% chance of energy crash at 2 PM',
      confidence: 72,
      timeframe: '1-2 hours',
      triggers: ['Low protein breakfast', 'High refined carb lunch', 'Caffeine dependency pattern'],
      recommendations: [
        'Eat balanced snack with protein and fiber',
        'Take a 10-minute walk',
        'Limit caffeine intake',
        'Consider light stretching'
      ],
      status: 'active',
      createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      estimatedImpact: 5
    }
  ];

  const healthPatterns: HealthPattern[] = [
    {
      id: 'pattern-1',
      name: 'Weekend Sugar Spike',
      description: 'Increased sugar consumption every weekend, typically starting Friday evening',
      frequency: 'Weekly',
      accuracy: 87,
      lastDetected: '2024-12-28',
      enabled: true
    },
    {
      id: 'pattern-2',
      name: 'Stress-Eating Response',
      description: 'Correlates high-stress periods with increased processed food consumption',
      frequency: 'Variable',
      accuracy: 92,
      lastDetected: '2024-12-30',
      enabled: true
    },
    {
      id: 'pattern-3',
      name: 'Sleep-Mood Connection',
      description: 'Poor sleep quality predicts mood drops and food choice deterioration',
      frequency: '2-3x per week',
      accuracy: 78,
      lastDetected: '2025-01-01',
      enabled: true
    }
  ];

  const alertSettings = {
    cravingPrediction: true,
    moodDropWarning: true,
    energyCrashAlert: true,
    sleepDisruptionWarning: false,
    stressSpikeAlert: true,
    minimumConfidence: 70,
    advanceNoticeHours: 2,
    quietHours: { start: '22:00', end: '08:00' }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'high': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'low': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'craving': return <Target className="h-5 w-5" />;
      case 'mood_drop': return <Heart className="h-5 w-5" />;
      case 'energy_crash': return <Zap className="h-5 w-5" />;
      case 'sleep_disruption': return <Moon className="h-5 w-5" />;
      case 'stress_spike': return <Activity className="h-5 w-5" />;
      default: return <AlertTriangle className="h-5 w-5" />;
    }
  };

  const dismissAlert = (alertId: string) => {
    toast({
      title: "Alert dismissed",
      description: "This prediction has been marked as dismissed",
    });
  };

  const markResolved = (alertId: string) => {
    toast({
      title: "Alert resolved",
      description: "Great job managing this potential trigger!",
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to access predictive alerts</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            size="sm"
            className="text-dark-400 hover:text-dark-200"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            Predictive Health Alerts
          </h1>
          <p className="text-dark-400">AI-powered predictions to prevent health setbacks before they happen</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center">
          <div className="grid grid-cols-3 bg-dark-800 rounded-lg p-1">
            <Button
              onClick={() => setActiveTab('alerts')}
              variant={activeTab === 'alerts' ? 'default' : 'ghost'}
              className={activeTab === 'alerts' ? 'bg-primary' : ''}
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              Active Alerts
            </Button>
            <Button
              onClick={() => setActiveTab('patterns')}
              variant={activeTab === 'patterns' ? 'default' : 'ghost'}
              className={activeTab === 'patterns' ? 'bg-primary' : ''}
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Patterns
            </Button>
            <Button
              onClick={() => setActiveTab('settings')}
              variant={activeTab === 'settings' ? 'default' : 'ghost'}
              className={activeTab === 'settings' ? 'bg-primary' : ''}
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Active Alerts Tab */}
        {activeTab === 'alerts' && (
          <div className="space-y-6">
            {predictiveAlerts.length === 0 ? (
              <Card className="bg-dark-800 border-dark-700 p-8 text-center">
                <CheckCircle className="h-16 w-16 text-green-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-dark-50 mb-2">All Clear!</h3>
                <p className="text-dark-400">No immediate health risks detected. Keep up the great work!</p>
              </Card>
            ) : (
              <div className="space-y-4">
                {predictiveAlerts.map((alert) => (
                  <Card key={alert.id} className={`border-2 ${getSeverityColor(alert.severity)}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-4">
                          <div className={`p-2 rounded-lg ${getSeverityColor(alert.severity)}`}>
                            {getTypeIcon(alert.type)}
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold text-dark-50 mb-1">{alert.title}</h3>
                            <p className="text-dark-400 text-sm mb-2">{alert.description}</p>
                            <div className="flex items-center gap-4 text-xs text-dark-400">
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {alert.timeframe}
                              </span>
                              <span className="flex items-center gap-1">
                                <Brain className="h-3 w-3" />
                                {alert.confidence}% confidence
                              </span>
                              <span className="flex items-center gap-1">
                                <TrendingUp className="h-3 w-3" />
                                Impact: {alert.estimatedImpact}/10
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => dismissAlert(alert.id)}
                            variant="outline"
                            size="sm"
                            className="border-dark-600"
                          >
                            <XCircle className="h-3 w-3 mr-1" />
                            Dismiss
                          </Button>
                          <Button
                            onClick={() => markResolved(alert.id)}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Resolved
                          </Button>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-medium text-dark-50 mb-2">Prediction</h4>
                          <div className="bg-dark-700 rounded-lg p-3">
                            <p className="text-dark-300 text-sm">{alert.prediction}</p>
                            <div className="mt-2">
                              <div className="flex justify-between text-xs text-dark-400 mb-1">
                                <span>Confidence</span>
                                <span>{alert.confidence}%</span>
                              </div>
                              <Progress value={alert.confidence} className="h-2" />
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium text-dark-50 mb-2">Identified Triggers</h4>
                          <div className="space-y-1">
                            {alert.triggers.map((trigger, index) => (
                              <div key={index} className="flex items-center gap-2 text-sm text-dark-300">
                                <div className="w-1 h-1 bg-primary rounded-full" />
                                {trigger}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="mt-4">
                        <h4 className="font-medium text-dark-50 mb-2">AI Recommendations</h4>
                        <div className="grid gap-2">
                          {alert.recommendations.map((rec, index) => (
                            <div key={index} className="flex items-center gap-3 p-2 bg-dark-700 rounded-lg">
                              <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0" />
                              <span className="text-dark-300 text-sm">{rec}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Patterns Tab */}
        {activeTab === 'patterns' && (
          <div className="space-y-6">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Detected Health Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {healthPatterns.map((pattern) => (
                    <div key={pattern.id} className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
                          <TrendingUp className="h-5 w-5" />
                        </div>
                        <div>
                          <h4 className="font-medium text-dark-50 mb-1">{pattern.name}</h4>
                          <p className="text-dark-400 text-sm mb-2">{pattern.description}</p>
                          <div className="flex items-center gap-4 text-xs text-dark-400">
                            <span>Frequency: {pattern.frequency}</span>
                            <span>Accuracy: {pattern.accuracy}%</span>
                            <span>Last detected: {new Date(pattern.lastDetected).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="text-lg font-bold text-primary">{pattern.accuracy}%</div>
                          <div className="text-xs text-dark-400">Accuracy</div>
                        </div>
                        <Switch checked={pattern.enabled} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Alert Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Sugar Craving Predictions</h4>
                      <p className="text-dark-400 text-sm">Get alerts before likely craving episodes</p>
                    </div>
                    <Switch checked={alertSettings.cravingPrediction} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Mood Drop Warnings</h4>
                      <p className="text-dark-400 text-sm">Early warning for potential mood deterioration</p>
                    </div>
                    <Switch checked={alertSettings.moodDropWarning} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Energy Crash Alerts</h4>
                      <p className="text-dark-400 text-sm">Predict and prevent energy level drops</p>
                    </div>
                    <Switch checked={alertSettings.energyCrashAlert} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Sleep Disruption Warnings</h4>
                      <p className="text-dark-400 text-sm">Alerts for factors that may affect sleep quality</p>
                    </div>
                    <Switch checked={alertSettings.sleepDisruptionWarning} />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-dark-50">Stress Spike Alerts</h4>
                      <p className="text-dark-400 text-sm">Early detection of rising stress levels</p>
                    </div>
                    <Switch checked={alertSettings.stressSpikeAlert} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Alert Timing & Sensitivity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-dark-50 mb-2">Minimum Confidence Level</h4>
                    <div className="flex items-center gap-4">
                      <Progress value={alertSettings.minimumConfidence} className="flex-1" />
                      <span className="text-dark-300 text-sm w-12">{alertSettings.minimumConfidence}%</span>
                    </div>
                    <p className="text-dark-400 text-xs mt-1">Only show alerts with this confidence level or higher</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-dark-50 mb-2">Advance Notice</h4>
                    <div className="text-dark-300">{alertSettings.advanceNoticeHours} hours before predicted event</div>
                    <p className="text-dark-400 text-xs mt-1">How far in advance to receive alerts</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-dark-50 mb-2">Quiet Hours</h4>
                    <div className="text-dark-300">
                      {alertSettings.quietHours.start} - {alertSettings.quietHours.end}
                    </div>
                    <p className="text-dark-400 text-xs mt-1">No alerts during these hours except critical ones</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* AI Insights */}
        <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <Brain className="h-6 w-6 text-primary mt-1" />
              <div>
                <h3 className="text-lg font-semibold text-dark-50 mb-2">AI Health Intelligence</h3>
                <p className="text-dark-300 text-sm mb-3">
                  Our AI analyzes your behavioral patterns, biometric data, and environmental factors to predict health risks 
                  before they happen. This proactive approach helps you stay ahead of cravings, energy crashes, and mood dips.
                </p>
                <div className="grid md:grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">87%</div>
                    <div className="text-xs text-dark-400">Average Accuracy</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-secondary">2.4hrs</div>
                    <div className="text-xs text-dark-400">Average Notice</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">156</div>
                    <div className="text-xs text-dark-400">Predictions This Month</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}