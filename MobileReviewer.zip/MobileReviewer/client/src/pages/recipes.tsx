import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Clock, Droplet, Zap } from "lucide-react";

const filterTags = [
  "Low Sugar",
  "Quick", 
  "High Protein",
  "Vegetarian",
  "Mediterranean",
  "Breakfast",
  "Antioxidants"
];

export default function Recipes() {
  const [, setLocation] = useLocation();
  const [selectedTags, setSelectedTags] = useState<string[]>(["Low Sugar"]);

  const { data: recipes, isLoading } = useQuery({
    queryKey: ["/api/recipes", selectedTags.join(",")],
    queryFn: async () => {
      const params = selectedTags.length > 0 ? `?tags=${selectedTags.join(",")}` : "";
      const response = await fetch(`/api/recipes${params}`);
      if (!response.ok) throw new Error("Failed to fetch recipes");
      return response.json();
    },
  });

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag)
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const getSugarLevel = (sugar: number) => {
    if (sugar <= 5) return { level: "Low", color: "bg-green-500" };
    if (sugar <= 15) return { level: "Medium", color: "bg-yellow-500" };
    return { level: "High", color: "bg-red-500" };
  };

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Healthy Recipes</h2>
        </div>

        {/* Filter Tags */}
        <div className="flex space-x-2 mb-6 overflow-x-auto pb-2">
          {filterTags.map((tag) => (
            <Button
              key={tag}
              onClick={() => toggleTag(tag)}
              className={`px-4 py-2 rounded-full text-sm whitespace-nowrap ${
                selectedTags.includes(tag)
                  ? "bg-primary text-white"
                  : "bg-dark-700 text-dark-50 hover:bg-dark-600"
              }`}
              variant="ghost"
            >
              {tag}
            </Button>
          ))}
        </div>

        {/* Recipe Cards */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="bg-dark-800 border border-dark-700 rounded-xl overflow-hidden">
                <div className="w-full h-32 bg-dark-700 animate-pulse" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-dark-700 rounded animate-pulse" />
                  <div className="h-3 bg-dark-700 rounded animate-pulse w-3/4" />
                  <div className="h-6 bg-dark-700 rounded animate-pulse w-1/2" />
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {recipes?.map((recipe: any) => {
              const sugarInfo = getSugarLevel(recipe.sugarContent);
              
              return (
                <Card key={recipe.id} className="bg-dark-800 border border-dark-700 rounded-xl overflow-hidden card-hover">
                  <img 
                    src={recipe.imageUrl || "https://images.unsplash.com/photo-1512058564366-18510be2db19"} 
                    alt={recipe.name}
                    className="w-full h-32 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="font-semibold mb-2 text-dark-50">{recipe.name}</h3>
                    <p className="text-sm text-dark-400 mb-3">{recipe.description}</p>
                    
                    {/* Recipe Stats */}
                    <div className="flex justify-between items-center text-xs mb-3">
                      <div className="flex space-x-4 text-dark-400">
                        <span className="flex items-center">
                          <Clock size={12} className="mr-1" />
                          {recipe.prepTime} min
                        </span>
                        <span className="flex items-center">
                          <Droplet size={12} className="mr-1" />
                          {recipe.sugarContent}g sugar
                        </span>
                        {recipe.analysis?.protein && (
                          <span className="flex items-center">
                            <Zap size={12} className="mr-1" />
                            {recipe.analysis.protein}g protein
                          </span>
                        )}
                      </div>
                      <Badge className={`${sugarInfo.color} text-white text-xs px-2 py-1`}>
                        {sugarInfo.level} Sugar
                      </Badge>
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1">
                      {(recipe.tags as string[]).slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs border-dark-600 text-dark-400">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </Card>
              );
            })}

            {recipes?.length === 0 && (
              <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6 text-center">
                <p className="text-dark-400">No recipes found for the selected filters.</p>
                <Button 
                  onClick={() => setSelectedTags([])}
                  className="mt-2 text-primary"
                  variant="ghost"
                  size="sm"
                >
                  Clear filters
                </Button>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
