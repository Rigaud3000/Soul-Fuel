import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Calendar,
  Clock,
  Users,
  ChefHat,
  ShoppingCart,
  Utensils,
  Plus,
  Wand2,
  Heart,
  Target,
  CheckCircle,
  Download,
  Copy
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface MealPlan {
  id: number;
  name: string;
  weekStartDate: string;
  generatedBy: 'ai' | 'manual';
  totalCalories: number;
  avgHealthScore: string;
  meals: DailyMeals[];
  groceryList: GroceryItem[];
  preferences: {
    dietaryRestrictions: string[];
    servings: number;
    budget: number;
    timeConstraints: string;
  };
}

interface DailyMeals {
  date: string;
  breakfast: Meal;
  lunch: Meal;
  dinner: Meal;
  snacks: Meal[];
}

interface Meal {
  id: number;
  name: string;
  description: string;
  calories: number;
  prepTime: number;
  difficulty: 'easy' | 'medium' | 'hard';
  healthScore: 'A' | 'B' | 'C' | 'D' | 'F';
  ingredients: string[];
  instructions: string[];
  tags: string[];
  nutritionFacts: {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    sugar: number;
  };
}

interface GroceryItem {
  name: string;
  category: string;
  quantity: string;
  estimated_cost: number;
  isHealthy: boolean;
  alternatives?: string[];
}

export default function MealPlanner() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [currentWeek, setCurrentWeek] = useState(getWeekStart(new Date()));
  const [selectedDay, setSelectedDay] = useState(new Date().toISOString().split('T')[0]);
  const [showPlanner, setShowPlanner] = useState(false);
  const [plannerForm, setPlannerForm] = useState({
    dietaryRestrictions: [] as string[],
    servings: 2,
    budget: 100,
    timeConstraints: 'moderate',
    healthGoal: 'balanced',
    avoidIngredients: '',
    preferredCuisines: [] as string[]
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch current meal plan
  const { data: mealPlan, isLoading } = useQuery<MealPlan>({
    queryKey: ["/api/meal-plan", currentWeek],
    enabled: !!user,
  });

  // Generate meal plan mutation
  const generatePlanMutation = useMutation({
    mutationFn: async (preferences: typeof plannerForm) => {
      const response = await apiRequest("POST", "/api/meal-plan/generate", {
        weekStartDate: currentWeek,
        preferences
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plan"] });
      setShowPlanner(false);
      toast({
        title: "Meal plan generated!",
        description: "Your personalized weekly meal plan is ready.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to generate meal plan",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  // Save meal plan mutation
  const saveMealMutation = useMutation({
    mutationFn: async ({ mealId, day, mealType }: { mealId: number; day: string; mealType: string }) => {
      const response = await apiRequest("POST", "/api/meal-plan/save-meal", {
        mealId,
        day,
        mealType,
        weekStartDate: currentWeek
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plan"] });
      toast({
        title: "Meal saved",
        description: "Added to your meal plan.",
      });
    },
  });

  function getWeekStart(date: Date): string {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff)).toISOString().split('T')[0];
  }

  function getWeekDays(weekStart: string): string[] {
    const days = [];
    const start = new Date(weekStart);
    for (let i = 0; i < 7; i++) {
      const day = new Date(start);
      day.setDate(start.getDate() + i);
      days.push(day.toISOString().split('T')[0]);
    }
    return days;
  }

  const getDayName = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
  };

  const getFormattedDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const copyGroceryList = () => {
    if (!mealPlan?.groceryList) return;
    
    const groceryText = mealPlan.groceryList
      .reduce((acc, item, index) => {
        if (index === 0 || item.category !== mealPlan.groceryList[index - 1].category) {
          acc += `\n${item.category.toUpperCase()}:\n`;
        }
        acc += `• ${item.name} - ${item.quantity}\n`;
        return acc;
      }, 'SOULFUEL Weekly Grocery List\n========================');
    
    navigator.clipboard.writeText(groceryText);
    toast({
      title: "Grocery list copied",
      description: "Copied to clipboard for shopping.",
    });
  };

  const handleDietaryRestrictionChange = (restriction: string, checked: boolean) => {
    setPlannerForm(prev => ({
      ...prev,
      dietaryRestrictions: checked 
        ? [...prev.dietaryRestrictions, restriction]
        : prev.dietaryRestrictions.filter(r => r !== restriction)
    }));
  };

  const weekDays = getWeekDays(currentWeek);
  const selectedMeals = mealPlan?.meals.find(day => day.date === selectedDay);

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to access meal planner</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setLocation("/")}
              variant="ghost"
              size="sm"
              className="text-dark-400 hover:text-dark-200"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
          <Button
            onClick={() => setShowPlanner(true)}
            className="bg-primary hover:bg-primary/80"
          >
            <Wand2 className="h-4 w-4 mr-2" />
            Generate New Plan
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50">AI Meal Planner</h1>
          <p className="text-dark-400">Personalized meal plans for your wellness journey</p>
        </div>

        {/* Week Navigation */}
        <Card className="bg-dark-800 border-dark-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-dark-50">Week of {getFormattedDate(currentWeek)}</h3>
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    const prev = new Date(currentWeek);
                    prev.setDate(prev.getDate() - 7);
                    setCurrentWeek(getWeekStart(prev));
                  }}
                  variant="outline"
                  size="sm"
                  className="border-dark-600"
                >
                  Previous
                </Button>
                <Button
                  onClick={() => {
                    const next = new Date(currentWeek);
                    next.setDate(next.getDate() + 7);
                    setCurrentWeek(getWeekStart(next));
                  }}
                  variant="outline"
                  size="sm"
                  className="border-dark-600"
                >
                  Next
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-7 gap-2">
              {weekDays.map((day) => (
                <Button
                  key={day}
                  onClick={() => setSelectedDay(day)}
                  variant={selectedDay === day ? "default" : "outline"}
                  className={`p-3 text-center ${
                    selectedDay === day 
                      ? "bg-primary hover:bg-primary/80" 
                      : "border-dark-600 hover:border-dark-500"
                  }`}
                >
                  <div>
                    <div className="text-xs">{getDayName(day).slice(0, 3)}</div>
                    <div className="text-sm font-medium">{getFormattedDate(day).split(' ')[1]}</div>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Meal Plan Overview */}
        {mealPlan && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-dark-800 border-dark-700">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary">{mealPlan.totalCalories}</div>
                <div className="text-sm text-dark-400">Weekly Calories</div>
              </CardContent>
            </Card>
            <Card className="bg-dark-800 border-dark-700">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-secondary">{mealPlan.avgHealthScore}</div>
                <div className="text-sm text-dark-400">Avg Health Score</div>
              </CardContent>
            </Card>
            <Card className="bg-dark-800 border-dark-700">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-accent">{mealPlan.groceryList?.length || 0}</div>
                <div className="text-sm text-dark-400">Grocery Items</div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Daily Meals */}
        {selectedMeals ? (
          <div className="grid gap-4">
            <Card className="bg-dark-800 border-dark-700">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                  <Utensils className="h-5 w-5" />
                  {getDayName(selectedDay)} - {getFormattedDate(selectedDay)}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Breakfast */}
                <div>
                  <h4 className="font-medium text-dark-50 mb-3">Breakfast</h4>
                  <Card className="bg-dark-700 border-dark-600">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="font-medium text-dark-50">{selectedMeals.breakfast.name}</h5>
                        <Badge className={`${
                          selectedMeals.breakfast.healthScore === 'A' ? 'bg-green-500/20 text-green-400' :
                          selectedMeals.breakfast.healthScore === 'B' ? 'bg-blue-500/20 text-blue-400' :
                          selectedMeals.breakfast.healthScore === 'C' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {selectedMeals.breakfast.healthScore}
                        </Badge>
                      </div>
                      <p className="text-dark-400 text-sm mb-3">{selectedMeals.breakfast.description}</p>
                      <div className="flex gap-4 text-xs text-dark-400">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {selectedMeals.breakfast.prepTime}min
                        </span>
                        <span>{selectedMeals.breakfast.calories} cal</span>
                        <span className="capitalize">{selectedMeals.breakfast.difficulty}</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Lunch */}
                <div>
                  <h4 className="font-medium text-dark-50 mb-3">Lunch</h4>
                  <Card className="bg-dark-700 border-dark-600">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="font-medium text-dark-50">{selectedMeals.lunch.name}</h5>
                        <Badge className={`${
                          selectedMeals.lunch.healthScore === 'A' ? 'bg-green-500/20 text-green-400' :
                          selectedMeals.lunch.healthScore === 'B' ? 'bg-blue-500/20 text-blue-400' :
                          selectedMeals.lunch.healthScore === 'C' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {selectedMeals.lunch.healthScore}
                        </Badge>
                      </div>
                      <p className="text-dark-400 text-sm mb-3">{selectedMeals.lunch.description}</p>
                      <div className="flex gap-4 text-xs text-dark-400">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {selectedMeals.lunch.prepTime}min
                        </span>
                        <span>{selectedMeals.lunch.calories} cal</span>
                        <span className="capitalize">{selectedMeals.lunch.difficulty}</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Dinner */}
                <div>
                  <h4 className="font-medium text-dark-50 mb-3">Dinner</h4>
                  <Card className="bg-dark-700 border-dark-600">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="font-medium text-dark-50">{selectedMeals.dinner.name}</h5>
                        <Badge className={`${
                          selectedMeals.dinner.healthScore === 'A' ? 'bg-green-500/20 text-green-400' :
                          selectedMeals.dinner.healthScore === 'B' ? 'bg-blue-500/20 text-blue-400' :
                          selectedMeals.dinner.healthScore === 'C' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {selectedMeals.dinner.healthScore}
                        </Badge>
                      </div>
                      <p className="text-dark-400 text-sm mb-3">{selectedMeals.dinner.description}</p>
                      <div className="flex gap-4 text-xs text-dark-400">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {selectedMeals.dinner.prepTime}min
                        </span>
                        <span>{selectedMeals.dinner.calories} cal</span>
                        <span className="capitalize">{selectedMeals.dinner.difficulty}</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Snacks */}
                {selectedMeals.snacks.length > 0 && (
                  <div>
                    <h4 className="font-medium text-dark-50 mb-3">Snacks</h4>
                    <div className="grid gap-3">
                      {selectedMeals.snacks.map((snack, index) => (
                        <Card key={index} className="bg-dark-700 border-dark-600">
                          <CardContent className="p-3">
                            <div className="flex justify-between items-center">
                              <h5 className="font-medium text-dark-50 text-sm">{snack.name}</h5>
                              <span className="text-xs text-dark-400">{snack.calories} cal</span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ) : !isLoading && !mealPlan ? (
          <Card className="bg-dark-800 border-dark-700 p-8 text-center">
            <ChefHat className="h-16 w-16 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-dark-50 mb-2">No meal plan yet</h3>
            <p className="text-dark-400 mb-6">Generate your first AI-powered meal plan to get started</p>
            <Button
              onClick={() => setShowPlanner(true)}
              className="bg-primary hover:bg-primary/80"
            >
              <Wand2 className="h-4 w-4 mr-2" />
              Generate Meal Plan
            </Button>
          </Card>
        ) : null}

        {/* Grocery List */}
        {mealPlan?.groceryList && (
          <Card className="bg-dark-800 border-dark-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Grocery List
                </CardTitle>
                <Button
                  onClick={copyGroceryList}
                  variant="outline"
                  size="sm"
                  className="border-dark-600"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy List
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(
                  mealPlan.groceryList.reduce((acc, item) => {
                    if (!acc[item.category]) acc[item.category] = [];
                    acc[item.category].push(item);
                    return acc;
                  }, {} as Record<string, GroceryItem[]>)
                ).map(([category, items]) => (
                  <div key={category}>
                    <h4 className="font-medium text-dark-50 mb-2 capitalize">{category}</h4>
                    <div className="grid gap-2">
                      {items.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                          <div className="flex items-center gap-3">
                            <Checkbox className="border-dark-500" />
                            <span className="text-dark-50">{item.name}</span>
                            <span className="text-dark-400 text-sm">- {item.quantity}</span>
                            {item.isHealthy && (
                              <Badge className="bg-green-500/20 text-green-400 text-xs">Healthy</Badge>
                            )}
                          </div>
                          <span className="text-dark-400 text-sm">${item.estimated_cost.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                <div className="pt-4 border-t border-dark-600">
                  <div className="flex justify-between text-lg font-semibold">
                    <span className="text-dark-50">Estimated Total:</span>
                    <span className="text-primary">
                      ${mealPlan.groceryList.reduce((sum, item) => sum + item.estimated_cost, 0).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Meal Plan Generator Modal */}
        {showPlanner && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">Generate AI Meal Plan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Dietary Restrictions</label>
                  <div className="grid grid-cols-2 gap-2">
                    {['vegetarian', 'vegan', 'gluten-free', 'dairy-free', 'keto', 'paleo', 'low-carb', 'mediterranean'].map(restriction => (
                      <div key={restriction} className="flex items-center space-x-2">
                        <Checkbox
                          checked={plannerForm.dietaryRestrictions.includes(restriction)}
                          onCheckedChange={(checked) => handleDietaryRestrictionChange(restriction, checked as boolean)}
                        />
                        <label className="text-sm text-dark-300 capitalize">{restriction}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-dark-50 mb-2">Servings</label>
                    <Select value={plannerForm.servings.toString()} onValueChange={(value) => setPlannerForm(prev => ({ ...prev, servings: parseInt(value) }))}>
                      <SelectTrigger className="bg-dark-700 border-dark-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-700 border-dark-600">
                        <SelectItem value="1">1 person</SelectItem>
                        <SelectItem value="2">2 people</SelectItem>
                        <SelectItem value="3">3 people</SelectItem>
                        <SelectItem value="4">4 people</SelectItem>
                        <SelectItem value="5">5+ people</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-dark-50 mb-2">Weekly Budget</label>
                    <Input
                      type="number"
                      value={plannerForm.budget}
                      onChange={(e) => setPlannerForm(prev => ({ ...prev, budget: parseInt(e.target.value) }))}
                      className="bg-dark-700 border-dark-600"
                      placeholder="100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Time Constraints</label>
                  <Select value={plannerForm.timeConstraints} onValueChange={(value) => setPlannerForm(prev => ({ ...prev, timeConstraints: value }))}>
                    <SelectTrigger className="bg-dark-700 border-dark-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-dark-700 border-dark-600">
                      <SelectItem value="minimal">Minimal prep (15-30 min)</SelectItem>
                      <SelectItem value="moderate">Moderate prep (30-60 min)</SelectItem>
                      <SelectItem value="extended">Extended prep (60+ min)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Health Goal</label>
                  <Select value={plannerForm.healthGoal} onValueChange={(value) => setPlannerForm(prev => ({ ...prev, healthGoal: value }))}>
                    <SelectTrigger className="bg-dark-700 border-dark-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-dark-700 border-dark-600">
                      <SelectItem value="weight-loss">Weight Loss</SelectItem>
                      <SelectItem value="muscle-gain">Muscle Gain</SelectItem>
                      <SelectItem value="balanced">Balanced Nutrition</SelectItem>
                      <SelectItem value="low-sugar">Low Sugar</SelectItem>
                      <SelectItem value="high-protein">High Protein</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Avoid Ingredients</label>
                  <Textarea
                    value={plannerForm.avoidIngredients}
                    onChange={(e) => setPlannerForm(prev => ({ ...prev, avoidIngredients: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="e.g., nuts, shellfish, mushrooms..."
                    rows={2}
                  />
                </div>

                <div className="flex justify-end gap-3">
                  <Button
                    onClick={() => setShowPlanner(false)}
                    variant="outline"
                    className="border-dark-600"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => generatePlanMutation.mutate(plannerForm)}
                    disabled={generatePlanMutation.isPending}
                    className="bg-primary hover:bg-primary/80"
                  >
                    {generatePlanMutation.isPending ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Wand2 className="h-4 w-4 mr-2" />
                        Generate Plan
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}