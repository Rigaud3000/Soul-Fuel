import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthenticatedRequest } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import MoodChart from "@/components/mood-chart";

const moodOptions = [
  { emoji: "😊", label: "Happy", value: "happy" },
  { emoji: "😐", label: "Okay", value: "okay" },
  { emoji: "😢", label: "Sad", value: "sad" },
  { emoji: "😰", label: "Stressed", value: "stressed" },
];

export default function MoodTracker() {
  const [, setLocation] = useLocation();
  const { getAuthHeaders } = useAuthenticatedRequest();
  const [selectedMood, setSelectedMood] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: moodEntries } = useQuery({
    queryKey: ["/api/mood-entries"],
    queryFn: async () => {
      const response = await fetch("/api/mood-entries", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch mood entries");
      return response.json();
    },
  });

  const addMoodMutation = useMutation({
    mutationFn: async (mood: string) => {
      return apiRequest("POST", "/api/mood-entries", {
        mood,
        date: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      toast({
        title: "Mood logged",
        description: "Your mood has been recorded successfully.",
      });
      setSelectedMood("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to log mood",
        variant: "destructive",
      });
    },
  });

  const handleMoodSelect = (mood: string) => {
    setSelectedMood(mood);
    addMoodMutation.mutate(mood);
  };

  // Get this week's mood data
  const getThisWeekMoods = () => {
    if (!moodEntries) return [];
    
    const now = new Date();
    const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
    const weekEnd = new Date(weekStart.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    return moodEntries.filter((entry: any) => {
      const entryDate = new Date(entry.date);
      return entryDate >= weekStart && entryDate < weekEnd;
    });
  };

  const thisWeekMoods = getThisWeekMoods();
  const weeklyMoodData = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
    const dayMood = thisWeekMoods.find((entry: any) => {
      const entryDate = new Date(entry.date);
      return entryDate.getDay() === (index + 1) % 7;
    });
    
    return {
      day,
      mood: dayMood?.mood || null,
      emoji: dayMood ? moodOptions.find(opt => opt.value === dayMood.mood)?.emoji : '🤷'
    };
  });

  return (
    <div className="pb-20 bg-dark-900 min-h-screen">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <Button
            onClick={() => setLocation("/")}
            className="mr-4 text-dark-400 p-0"
            variant="ghost"
          >
            <ArrowLeft size={24} />
          </Button>
          <h2 className="text-2xl font-bold text-dark-50">Mood Tracker</h2>
        </div>

        {/* Mood Check-in */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">How are you feeling right now?</h3>
          <div className="grid grid-cols-4 gap-4 mb-4">
            {moodOptions.map((option) => (
              <Button
                key={option.value}
                onClick={() => handleMoodSelect(option.value)}
                disabled={addMoodMutation.isPending}
                className="mood-emoji text-4xl p-3 rounded-xl bg-dark-700 hover:bg-dark-600 text-center border-0 h-auto aspect-square flex flex-col items-center justify-center transition-all duration-200 hover:scale-105"
                variant="ghost"
              >
                <span className="mb-1">{option.emoji}</span>
              </Button>
            ))}
          </div>
          <div className="grid grid-cols-4 gap-4 text-xs text-center text-dark-400">
            {moodOptions.map((option) => (
              <div key={option.value}>{option.label}</div>
            ))}
          </div>
        </Card>

        {/* Mood History */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">This Week's Mood</h3>
          <div className="grid grid-cols-7 gap-2 mb-4">
            {weeklyMoodData.map((data, index) => {
              const isToday = index === new Date().getDay() - 1;
              
              return (
                <div key={index} className="text-center">
                  <div className="text-xs text-dark-400 mb-1">{data.day}</div>
                  <div className={`text-2xl ${data.mood ? '' : 'opacity-30'} ${isToday ? 'ring-2 ring-secondary rounded-lg p-1' : ''}`}>
                    {data.emoji}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Mood Chart */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4 mb-6">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">Mood Trends</h3>
          <MoodChart entries={moodEntries || []} />
        </Card>

        {/* Mood Insights */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl p-4">
          <h3 className="text-lg font-semibold mb-3 text-dark-50">AI Insights</h3>
          <div className="space-y-3">
            <div className="bg-secondary/10 border border-secondary/20 rounded-lg p-3">
              <p className="text-sm text-dark-50">
                📊 You've logged {thisWeekMoods.length} mood check-ins this week. 
                {thisWeekMoods.length < 7 && " Try to check in daily for better insights!"}
              </p>
            </div>
            {thisWeekMoods.length > 3 && (
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
                <p className="text-sm text-dark-50">
                  🌟 Great consistency! Regular mood tracking helps identify patterns and improve emotional well-being.
                </p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
