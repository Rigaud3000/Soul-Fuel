import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Calendar,
  Clock,
  Video,
  MessageSquare,
  User,
  Star,
  CheckCircle,
  Plus
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface Expert {
  id: string;
  name: string;
  title: string;
  specialties: string[];
  rating: number;
  totalConsultations: number;
  hourlyRate: number;
  availability: string[];
  profileImage: string;
  bio: string;
}

interface Consultation {
  id: string;
  expertId: string;
  expertName: string;
  date: string;
  time: string;
  duration: number;
  type: 'video' | 'phone' | 'chat';
  status: 'scheduled' | 'completed' | 'cancelled';
  topic: string;
  notes?: string;
}

export default function ExpertConsultation() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [selectedExpert, setSelectedExpert] = useState<Expert | null>(null);
  const [bookingForm, setBookingForm] = useState({
    date: '',
    time: '',
    type: 'video',
    topic: '',
    notes: ''
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock data for demonstration
  const experts: Expert[] = [
    {
      id: 'dr-smith',
      name: 'Dr. Sarah Smith',
      title: 'Registered Dietitian & Sugar Addiction Specialist',
      specialties: ['Sugar Addiction', 'Nutrition Planning', 'Behavioral Psychology'],
      rating: 4.9,
      totalConsultations: 1247,
      hourlyRate: 150,
      availability: ['Monday 9-17', 'Wednesday 9-17', 'Friday 9-17'],
      profileImage: '/api/placeholder/expert-1',
      bio: 'Dr. Smith has 15+ years of experience helping people overcome sugar addiction and develop sustainable eating habits.'
    },
    {
      id: 'dr-jones',
      name: 'Dr. Michael Jones',
      title: 'Clinical Psychologist & Habit Formation Expert',
      specialties: ['Habit Formation', 'Cognitive Behavioral Therapy', 'Motivation'],
      rating: 4.8,
      totalConsultations: 892,
      hourlyRate: 120,
      availability: ['Tuesday 10-18', 'Thursday 10-18', 'Saturday 9-15'],
      profileImage: '/api/placeholder/expert-2',
      bio: 'Specialized in the psychology of habit change and breaking addictive patterns through evidence-based methods.'
    }
  ];

  const consultations: Consultation[] = [
    {
      id: 'consult-1',
      expertId: 'dr-smith',
      expertName: 'Dr. Sarah Smith',
      date: '2025-01-03',
      time: '14:00',
      duration: 60,
      type: 'video',
      status: 'scheduled',
      topic: 'Sugar Craving Management',
      notes: 'Discussing evening sugar cravings and meal timing strategies'
    }
  ];

  // Book consultation mutation
  const bookConsultationMutation = useMutation({
    mutationFn: async (data: typeof bookingForm & { expertId: string }) => {
      const response = await apiRequest("POST", "/api/consultations", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/consultations"] });
      setShowBookingForm(false);
      setSelectedExpert(null);
      toast({
        title: "Consultation booked",
        description: "You'll receive a confirmation email shortly",
      });
    },
  });

  const handleBookConsultation = (expert: Expert) => {
    setSelectedExpert(expert);
    setShowBookingForm(true);
  };

  const submitBooking = () => {
    if (!selectedExpert) return;
    bookConsultationMutation.mutate({
      ...bookingForm,
      expertId: selectedExpert.id
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to book consultations</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            size="sm"
            className="text-dark-400 hover:text-dark-200"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50 flex items-center justify-center gap-2">
            <User className="h-8 w-8 text-primary" />
            Expert Consultations
          </h1>
          <p className="text-dark-400">Get personalized guidance from certified specialists</p>
        </div>

        {/* Upcoming Consultations */}
        {consultations.length > 0 && (
          <Card className="bg-dark-800 border-dark-700">
            <CardHeader>
              <CardTitle className="text-lg text-dark-50">Upcoming Consultations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {consultations.map((consultation) => (
                  <div key={consultation.id} className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-primary/20 rounded-lg text-primary">
                        <Video className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="font-medium text-dark-50">{consultation.expertName}</h4>
                        <p className="text-dark-400 text-sm">{consultation.topic}</p>
                        <div className="flex items-center gap-4 text-xs text-dark-400 mt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(consultation.date).toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {consultation.time}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className="bg-green-500/20 text-green-400">
                        {consultation.status}
                      </Badge>
                      <Button size="sm" className="bg-primary hover:bg-primary/80">
                        Join Call
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Available Experts */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50">Available Experts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6">
              {experts.map((expert) => (
                <Card key={expert.id} className="bg-dark-700 border-dark-600">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start gap-4">
                        <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center">
                          <User className="h-8 w-8 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-dark-50">{expert.name}</h3>
                          <p className="text-dark-400 text-sm mb-2">{expert.title}</p>
                          <div className="flex items-center gap-2 mb-2">
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                              <span className="text-dark-50 text-sm">{expert.rating}</span>
                            </div>
                            <span className="text-dark-400 text-sm">
                              ({expert.totalConsultations} consultations)
                            </span>
                          </div>
                          <div className="flex gap-2 mb-3">
                            {expert.specialties.map((specialty, index) => (
                              <Badge key={index} className="bg-blue-500/20 text-blue-400 text-xs">
                                {specialty}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-dark-50">${expert.hourlyRate}/hr</div>
                        <Button
                          onClick={() => handleBookConsultation(expert)}
                          className="bg-primary hover:bg-primary/80 mt-2"
                        >
                          Book Session
                        </Button>
                      </div>
                    </div>
                    
                    <p className="text-dark-300 text-sm mb-4">{expert.bio}</p>
                    
                    <div>
                      <h4 className="text-sm font-medium text-dark-50 mb-2">Availability:</h4>
                      <div className="flex gap-2">
                        {expert.availability.map((slot, index) => (
                          <Badge key={index} className="bg-green-500/20 text-green-400 text-xs">
                            {slot}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Benefits Section */}
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50">Why Choose Expert Consultations?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4">
                <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-3" />
                <h4 className="font-medium text-dark-50 mb-2">Personalized Guidance</h4>
                <p className="text-dark-400 text-sm">Get customized strategies based on your unique situation and goals</p>
              </div>
              <div className="text-center p-4">
                <Star className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
                <h4 className="font-medium text-dark-50 mb-2">Certified Experts</h4>
                <p className="text-dark-400 text-sm">Work with licensed professionals who specialize in sugar addiction recovery</p>
              </div>
              <div className="text-center p-4">
                <Video className="h-8 w-8 text-blue-400 mx-auto mb-3" />
                <h4 className="font-medium text-dark-50 mb-2">Flexible Sessions</h4>
                <p className="text-dark-400 text-sm">Choose video, phone, or chat consultations that fit your schedule</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Booking Modal */}
        {showBookingForm && selectedExpert && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-dark-800 border-dark-700 w-full max-w-lg">
              <CardHeader>
                <CardTitle className="text-lg text-dark-50">
                  Book Consultation with {selectedExpert.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Preferred Date</label>
                  <Input
                    type="date"
                    value={bookingForm.date}
                    onChange={(e) => setBookingForm(prev => ({ ...prev, date: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Preferred Time</label>
                  <Input
                    type="time"
                    value={bookingForm.time}
                    onChange={(e) => setBookingForm(prev => ({ ...prev, time: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Session Type</label>
                  <Select value={bookingForm.type} onValueChange={(value) => setBookingForm(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger className="bg-dark-700 border-dark-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-dark-700 border-dark-600">
                      <SelectItem value="video">Video Call</SelectItem>
                      <SelectItem value="phone">Phone Call</SelectItem>
                      <SelectItem value="chat">Chat Session</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Topic/Focus Area</label>
                  <Input
                    value={bookingForm.topic}
                    onChange={(e) => setBookingForm(prev => ({ ...prev, topic: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="e.g., Evening sugar cravings"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-50 mb-2">Additional Notes (Optional)</label>
                  <Textarea
                    value={bookingForm.notes}
                    onChange={(e) => setBookingForm(prev => ({ ...prev, notes: e.target.value }))}
                    className="bg-dark-700 border-dark-600"
                    placeholder="Any specific concerns or questions..."
                    rows={3}
                  />
                </div>
                <div className="flex justify-end gap-3">
                  <Button
                    onClick={() => setShowBookingForm(false)}
                    variant="outline"
                    className="border-dark-600"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={submitBooking}
                    disabled={bookConsultationMutation.isPending}
                    className="bg-primary hover:bg-primary/80"
                  >
                    Book Session - ${selectedExpert.hourlyRate}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}