import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Users, 
  Trophy, 
  Target, 
  Calendar,
  Crown,
  CheckCircle,
  Clock,
  TrendingUp,
  Medal,
  Star,
  Flame
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface Challenge {
  id: number;
  title: string;
  description: string;
  type: 'sugar_reduction' | 'mood_tracking' | 'streak_building' | 'community';
  difficulty: 'easy' | 'medium' | 'hard';
  duration: number; // days
  target: number;
  participants: number;
  maxParticipants?: number;
  startDate: string;
  endDate: string;
  status: 'upcoming' | 'active' | 'completed';
  reward: {
    points: number;
    badge?: string;
    tier?: string;
  };
  progress?: {
    current: number;
    target: number;
    rank?: number;
  };
  isJoined?: boolean;
}

interface Leaderboard {
  userId: number;
  username: string;
  progress: number;
  rank: number;
  points: number;
  isCurrentUser?: boolean;
}

export default function Challenges() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("active");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch challenges
  const { data: challenges = [], isLoading } = useQuery<Challenge[]>({
    queryKey: ["/api/challenges"],
    enabled: !!user,
  });

  // Fetch leaderboard for active challenges
  const { data: leaderboard = [] } = useQuery<Leaderboard[]>({
    queryKey: ["/api/challenges/leaderboard"],
    enabled: !!user,
  });

  // Join challenge mutation
  const joinChallengeMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      const response = await apiRequest("POST", `/api/challenges/${challengeId}/join`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/challenges"] });
      toast({
        title: "Challenge joined!",
        description: "You're now part of this challenge. Good luck!",
      });
    },
    onError: () => {
      toast({
        title: "Failed to join challenge",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  // Leave challenge mutation
  const leaveChallengeMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      const response = await apiRequest("DELETE", `/api/challenges/${challengeId}/leave`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/challenges"] });
      toast({
        title: "Left challenge",
        description: "You have left this challenge.",
      });
    },
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-500/20 text-green-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'hard': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming': return 'bg-blue-500/20 text-blue-400';
      case 'active': return 'bg-green-500/20 text-green-400';
      case 'completed': return 'bg-gray-500/20 text-gray-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getChallengeIcon = (type: string) => {
    switch (type) {
      case 'sugar_reduction': return <Target className="h-5 w-5" />;
      case 'mood_tracking': return <TrendingUp className="h-5 w-5" />;
      case 'streak_building': return <Flame className="h-5 w-5" />;
      case 'community': return <Users className="h-5 w-5" />;
      default: return <Trophy className="h-5 w-5" />;
    }
  };

  const filterChallenges = (status: string) => {
    return challenges.filter(challenge => {
      if (status === "active") return challenge.status === "active";
      if (status === "joined") return challenge.isJoined;
      if (status === "completed") return challenge.status === "completed";
      return challenge.status === "upcoming";
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 p-8 text-center">
          <h2 className="text-xl font-semibold text-dark-50 mb-4">Please sign in to view challenges</h2>
          <Button onClick={() => setLocation("/auth")} className="bg-primary hover:bg-primary/80">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-dark-50">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            size="sm"
            className="text-dark-400 hover:text-dark-200"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-dark-50">Community Challenges</h1>
          <p className="text-dark-400">Join others on your wellness journey</p>
        </div>

        {/* Challenge Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 bg-dark-800">
            <TabsTrigger value="active" className="data-[state=active]:bg-primary">
              Active
            </TabsTrigger>
            <TabsTrigger value="joined" className="data-[state=active]:bg-primary">
              My Challenges
            </TabsTrigger>
            <TabsTrigger value="upcoming" className="data-[state=active]:bg-primary">
              Upcoming
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-primary">
              Completed
            </TabsTrigger>
          </TabsList>

          {/* Active Challenges */}
          <TabsContent value="active" className="space-y-4">
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto" />
              </div>
            ) : (
              <div className="grid gap-4">
                {filterChallenges("active").map((challenge) => (
                  <Card key={challenge.id} className="bg-dark-800 border-dark-700">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-primary/20 rounded-lg text-primary">
                            {getChallengeIcon(challenge.type)}
                          </div>
                          <div>
                            <CardTitle className="text-lg text-dark-50">{challenge.title}</CardTitle>
                            <p className="text-dark-400 text-sm mt-1">{challenge.description}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getDifficultyColor(challenge.difficulty)}>
                            {challenge.difficulty}
                          </Badge>
                          <Badge className={getStatusColor(challenge.status)}>
                            {challenge.status}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-4 text-dark-400">
                          <span className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            {challenge.participants} participants
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {challenge.duration} days
                          </span>
                          <span className="flex items-center gap-1">
                            <Trophy className="h-4 w-4" />
                            {challenge.reward.points} points
                          </span>
                        </div>
                      </div>

                      {challenge.progress && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-dark-400">Progress</span>
                            <span className="text-dark-50">
                              {challenge.progress.current}/{challenge.progress.target}
                            </span>
                          </div>
                          <Progress 
                            value={(challenge.progress.current / challenge.progress.target) * 100} 
                            className="h-2"
                          />
                        </div>
                      )}

                      <div className="flex justify-between items-center">
                        {challenge.isJoined ? (
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-400" />
                            <span className="text-green-400 text-sm">Joined</span>
                            {challenge.progress?.rank && (
                              <Badge className="bg-yellow-500/20 text-yellow-400">
                                Rank #{challenge.progress.rank}
                              </Badge>
                            )}
                          </div>
                        ) : (
                          <Button
                            onClick={() => joinChallengeMutation.mutate(challenge.id)}
                            disabled={joinChallengeMutation.isPending}
                            className="bg-primary hover:bg-primary/80"
                          >
                            Join Challenge
                          </Button>
                        )}
                        
                        {challenge.isJoined && (
                          <Button
                            onClick={() => leaveChallengeMutation.mutate(challenge.id)}
                            variant="outline"
                            size="sm"
                            className="border-dark-600 text-dark-300"
                          >
                            Leave
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* My Challenges */}
          <TabsContent value="joined" className="space-y-4">
            <div className="grid gap-4">
              {filterChallenges("joined").length === 0 ? (
                <Card className="bg-dark-800 border-dark-700 p-8 text-center">
                  <h3 className="text-lg font-semibold text-dark-50 mb-2">No joined challenges</h3>
                  <p className="text-dark-400 mb-4">Join an active challenge to start tracking your progress</p>
                  <Button onClick={() => setActiveTab("active")} className="bg-primary hover:bg-primary/80">
                    Browse Challenges
                  </Button>
                </Card>
              ) : (
                filterChallenges("joined").map((challenge) => (
                  <Card key={challenge.id} className="bg-dark-800 border-dark-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-dark-50">{challenge.title}</CardTitle>
                        <Badge className="bg-green-500/20 text-green-400">Joined</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {challenge.progress && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-dark-400">Your Progress</span>
                            <span className="text-dark-50">
                              {challenge.progress.current}/{challenge.progress.target}
                            </span>
                          </div>
                          <Progress 
                            value={(challenge.progress.current / challenge.progress.target) * 100} 
                            className="h-2"
                          />
                          {challenge.progress.rank && (
                            <div className="flex items-center gap-2 mt-2">
                              <Medal className="h-4 w-4 text-yellow-400" />
                              <span className="text-yellow-400 text-sm">Rank #{challenge.progress.rank}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Upcoming and Completed tabs */}
          <TabsContent value="upcoming" className="space-y-4">
            <div className="grid gap-4">
              {filterChallenges("upcoming").map((challenge) => (
                <Card key={challenge.id} className="bg-dark-800 border-dark-700">
                  <CardHeader>
                    <CardTitle className="text-lg text-dark-50">{challenge.title}</CardTitle>
                    <p className="text-dark-400 text-sm">{challenge.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 text-sm text-dark-400">
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        Starts {new Date(challenge.startDate).toLocaleDateString()}
                      </span>
                      <Badge className="bg-blue-500/20 text-blue-400">Coming Soon</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            <div className="grid gap-4">
              {filterChallenges("completed").map((challenge) => (
                <Card key={challenge.id} className="bg-dark-800 border-dark-700">
                  <CardHeader>
                    <CardTitle className="text-lg text-dark-50">{challenge.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <Badge className="bg-gray-500/20 text-gray-400">Completed</Badge>
                      {challenge.progress && (
                        <div className="text-sm text-dark-400">
                          Final Rank: #{challenge.progress.rank}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Leaderboard */}
        {activeTab === "active" && leaderboard.length > 0 && (
          <Card className="bg-dark-800 border-dark-700">
            <CardHeader>
              <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-400" />
                Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.slice(0, 10).map((entry) => (
                  <div
                    key={entry.userId}
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      entry.isCurrentUser ? 'bg-primary/10 border border-primary/20' : 'bg-dark-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        entry.rank === 1 ? 'bg-yellow-500 text-black' :
                        entry.rank === 2 ? 'bg-gray-400 text-black' :
                        entry.rank === 3 ? 'bg-orange-500 text-black' :
                        'bg-dark-600 text-dark-200'
                      }`}>
                        {entry.rank}
                      </div>
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-primary/20 text-primary text-sm">
                          {entry.username.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className={`font-medium ${entry.isCurrentUser ? 'text-primary' : 'text-dark-50'}`}>
                          {entry.username} {entry.isCurrentUser && '(You)'}
                        </div>
                        <div className="text-dark-400 text-sm">{entry.points} points</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-dark-50 font-medium">{entry.progress}%</div>
                      <div className="text-dark-400 text-sm">progress</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}