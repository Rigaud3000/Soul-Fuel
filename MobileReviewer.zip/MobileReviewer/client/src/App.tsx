import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import { LanguageProvider } from "@/contexts/LanguageContext";

import AuthPage from "@/pages/auth";
import Dashboard from "@/pages/dashboard";
import SugarTracker from "@/pages/sugar-tracker";
import MoodTracker from "@/pages/mood-tracker";
import CravingTracker from "@/pages/craving-tracker";
import UnifiedTracking from "@/pages/unified-tracking";
import Tracking from "@/pages/tracking";
import AICoach from "@/pages/ai-coach";
import SoulCompanion from "@/pages/soul-companion";
import FoodScanner from "@/pages/enhanced-food-scanner";
import Recipes from "@/pages/recipes";
import HealthyRecipes from "@/pages/healthy-recipes";
import CravingEmergency from "@/pages/craving-emergency";
import WithdrawalTracker from "@/pages/withdrawal-tracker";
import Community from "@/pages/community";
import Gamification from "@/pages/gamification";
import Subscription from "@/pages/subscription";
import Challenges from "@/pages/challenges";
import MealPlanner from "@/pages/meal-planner";
import Emergency from "@/pages/emergency";
import HealingGames from "@/pages/healing-games";
import HabitScience from "@/pages/habit-science";
import WearableDevices from "@/pages/wearable-devices";
import PredictiveWellnessPage from "@/pages/predictive-wellness";
import ExpertConsultation from "@/pages/expert-consultation";
import FamilyManagement from "@/pages/family-management";
import PredictiveAlerts from "@/pages/predictive-alerts";
import AdvancedAnalytics from "@/pages/analytics";
import IntelligentNotifications from "@/pages/notifications";
import Settings from "@/pages/settings";
import DataExportPage from "@/pages/data-export";
import AdminDashboard from "@/pages/admin-dashboard";

import BottomNavigation from "@/components/bottom-navigation";
import { CraveClock } from "@/components/crave-clock";
import { VoiceSoulTalk } from "@/components/voice-soul-talk";
import { CrisisMode } from "@/components/crisis-mode";
import { KnowledgeScrolls } from "@/components/knowledge-scrolls";

function AppContent() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Temporarily bypass login for app testing
  // if (!user) {
  //   return <AuthPage />;
  // }

  return (
    <div className="max-w-md mx-auto bg-dark-900 min-h-screen relative">
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/sugar" component={SugarTracker} />
        <Route path="/mood" component={MoodTracker} />
        <Route path="/cravings" component={CravingTracker} />
        <Route path="/tracking" component={UnifiedTracking} />
        <Route path="/coach" component={AICoach} />
        <Route path="/soul-companion" component={SoulCompanion} />
        <Route path="/scanner" component={FoodScanner} />
        <Route path="/recipes" component={Recipes} />
        <Route path="/healthy-recipes" component={HealthyRecipes} />
        <Route path="/emergency" component={CravingEmergency} />
        <Route path="/withdrawal" component={WithdrawalTracker} />
        <Route path="/community" component={Community} />
        <Route path="/progress" component={Gamification} />
        <Route path="/subscription" component={Subscription} />
        <Route path="/challenges" component={Challenges} />
        <Route path="/meal-planner" component={MealPlanner} />
        <Route path="/emergency-toolkit" component={Emergency} />
        <Route path="/healing-games" component={HealingGames} />
        <Route path="/habit-science" component={HabitScience} />
        <Route path="/wearables" component={WearableDevices} />
        <Route path="/predictive-wellness" component={PredictiveWellnessPage} />
        <Route path="/expert-consultation" component={ExpertConsultation} />
        <Route path="/family-management" component={FamilyManagement} />
        <Route path="/predictive-alerts" component={PredictiveAlerts} />
        <Route path="/analytics" component={AdvancedAnalytics} />
        <Route path="/notifications" component={IntelligentNotifications} />
        <Route path="/settings" component={Settings} />
        <Route path="/data-export" component={DataExportPage} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/crave-clock" component={() => <CraveClock />} />
        <Route path="/voice-soul-talk" component={() => <VoiceSoulTalk />} />
        <Route path="/crisis-mode" component={() => <CrisisMode />} />
        <Route path="/knowledge-scrolls" component={() => <KnowledgeScrolls />} />
        <Route component={Dashboard} />
      </Switch>
      <BottomNavigation />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
          <AuthProvider>
            <AppContent />
            <Toaster />
          </AuthProvider>
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
