import React, { useState } from 'react';
import { Calendar, CheckCircle, Circle, Flame, Target, Heart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CheckInData {
  date: string;
  completed: boolean;
  sugarFree: boolean;
  moodLogged: boolean;
  exercised: boolean;
}

export function VisualCheckInTracker() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const { data: checkIns = [] } = useQuery({
    queryKey: ['/api/check-ins', user?.uid],
    enabled: !!user?.uid,
  });

  const checkInMutation = useMutation({
    mutationFn: async (checkIn: Partial<CheckInData>) => {
      return apiRequest('POST', '/api/check-ins', checkIn);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/check-ins'] });
      toast({
        title: "Daily Check-in Complete!",
        description: "Great job staying on track with your wellness journey.",
      });
    },
  });

  const handleCheckIn = (type: keyof Omit<CheckInData, 'date' | 'completed'>) => {
    checkInMutation.mutate({
      date: selectedDate,
      [type]: true
    });
  };

  const getDayStatus = (date: string) => {
    const checkIn = checkIns.find((c: CheckInData) => c.date === date);
    if (!checkIn) return 'none';
    
    const completedTasks = [checkIn.sugarFree, checkIn.moodLogged, checkIn.exercised].filter(Boolean).length;
    if (completedTasks === 3) return 'perfect';
    if (completedTasks >= 2) return 'good';
    if (completedTasks >= 1) return 'partial';
    return 'none';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'perfect': return 'text-emerald-500 bg-emerald-500/20';
      case 'good': return 'text-blue-500 bg-blue-500/20';
      case 'partial': return 'text-yellow-500 bg-yellow-500/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const generateCalendarDays = () => {
    const today = new Date();
    const days = [];
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      days.push({
        date: dateStr,
        day: date.getDate(),
        isToday: i === 0,
        status: getDayStatus(dateStr)
      });
    }
    return days;
  };

  const todayCheckIn = checkIns.find((c: CheckInData) => c.date === selectedDate);
  const streak = checkIns.filter((c: CheckInData) => c.completed).length;

  return (
    <Card className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 border-emerald-500/20 backdrop-blur-sm">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-emerald-400">
          <Calendar className="w-5 h-5" />
          Daily Check-In Tracker
          {streak > 0 && (
            <div className="flex items-center gap-1 text-sm text-orange-400">
              <Flame className="w-4 h-4" />
              {streak} day streak
            </div>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Weekly Calendar View */}
        <div className="grid grid-cols-7 gap-2">
          {generateCalendarDays().map((day) => (
            <div
              key={day.date}
              className={`aspect-square rounded-lg border-2 p-2 text-center transition-all cursor-pointer
                ${day.isToday ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-gray-700'}
                ${getStatusColor(day.status)}
              `}
              onClick={() => setSelectedDate(day.date)}
            >
              <div className="text-xs text-gray-400 mb-1">
                {new Date(day.date).toLocaleDateString('en', { weekday: 'short' })}
              </div>
              <div className="text-lg font-bold">{day.day}</div>
              <div className="mt-1">
                {day.status === 'perfect' && <CheckCircle className="w-4 h-4 mx-auto text-emerald-500" />}
                {day.status === 'good' && <CheckCircle className="w-4 h-4 mx-auto text-blue-500" />}
                {day.status === 'partial' && <Circle className="w-4 h-4 mx-auto text-yellow-500" />}
                {day.status === 'none' && <Circle className="w-4 h-4 mx-auto text-gray-500" />}
              </div>
            </div>
          ))}
        </div>

        {/* Today's Check-in Tasks */}
        {selectedDate === new Date().toISOString().split('T')[0] && (
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-white">Today's Wellness Goals</h3>
            
            <div className="grid gap-3">
              <Button
                onClick={() => handleCheckIn('sugarFree')}
                disabled={todayCheckIn?.sugarFree || checkInMutation.isPending}
                className={`flex items-center justify-between p-4 h-auto text-left
                  ${todayCheckIn?.sugarFree 
                    ? 'bg-emerald-600 hover:bg-emerald-600' 
                    : 'bg-slate-700 hover:bg-slate-600'
                  }`}
              >
                <div className="flex items-center gap-3">
                  <Target className="w-5 h-5" />
                  <div>
                    <div className="font-semibold">Stay Sugar-Free</div>
                    <div className="text-sm opacity-80">Avoid processed sugars today</div>
                  </div>
                </div>
                {todayCheckIn?.sugarFree && <CheckCircle className="w-6 h-6 text-emerald-300" />}
              </Button>

              <Button
                onClick={() => handleCheckIn('moodLogged')}
                disabled={todayCheckIn?.moodLogged || checkInMutation.isPending}
                className={`flex items-center justify-between p-4 h-auto text-left
                  ${todayCheckIn?.moodLogged 
                    ? 'bg-emerald-600 hover:bg-emerald-600' 
                    : 'bg-slate-700 hover:bg-slate-600'
                  }`}
              >
                <div className="flex items-center gap-3">
                  <Heart className="w-5 h-5" />
                  <div>
                    <div className="font-semibold">Log Your Mood</div>
                    <div className="text-sm opacity-80">Track your emotional state</div>
                  </div>
                </div>
                {todayCheckIn?.moodLogged && <CheckCircle className="w-6 h-6 text-emerald-300" />}
              </Button>

              <Button
                onClick={() => handleCheckIn('exercised')}
                disabled={todayCheckIn?.exercised || checkInMutation.isPending}
                className={`flex items-center justify-between p-4 h-auto text-left
                  ${todayCheckIn?.exercised 
                    ? 'bg-emerald-600 hover:bg-emerald-600' 
                    : 'bg-slate-700 hover:bg-slate-600'
                  }`}
              >
                <div className="flex items-center gap-3">
                  <Flame className="w-5 h-5" />
                  <div>
                    <div className="font-semibold">Move Your Body</div>
                    <div className="text-sm opacity-80">Any physical activity counts</div>
                  </div>
                </div>
                {todayCheckIn?.exercised && <CheckCircle className="w-6 h-6 text-emerald-300" />}
              </Button>
            </div>
          </div>
        )}

        {/* Progress Summary */}
        <div className="bg-slate-800/50 rounded-lg p-4 border border-gray-700">
          <div className="flex justify-between items-center">
            <span className="text-gray-300">Weekly Progress</span>
            <span className="text-emerald-400 font-semibold">
              {checkIns.filter((c: CheckInData) => c.completed).length}/7 days
            </span>
          </div>
          <div className="mt-2 bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-2 rounded-full transition-all duration-500"
              style={{ width: `${(checkIns.filter((c: CheckInData) => c.completed).length / 7) * 100}%` }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}