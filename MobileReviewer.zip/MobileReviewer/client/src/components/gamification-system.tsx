import React, { useState, useEffect } from 'react';
import { Gift, Star, Trophy, Crown, Flame, Target, Calendar, Volume2, VolumeX, Play, Pause } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface DailyReward {
  day: number;
  xp: number;
  badges?: string[];
  special?: string;
  claimed: boolean;
}

interface AudioGuidance {
  id: string;
  title: string;
  type: 'coaching' | 'meditation' | 'craving_support';
  duration: number;
  description: string;
  audioUrl: string;
  unlockLevel: number;
}

interface UserProgress {
  currentXP: number;
  level: number;
  dailyLoginStreak: number;
  lastLoginDate: Date;
  totalBadges: number;
  weeklyXP: number;
  monthlyXP: number;
}

export function GamificationSystem() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [rewardDialogOpen, setRewardDialogOpen] = useState(false);
  const [audioDialogOpen, setAudioDialogOpen] = useState(false);
  const [selectedAudio, setSelectedAudio] = useState<AudioGuidance | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(70);
  const [audioRef, setAudioRef] = useState<HTMLAudioElement | null>(null);

  const { data: userProgress } = useQuery({
    queryKey: ['/api/user/progress', user?.uid],
    enabled: !!user?.uid,
  });

  const { data: dailyRewards = [] } = useQuery({
    queryKey: ['/api/daily-rewards', user?.uid],
    enabled: !!user?.uid,
  });

  const { data: audioGuidances = [] } = useQuery({
    queryKey: ['/api/audio-guidance'],
    enabled: !!user?.uid,
  });

  const claimDailyRewardMutation = useMutation({
    mutationFn: async (day: number) => {
      return apiRequest("POST", `/api/daily-rewards/claim/${day}`);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-rewards'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/progress'] });
      
      toast({
        title: "Daily Reward Claimed!",
        description: `You earned ${data.xp} XP and new achievements!`,
      });
      
      showRewardAnimation(data);
    },
  });

  const checkDailyLoginMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/daily-login");
    },
    onSuccess: (data) => {
      if (data.newDay) {
        queryClient.invalidateQueries({ queryKey: ['/api/user/progress'] });
        queryClient.invalidateQueries({ queryKey: ['/api/daily-rewards'] });
        
        if (data.bonusXP > 0) {
          toast({
            title: "Welcome Back!",
            description: `Daily login bonus: +${data.bonusXP} XP`,
          });
        }
      }
    },
  });

  useEffect(() => {
    // Check for daily login bonus when component mounts
    if (user?.uid) {
      checkDailyLoginMutation.mutate();
    }
  }, [user?.uid]);

  useEffect(() => {
    if (audioRef) {
      audioRef.volume = volume / 100;
    }
  }, [volume, audioRef]);

  const showRewardAnimation = (reward: DailyReward) => {
    setRewardDialogOpen(true);
    
    // Auto-close after 3 seconds
    setTimeout(() => {
      setRewardDialogOpen(false);
    }, 3000);
  };

  const getLevelProgress = (currentXP: number, level: number) => {
    const levelXPRequirements = [0, 100, 300, 600, 1000, 1500, 2200, 3000, 4000, 5200, 6600, 8200, 10000];
    const currentLevelXP = levelXPRequirements[level - 1] || 0;
    const nextLevelXP = levelXPRequirements[level] || levelXPRequirements[levelXPRequirements.length - 1];
    
    const progress = ((currentXP - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
    return { progress: Math.min(progress, 100), nextLevelXP, currentLevelXP };
  };

  const getDailyRewardPreview = () => {
    const today = new Date().getDay() + 1; // 1-7 for days of week
    const baseRewards: DailyReward[] = [
      { day: 1, xp: 10, claimed: false },
      { day: 2, xp: 15, claimed: false },
      { day: 3, xp: 20, badges: ['consistent'], claimed: false },
      { day: 4, xp: 25, claimed: false },
      { day: 5, xp: 30, badges: ['weekday_warrior'], claimed: false },
      { day: 6, xp: 35, claimed: false },
      { day: 7, xp: 50, badges: ['weekly_champion'], special: 'Premium Feature Unlock', claimed: false },
    ];
    
    return baseRewards.map(reward => ({
      ...reward,
      claimed: dailyRewards.some((r: DailyReward) => r.day === reward.day && r.claimed)
    }));
  };

  const playAudio = (audio: AudioGuidance) => {
    if (audioRef) {
      audioRef.pause();
    }
    
    const newAudio = new Audio(audio.audioUrl);
    setAudioRef(newAudio);
    setSelectedAudio(audio);
    setAudioDialogOpen(true);
    
    newAudio.play();
    setIsPlaying(true);
    
    newAudio.onended = () => {
      setIsPlaying(false);
    };
  };

  const togglePlayPause = () => {
    if (!audioRef) return;
    
    if (isPlaying) {
      audioRef.pause();
      setIsPlaying(false);
    } else {
      audioRef.play();
      setIsPlaying(true);
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const progress = userProgress ? getLevelProgress(userProgress.currentXP, userProgress.level) : { progress: 0, nextLevelXP: 100, currentLevelXP: 0 };
  const rewardPreview = getDailyRewardPreview();
  const canClaimToday = rewardPreview.find(r => r.day === new Date().getDay() + 1 && !r.claimed);

  return (
    <div className="space-y-6">
      {/* XP and Level Progress */}
      <Card className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Crown className="w-5 h-5" />
            Level {userProgress?.level || 1} Wellness Warrior
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span>XP Progress</span>
            <span className="font-bold">
              {userProgress?.currentXP || 0} / {progress.nextLevelXP} XP
            </span>
          </div>
          
          <Progress value={progress.progress} className="h-3 bg-white/20" />
          
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold">{userProgress?.dailyLoginStreak || 0}</div>
              <div className="text-sm opacity-80">Day Streak</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{userProgress?.totalBadges || 0}</div>
              <div className="text-sm opacity-80">Badges</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{userProgress?.weeklyXP || 0}</div>
              <div className="text-sm opacity-80">Weekly XP</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Login Rewards */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gift className="w-5 h-5" />
            Daily Login Rewards
            {canClaimToday && (
              <Badge className="bg-green-500 text-white animate-pulse">
                Available!
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {rewardPreview.map((reward) => {
              const isToday = reward.day === new Date().getDay() + 1;
              const canClaim = isToday && !reward.claimed;
              
              return (
                <Card 
                  key={reward.day} 
                  className={`relative p-3 text-center cursor-pointer transition-all ${
                    canClaim ? 'ring-2 ring-green-500 bg-green-50 dark:bg-green-950' :
                    reward.claimed ? 'bg-gray-100 dark:bg-gray-800' :
                    'hover:bg-gray-50 dark:hover:bg-gray-800'
                  }`}
                  onClick={() => canClaim && claimDailyRewardMutation.mutate(reward.day)}
                >
                  {reward.claimed && (
                    <div className="absolute top-1 right-1">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                  )}
                  
                  <div className="text-xs font-medium mb-1">Day {reward.day}</div>
                  
                  <div className="text-lg mb-1">
                    {reward.special ? '🎁' : '⭐'}
                  </div>
                  
                  <div className="text-xs">
                    <div className="font-medium">{reward.xp} XP</div>
                    {reward.badges && (
                      <div className="text-yellow-600">+Badge</div>
                    )}
                    {reward.special && (
                      <div className="text-purple-600">Special</div>
                    )}
                  </div>
                  
                  {canClaim && (
                    <Button size="sm" className="mt-2 w-full">
                      Claim
                    </Button>
                  )}
                </Card>
              );
            })}
          </div>
          
          <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg text-center">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <Flame className="w-4 h-4 inline mr-1" />
              {userProgress?.dailyLoginStreak || 0} day login streak! 
              Keep it up for bonus rewards!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Audio Guidance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Volume2 className="w-5 h-5" />
            Audio Guidance & Support
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {audioGuidances.map((audio: AudioGuidance) => {
              const isUnlocked = (userProgress?.level || 1) >= audio.unlockLevel;
              
              return (
                <Card 
                  key={audio.id} 
                  className={`relative ${!isUnlocked ? 'opacity-60' : 'cursor-pointer hover:shadow-md'}`}
                  onClick={() => isUnlocked && playAudio(audio)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${
                        audio.type === 'coaching' ? 'bg-blue-100 text-blue-600' :
                        audio.type === 'meditation' ? 'bg-purple-100 text-purple-600' :
                        'bg-red-100 text-red-600'
                      }`}>
                        {audio.type === 'coaching' ? <Target className="w-4 h-4" /> :
                         audio.type === 'meditation' ? <Star className="w-4 h-4" /> :
                         <Flame className="w-4 h-4" />}
                      </div>
                      
                      <div className="flex-1">
                        <h4 className="font-medium">{audio.title}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {audio.description}
                        </p>
                        <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                          <span>{formatDuration(audio.duration)}</span>
                          <Badge variant="outline">
                            Level {audio.unlockLevel}+
                          </Badge>
                        </div>
                      </div>
                      
                      {!isUnlocked && (
                        <div className="absolute top-2 right-2">
                          <Badge variant="secondary">🔒</Badge>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Reward Claim Dialog */}
      <Dialog open={rewardDialogOpen} onOpenChange={setRewardDialogOpen}>
        <DialogContent className="text-center">
          <DialogHeader>
            <DialogTitle className="text-2xl">🎉 Daily Reward Claimed!</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-6">
            <div className="text-6xl animate-bounce">🎁</div>
            <div className="text-xl font-bold text-green-600">
              +{canClaimToday?.xp} XP Earned!
            </div>
            {canClaimToday?.badges && (
              <div className="text-lg text-yellow-600">
                🏆 New Badge Unlocked!
              </div>
            )}
            {canClaimToday?.special && (
              <div className="text-lg text-purple-600">
                ✨ {canClaimToday.special}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Audio Player Dialog */}
      <Dialog open={audioDialogOpen} onOpenChange={setAudioDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Volume2 className="w-5 h-5" />
              {selectedAudio?.title}
            </DialogTitle>
          </DialogHeader>
          
          {selectedAudio && (
            <div className="space-y-4">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {selectedAudio.description}
              </p>
              
              <div className="flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={togglePlayPause}
                  className="rounded-full w-16 h-16"
                >
                  {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                </Button>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <VolumeX className="w-4 h-4" />
                  <Slider
                    value={[volume]}
                    onValueChange={(value) => setVolume(value[0])}
                    max={100}
                    step={1}
                    className="flex-1"
                  />
                  <Volume2 className="w-4 h-4" />
                </div>
                <div className="text-center text-sm text-gray-500">
                  Volume: {volume}%
                </div>
              </div>
              
              <div className="text-center text-sm text-gray-500">
                Duration: {formatDuration(selectedAudio.duration)}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}