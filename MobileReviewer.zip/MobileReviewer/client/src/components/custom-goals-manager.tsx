import React, { useState } from 'react';
import { Target, Plus, Edit, Trash2, Calendar, TrendingUp, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CustomGoal {
  id: string;
  title: string;
  description: string;
  category: 'nutrition' | 'mood' | 'exercise' | 'habits' | 'custom';
  targetValue: number;
  currentValue: number;
  unit: string;
  timeframe: 'daily' | 'weekly' | 'monthly';
  createdAt: Date;
  deadline?: Date;
  isCompleted: boolean;
  priority: 'low' | 'medium' | 'high';
}

export function CustomGoalsManager() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<CustomGoal | null>(null);

  const { data: goals = [] } = useQuery({
    queryKey: ['/api/custom-goals', user?.uid],
    enabled: !!user?.uid,
  });

  const createGoalMutation = useMutation({
    mutationFn: async (goalData: Partial<CustomGoal>) => {
      return apiRequest("POST", "/api/custom-goals", goalData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/custom-goals'] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Goal Created",
        description: "Your custom goal has been added successfully!",
      });
    },
  });

  const updateGoalMutation = useMutation({
    mutationFn: async ({ id, ...data }: Partial<CustomGoal> & { id: string }) => {
      return apiRequest("PATCH", `/api/custom-goals/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/custom-goals'] });
      setEditingGoal(null);
      toast({
        title: "Goal Updated",
        description: "Your goal has been updated successfully!",
      });
    },
  });

  const deleteGoalMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/custom-goals/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/custom-goals'] });
      toast({
        title: "Goal Deleted",
        description: "Goal has been removed successfully.",
      });
    },
  });

  const updateProgressMutation = useMutation({
    mutationFn: async ({ id, currentValue }: { id: string; currentValue: number }) => {
      return apiRequest("PATCH", `/api/custom-goals/${id}/progress`, { currentValue });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/custom-goals'] });
    },
  });

  const GoalForm = ({ goal, onSubmit, onCancel }: {
    goal?: CustomGoal;
    onSubmit: (data: Partial<CustomGoal>) => void;
    onCancel: () => void;
  }) => {
    const [formData, setFormData] = useState({
      title: goal?.title || '',
      description: goal?.description || '',
      category: goal?.category || 'custom',
      targetValue: goal?.targetValue || 0,
      unit: goal?.unit || '',
      timeframe: goal?.timeframe || 'weekly',
      priority: goal?.priority || 'medium',
      deadline: goal?.deadline ? new Date(goal.deadline).toISOString().split('T')[0] : '',
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      onSubmit({
        ...formData,
        deadline: formData.deadline ? new Date(formData.deadline) : undefined,
      });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="title">Goal Title</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
            placeholder="e.g., Drink 8 glasses of water daily"
            required
          />
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Describe your goal and why it's important..."
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="category">Category</Label>
            <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value as any }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="nutrition">Nutrition</SelectItem>
                <SelectItem value="mood">Mood & Mental Health</SelectItem>
                <SelectItem value="exercise">Exercise & Fitness</SelectItem>
                <SelectItem value="habits">Healthy Habits</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="priority">Priority</Label>
            <Select value={formData.priority} onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value as any }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <Label htmlFor="targetValue">Target</Label>
            <Input
              id="targetValue"
              type="number"
              value={formData.targetValue}
              onChange={(e) => setFormData(prev => ({ ...prev, targetValue: Number(e.target.value) }))}
              required
            />
          </div>

          <div>
            <Label htmlFor="unit">Unit</Label>
            <Input
              id="unit"
              value={formData.unit}
              onChange={(e) => setFormData(prev => ({ ...prev, unit: e.target.value }))}
              placeholder="e.g., glasses, minutes, times"
              required
            />
          </div>

          <div>
            <Label htmlFor="timeframe">Timeframe</Label>
            <Select value={formData.timeframe} onValueChange={(value) => setFormData(prev => ({ ...prev, timeframe: value as any }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="deadline">Deadline (Optional)</Label>
          <Input
            id="deadline"
            type="date"
            value={formData.deadline}
            onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
          />
        </div>

        <div className="flex gap-2 pt-4">
          <Button type="submit" className="flex-1">
            {goal ? 'Update Goal' : 'Create Goal'}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </form>
    );
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'nutrition': return '🥗';
      case 'mood': return '😊';
      case 'exercise': return '💪';
      case 'habits': return '⭐';
      default: return '🎯';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Custom Goals</h2>
          <p className="text-gray-600 dark:text-gray-400">Create and track your personalized health goals</p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Create Goal
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Custom Goal</DialogTitle>
            </DialogHeader>
            <GoalForm
              onSubmit={(data) => createGoalMutation.mutate(data)}
              onCancel={() => setIsCreateDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {goals.map((goal: CustomGoal) => {
          const progress = Math.min((goal.currentValue / goal.targetValue) * 100, 100);
          const isCompleted = goal.currentValue >= goal.targetValue;

          return (
            <Card key={goal.id} className="relative overflow-hidden">
              <div className={`absolute top-0 left-0 w-1 h-full ${getPriorityColor(goal.priority)}`} />
              
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getCategoryIcon(goal.category)}</span>
                    <div>
                      <CardTitle className="text-lg">{goal.title}</CardTitle>
                      <Badge variant="secondary" className="text-xs">
                        {goal.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditingGoal(goal)}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteGoalMutation.mutate(goal.id)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-3">
                  {goal.description && (
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {goal.description}
                    </p>
                  )}

                  <div className="flex justify-between items-center text-sm">
                    <span>Progress</span>
                    <span className="font-medium">
                      {goal.currentValue} / {goal.targetValue} {goal.unit}
                    </span>
                  </div>

                  <Progress value={progress} className="h-2" />

                  <div className="flex justify-between items-center">
                    <Badge variant={isCompleted ? "default" : "outline"} className="text-xs">
                      {isCompleted ? (
                        <><CheckCircle className="w-3 h-3 mr-1" />Completed</>
                      ) : (
                        <><TrendingUp className="w-3 h-3 mr-1" />{Math.round(progress)}%</>
                      )}
                    </Badge>

                    <span className="text-xs text-gray-500">
                      {goal.timeframe}
                    </span>
                  </div>

                  {goal.deadline && (
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Calendar className="w-3 h-3" />
                      Due: {new Date(goal.deadline).toLocaleDateString()}
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        const newValue = Math.min(goal.currentValue + 1, goal.targetValue);
                        updateProgressMutation.mutate({ id: goal.id, currentValue: newValue });
                      }}
                      disabled={isCompleted}
                    >
                      +1 {goal.unit}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        const input = prompt(`Update progress for "${goal.title}":`, goal.currentValue.toString());
                        if (input && !isNaN(Number(input))) {
                          updateProgressMutation.mutate({ id: goal.id, currentValue: Number(input) });
                        }
                      }}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {editingGoal && (
        <Dialog open={!!editingGoal} onOpenChange={() => setEditingGoal(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Goal</DialogTitle>
            </DialogHeader>
            <GoalForm
              goal={editingGoal}
              onSubmit={(data) => updateGoalMutation.mutate({ ...data, id: editingGoal.id })}
              onCancel={() => setEditingGoal(null)}
            />
          </DialogContent>
        </Dialog>
      )}

      {goals.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Target className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              No Custom Goals Yet
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Create your first custom goal to start tracking your personalized health journey.
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Goal
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}