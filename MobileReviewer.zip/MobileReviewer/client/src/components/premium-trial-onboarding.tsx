import React, { useState, useEffect } from 'react';
import { Crown, Star, Zap, Shield, Check, Gift, Calendar, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface TrialFeature {
  icon: React.ReactNode;
  title: string;
  description: string;
  value: string;
}

interface TestimonialData {
  name: string;
  avatar: string;
  role: string;
  content: string;
  rating: number;
  results: string;
}

export function PremiumTrialOnboarding() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showTrialDialog, setShowTrialDialog] = useState(false);
  const [trialDaysLeft, setTrialDaysLeft] = useState(7);
  const [hasTrialStarted, setHasTrialStarted] = useState(false);

  const startTrialMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/premium-trial/start");
    },
    onSuccess: (data) => {
      setHasTrialStarted(true);
      setTrialDaysLeft(data.daysRemaining);
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      
      toast({
        title: "Premium Trial Started! 🎉",
        description: "You now have access to all premium features for 7 days.",
      });
      
      setShowTrialDialog(false);
    },
  });

  const checkTrialStatusMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("GET", "/api/premium-trial/status");
    },
    onSuccess: (data) => {
      setHasTrialStarted(data.isActive);
      setTrialDaysLeft(data.daysRemaining);
    },
  });

  useEffect(() => {
    if (user?.uid && !hasTrialStarted) {
      checkTrialStatusMutation.mutate();
    }
  }, [user?.uid]);

  useEffect(() => {
    // Show trial dialog for new users after a short delay
    if (user && !hasTrialStarted && !localStorage.getItem('trial_dialog_shown')) {
      const timer = setTimeout(() => {
        setShowTrialDialog(true);
        localStorage.setItem('trial_dialog_shown', 'true');
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [user, hasTrialStarted]);

  const premiumFeatures: TrialFeature[] = [
    {
      icon: <Zap className="w-5 h-5 text-yellow-500" />,
      title: "Unlimited AI Coaching",
      description: "Get personalized coaching 24/7 with all 6 specialized AI coaches",
      value: "Unlimited vs 4 free services/week"
    },
    {
      icon: <Crown className="w-5 h-5 text-purple-500" />,
      title: "Advanced Food Scanner",
      description: "Scan unlimited foods with detailed nutrition analysis and recommendations",
      value: "Unlimited vs shared 4 services/week"
    },
    {
      icon: <Star className="w-5 h-5 text-blue-500" />,
      title: "Predictive Health Insights",
      description: "AI-powered predictions to prevent health setbacks before they happen",
      value: "Weekly predictions & alerts"
    },
    {
      icon: <Shield className="w-5 h-5 text-green-500" />,
      title: "Expert Consultations",
      description: "Book 1-on-1 sessions with certified nutritionists and wellness coaches",
      value: "2 free consultations/month"
    },
    {
      icon: <Gift className="w-5 h-5 text-red-500" />,
      title: "Premium Content Library",
      description: "Access exclusive recipes, meal plans, and wellness programs",
      value: "500+ premium resources"
    },
    {
      icon: <Calendar className="w-5 h-5 text-indigo-500" />,
      title: "Smart Meal Planning",
      description: "AI-generated weekly meal plans with automated grocery lists",
      value: "Personalized weekly plans"
    }
  ];

  const testimonials: TestimonialData[] = [
    {
      name: "Sarah Chen",
      avatar: "/api/placeholder/40/40",
      role: "Busy Professional",
      content: "SOULFUEL's AI coaching helped me break my sugar addiction in just 2 weeks. The personalized insights were game-changing!",
      rating: 5,
      results: "Lost 15 lbs, Sugar-free for 45 days"
    },
    {
      name: "Michael Rodriguez", 
      avatar: "/api/placeholder/40/40",
      role: "Fitness Enthusiast",
      content: "The food scanner and meal planning features revolutionized my nutrition. I finally understand what I'm putting in my body.",
      rating: 5,
      results: "30% better nutrition scores"
    },
    {
      name: "Emma Thompson",
      avatar: "/api/placeholder/40/40", 
      role: "Working Mom",
      content: "The expert consultations were invaluable. Having real nutritionists guide my family's wellness journey made all the difference.",
      rating: 5,
      results: "Whole family eating healthier"
    }
  ];

  const handleStartTrial = () => {
    startTrialMutation.mutate();
  };

  const trialProgress = ((7 - trialDaysLeft) / 7) * 100;

  return (
    <>
      {/* Trial Status Banner */}
      {hasTrialStarted && trialDaysLeft > 0 && (
        <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950 dark:to-indigo-950">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Crown className="w-6 h-6 text-purple-600" />
                <div>
                  <h3 className="font-semibold text-purple-900 dark:text-purple-100">
                    Premium Trial Active
                  </h3>
                  <p className="text-sm text-purple-700 dark:text-purple-300">
                    {trialDaysLeft} days remaining • All features unlocked
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <Progress value={trialProgress} className="w-24 mb-1" />
                <Button size="sm" variant="outline" className="border-purple-300">
                  Upgrade Now
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Premium Trial Dialog */}
      <Dialog open={showTrialDialog} onOpenChange={setShowTrialDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className="flex items-center justify-center gap-2 text-2xl">
                <Crown className="w-8 h-8 text-purple-600" />
                Start Your Free 7-Day Premium Trial
              </div>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-8">
            {/* Hero Section */}
            <div className="text-center space-y-4">
              <div className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white p-6 rounded-xl">
                <h3 className="text-xl font-bold mb-2">
                  Unlock Your Full Wellness Potential
                </h3>
                <p className="opacity-90">
                  Experience all premium features free for 7 days. No commitment, cancel anytime.
                </p>
                
                <div className="flex justify-center gap-8 mt-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">Unlimited</div>
                    <div className="text-sm opacity-80">AI Coaching</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">∞</div>
                    <div className="text-sm opacity-80">Food Scans</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">24/7</div>
                    <div className="text-sm opacity-80">Support</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid gap-4 md:grid-cols-2">
              {premiumFeatures.map((feature, index) => (
                <Card key={index} className="border-purple-100">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-purple-50 rounded-lg">
                        {feature.icon}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold mb-1">{feature.title}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          {feature.description}
                        </p>
                        <Badge variant="secondary" className="text-xs">
                          {feature.value}
                        </Badge>
                      </div>
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-1" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* User Testimonials */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-center">
                What Our Premium Users Say
              </h3>
              
              <div className="grid gap-4 md:grid-cols-3">
                {testimonials.map((testimonial, index) => (
                  <Card key={index} className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <img 
                          src={testimonial.avatar} 
                          alt={testimonial.name}
                          className="w-10 h-10 rounded-full"
                        />
                        <div>
                          <div className="font-medium">{testimonial.name}</div>
                          <div className="text-xs text-gray-500">{testimonial.role}</div>
                        </div>
                      </div>
                      
                      <div className="flex mb-2">
                        {Array(testimonial.rating).fill(0).map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      
                      <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                        "{testimonial.content}"
                      </p>
                      
                      <Badge variant="outline" className="text-xs">
                        {testimonial.results}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Trial Terms */}
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Trial Terms & Benefits</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>✓ Full access to all premium features for 7 days</li>
                <li>✓ No credit card required to start</li>
                <li>✓ Cancel anytime during trial period</li>
                <li>✓ Personal onboarding session included</li>
                <li>✓ Priority customer support</li>
                <li>✓ Export all your data if you choose not to continue</li>
              </ul>
            </div>

            {/* CTA Buttons */}
            <div className="flex gap-3">
              <Button 
                onClick={handleStartTrial}
                disabled={startTrialMutation.isPending}
                className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                size="lg"
              >
                {startTrialMutation.isPending ? (
                  "Starting Trial..."
                ) : (
                  <>
                    Start Free Trial
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
              
              <Button 
                variant="outline" 
                onClick={() => setShowTrialDialog(false)}
                size="lg"
              >
                Maybe Later
              </Button>
            </div>

            <div className="text-center text-xs text-gray-500">
              By starting your trial, you agree to our Terms of Service and Privacy Policy
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Trial CTA for existing users */}
      {!hasTrialStarted && !showTrialDialog && user && (
        <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Crown className="w-6 h-6 text-purple-600" />
                <div>
                  <h3 className="font-semibold text-purple-900 dark:text-purple-100">
                    Ready for Premium?
                  </h3>
                  <p className="text-sm text-purple-700 dark:text-purple-300">
                    Try all features free for 7 days
                  </p>
                </div>
              </div>
              
              <Button 
                onClick={() => setShowTrialDialog(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Start Trial
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}