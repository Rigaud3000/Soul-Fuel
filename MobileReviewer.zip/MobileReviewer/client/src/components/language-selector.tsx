import { useState } from 'react';
import { Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useLanguage } from '@/contexts/LanguageContext';
import { languages, Language } from '@/lib/translations';

export default function LanguageSelector() {
  const { language, setLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const currentLanguage = languages.find(lang => lang.code === language);

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="text-dark-300 hover:text-dark-50 hover:bg-dark-700/50 transition-colors h-9 px-3"
        >
          <Globe className="h-4 w-4 mr-2" />
          <span className="text-sm font-medium">
            {currentLanguage?.nativeName || 'EN'}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        align="end" 
        className="w-64 bg-dark-800 border-dark-700 shadow-xl"
        side="bottom"
        sideOffset={8}
      >
        <div className="py-2">
          {languages.map((lang) => (
            <DropdownMenuItem
              key={lang.code}
              onClick={() => {
                setLanguage(lang.code);
                setIsOpen(false);
              }}
              className={`
                flex items-center justify-between px-4 py-3 cursor-pointer
                text-dark-200 hover:text-dark-50 hover:bg-dark-700/70
                transition-colors duration-200
                ${language === lang.code ? 'bg-primary/10 text-primary border-r-2 border-primary' : ''}
              `}
            >
              <div className="flex flex-col">
                <span className="font-medium text-sm">{lang.nativeName}</span>
                <span className="text-xs text-dark-400">{lang.name}</span>
              </div>
              {language === lang.code && (
                <div className="w-2 h-2 bg-primary rounded-full"></div>
              )}
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}