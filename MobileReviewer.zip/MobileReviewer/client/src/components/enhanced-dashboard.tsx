import { useState, useEffect, Suspense, lazy } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Activity, 
  Brain, 
  Heart, 
  Zap, 
  Target, 
  TrendingUp, 
  Sparkles,
  Shield,
  Camera,
  MessageCircle,
  Trophy,
  Calendar,
  Bell,
  Settings,
  ChevronRight,
  Flame,
  Droplets,
  Moon,
  Dumbbell
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { performanceEngine } from '@/lib/performance-enhancement-engine';
import { aiEnhancementAnalyzer } from '@/lib/ai-enhancement-analyzer';
import { simpleReminderSystem } from '@/lib/simple-reminder-system';

// Import components directly for now
import { QuickActions } from './quick-actions';
import { HealthMetrics } from './health-metrics';
import { WellnessInsights } from './wellness-insights';

interface DashboardStats {
  todayScore: number;
  weeklyProgress: number;
  streakDays: number;
  totalScans: number;
  moodAverage: number;
  aiSessionsUsed: number;
  nextGoal: string;
  recentAchievements: string[];
}

interface EnhancedFeature {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  progress: number;
  status: 'active' | 'available' | 'premium' | 'coming-soon';
  action: () => void;
  enhancementLevel: number;
}

export function EnhancedDashboard() {
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [enhancedFeatures, setEnhancedFeatures] = useState<EnhancedFeature[]>([]);
  const [optimizationScore, setOptimizationScore] = useState(0);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [lastEnhanced, setLastEnhanced] = useState<Date | null>(null);

  // Fetch analytics data with enhanced caching
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/analytics'],
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes (renamed from cacheTime in v5)
  });

  // Enhanced initialization
  useEffect(() => {
    initializeEnhancedDashboard();
    applyPerformanceOptimizations();
  }, []);

  // Real-time updates every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      refreshDashboardData();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const initializeEnhancedDashboard = async () => {
    try {
      // Initialize performance monitoring
      performanceEngine.optimizeComponents();
      
      // Analyze current features
      const optimizationPlan = aiEnhancementAnalyzer.generateOptimizationPlan();
      setOptimizationScore(optimizationPlan.totalScore);
      
      // Set up enhanced features
      setupEnhancedFeatures();
      
      // Load dashboard stats
      loadDashboardStats();
      
      console.log('Enhanced dashboard initialized successfully');
    } catch (error) {
      console.error('Dashboard initialization error:', error);
    }
  };

  const applyPerformanceOptimizations = () => {
    // Enable lazy loading for images
    document.querySelectorAll('img').forEach(img => {
      if (!img.loading) {
        img.loading = 'lazy';
      }
    });

    // Preload critical resources
    const criticalResources = ['/api/analytics', '/api/food-analyses'];
    criticalResources.forEach(resource => {
      const link = document.createElement('link');
      link.rel = 'prefetch';
      link.href = resource;
      document.head.appendChild(link);
    });
  };

  const setupEnhancedFeatures = () => {
    const features: EnhancedFeature[] = [
      {
        id: 'ai-coach',
        title: 'AI Wellness Coach',
        description: 'Personalized coaching with emotional intelligence',
        icon: <Brain className="h-5 w-5" />,
        progress: 94,
        status: 'active',
        action: () => window.location.href = '/coach',
        enhancementLevel: 5
      },
      {
        id: 'smart-scanner',
        title: 'Smart Food Scanner',
        description: 'Multi-modal food analysis with batch scanning',
        icon: <Camera className="h-5 w-5" />,
        progress: 92,
        status: 'active',
        action: () => window.location.href = '/scanner',
        enhancementLevel: 4
      },
      {
        id: 'mood-intelligence',
        title: 'Mood Intelligence',
        description: 'Advanced emotion tracking with predictive insights',
        icon: <Heart className="h-5 w-5" />,
        progress: 88,
        status: 'active',
        action: () => window.location.href = '/tracking',
        enhancementLevel: 4
      },
      {
        id: 'emergency-toolkit',
        title: 'Crisis Intervention',
        description: 'Multi-tiered emergency support system',
        icon: <Shield className="h-5 w-5" />,
        progress: 93,
        status: 'active',
        action: () => triggerEmergencyToolkit(),
        enhancementLevel: 5
      },
      {
        id: 'voice-commands',
        title: 'Voice Soul Talk',
        description: 'Hands-free interaction with AI companion',
        icon: <MessageCircle className="h-5 w-5" />,
        progress: 85,
        status: 'active',
        action: () => activateVoiceMode(),
        enhancementLevel: 4
      },
      {
        id: 'predictive-alerts',
        title: 'Craving Prediction',
        description: 'AI-powered craving timeline and prevention',
        icon: <Zap className="h-5 w-5" />,
        progress: 89,
        status: 'active',
        action: () => window.location.href = '/predictions',
        enhancementLevel: 5
      },
      {
        id: 'wellness-gaming',
        title: 'Wellness Gamification',
        description: 'Achievement system with mini-games',
        icon: <Trophy className="h-5 w-5" />,
        progress: 84,
        status: 'active',
        action: () => window.location.href = '/games',
        enhancementLevel: 3
      },
      {
        id: 'smart-reminders',
        title: 'Smart Notifications',
        description: 'AI-optimized reminder system',
        icon: <Bell className="h-5 w-5" />,
        progress: 79,
        status: 'active',
        action: () => window.location.href = '/settings',
        enhancementLevel: 3
      }
    ];

    setEnhancedFeatures(features);
  };

  const loadDashboardStats = () => {
    const stats: DashboardStats = {
      todayScore: 87,
      weeklyProgress: 73,
      streakDays: 12,
      totalScans: 156,
      moodAverage: 4.2,
      aiSessionsUsed: 8,
      nextGoal: 'Complete 7-day sugar-free streak',
      recentAchievements: [
        'Wellness Warrior (7-day streak)',
        'Scanner Expert (100+ scans)',
        'Mood Master (consistent tracking)'
      ]
    };

    setDashboardStats(stats);
  };

  const refreshDashboardData = async () => {
    // Refresh critical data without full reload
    try {
      const optimizationPlan = aiEnhancementAnalyzer.generateOptimizationPlan();
      setOptimizationScore(optimizationPlan.totalScore);
      
      // Update last enhanced timestamp
      setLastEnhanced(new Date());
    } catch (error) {
      console.error('Data refresh error:', error);
    }
  };

  const runFullOptimization = async () => {
    setIsOptimizing(true);
    
    try {
      // Apply AI enhancements
      const implemented = await aiEnhancementAnalyzer.implementAutoEnhancements();
      
      // Update optimization score
      const newPlan = aiEnhancementAnalyzer.generateOptimizationPlan();
      setOptimizationScore(newPlan.totalScore);
      
      // Refresh features with enhancement levels
      setupEnhancedFeatures();
      
      console.log(`Optimization complete. Implemented ${implemented.length} enhancements.`);
    } catch (error) {
      console.error('Optimization error:', error);
    } finally {
      setIsOptimizing(false);
      setLastEnhanced(new Date());
    }
  };

  const triggerEmergencyToolkit = () => {
    // Enhanced emergency toolkit with multi-tier response
    const emergencyModal = document.createElement('div');
    emergencyModal.innerHTML = `
      <div class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div class="bg-white p-6 rounded-lg max-w-md w-full m-4">
          <h3 class="text-lg font-bold mb-4">🛡️ Crisis Support Active</h3>
          <div class="space-y-3">
            <button class="w-full p-3 bg-green-500 text-white rounded" onclick="window.location.href='/coach'">
              🧘 Talk to AI Coach
            </button>
            <button class="w-full p-3 bg-blue-500 text-white rounded" onclick="window.location.href='/games'">
              🎮 Play Calming Games
            </button>
            <button class="w-full p-3 bg-purple-500 text-white rounded" onclick="this.parentElement.parentElement.parentElement.remove()">
              🌬️ Breathing Exercise
            </button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(emergencyModal);
  };

  const activateVoiceMode = () => {
    // Enhanced voice activation
    if ('speechSynthesis' in window && 'webkitSpeechRecognition' in window) {
      const synthesis = window.speechSynthesis;
      const utterance = new SpeechSynthesisUtterance('Voice mode activated. How can I help you today?');
      synthesis.speak(utterance);
    }
    window.location.href = '/voice';
  };

  const quickReminder = async (type: string) => {
    try {
      await simpleReminderSystem.sendImmediateReminder(type);
    } catch (error) {
      console.error('Reminder error:', error);
    }
  };

  if (analyticsLoading || !dashboardStats) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="text-muted-foreground">Optimizing your wellness dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4" data-feature="dashboard">
      {/* Enhanced Header with Real-time Score */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-emerald-500 via-emerald-600 to-emerald-700 p-6 text-white">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Flame className="h-6 w-6 text-orange-300" />
                SOULFUEL Enhanced
              </h1>
              <p className="text-emerald-100">AI-Powered Wellness Platform</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">{dashboardStats.todayScore}</div>
              <div className="text-sm text-emerald-200">Today's Score</div>
            </div>
          </div>
          
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-xl font-bold">{dashboardStats.streakDays}</div>
              <div className="text-xs text-emerald-200">Day Streak</div>
            </div>
            <div>
              <div className="text-xl font-bold">{dashboardStats.totalScans}</div>
              <div className="text-xs text-emerald-200">Total Scans</div>
            </div>
            <div>
              <div className="text-xl font-bold">{dashboardStats.moodAverage}</div>
              <div className="text-xs text-emerald-200">Avg Mood</div>
            </div>
            <div>
              <div className="text-xl font-bold">{optimizationScore}%</div>
              <div className="text-xs text-emerald-200">Optimized</div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {enhancedFeatures.map((feature) => (
          <Card 
            key={feature.id} 
            className="relative overflow-hidden transition-all duration-300 hover:shadow-lg hover:scale-105 cursor-pointer group"
            onClick={feature.action}
            data-feature={feature.id}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-lg bg-primary/10 text-primary">
                  {feature.icon}
                </div>
                <Badge 
                  variant={feature.status === 'active' ? 'default' : 'secondary'}
                  className="text-xs"
                >
                  {feature.status === 'active' ? 'Enhanced' : feature.status}
                </Badge>
              </div>
              <CardTitle className="text-sm font-medium">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-xs text-muted-foreground mb-3">{feature.description}</p>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span>Performance</span>
                  <span>{feature.progress}%</span>
                </div>
                <Progress value={feature.progress} className="h-1" />
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    Enhancement Level {feature.enhancementLevel}
                  </span>
                  <ChevronRight className="h-3 w-3 text-muted-foreground group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions Bar */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => quickReminder('mood')}
              className="flex items-center gap-2"
            >
              <Heart className="h-4 w-4" />
              Log Mood
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => quickReminder('water')}
              className="flex items-center gap-2"
            >
              <Droplets className="h-4 w-4" />
              Drink Water
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => window.location.href = '/scanner'}
              className="flex items-center gap-2"
            >
              <Camera className="h-4 w-4" />
              Scan Food
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={triggerEmergencyToolkit}
              className="flex items-center gap-2"
            >
              <Shield className="h-4 w-4" />
              Emergency
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* System Optimization Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              System Enhancement
            </div>
            <Badge variant="outline">{optimizationScore}% Optimized</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">AI Enhancement Engine</p>
              <p className="text-sm text-muted-foreground">
                Automatically optimizes performance and features
              </p>
            </div>
            <Button 
              onClick={runFullOptimization}
              disabled={isOptimizing}
              className="flex items-center gap-2"
            >
              {isOptimizing ? (
                <>
                  <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full" />
                  Optimizing...
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4" />
                  Enhance Now
                </>
              )}
            </Button>
          </div>
          
          <Progress value={optimizationScore} className="h-2" />
          
          {lastEnhanced && (
            <p className="text-xs text-muted-foreground">
              Last enhanced: {lastEnhanced.toLocaleTimeString()}
            </p>
          )}
        </CardContent>
      </Card>

      {/* Enhanced Components */}
      <QuickActions />
      <HealthMetrics />
      <WellnessInsights />
    </div>
  );
}