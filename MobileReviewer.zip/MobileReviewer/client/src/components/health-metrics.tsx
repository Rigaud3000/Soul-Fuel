import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  Heart, 
  Droplets, 
  Moon, 
  TrendingUp, 
  TrendingDown,
  Minus,
  Zap
} from 'lucide-react';

interface MetricData {
  label: string;
  value: number;
  unit: string;
  target: number;
  trend: 'up' | 'down' | 'stable';
  status: 'excellent' | 'good' | 'fair' | 'needs-attention';
  icon: React.ReactNode;
}

export function HealthMetrics() {
  const metrics: MetricData[] = [
    {
      label: 'Daily Steps',
      value: 8240,
      unit: 'steps',
      target: 10000,
      trend: 'up',
      status: 'good',
      icon: <Activity className="h-4 w-4" />
    },
    {
      label: 'Heart Rate',
      value: 72,
      unit: 'bpm',
      target: 75,
      trend: 'stable',
      status: 'excellent',
      icon: <Heart className="h-4 w-4" />
    },
    {
      label: 'Water Intake',
      value: 1.8,
      unit: 'L',
      target: 2.5,
      trend: 'up',
      status: 'fair',
      icon: <Droplets className="h-4 w-4" />
    },
    {
      label: 'Sleep Quality',
      value: 7.5,
      unit: 'hrs',
      target: 8,
      trend: 'down',
      status: 'good',
      icon: <Moon className="h-4 w-4" />
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-green-600 bg-green-50';
      case 'good': return 'text-blue-600 bg-blue-50';
      case 'fair': return 'text-yellow-600 bg-yellow-50';
      case 'needs-attention': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-3 w-3 text-green-500" />;
      case 'down': return <TrendingDown className="h-3 w-3 text-red-500" />;
      case 'stable': return <Minus className="h-3 w-3 text-gray-500" />;
      default: return <Minus className="h-3 w-3 text-gray-500" />;
    }
  };

  const calculateProgress = (value: number, target: number) => {
    return Math.min(100, (value / target) * 100);
  };

  return (
    <Card data-feature="health-metrics">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-purple-600" />
          Health Metrics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {metrics.map((metric, index) => (
            <div key={index} className="p-4 rounded-lg border bg-card">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    {metric.icon}
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">{metric.label}</h4>
                    <div className="flex items-center gap-1">
                      <span className="text-lg font-bold">{metric.value}</span>
                      <span className="text-xs text-muted-foreground">{metric.unit}</span>
                      {getTrendIcon(metric.trend)}
                    </div>
                  </div>
                </div>
                <Badge className={getStatusColor(metric.status)}>
                  {metric.status}
                </Badge>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Progress to target</span>
                  <span>{metric.target} {metric.unit}</span>
                </div>
                <Progress 
                  value={calculateProgress(metric.value, metric.target)} 
                  className="h-2"
                />
                <div className="text-xs text-muted-foreground">
                  {Math.round(calculateProgress(metric.value, metric.target))}% of daily goal
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
          <div className="flex items-center gap-2 text-blue-700">
            <Activity className="h-4 w-4" />
            <span className="font-medium text-sm">Health Score: 78/100</span>
          </div>
          <p className="text-xs text-blue-600 mt-1">
            Good progress! Focus on increasing water intake and maintaining sleep schedule.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}