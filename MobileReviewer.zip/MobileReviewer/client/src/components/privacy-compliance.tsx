import React, { useState } from 'react';
import { Download, Trash2, Shield, FileText, Lock, Eye, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface DataExportRequest {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  requestedAt: Date;
  completedAt?: Date;
  downloadUrl?: string;
  expiresAt?: Date;
}

interface AccountDeletionRequest {
  reason: string;
  feedback?: string;
  confirmations: {
    dataLoss: boolean;
    irreversible: boolean;
    alternatives: boolean;
  };
}

export function PrivacyComplianceManager() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [deletionDialogOpen, setDeletionDialogOpen] = useState(false);
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [deletionRequest, setDeletionRequest] = useState<AccountDeletionRequest>({
    reason: '',
    feedback: '',
    confirmations: {
      dataLoss: false,
      irreversible: false,
      alternatives: false,
    }
  });

  const { data: exportRequests = [] } = useQuery({
    queryKey: ['/api/data-exports', user?.uid],
    enabled: !!user?.uid,
  });

  const { data: privacySettings } = useQuery({
    queryKey: ['/api/privacy-settings', user?.uid],
    enabled: !!user?.uid,
  });

  const requestDataExportMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/data-exports/request");
    },
    onSuccess: () => {
      toast({
        title: "Data Export Requested",
        description: "We'll prepare your data and notify you when it's ready for download.",
      });
      setExportDialogOpen(false);
    },
  });

  const downloadDataMutation = useMutation({
    mutationFn: async (exportId: string) => {
      const response = await fetch(`/api/data-exports/${exportId}/download`, {
        headers: {
          'X-Firebase-UID': user?.uid || '',
        },
      });
      
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `soulfuel-data-${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Download Started",
        description: "Your data export is downloading now.",
      });
    },
  });

  const requestAccountDeletionMutation = useMutation({
    mutationFn: async (request: AccountDeletionRequest) => {
      return apiRequest("POST", "/api/account/delete-request", request);
    },
    onSuccess: () => {
      toast({
        title: "Account Deletion Requested",
        description: "We'll process your request within 30 days as required by law.",
        variant: "destructive",
      });
      setDeletionDialogOpen(false);
    },
  });

  const encryptLocalDataMutation = useMutation({
    mutationFn: async () => {
      // Encrypt any locally stored data
      const localData = localStorage.getItem('soulfuel_offline_queue');
      if (localData) {
        const encrypted = await encryptData(localData);
        localStorage.setItem('soulfuel_offline_queue_encrypted', encrypted);
        localStorage.removeItem('soulfuel_offline_queue');
      }
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Local Data Encrypted",
        description: "Your offline data has been encrypted for additional security.",
      });
    },
  });

  // Simple encryption for demonstration (in production, use proper encryption)
  const encryptData = async (data: string): Promise<string> => {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    
    // Generate a key (in production, derive from user credentials)
    const key = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt']
    );
    
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      dataBuffer
    );
    
    return btoa(String.fromCharCode(...new Uint8Array(encrypted)));
  };

  const getDataCategories = () => [
    { name: 'Profile Information', description: 'Username, email, subscription details', included: true },
    { name: 'Food Tracking Data', description: 'All food scans, analyses, and nutrition logs', included: true },
    { name: 'Mood & Wellness Data', description: 'Mood entries, craving logs, withdrawal tracking', included: true },
    { name: 'AI Chat History', description: 'Conversations with AI coaches and recommendations', included: true },
    { name: 'Community Activity', description: 'Posts, comments, likes, and social interactions', included: true },
    { name: 'App Usage Analytics', description: 'Session data, feature usage, performance metrics', included: false },
    { name: 'Device Information', description: 'Device type, OS version, app version', included: false },
  ];

  const getExportStatus = (status: string) => {
    switch (status) {
      case 'pending': return { color: 'bg-yellow-500', text: 'Pending' };
      case 'processing': return { color: 'bg-blue-500', text: 'Processing' };
      case 'completed': return { color: 'bg-green-500', text: 'Ready' };
      case 'failed': return { color: 'bg-red-500', text: 'Failed' };
      default: return { color: 'bg-gray-500', text: 'Unknown' };
    }
  };

  const canSubmitDeletion = () => {
    return Object.values(deletionRequest.confirmations).every(Boolean) && 
           deletionRequest.reason.trim().length > 0;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Privacy & Data Rights</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Manage your data, privacy settings, and exercise your rights under GDPR and CCPA.
        </p>
      </div>

      {/* Data Export Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Download Your Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Request a complete copy of all your data stored in SOULFUEL. This includes your profile, 
            tracking data, AI conversations, and more.
          </p>

          <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Request Data Export
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Request Data Export</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Your export will include the following data categories:
                </p>
                
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {getDataCategories().map((category, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                      <Checkbox checked={category.included} disabled />
                      <div>
                        <Label className="font-medium">{category.name}</Label>
                        <p className="text-xs text-gray-500">{category.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
                  <div className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
                    <Shield className="w-4 h-4" />
                    <span className="font-medium">Data Export Information</span>
                  </div>
                  <ul className="text-sm text-blue-700 dark:text-blue-300 mt-2 space-y-1">
                    <li>• Processing typically takes 1-3 business days</li>
                    <li>• You'll receive an email notification when ready</li>
                    <li>• Download links expire after 7 days for security</li>
                    <li>• Data is exported in JSON format for portability</li>
                  </ul>
                </div>

                <Button 
                  onClick={() => requestDataExportMutation.mutate()}
                  disabled={requestDataExportMutation.isPending}
                  className="w-full"
                >
                  {requestDataExportMutation.isPending ? 'Requesting...' : 'Confirm Export Request'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Recent Export Requests */}
          {exportRequests.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-medium">Recent Export Requests</h4>
              {exportRequests.map((request: DataExportRequest) => {
                const status = getExportStatus(request.status);
                return (
                  <div key={request.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <div className="flex items-center gap-2">
                        <Badge className={`${status.color} text-white`}>
                          {status.text}
                        </Badge>
                        <span className="text-sm">
                          Requested {new Date(request.requestedAt).toLocaleDateString()}
                        </span>
                      </div>
                      {request.expiresAt && (
                        <p className="text-xs text-gray-500 mt-1">
                          Expires: {new Date(request.expiresAt).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    
                    {request.status === 'completed' && request.downloadUrl && (
                      <Button
                        size="sm"
                        onClick={() => downloadDataMutation.mutate(request.id)}
                        disabled={downloadDataMutation.isPending}
                      >
                        <Download className="w-3 h-3 mr-1" />
                        Download
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Local Data Encryption */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Local Data Encryption
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Encrypt data stored locally on your device for additional security.
          </p>
          
          <Button 
            onClick={() => encryptLocalDataMutation.mutate()}
            disabled={encryptLocalDataMutation.isPending}
            variant="outline"
            className="w-full"
          >
            <Lock className="w-4 h-4 mr-2" />
            {encryptLocalDataMutation.isPending ? 'Encrypting...' : 'Encrypt Local Data'}
          </Button>
        </CardContent>
      </Card>

      {/* Account Deletion */}
      <Card className="border-red-200 dark:border-red-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
            <Trash2 className="w-5 h-5" />
            Delete Account
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-red-50 dark:bg-red-950 p-4 rounded-lg">
            <div className="flex items-center gap-2 text-red-800 dark:text-red-200 mb-2">
              <AlertTriangle className="w-4 h-4" />
              <span className="font-medium">Permanent Account Deletion</span>
            </div>
            <p className="text-sm text-red-700 dark:text-red-300">
              This action cannot be undone. All your data will be permanently deleted within 30 days.
            </p>
          </div>

          <Dialog open={deletionDialogOpen} onOpenChange={setDeletionDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete My Account
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-red-600 dark:text-red-400">
                  Delete Account Permanently
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="deletion-reason">Reason for deletion (required)</Label>
                    <Textarea
                      id="deletion-reason"
                      value={deletionRequest.reason}
                      onChange={(e) => setDeletionRequest(prev => ({ ...prev, reason: e.target.value }))}
                      placeholder="Please tell us why you're deleting your account..."
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="deletion-feedback">Additional feedback (optional)</Label>
                    <Textarea
                      id="deletion-feedback"
                      value={deletionRequest.feedback}
                      onChange={(e) => setDeletionRequest(prev => ({ ...prev, feedback: e.target.value }))}
                      placeholder="How could we improve SOULFUEL?"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Required Confirmations</Label>
                  
                  {[
                    { key: 'dataLoss', text: 'I understand that all my data will be permanently deleted' },
                    { key: 'irreversible', text: 'I understand this action cannot be undone' },
                    { key: 'alternatives', text: 'I have considered alternatives like deactivating my account' },
                  ].map((confirmation) => (
                    <div key={confirmation.key} className="flex items-start gap-3">
                      <Checkbox
                        checked={deletionRequest.confirmations[confirmation.key as keyof typeof deletionRequest.confirmations]}
                        onCheckedChange={(checked) => 
                          setDeletionRequest(prev => ({
                            ...prev,
                            confirmations: {
                              ...prev.confirmations,
                              [confirmation.key]: !!checked
                            }
                          }))
                        }
                      />
                      <Label className="text-sm leading-5">{confirmation.text}</Label>
                    </div>
                  ))}
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-950 p-4 rounded-lg">
                  <div className="flex items-center gap-2 text-yellow-800 dark:text-yellow-200">
                    <Eye className="w-4 h-4" />
                    <span className="font-medium">Before You Delete</span>
                  </div>
                  <ul className="text-sm text-yellow-700 dark:text-yellow-300 mt-2 space-y-1">
                    <li>• Consider downloading your data first</li>
                    <li>• Account deletion takes up to 30 days to complete</li>
                    <li>• Some data may be retained for legal/security purposes</li>
                    <li>• You can contact support to cancel deletion within 7 days</li>
                  </ul>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="destructive"
                    onClick={() => requestAccountDeletionMutation.mutate(deletionRequest)}
                    disabled={!canSubmitDeletion() || requestAccountDeletionMutation.isPending}
                    className="flex-1"
                  >
                    {requestAccountDeletionMutation.isPending ? 'Processing...' : 'Confirm Deletion'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setDeletionDialogOpen(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Privacy Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Your Privacy Rights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium mb-2">GDPR Rights (EU Users)</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Right to access your data</li>
                <li>• Right to rectification</li>
                <li>• Right to erasure</li>
                <li>• Right to data portability</li>
                <li>• Right to object to processing</li>
              </ul>
            </div>
            
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium mb-2">CCPA Rights (CA Users)</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Right to know about data collection</li>
                <li>• Right to delete personal information</li>
                <li>• Right to opt-out of data sales</li>
                <li>• Right to non-discrimination</li>
                <li>• Right to correct inaccurate data</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <strong>Need help?</strong> Contact our Data Protection Officer at privacy@soulfuel.app 
              for questions about your privacy rights or data handling practices.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}