import React, { Suspense, lazy } from 'react';
import { Loader2 } from 'lucide-react';

// Lazy load components for better performance
export const LazyOfflineStorage = lazy(() => 
  import('./offline-storage').then(module => ({ default: module.OfflineStorageManager }))
);

export const LazyCustomGoals = lazy(() => 
  import('./custom-goals-manager').then(module => ({ default: module.CustomGoalsManager }))
);

export const LazyHabitStreaks = lazy(() => 
  import('./habit-streak-notifications').then(module => ({ default: module.HabitStreakNotifications }))
);

export const LazyPrivacyCompliance = lazy(() => 
  import('./privacy-compliance').then(module => ({ default: module.PrivacyComplianceManager }))
);

export const LazyCommunityEnhancements = lazy(() => 
  import('./community-enhancements').then(module => ({ default: module.CommunityEnhancements }))
);

export const LazyGamificationSystem = lazy(() => 
  import('./gamification-system').then(module => ({ default: module.GamificationSystem }))
);

export const LazyPremiumTrial = lazy(() => 
  import('./premium-trial-onboarding').then(module => ({ default: module.PremiumTrialOnboarding }))
);

export const LazyVisualCheckIn = lazy(() => 
  import('./visual-check-in-tracker').then(module => ({ default: module.VisualCheckInTracker }))
);

export const LazyFloatingToolkit = lazy(() => 
  import('./floating-emergency-toolkit').then(module => ({ default: module.FloatingEmergencyToolkit }))
);

export const LazySuccessAnimations = lazy(() => 
  import('./success-animations').then(module => ({ default: module.SuccessAnimation }))
);

// Loading fallback component
export const ComponentLoader = ({ name }: { name?: string }) => (
  <div className="flex items-center justify-center p-8">
    <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
      <Loader2 className="w-5 h-5 animate-spin" />
      <span>Loading {name || 'component'}...</span>
    </div>
  </div>
);

// Higher-order component for lazy loading with suspense
export const withLazyLoading = <T extends object>(
  Component: React.ComponentType<T>,
  name?: string
) => {
  return (props: T) => (
    <Suspense fallback={<ComponentLoader name={name} />}>
      <Component {...props} />
    </Suspense>
  );
};

// Preload components for better UX
export const preloadComponents = () => {
  // Preload critical components after initial render
  setTimeout(() => {
    import('./floating-emergency-toolkit');
    import('./success-animations');
  }, 1000);

  // Preload secondary components
  setTimeout(() => {
    import('./offline-storage');
    import('./visual-check-in-tracker');
  }, 2000);

  // Preload advanced features
  setTimeout(() => {
    import('./custom-goals-manager');
    import('./habit-streak-notifications');
    import('./gamification-system');
  }, 3000);

  // Preload premium features
  setTimeout(() => {
    import('./premium-trial-onboarding');
    import('./privacy-compliance');
    import('./community-enhancements');
  }, 4000);
};