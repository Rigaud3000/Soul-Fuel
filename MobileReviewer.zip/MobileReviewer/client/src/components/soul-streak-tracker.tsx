import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Flame, Star, Crown, Award, Trophy, Zap } from 'lucide-react';
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

interface StreakData {
  currentStreak: number;
  longestStreak: number;
  lastCheckIn: string | null;
  streakMilestones: number[];
  badges: string[];
  totalXP: number;
}

const STREAK_MILESTONES = [3, 7, 14, 21, 30, 60, 90, 180, 365];
const STREAK_REWARDS = {
  3: { badge: 'Soul Beginner', xp: 50, icon: Flame },
  7: { badge: 'Week Warrior', xp: 100, icon: Star },
  14: { badge: 'Fortnight Fighter', xp: 200, icon: Award },
  21: { badge: 'Triple Week Champion', xp: 300, icon: Trophy },
  30: { badge: 'Monthly Master', xp: 500, icon: Crown },
  60: { badge: 'Soul Sustainer', xp: 750, icon: Zap },
  90: { badge: 'Quarterly Conqueror', xp: 1000, icon: Star },
  180: { badge: 'Half-Year Hero', xp: 1500, icon: Trophy },
  365: { badge: 'Annual Ascended', xp: 2500, icon: Crown }
};

export function SoulStreakTracker() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [streakData, setStreakData] = useState<StreakData>({
    currentStreak: 0,
    longestStreak: 0,
    lastCheckIn: null,
    streakMilestones: [],
    badges: [],
    totalXP: 0
  });
  const [canCheckIn, setCanCheckIn] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadStreakData();
  }, [user]);

  const loadStreakData = async () => {
    if (!user) return;

    try {
      const response = await fetch('/api/streak-data', {
        headers: { 'X-Firebase-UID': user.firebaseUid }
      });

      if (response.ok) {
        const data = await response.json();
        setStreakData(data);
        
        // Check if user can check in today
        const lastCheckIn = data.lastCheckIn ? new Date(data.lastCheckIn) : null;
        const today = new Date();
        const canCheck = !lastCheckIn || 
          lastCheckIn.toDateString() !== today.toDateString();
        setCanCheckIn(canCheck);
      }
    } catch (error) {
      console.error('Failed to load streak data:', error);
    }
  };

  const performDailyCheckIn = async () => {
    if (!user || !canCheckIn) return;

    setLoading(true);
    try {
      const response = await fetch('/api/daily-checkin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Firebase-UID': user.firebaseUid
        }
      });

      if (response.ok) {
        const data = await response.json();
        setStreakData(data.streakData);
        setCanCheckIn(false);

        // Show rewards if milestone reached
        if (data.newBadge) {
          toast({
            title: "🎉 New Badge Earned!",
            description: `You've unlocked: ${data.newBadge.badge} (+${data.newBadge.xp} XP)`,
          });
        } else {
          toast({
            title: "✨ Daily Check-in Complete!",
            description: `Streak: ${data.streakData.currentStreak} days (+10 XP)`,
          });
        }
      }
    } catch (error) {
      console.error('Failed to check in:', error);
      toast({
        title: "Check-in Failed",
        description: "Please try again later.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getNextMilestone = () => {
    return STREAK_MILESTONES.find(milestone => milestone > streakData.currentStreak) || null;
  };

  const getStreakMotivation = () => {
    const { currentStreak } = streakData;
    if (currentStreak === 0) return "Start your healing journey today! 🌱";
    if (currentStreak < 7) return "Building momentum, soul warrior! 💪";
    if (currentStreak < 30) return "Your soul is growing stronger! ✨";
    if (currentStreak < 90) return "Incredible dedication to your wellness! 🌟";
    return "You are a true soul master! 👑";
  };

  const nextMilestone = getNextMilestone();
  const progressToNext = nextMilestone ? 
    (streakData.currentStreak / nextMilestone) * 100 : 100;

  return (
    <div className="space-y-6">
      {/* Main Streak Display */}
      <Card className="bg-gradient-to-br from-emerald-500/10 to-blue-500/10 border-emerald-500/20">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-2">
            <div className="relative">
              <Flame className="h-16 w-16 text-emerald-500" />
              {streakData.currentStreak > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-orange-500 text-white">
                  {streakData.currentStreak}
                </Badge>
              )}
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-emerald-600">
            {streakData.currentStreak}-Day Soul Streak
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            {getStreakMotivation()}
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Check-in Button */}
          <Button
            onClick={performDailyCheckIn}
            disabled={!canCheckIn || loading}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            size="lg"
          >
            {loading ? (
              "Checking in..."
            ) : canCheckIn ? (
              "Complete Daily Check-in ✨"
            ) : (
              "Already checked in today! 🎉"
            )}
          </Button>

          {/* Progress to Next Milestone */}
          {nextMilestone && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress to {nextMilestone}-day milestone</span>
                <span>{streakData.currentStreak}/{nextMilestone} days</span>
              </div>
              <Progress value={progressToNext} className="h-2" />
            </div>
          )}

          {/* Stats Row */}
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="bg-white/50 rounded-lg p-3">
              <div className="text-2xl font-bold text-emerald-600">
                {streakData.longestStreak}
              </div>
              <div className="text-xs text-muted-foreground">Longest Streak</div>
            </div>
            <div className="bg-white/50 rounded-lg p-3">
              <div className="text-2xl font-bold text-blue-600">
                {streakData.totalXP}
              </div>
              <div className="text-xs text-muted-foreground">Total XP</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Badges Collection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-yellow-500" />
            Soul Achievement Badges
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {STREAK_MILESTONES.map(milestone => {
              const reward = STREAK_REWARDS[milestone as keyof typeof STREAK_REWARDS];
              const earned = streakData.streakMilestones.includes(milestone);
              const IconComponent = reward.icon;
              
              return (
                <div
                  key={milestone}
                  className={`p-3 rounded-lg border text-center transition-all ${
                    earned 
                      ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-300 shadow-md' 
                      : 'bg-gray-50 border-gray-200 opacity-60'
                  }`}
                >
                  <IconComponent 
                    className={`h-8 w-8 mx-auto mb-2 ${
                      earned ? 'text-yellow-600' : 'text-gray-400'
                    }`} 
                  />
                  <div className={`font-semibold text-sm ${
                    earned ? 'text-yellow-800' : 'text-gray-500'
                  }`}>
                    {reward.badge}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {milestone} days
                  </div>
                  {earned && (
                    <Badge variant="secondary" className="mt-1 text-xs">
                      +{reward.xp} XP
                    </Badge>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Streak Tips */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="pt-6">
          <h3 className="font-semibold text-blue-800 mb-2">Build Your Soul Streak</h3>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Check in daily to maintain your streak</li>
            <li>• Complete any wellness activity (scan food, log mood, AI chat)</li>
            <li>• Use the emergency toolkit to stay on track</li>
            <li>• Engage with the community for extra support</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}