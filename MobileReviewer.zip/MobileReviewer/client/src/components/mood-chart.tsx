import { useMemo } from "react";
import type { MoodEntry } from "@shared/schema";

interface MoodChartProps {
  entries: MoodEntry[];
}

const moodValues = {
  happy: 4,
  okay: 3,
  sad: 2,
  stressed: 1,
};

const moodEmojis = {
  happy: "😊",
  okay: "😐", 
  sad: "😢",
  stressed: "😰",
};

const moodColors = {
  happy: "bg-green-500",
  okay: "bg-yellow-500",
  sad: "bg-blue-500", 
  stressed: "bg-red-500",
};

export default function MoodChart({ entries }: MoodChartProps) {
  const chartData = useMemo(() => {
    const now = new Date();
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    // Get start of current week (Monday)
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    weekStart.setHours(0, 0, 0, 0);
    
    return days.map((day, index) => {
      const dayDate = new Date(weekStart);
      dayDate.setDate(weekStart.getDate() + index);
      
      // Find mood entry for this day
      const dayEntry = entries.find(entry => {
        const entryDate = new Date(entry.date);
        return entryDate.toDateString() === dayDate.toDateString();
      });
      
      const isToday = dayDate.toDateString() === now.toDateString();
      
      if (dayEntry) {
        const moodValue = moodValues[dayEntry.mood as keyof typeof moodValues] || 0;
        const heightPercent = (moodValue / 4) * 100;
        
        return {
          day,
          mood: dayEntry.mood,
          emoji: moodEmojis[dayEntry.mood as keyof typeof moodEmojis],
          color: moodColors[dayEntry.mood as keyof typeof moodColors],
          height: heightPercent,
          value: moodValue,
          isToday,
          hasData: true,
        };
      }
      
      return {
        day,
        mood: null,
        emoji: null,
        color: "bg-dark-600",
        height: 0,
        value: 0,
        isToday,
        hasData: false,
      };
    });
  }, [entries]);

  const weeklyStats = useMemo(() => {
    const moodsWithData = chartData.filter(day => day.hasData);
    const averageMood = moodsWithData.length > 0 
      ? moodsWithData.reduce((sum, day) => sum + day.value, 0) / moodsWithData.length
      : 0;
    
    const moodCounts = {
      happy: moodsWithData.filter(day => day.mood === 'happy').length,
      okay: moodsWithData.filter(day => day.mood === 'okay').length,
      sad: moodsWithData.filter(day => day.mood === 'sad').length,
      stressed: moodsWithData.filter(day => day.mood === 'stressed').length,
    };
    
    const dominantMood = Object.entries(moodCounts).reduce((a, b) => 
      moodCounts[a[0] as keyof typeof moodCounts] > moodCounts[b[0] as keyof typeof moodCounts] ? a : b
    )[0];
    
    return {
      averageMood: Math.round(averageMood * 10) / 10,
      dominantMood,
      totalEntries: moodsWithData.length,
      moodCounts,
    };
  }, [chartData]);

  return (
    <div className="w-full">
      {/* Emoji Timeline */}
      <div className="grid grid-cols-7 gap-2 mb-4">
        {chartData.map((data, index) => (
          <div key={index} className="text-center">
            <div className="text-xs text-dark-400 mb-1">{data.day}</div>
            <div className={`text-2xl ${data.hasData ? '' : 'opacity-30'} ${
              data.isToday ? 'ring-2 ring-secondary rounded-lg p-1' : ''
            }`}>
              {data.emoji || '🤷'}
            </div>
          </div>
        ))}
      </div>
      
      {/* Mood Trend Chart */}
      <div className="mb-4">
        <h4 className="text-sm font-medium text-dark-300 mb-2">Mood Trend (1-4 scale)</h4>
        <div className="flex items-end justify-between h-20 bg-dark-700/50 rounded-lg p-2">
          {chartData.map((data, index) => (
            <div key={index} className="flex flex-col items-center flex-1">
              <div 
                className={`w-4 chart-bar mb-1 rounded-t transition-all duration-300 ${
                  data.hasData ? data.color : 'bg-dark-600'
                }`}
                style={{ height: `${data.height}%` }}
                title={`${data.day}: ${data.mood || 'No data'}`}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Mood Statistics */}
      <div className="grid grid-cols-2 gap-3 text-xs">
        <div className="bg-dark-700/50 rounded-lg p-2 text-center">
          <div className="font-semibold text-dark-200">{weeklyStats.totalEntries}/7</div>
          <div className="text-dark-400">Check-ins</div>
        </div>
        <div className="bg-dark-700/50 rounded-lg p-2 text-center">
          <div className="font-semibold text-dark-200">
            {moodEmojis[weeklyStats.dominantMood as keyof typeof moodEmojis] || '😐'}
          </div>
          <div className="text-dark-400">Most common</div>
        </div>
      </div>
      
      {/* Mood Distribution */}
      {weeklyStats.totalEntries > 0 && (
        <div className="mt-3">
          <h5 className="text-xs font-medium text-dark-400 mb-2">This Week's Distribution</h5>
          <div className="flex space-x-1 h-2 bg-dark-700 rounded-full overflow-hidden">
            {Object.entries(weeklyStats.moodCounts).map(([mood, count]) => {
              const percentage = (count / weeklyStats.totalEntries) * 100;
              if (count === 0) return null;
              
              return (
                <div
                  key={mood}
                  className={moodColors[mood as keyof typeof moodColors]}
                  style={{ width: `${percentage}%` }}
                  title={`${mood}: ${count} day${count !== 1 ? 's' : ''}`}
                />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
