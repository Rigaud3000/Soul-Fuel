import { useState, useEffect } from 'react';
import { Wifi, WifiOff, Upload, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

interface OfflineData {
  id: string;
  type: 'mood' | 'food' | 'craving' | 'sugar';
  data: any;
  timestamp: Date;
  synced: boolean;
}

export function OfflineStorageManager() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [offlineQueue, setOfflineQueue] = useState<OfflineData[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      syncOfflineData();
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      toast({
        title: "Offline Mode",
        description: "You're offline. Data will be saved locally and synced when you reconnect.",
        variant: "default",
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Load offline queue from localStorage
    loadOfflineQueue();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadOfflineQueue = () => {
    try {
      const stored = localStorage.getItem('soulfuel_offline_queue');
      if (stored) {
        const parsed = JSON.parse(stored);
        setOfflineQueue(parsed.map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp)
        })));
      }
    } catch (error) {
      console.error('Error loading offline queue:', error);
    }
  };

  const saveToOfflineQueue = (type: string, data: any) => {
    const offlineItem: OfflineData = {
      id: `offline_${Date.now()}_${Math.random()}`,
      type: type as any,
      data,
      timestamp: new Date(),
      synced: false
    };

    const newQueue = [...offlineQueue, offlineItem];
    setOfflineQueue(newQueue);
    localStorage.setItem('soulfuel_offline_queue', JSON.stringify(newQueue));

    toast({
      title: "Saved Offline",
      description: `${type} entry saved locally. Will sync when online.`,
    });
  };

  const syncOfflineData = async () => {
    if (!isOnline || offlineQueue.length === 0) return;

    const unsyncedItems = offlineQueue.filter(item => !item.synced);
    
    for (const item of unsyncedItems) {
      try {
        let endpoint = '';
        switch (item.type) {
          case 'mood':
            endpoint = '/api/mood-entries';
            break;
          case 'food':
            endpoint = '/api/food-analyses';
            break;
          case 'craving':
            endpoint = '/api/craving-entries';
            break;
          case 'sugar':
            endpoint = '/api/sugar-entries';
            break;
        }

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(item.data),
        });

        if (response.ok) {
          item.synced = true;
        }
      } catch (error) {
        console.error(`Failed to sync ${item.type} entry:`, error);
      }
    }

    const updatedQueue = offlineQueue.map(item => 
      unsyncedItems.find(ui => ui.id === item.id)?.synced ? { ...item, synced: true } : item
    );
    
    setOfflineQueue(updatedQueue);
    localStorage.setItem('soulfuel_offline_queue', JSON.stringify(updatedQueue));

    const syncedCount = unsyncedItems.filter(item => item.synced).length;
    if (syncedCount > 0) {
      toast({
        title: "Data Synced",
        description: `${syncedCount} offline entries successfully synced.`,
      });
    }
  };

  const clearSyncedData = () => {
    const unsyncedOnly = offlineQueue.filter(item => !item.synced);
    setOfflineQueue(unsyncedOnly);
    localStorage.setItem('soulfuel_offline_queue', JSON.stringify(unsyncedOnly));
  };

  const unsyncedCount = offlineQueue.filter(item => !item.synced).length;

  return (
    <div className="flex items-center gap-2">
      <Badge variant={isOnline ? "default" : "secondary"} className="flex items-center gap-1">
        {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
        {isOnline ? "Online" : "Offline"}
      </Badge>
      
      {unsyncedCount > 0 && (
        <Badge variant="outline" className="flex items-center gap-1">
          <Download className="w-3 h-3" />
          {unsyncedCount} pending
        </Badge>
      )}

      {isOnline && unsyncedCount > 0 && (
        <Button
          size="sm"
          variant="outline"
          onClick={syncOfflineData}
          className="flex items-center gap-1"
        >
          <Upload className="w-3 h-3" />
          Sync Now
        </Button>
      )}
    </div>
  );
}

// Hook for offline-aware data operations
export function useOfflineStorage() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const saveOfflineEntry = (type: string, data: any) => {
    const offlineItem = {
      id: `offline_${Date.now()}_${Math.random()}`,
      type,
      data,
      timestamp: new Date(),
      synced: false
    };

    const existingQueue = JSON.parse(localStorage.getItem('soulfuel_offline_queue') || '[]');
    existingQueue.push(offlineItem);
    localStorage.setItem('soulfuel_offline_queue', JSON.stringify(existingQueue));
  };

  return {
    isOnline,
    saveOfflineEntry
  };
}