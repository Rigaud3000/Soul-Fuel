import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Camera, 
  Heart, 
  Brain, 
  MessageCircle, 
  Trophy, 
  Droplets, 
  Dumbbell, 
  Shield,
  Zap,
  Sparkles
} from 'lucide-react';

interface QuickAction {
  id: string;
  title: string;
  icon: React.ReactNode;
  description: string;
  action: () => void;
  frequency: 'high' | 'medium' | 'low';
  category: 'tracking' | 'wellness' | 'emergency' | 'social';
}

export function QuickActions() {
  const actions: QuickAction[] = [
    {
      id: 'scan-food',
      title: 'Smart Scan',
      icon: <Camera className="h-4 w-4" />,
      description: 'Analyze food with AI',
      action: () => window.location.href = '/scanner',
      frequency: 'high',
      category: 'tracking'
    },
    {
      id: 'log-mood',
      title: 'Mood Check',
      icon: <Heart className="h-4 w-4" />,
      description: 'Track emotional state',
      action: () => window.location.href = '/tracking#mood',
      frequency: 'high',
      category: 'tracking'
    },
    {
      id: 'ai-coach',
      title: 'AI Coach',
      icon: <Brain className="h-4 w-4" />,
      description: 'Get personalized guidance',
      action: () => window.location.href = '/coach',
      frequency: 'medium',
      category: 'wellness'
    },
    {
      id: 'voice-talk',
      title: 'Voice Chat',
      icon: <MessageCircle className="h-4 w-4" />,
      description: 'Talk to your AI companion',
      action: () => window.location.href = '/voice',
      frequency: 'medium',
      category: 'wellness'
    },
    {
      id: 'hydration',
      title: 'Water Log',
      icon: <Droplets className="h-4 w-4" />,
      description: 'Track water intake',
      action: () => logHydration(),
      frequency: 'high',
      category: 'tracking'
    },
    {
      id: 'emergency',
      title: 'Emergency Kit',
      icon: <Shield className="h-4 w-4" />,
      description: 'Crisis intervention tools',
      action: () => triggerEmergency(),
      frequency: 'low',
      category: 'emergency'
    },
    {
      id: 'exercise',
      title: 'Quick Exercise',
      icon: <Dumbbell className="h-4 w-4" />,
      description: 'Start a workout',
      action: () => startExercise(),
      frequency: 'medium',
      category: 'wellness'
    },
    {
      id: 'achievements',
      title: 'Achievements',
      icon: <Trophy className="h-4 w-4" />,
      description: 'View progress & rewards',
      action: () => window.location.href = '/achievements',
      frequency: 'low',
      category: 'social'
    }
  ];

  const getFrequencyColor = (frequency: string) => {
    switch (frequency) {
      case 'high': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'tracking': return <Zap className="h-3 w-3" />;
      case 'wellness': return <Sparkles className="h-3 w-3" />;
      case 'emergency': return <Shield className="h-3 w-3" />;
      case 'social': return <Trophy className="h-3 w-3" />;
      default: return <Zap className="h-3 w-3" />;
    }
  };

  return (
    <Card data-feature="quick-actions">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-blue-600" />
          Enhanced Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {actions.map((action) => (
            <Button
              key={action.id}
              variant="outline"
              className="h-auto p-3 flex flex-col items-center gap-2 relative group hover:shadow-md transition-all duration-200"
              onClick={action.action}
              data-action={action.id}
            >
              {/* Frequency indicator */}
              <div className={`absolute top-1 right-1 w-2 h-2 rounded-full ${getFrequencyColor(action.frequency)}`}></div>
              
              {/* Category badge */}
              <Badge variant="outline" className="absolute top-1 left-1 p-1 h-5">
                {getCategoryIcon(action.category)}
              </Badge>

              <div className="text-primary group-hover:scale-110 transition-transform">
                {action.icon}
              </div>
              <div className="text-center">
                <div className="font-medium text-xs">{action.title}</div>
                <div className="text-xs text-muted-foreground leading-tight">{action.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Helper functions
function logHydration() {
  const currentIntake = parseInt(localStorage.getItem('daily_water') || '0');
  const newIntake = currentIntake + 250; // 250ml glass
  localStorage.setItem('daily_water', newIntake.toString());
  
  // Show success feedback
  showQuickFeedback('💧 Water logged! Keep hydrating!');
}

function triggerEmergency() {
  // Enhanced emergency system
  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-50';
  modal.innerHTML = `
    <div class="bg-white p-6 rounded-lg max-w-md w-full m-4 animate-in fade-in duration-200">
      <h3 class="text-lg font-bold mb-4 text-red-600">🛡️ Crisis Support Activated</h3>
      <div class="space-y-3">
        <button class="w-full p-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors" onclick="window.location.href='/coach'">
          🧘 Talk to AI Coach
        </button>
        <button class="w-full p-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors" onclick="startBreathingExercise()">
          🌬️ Breathing Exercise
        </button>
        <button class="w-full p-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors" onclick="window.location.href='/games'">
          🎮 Calming Games
        </button>
        <button class="w-full p-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors" onclick="this.closest('.fixed').remove()">
          ✕ Close
        </button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // Auto-remove after 30 seconds
  setTimeout(() => {
    if (modal.parentNode) {
      modal.remove();
    }
  }, 30000);
}

function startExercise() {
  const exercises = [
    '🤸‍♀️ 10 jumping jacks',
    '🧘‍♂️ 2-minute meditation',
    '🚶‍♀️ 5-minute walk',
    '💪 10 push-ups',
    '🤸‍♂️ 30-second plank'
  ];
  
  const randomExercise = exercises[Math.floor(Math.random() * exercises.length)];
  showQuickFeedback(`Let's do: ${randomExercise}`);
  
  // Start a timer
  setTimeout(() => {
    showQuickFeedback('Great job! Exercise complete! 🎉');
  }, 5000);
}

function showQuickFeedback(message: string) {
  const toast = document.createElement('div');
  toast.className = 'fixed top-4 right-4 bg-green-500 text-white p-3 rounded-lg shadow-lg z-50 animate-in slide-in-from-right duration-300';
  toast.textContent = message;
  
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.classList.add('animate-out', 'slide-out-to-right');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Make functions globally available for onclick handlers
(window as any).startBreathingExercise = () => {
  showQuickFeedback('Breathe in... breathe out... You have got this!');
  window.location.href = '/breathing';
};