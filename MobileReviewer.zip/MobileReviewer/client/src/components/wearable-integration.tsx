import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Watch, 
  Heart, 
  Activity, 
  Footprints, 
  Moon, 
  Zap,
  Smartphone,
  Wifi,
  WifiOff,
  CheckCircle2,
  AlertCircle
} from "lucide-react";

interface WearableDevice {
  id: string;
  name: string;
  type: 'fitness_tracker' | 'smartwatch' | 'health_app';
  icon: any;
  connected: boolean;
  lastSync?: Date;
  dataTypes: string[];
  metrics?: {
    steps?: number;
    heartRate?: number;
    sleep?: number;
    calories?: number;
    activeMinutes?: number;
  };
}

interface HealthMetrics {
  steps: number;
  heartRate: number;
  sleepHours: number;
  caloriesBurned: number;
  activeMinutes: number;
  stressLevel: number;
}

export function WearableIntegration() {
  const { toast } = useToast();
  const [devices, setDevices] = useState<WearableDevice[]>([
    {
      id: 'apple-health',
      name: 'Apple Health',
      type: 'health_app',
      icon: Heart,
      connected: false,
      dataTypes: ['steps', 'heart_rate', 'sleep', 'nutrition', 'mindfulness']
    },
    {
      id: 'google-fit',
      name: 'Google Fit',
      type: 'health_app', 
      icon: Activity,
      connected: false,
      dataTypes: ['steps', 'heart_rate', 'weight', 'activities']
    },
    {
      id: 'fitbit',
      name: 'Fitbit',
      type: 'fitness_tracker',
      icon: Watch,
      connected: false,
      dataTypes: ['steps', 'heart_rate', 'sleep', 'calories', 'stress']
    },
    {
      id: 'samsung-health',
      name: 'Samsung Health',
      type: 'health_app',
      icon: Smartphone,
      connected: false,
      dataTypes: ['steps', 'heart_rate', 'sleep', 'stress', 'nutrition']
    }
  ]);

  const [healthMetrics, setHealthMetrics] = useState<HealthMetrics>({
    steps: 0,
    heartRate: 0,
    sleepHours: 0,
    caloriesBurned: 0,
    activeMinutes: 0,
    stressLevel: 0
  });

  const [autoSync, setAutoSync] = useState(true);
  const [syncInterval, setSyncInterval] = useState(15); // minutes

  // Simulate health data fetching
  useEffect(() => {
    const connectedDevices = devices.filter(d => d.connected);
    if (connectedDevices.length > 0) {
      // Simulate aggregated health data
      setHealthMetrics({
        steps: Math.floor(Math.random() * 8000) + 2000,
        heartRate: Math.floor(Math.random() * 40) + 60,
        sleepHours: Math.random() * 3 + 6,
        caloriesBurned: Math.floor(Math.random() * 800) + 200,
        activeMinutes: Math.floor(Math.random() * 60) + 30,
        stressLevel: Math.floor(Math.random() * 70) + 10
      });
    }
  }, [devices]);

  const connectDevice = async (deviceId: string) => {
    try {
      // Simulate device connection flow
      const device = devices.find(d => d.id === deviceId);
      if (!device) return;

      // Check for browser APIs
      if (deviceId === 'apple-health' && 'HealthKit' in window) {
        // Apple Health integration would use HealthKit
        await simulateHealthKitConnection();
      } else if (deviceId === 'google-fit' && 'gapi' in window) {
        // Google Fit integration would use Google APIs
        await simulateGoogleFitConnection();
      } else if (deviceId === 'fitbit') {
        // Fitbit integration would use OAuth
        await simulateFitbitConnection(deviceId);
      } else {
        // Generic connection simulation
        await simulateGenericConnection(deviceId);
      }

      setDevices(prev => prev.map(d => 
        d.id === deviceId 
          ? { ...d, connected: true, lastSync: new Date() }
          : d
      ));

      toast({
        title: "Device Connected",
        description: `${device.name} is now syncing your health data`,
      });

    } catch (error) {
      toast({
        title: "Connection Failed",
        description: "Please check device permissions and try again",
        variant: "destructive"
      });
    }
  };

  const disconnectDevice = (deviceId: string) => {
    setDevices(prev => prev.map(d => 
      d.id === deviceId 
        ? { ...d, connected: false, lastSync: undefined }
        : d
    ));

    const device = devices.find(d => d.id === deviceId);
    toast({
      title: "Device Disconnected",
      description: `${device?.name} has been disconnected`,
    });
  };

  const syncAllDevices = async () => {
    const connectedDevices = devices.filter(d => d.connected);
    
    for (const device of connectedDevices) {
      setDevices(prev => prev.map(d => 
        d.id === device.id 
          ? { ...d, lastSync: new Date() }
          : d
      ));
    }

    toast({
      title: "Sync Complete",
      description: `Updated data from ${connectedDevices.length} devices`,
    });
  };

  // Simulation functions for different integrations
  const simulateHealthKitConnection = async () => {
    return new Promise(resolve => setTimeout(resolve, 1500));
  };

  const simulateGoogleFitConnection = async () => {
    return new Promise(resolve => setTimeout(resolve, 1500));
  };

  const simulateFitbitConnection = async (deviceId: string) => {
    // Simulate OAuth flow
    window.open(`/api/auth/fitbit?device=${deviceId}`, '_blank', 'width=500,height=600');
    return new Promise(resolve => setTimeout(resolve, 2000));
  };

  const simulateGenericConnection = async (deviceId: string) => {
    return new Promise(resolve => setTimeout(resolve, 1000));
  };

  const getStepsProgress = () => {
    const goal = 10000;
    return Math.min((healthMetrics.steps / goal) * 100, 100);
  };

  const getHeartRateZone = (hr: number) => {
    if (hr < 60) return { zone: "Resting", color: "bg-blue-500" };
    if (hr < 100) return { zone: "Fat Burn", color: "bg-green-500" };
    if (hr < 140) return { zone: "Cardio", color: "bg-yellow-500" };
    return { zone: "Peak", color: "bg-red-500" };
  };

  const getSleepQuality = (hours: number) => {
    if (hours >= 7.5) return { quality: "Excellent", color: "text-green-600" };
    if (hours >= 6.5) return { quality: "Good", color: "text-blue-600" };
    if (hours >= 5.5) return { quality: "Fair", color: "text-yellow-600" };
    return { quality: "Poor", color: "text-red-600" };
  };

  return (
    <div className="space-y-6">
      {/* Health Metrics Overview */}
      <Card className="bg-gradient-to-br from-emerald-50 to-blue-50 dark:from-emerald-950 dark:to-blue-950 border-emerald-200 dark:border-emerald-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-emerald-600" />
            Today's Health Metrics
          </CardTitle>
          <CardDescription>
            Real-time data from your connected devices
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="text-center">
              <Footprints className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">{healthMetrics.steps.toLocaleString()}</div>
              <div className="text-sm text-gray-600">Steps</div>
              <Progress value={getStepsProgress()} className="mt-2" />
            </div>
            
            <div className="text-center">
              <Heart className="h-8 w-8 text-red-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">{healthMetrics.heartRate}</div>
              <div className="text-sm text-gray-600">BPM</div>
              <Badge variant="outline" className={`mt-1 ${getHeartRateZone(healthMetrics.heartRate).color} text-white`}>
                {getHeartRateZone(healthMetrics.heartRate).zone}
              </Badge>
            </div>

            <div className="text-center">
              <Moon className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">{healthMetrics.sleepHours.toFixed(1)}h</div>
              <div className="text-sm text-gray-600">Sleep</div>
              <div className={`text-sm mt-1 ${getSleepQuality(healthMetrics.sleepHours).color}`}>
                {getSleepQuality(healthMetrics.sleepHours).quality}
              </div>
            </div>

            <div className="text-center">
              <Zap className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">{healthMetrics.caloriesBurned}</div>
              <div className="text-sm text-gray-600">Calories</div>
            </div>

            <div className="text-center">
              <Activity className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">{healthMetrics.activeMinutes}</div>
              <div className="text-sm text-gray-600">Active Min</div>
            </div>

            <div className="text-center">
              <AlertCircle className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">{healthMetrics.stressLevel}%</div>
              <div className="text-sm text-gray-600">Stress Level</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Device Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Watch className="h-5 w-5" />
              Connected Devices
            </span>
            <Button onClick={syncAllDevices} variant="outline" size="sm">
              Sync All
            </Button>
          </CardTitle>
          <CardDescription>
            Connect your wearables and health apps for comprehensive tracking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {devices.map((device) => {
              const IconComponent = device.icon;
              return (
                <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <IconComponent className="h-8 w-8 text-gray-600" />
                    <div>
                      <h3 className="font-medium">{device.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        {device.connected ? (
                          <>
                            <Wifi className="h-4 w-4 text-green-500" />
                            <span>Connected</span>
                            {device.lastSync && (
                              <span>• Last sync: {device.lastSync.toLocaleTimeString()}</span>
                            )}
                          </>
                        ) : (
                          <>
                            <WifiOff className="h-4 w-4 text-gray-400" />
                            <span>Not connected</span>
                          </>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {device.dataTypes.map((type) => (
                          <Badge key={type} variant="secondary" className="text-xs">
                            {type.replace('_', ' ')}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {device.connected ? (
                      <>
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <Button 
                          onClick={() => disconnectDevice(device.id)}
                          variant="outline" 
                          size="sm"
                        >
                          Disconnect
                        </Button>
                      </>
                    ) : (
                      <Button 
                        onClick={() => connectDevice(device.id)}
                        size="sm"
                      >
                        Connect
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Sync Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Sync Settings</CardTitle>
          <CardDescription>
            Configure how your health data is synchronized
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <label className="text-sm font-medium">Auto-sync</label>
              <p className="text-sm text-gray-600">Automatically sync data in the background</p>
            </div>
            <Switch 
              checked={autoSync} 
              onCheckedChange={setAutoSync}
            />
          </div>

          <div>
            <label className="text-sm font-medium">Sync Frequency</label>
            <select 
              value={syncInterval}
              onChange={(e) => setSyncInterval(Number(e.target.value))}
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
            >
              <option value={5}>Every 5 minutes</option>
              <option value={15}>Every 15 minutes</option>
              <option value={30}>Every 30 minutes</option>
              <option value={60}>Every hour</option>
            </select>
          </div>

          <div className="pt-4 border-t">
            <h4 className="text-sm font-medium mb-2">Data Privacy</h4>
            <p className="text-sm text-gray-600">
              Your health data is encrypted and stored securely. We never share personal 
              health information with third parties without your explicit consent.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}