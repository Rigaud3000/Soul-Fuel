import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Sparkles, Heart, Brain, Star, ArrowRight, Flame } from 'lucide-react';
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

interface WelcomeData {
  companionName: string;
  healingGoal: string;
  personalityPreference: 'nurturing' | 'spiritual' | 'energetic';
  primaryChallenge: string;
  motivationSource: string;
}

const PERSONALITY_OPTIONS = [
  {
    id: 'nurturing',
    name: 'Nurturing Soul',
    description: 'Gentle, empathetic companion focused on emotional healing',
    icon: Heart,
    color: 'text-pink-500',
    bgColor: 'bg-pink-50',
    borderColor: 'border-pink-200'
  },
  {
    id: 'spiritual',
    name: 'Spiritual Guide',
    description: 'Wise, philosophical mentor providing deep insights',
    icon: Sparkles,
    color: 'text-purple-500',
    bgColor: 'bg-purple-50',
    borderColor: 'border-purple-200'
  },
  {
    id: 'energetic',
    name: 'Energetic Motivator',
    description: 'Upbeat, enthusiastic coach celebrating your progress',
    icon: Brain,
    color: 'text-orange-500',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200'
  }
];

interface WelcomeRitualProps {
  onComplete: (data: WelcomeData) => void;
}

export function WelcomeRitual({ onComplete }: WelcomeRitualProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [welcomeData, setWelcomeData] = useState<WelcomeData>({
    companionName: '',
    healingGoal: '',
    personalityPreference: 'nurturing',
    primaryChallenge: '',
    motivationSource: ''
  });

  const [showAnimation, setShowAnimation] = useState(false);

  const handleNext = () => {
    if (step < 5) {
      setStep(step + 1);
    } else {
      completeWelcomeRitual();
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const completeWelcomeRitual = async () => {
    if (!user) return;

    setIsLoading(true);
    setShowAnimation(true);

    try {
      // Save welcome data and personalization preferences
      const response = await fetch('/api/welcome-ritual', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Firebase-UID': user.firebaseUid
        },
        body: JSON.stringify(welcomeData)
      });

      if (response.ok) {
        // Show completion animation for 3 seconds
        setTimeout(() => {
          onComplete(welcomeData);
          toast({
            title: "Welcome to SOULFUEL! 🌟",
            description: `Your journey begins with ${welcomeData.companionName}. Your soul has been seen.`,
          });
        }, 3000);
      }
    } catch (error) {
      console.error('Failed to complete welcome ritual:', error);
      setIsLoading(false);
      setShowAnimation(false);
    }
  };

  const canProceed = () => {
    switch (step) {
      case 1: return welcomeData.companionName.trim().length > 0;
      case 2: return welcomeData.healingGoal.trim().length > 0;
      case 3: return welcomeData.personalityPreference;
      case 4: return welcomeData.primaryChallenge.trim().length > 0;
      case 5: return welcomeData.motivationSource.trim().length > 0;
      default: return false;
    }
  };

  if (showAnimation) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-500 via-blue-500 to-purple-600 flex items-center justify-center">
        <div className="text-center text-white space-y-6">
          <div className="relative">
            <Flame className="h-32 w-32 mx-auto text-emerald-300 animate-pulse" />
            <div className="absolute inset-0 h-32 w-32 mx-auto">
              <div className="h-full w-full rounded-full bg-emerald-300/20 animate-ping"></div>
            </div>
            <div className="absolute inset-4 h-24 w-24 mx-auto">
              <div className="h-full w-full rounded-full bg-emerald-300/30 animate-ping animation-delay-200"></div>
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-bold">Your Journey Begins...</h1>
            <p className="text-xl text-emerald-200">Your soul has been seen 🌱</p>
            <div className="flex justify-center space-x-1 mt-4">
              {[0, 1, 2].map((index) => (
                <div
                  key={index}
                  className="h-2 w-2 bg-white rounded-full animate-bounce"
                  style={{ animationDelay: `${index * 0.1}s` }}
                ></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-2xl border-0">
        <CardHeader className="text-center bg-gradient-to-r from-emerald-500 to-blue-500 text-white rounded-t-lg">
          <div className="flex justify-center mb-4">
            <Star className="h-12 w-12 text-yellow-300" />
          </div>
          <CardTitle className="text-2xl font-bold">
            Welcome to Your SOULFUEL Journey
          </CardTitle>
          <p className="text-emerald-100">
            Let's create your personalized healing experience
          </p>
          <div className="flex justify-center mt-4">
            <div className="flex space-x-2">
              {[1, 2, 3, 4, 5].map((stepNum) => (
                <div
                  key={stepNum}
                  className={`h-2 w-8 rounded-full transition-all ${
                    stepNum <= step ? 'bg-yellow-300' : 'bg-emerald-300/30'
                  }`}
                />
              ))}
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-8 space-y-6">
          {/* Step 1: Name Your Companion */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <Heart className="h-16 w-16 text-pink-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">Meet Your AI Companion</h2>
                <p className="text-gray-600">Every journey needs a trusted guide. What would you like to name your AI companion?</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="companionName" className="text-lg font-semibold">Companion Name</Label>
                <Input
                  id="companionName"
                  value={welcomeData.companionName}
                  onChange={(e) => setWelcomeData({ ...welcomeData, companionName: e.target.value })}
                  placeholder="Luna, Sage, Phoenix, or choose your own..."
                  className="text-lg p-4 border-2 focus:border-emerald-500"
                />
              </div>
              <div className="bg-emerald-50 p-4 rounded-lg">
                <p className="text-sm text-emerald-700">
                  💡 <strong>Tip:</strong> Choose a name that feels meaningful to you. This companion will be with you throughout your healing journey.
                </p>
              </div>
            </div>
          )}

          {/* Step 2: Healing Goal */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <Sparkles className="h-16 w-16 text-purple-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">What Are You Hoping to Heal?</h2>
                <p className="text-gray-600">Share your deepest intention for this journey. There's no wrong answer.</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="healingGoal" className="text-lg font-semibold">Your Healing Intention</Label>
                <Textarea
                  id="healingGoal"
                  value={welcomeData.healingGoal}
                  onChange={(e) => setWelcomeData({ ...welcomeData, healingGoal: e.target.value })}
                  placeholder="I want to break free from sugar addiction and find emotional balance..."
                  className="min-h-32 text-lg p-4 border-2 focus:border-emerald-500"
                />
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-700">
                  🌟 <strong>Remember:</strong> Healing happens one moment at a time. You're already taking the first step.
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Personality Preference */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <Brain className="h-16 w-16 text-orange-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">Choose Your Companion's Personality</h2>
                <p className="text-gray-600">How would you like {welcomeData.companionName} to support you?</p>
              </div>
              <RadioGroup
                value={welcomeData.personalityPreference}
                onValueChange={(value: any) => setWelcomeData({ ...welcomeData, personalityPreference: value })}
                className="space-y-4"
              >
                {PERSONALITY_OPTIONS.map((option) => {
                  const Icon = option.icon;
                  return (
                    <div key={option.id} className="relative">
                      <RadioGroupItem value={option.id} id={option.id} className="sr-only" />
                      <Label
                        htmlFor={option.id}
                        className={`flex items-start space-x-4 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          welcomeData.personalityPreference === option.id
                            ? `${option.bgColor} ${option.borderColor} shadow-md`
                            : 'bg-white border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <Icon className={`h-8 w-8 ${option.color} mt-1`} />
                        <div className="flex-1">
                          <div className="font-semibold text-lg">{option.name}</div>
                          <div className="text-gray-600">{option.description}</div>
                        </div>
                      </Label>
                    </div>
                  );
                })}
              </RadioGroup>
            </div>
          )}

          {/* Step 4: Primary Challenge */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <Flame className="h-16 w-16 text-red-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">Your Biggest Challenge</h2>
                <p className="text-gray-600">What's the main obstacle you're facing right now?</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="primaryChallenge" className="text-lg font-semibold">Current Challenge</Label>
                <Textarea
                  id="primaryChallenge"
                  value={welcomeData.primaryChallenge}
                  onChange={(e) => setWelcomeData({ ...welcomeData, primaryChallenge: e.target.value })}
                  placeholder="Late-night cravings, emotional eating, feeling overwhelmed..."
                  className="min-h-28 text-lg p-4 border-2 focus:border-emerald-500"
                />
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg">
                <p className="text-sm text-yellow-700">
                  💪 <strong>Strength in Vulnerability:</strong> Naming your challenge is the first step to overcoming it.
                </p>
              </div>
            </div>
          )}

          {/* Step 5: Motivation Source */}
          {step === 5 && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <Star className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">Your Source of Strength</h2>
                <p className="text-gray-600">What motivates you to keep going on difficult days?</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="motivationSource" className="text-lg font-semibold">What Gives You Strength?</Label>
                <Textarea
                  id="motivationSource"
                  value={welcomeData.motivationSource}
                  onChange={(e) => setWelcomeData({ ...welcomeData, motivationSource: e.target.value })}
                  placeholder="My family, my future self, my dreams, my values..."
                  className="min-h-28 text-lg p-4 border-2 focus:border-emerald-500"
                />
              </div>
              <div className="bg-emerald-50 p-4 rounded-lg">
                <p className="text-sm text-emerald-700">
                  ✨ <strong>Your Why:</strong> {welcomeData.companionName} will remind you of this strength whenever you need it.
                </p>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between pt-6">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={step === 1}
              className="flex items-center gap-2"
            >
              ← Back
            </Button>
            
            <Button
              onClick={handleNext}
              disabled={!canProceed() || isLoading}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700"
            >
              {step === 5 ? (
                isLoading ? "Creating your journey..." : "Begin Journey"
              ) : (
                <>Next <ArrowRight className="h-4 w-4" /></>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}