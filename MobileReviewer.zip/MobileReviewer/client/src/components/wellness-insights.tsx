import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Brain, 
  TrendingUp, 
  Target, 
  AlertCircle,
  CheckCircle,
  Lightbulb,
  Star
} from 'lucide-react';

interface InsightData {
  type: 'achievement' | 'recommendation' | 'alert' | 'milestone';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  action?: string;
  actionUrl?: string;
}

export function WellnessInsights() {
  const insights: InsightData[] = [
    {
      type: 'achievement',
      title: 'Consistent Mood Tracking',
      description: 'You have tracked your mood for 7 consecutive days!',
      impact: 'high',
      action: 'View Progress',
      actionUrl: '/analytics'
    },
    {
      type: 'recommendation',
      title: 'Optimize Meal Timing',
      description: 'Your sugar cravings peak at 3 PM. Consider a healthy snack at 2:30 PM.',
      impact: 'medium',
      action: 'Set Reminder',
      actionUrl: '/settings'
    },
    {
      type: 'alert',
      title: 'Hydration Below Target',
      description: 'You are 30% below your daily water intake goal.',
      impact: 'medium',
      action: 'Log Water',
      actionUrl: '/tracking'
    },
    {
      type: 'milestone',
      title: 'Sugar Reduction Milestone',
      description: 'You have reduced sugar intake by 25% this month!',
      impact: 'high',
      action: 'Celebrate',
      actionUrl: '/achievements'
    }
  ];

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'achievement': return <CheckCircle className="h-4 w-4" />;
      case 'recommendation': return <Lightbulb className="h-4 w-4" />;
      case 'alert': return <AlertCircle className="h-4 w-4" />;
      case 'milestone': return <Star className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'achievement': return 'text-green-600 bg-green-50';
      case 'recommendation': return 'text-blue-600 bg-blue-50';
      case 'alert': return 'text-orange-600 bg-orange-50';
      case 'milestone': return 'text-purple-600 bg-purple-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getImpactBadge = (impact: string) => {
    const colors = {
      high: 'bg-red-100 text-red-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-green-100 text-green-800'
    };
    return colors[impact as keyof typeof colors] || colors.low;
  };

  return (
    <Card data-feature="wellness-insights">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-indigo-600" />
          AI Wellness Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {insights.map((insight, index) => (
          <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
            <div className={`p-2 rounded-lg ${getInsightColor(insight.type)}`}>
              {getInsightIcon(insight.type)}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h4 className="font-medium text-sm">{insight.title}</h4>
                <Badge variant="outline" className={getImpactBadge(insight.impact)}>
                  {insight.impact} impact
                </Badge>
              </div>
              
              <p className="text-sm text-muted-foreground mb-2">
                {insight.description}
              </p>
              
              {insight.action && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => insight.actionUrl && (window.location.href = insight.actionUrl)}
                >
                  {insight.action}
                </Button>
              )}
            </div>
          </div>
        ))}
        
        <div className="p-3 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-200">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-indigo-600" />
            <span className="font-medium text-sm text-indigo-900">Weekly Trend</span>
          </div>
          <p className="text-sm text-indigo-700">
            Your wellness score improved by 12% this week. Keep up the great work!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}