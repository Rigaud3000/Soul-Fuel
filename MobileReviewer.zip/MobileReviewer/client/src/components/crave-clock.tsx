import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useLocation } from "wouter";
import { 
  Clock, 
  AlertTriangle, 
  Brain, 
  Heart, 
  Activity, 
  Droplets,
  BookOpen,
  Gamepad2,
  Target,
  TrendingUp
} from "lucide-react";

interface CravingPrediction {
  time: string;
  probability: number;
  triggers: string[];
  preventionTips: string[];
  severity: 'low' | 'medium' | 'high';
  timeUntil: number; // minutes
}

export function CraveClock() {
  const [, setLocation] = useLocation();
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Fetch craving predictions
  const { data: predictions } = useQuery({
    queryKey: ['/api/craving-predictions'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/craving-predictions');
      return response.json();
    },
    refetchInterval: 5 * 60 * 1000 // Refresh every 5 minutes
  });

  const nextPrediction = predictions?.nextPrediction;
  const upcomingPredictions = predictions?.upcoming || [];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-900/20 border-red-800/30 text-red-400';
      case 'medium': return 'bg-orange-900/20 border-orange-800/30 text-orange-400';
      case 'low': return 'bg-green-900/20 border-green-800/30 text-green-400';
      default: return 'bg-dark-700 border-dark-600 text-dark-300';
    }
  };

  const formatTimeUntil = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-primary via-secondary to-accent rounded-full flex items-center justify-center animate-pulse">
              <Clock className="text-white" size={24} />
            </div>
            <h1 className="text-3xl font-bold text-white">CraveClock™</h1>
          </div>
          <p className="text-dark-300 text-lg">Predict and prevent cravings before they strike</p>
          <div className="text-sm text-dark-400 mt-2">
            Current Time: {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>

        {/* Next Craving Alert */}
        {nextPrediction && (
          <Alert className={`${getSeverityColor(nextPrediction.severity)} rounded-xl border-2`}>
            <AlertTriangle className="h-6 w-6" />
            <AlertDescription className="ml-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-bold text-lg">
                    Craving Surge Likely at {nextPrediction.time}
                  </h3>
                  <p className="text-sm opacity-90">
                    {nextPrediction.probability}% probability · {formatTimeUntil(nextPrediction.timeUntil)} from now
                  </p>
                </div>
                <Badge variant="outline" className="text-lg px-3 py-1">
                  {nextPrediction.severity.toUpperCase()}
                </Badge>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4 mt-4">
                <div>
                  <h4 className="font-medium mb-2">Likely Triggers:</h4>
                  <ul className="text-sm space-y-1">
                    {nextPrediction.triggers.map((trigger, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-current rounded-full opacity-60" />
                        {trigger}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Prevention Tips:</h4>
                  <ul className="text-sm space-y-1">
                    {nextPrediction.preventionTips.map((tip, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-current rounded-full opacity-60" />
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <div className="flex gap-3 mt-4">
                <Button
                  onClick={() => setLocation('/healing-games')}
                  className="bg-white/10 hover:bg-white/20 text-white border-white/20"
                  variant="outline"
                  size="sm"
                >
                  <Gamepad2 className="mr-2 h-4 w-4" />
                  Play Prevention Game
                </Button>
                <Button
                  onClick={() => setLocation('/soul-companion')}
                  className="bg-white/10 hover:bg-white/20 text-white border-white/20"
                  variant="outline"
                  size="sm"
                >
                  <Brain className="mr-2 h-4 w-4" />
                  Talk to Soul Companion
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Craving Timeline */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="text-primary" size={20} />
              Today's Craving Timeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingPredictions.length === 0 ? (
                <div className="text-center py-8">
                  <Heart className="text-green-400 mx-auto mb-3" size={48} />
                  <h3 className="text-lg font-semibold text-green-400 mb-2">Clear Skies Ahead!</h3>
                  <p className="text-dark-300">No high-risk craving windows detected for today.</p>
                </div>
              ) : (
                upcomingPredictions.map((prediction: CravingPrediction, index: number) => (
                  <div key={index} className={`p-4 rounded-lg border ${getSeverityColor(prediction.severity)}`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <Clock className="h-5 w-5" />
                        <span className="font-medium">{prediction.time}</span>
                        <Badge variant="outline" className="text-xs">
                          {prediction.probability}% risk
                        </Badge>
                      </div>
                      <div className="text-sm opacity-75">
                        in {formatTimeUntil(prediction.timeUntil)}
                      </div>
                    </div>
                    
                    <div className="text-sm opacity-90">
                      <strong>Triggers:</strong> {prediction.triggers.join(', ')}
                    </div>
                    
                    <Progress 
                      value={prediction.probability} 
                      className="h-2 mt-3"
                    />
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Pre-Craving Prep Actions */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="text-accent" size={20} />
              Pre-Craving Prep Kit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button
                onClick={() => setLocation("/healing-games")}
                className="bg-gradient-to-r from-blue-600/20 to-blue-500/10 border border-blue-500/30 hover:from-blue-600/30 hover:to-blue-500/20 text-white h-auto p-4 flex-col gap-2"
                variant="ghost"
              >
                <Gamepad2 className="text-blue-400" size={20} />
                <span className="text-sm">Play Game</span>
              </Button>
              
              <Button
                onClick={() => {/* Hydration reminder */}}
                className="bg-gradient-to-r from-cyan-600/20 to-cyan-500/10 border border-cyan-500/30 hover:from-cyan-600/30 hover:to-cyan-500/20 text-white h-auto p-4 flex-col gap-2"
                variant="ghost"
              >
                <Droplets className="text-cyan-400" size={20} />
                <span className="text-sm">Drink Water</span>
              </Button>
              
              <Button
                onClick={() => setLocation("/soul-companion")}
                className="bg-gradient-to-r from-purple-600/20 to-purple-500/10 border border-purple-500/30 hover:from-purple-600/30 hover:to-purple-500/20 text-white h-auto p-4 flex-col gap-2"
                variant="ghost"
              >
                <BookOpen className="text-purple-400" size={20} />
                <span className="text-sm">Journal</span>
              </Button>
              
              <Button
                onClick={() => setLocation("/emergency-toolkit")}
                className="bg-gradient-to-r from-green-600/20 to-green-500/10 border border-green-500/30 hover:from-green-600/30 hover:to-green-500/20 text-white h-auto p-4 flex-col gap-2"
                variant="ghost"
              >
                <Activity className="text-green-400" size={20} />
                <span className="text-sm">Breathe</span>
              </Button>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}