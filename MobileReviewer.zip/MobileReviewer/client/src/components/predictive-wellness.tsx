import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useLocation } from "wouter";
import { 
  Brain, 
  Heart, 
  Activity, 
  Moon, 
  AlertTriangle, 
  TrendingUp, 
  Shield, 
  Zap,
  Target,
  CheckCircle
} from "lucide-react";

interface PredictiveInsight {
  type: 'stress' | 'sleep' | 'activity' | 'pattern';
  severity: 'low' | 'medium' | 'high';
  message: string;
  recommendation: string;
  action?: string;
  confidence: number;
}

interface WellnessScore {
  overall: number;
  stress: number;
  sleep: number;
  activity: number;
  recovery: number;
}

export function PredictiveWellness() {
  const [, setLocation] = useLocation();

  // Fetch predictive wellness insights
  const { data: wellnessData } = useQuery({
    queryKey: ['/api/predictive-wellness'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/predictive-wellness');
      return response.json();
    }
  });

  // Fetch wellness trends for additional context
  const { data: trendsData } = useQuery({
    queryKey: ['/api/wellness-trends'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/wellness-trends');
      return response.json();
    }
  });

  // Extract data from API response
  const insights = wellnessData?.insights || [];
  const wellnessScore = wellnessData?.wellnessScore || {
    overall: 85,
    stress: 70,
    sleep: 90,
    activity: 80,
    recovery: 88
  };



  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-900/20 border-red-800/30 text-red-400';
      case 'medium': return 'bg-orange-900/20 border-orange-800/30 text-orange-400';
      case 'low': return 'bg-green-900/20 border-green-800/30 text-green-400';
      default: return 'bg-dark-700 border-dark-600 text-dark-300';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'stress': return <Brain className="w-4 h-4" />;
      case 'sleep': return <Moon className="w-4 h-4" />;
      case 'activity': return <Activity className="w-4 h-4" />;
      case 'pattern': return <TrendingUp className="w-4 h-4" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-primary via-secondary to-accent rounded-full flex items-center justify-center">
              <Brain className="text-white" size={24} />
            </div>
            <h1 className="text-3xl font-bold text-white">Smart Wellness Prediction</h1>
          </div>
          <p className="text-dark-300 text-lg">AI-powered insights to prevent cravings before they start</p>
        </div>

        {/* Overall Wellness Score */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Shield className="text-primary" size={20} />
              Wellness Protection Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">{wellnessScore.overall}%</div>
                <p className="text-dark-300">Overall craving resistance strength</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <Brain className="text-blue-400 mx-auto mb-2" size={20} />
                  <div className="text-sm font-medium text-white">{wellnessScore.stress}%</div>
                  <div className="text-xs text-dark-400">Stress Management</div>
                </div>
                <div className="text-center">
                  <Moon className="text-purple-400 mx-auto mb-2" size={20} />
                  <div className="text-sm font-medium text-white">{wellnessScore.sleep}%</div>
                  <div className="text-xs text-dark-400">Sleep Quality</div>
                </div>
                <div className="text-center">
                  <Activity className="text-green-400 mx-auto mb-2" size={20} />
                  <div className="text-sm font-medium text-white">{wellnessScore.activity}%</div>
                  <div className="text-xs text-dark-400">Activity Level</div>
                </div>
                <div className="text-center">
                  <Heart className="text-red-400 mx-auto mb-2" size={20} />
                  <div className="text-sm font-medium text-white">{wellnessScore.recovery}%</div>
                  <div className="text-xs text-dark-400">Recovery State</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Predictive Insights */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Zap className="text-secondary" size={20} />
            Real-Time Craving Predictions
          </h2>
          
          {insights.length === 0 ? (
            <Card className="bg-dark-800 border border-dark-700 rounded-xl p-6">
              <div className="text-center">
                <CheckCircle className="text-green-400 mx-auto mb-3" size={48} />
                <h3 className="text-lg font-semibold text-green-400 mb-2">All Clear!</h3>
                <p className="text-dark-300">Your wellness indicators look great. Low craving risk detected.</p>
              </div>
            </Card>
          ) : (
            insights.map((insight, index) => (
              <Alert key={index} className={`${getSeverityColor(insight.severity)} rounded-xl`}>
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    {getTypeIcon(insight.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertDescription className="font-medium">
                        {insight.message}
                      </AlertDescription>
                      <Badge variant="outline" className="text-xs">
                        {insight.confidence}% confidence
                      </Badge>
                    </div>
                    <p className="text-sm mb-3 opacity-90">
                      <strong>Recommendation:</strong> {insight.recommendation}
                    </p>
                    {insight.action && (
                      <Button
                        onClick={() => setLocation(insight.action!)}
                        className="bg-white/10 hover:bg-white/20 text-white border-white/20"
                        variant="outline"
                        size="sm"
                      >
                        Take Action
                      </Button>
                    )}
                  </div>
                </div>
              </Alert>
            ))
          )}
        </div>

        {/* Quick Prevention Actions */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="text-accent" size={20} />
              Prevention Toolkit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <Button
                onClick={() => setLocation("/emergency-toolkit")}
                className="bg-gradient-to-r from-red-600/20 to-red-500/10 border border-red-500/30 hover:from-red-600/30 hover:to-red-500/20 text-white h-auto p-4 flex-col gap-2"
                variant="ghost"
              >
                <AlertTriangle className="text-red-400" size={20} />
                <span className="text-sm">Emergency Toolkit</span>
              </Button>
              
              <Button
                onClick={() => setLocation("/soul-companion")}
                className="bg-gradient-to-r from-blue-600/20 to-blue-500/10 border border-blue-500/30 hover:from-blue-600/30 hover:to-blue-500/20 text-white h-auto p-4 flex-col gap-2"
                variant="ghost"
              >
                <Brain className="text-blue-400" size={20} />
                <span className="text-sm">Soul Companion</span>
              </Button>
              
              <Button
                onClick={() => setLocation("/healing-games")}
                className="bg-gradient-to-r from-green-600/20 to-green-500/10 border border-green-500/30 hover:from-green-600/30 hover:to-green-500/20 text-white h-auto p-4 flex-col gap-2"
                variant="ghost"
              >
                <Activity className="text-green-400" size={20} />
                <span className="text-sm">Healing Games</span>
              </Button>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}