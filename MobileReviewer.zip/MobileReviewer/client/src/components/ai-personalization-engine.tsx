import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Brain, Heart, Sparkles, User, Settings, Palette } from 'lucide-react';
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

interface PersonalizationProfile {
  companionName: string;
  companionPersonality: 'nurturing' | 'spiritual' | 'energetic';
  voiceTone: 'gentle' | 'coach' | 'spiritual';
  colorTheme: 'emerald' | 'ocean' | 'sunset' | 'forest' | 'cosmic';
  emotionalState: string[];
  preferredGameTypes: string[];
  foodScanFrequency: number;
  dailyMotivationTime: string;
  crisisInterventionLevel: 'gentle' | 'moderate' | 'intensive';
  aiAdaptiveness: number; // 1-10 scale
}

const PERSONALITY_TYPES = {
  nurturing: {
    name: 'Nurturing Soul',
    description: 'Gentle, empathetic, focuses on emotional healing',
    icon: Heart,
    color: 'text-pink-600'
  },
  spiritual: {
    name: 'Spiritual Guide',
    description: 'Wise, philosophical, provides deep insights',
    icon: Sparkles,
    color: 'text-purple-600'
  },
  energetic: {
    name: 'Energetic Motivator',
    description: 'Upbeat, motivational, celebrates progress',
    icon: Brain,
    color: 'text-orange-600'
  }
};

const COLOR_THEMES = {
  emerald: { name: 'Emerald Healing', primary: 'bg-emerald-500', secondary: 'bg-emerald-100' },
  ocean: { name: 'Ocean Calm', primary: 'bg-blue-500', secondary: 'bg-blue-100' },
  sunset: { name: 'Sunset Warmth', primary: 'bg-orange-500', secondary: 'bg-orange-100' },
  forest: { name: 'Forest Peace', primary: 'bg-green-600', secondary: 'bg-green-100' },
  cosmic: { name: 'Cosmic Wonder', primary: 'bg-purple-500', secondary: 'bg-purple-100' }
};

export function AIPersonalizationEngine() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<PersonalizationProfile>({
    companionName: 'Luna',
    companionPersonality: 'nurturing',
    voiceTone: 'gentle',
    colorTheme: 'emerald',
    emotionalState: [],
    preferredGameTypes: [],
    foodScanFrequency: 3,
    dailyMotivationTime: '08:00',
    crisisInterventionLevel: 'moderate',
    aiAdaptiveness: 7
  });
  const [isLoading, setIsLoading] = useState(false);
  const [insights, setInsights] = useState<string[]>([]);

  useEffect(() => {
    loadPersonalizationProfile();
    generatePersonalizedInsights();
  }, [user]);

  const loadPersonalizationProfile = async () => {
    if (!user) return;

    try {
      const response = await fetch('/api/personalization-profile', {
        headers: { 'X-Firebase-UID': user.firebaseUid }
      });

      if (response.ok) {
        const data = await response.json();
        setProfile({ ...profile, ...data });
      }
    } catch (error) {
      console.error('Failed to load personalization profile:', error);
    }
  };

  const generatePersonalizedInsights = async () => {
    if (!user) return;

    try {
      const response = await fetch('/api/ai-insights', {
        headers: { 'X-Firebase-UID': user.firebaseUid }
      });

      if (response.ok) {
        const data = await response.json();
        setInsights(data.insights || []);
      }
    } catch (error) {
      console.error('Failed to generate insights:', error);
    }
  };

  const savePersonalizationProfile = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/personalization-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Firebase-UID': user.firebaseUid
        },
        body: JSON.stringify(profile)
      });

      if (response.ok) {
        toast({
          title: "Personalization Updated",
          description: "Your AI companion has been customized to your preferences.",
        });
        generatePersonalizedInsights();
      }
    } catch (error) {
      console.error('Failed to save profile:', error);
      toast({
        title: "Update Failed",
        description: "Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const selectedPersonality = PERSONALITY_TYPES[profile.companionPersonality];
  const PersonalityIcon = selectedPersonality.icon;

  return (
    <div className="space-y-6">
      {/* AI Companion Customization */}
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-purple-600" />
            AI Companion Personalization
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Companion Name */}
          <div className="space-y-2">
            <Label htmlFor="companionName">Companion Name</Label>
            <Input
              id="companionName"
              value={profile.companionName}
              onChange={(e) => setProfile({ ...profile, companionName: e.target.value })}
              placeholder="Give your AI companion a name"
            />
          </div>

          {/* Personality Type */}
          <div className="space-y-2">
            <Label>Personality Type</Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {Object.entries(PERSONALITY_TYPES).map(([key, personality]) => {
                const Icon = personality.icon;
                const isSelected = profile.companionPersonality === key;
                
                return (
                  <div
                    key={key}
                    onClick={() => setProfile({ ...profile, companionPersonality: key as any })}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      isSelected 
                        ? 'border-purple-500 bg-purple-50 shadow-md' 
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <Icon className={`h-6 w-6 mb-2 ${personality.color}`} />
                    <div className="font-semibold text-sm">{personality.name}</div>
                    <div className="text-xs text-muted-foreground">{personality.description}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Voice Tone */}
          <div className="space-y-2">
            <Label htmlFor="voiceTone">Voice Tone</Label>
            <Select 
              value={profile.voiceTone} 
              onValueChange={(value: any) => setProfile({ ...profile, voiceTone: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gentle">Gentle & Soft</SelectItem>
                <SelectItem value="coach">Motivational Coach</SelectItem>
                <SelectItem value="spiritual">Spiritual & Wise</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Color Theme */}
          <div className="space-y-2">
            <Label>App Color Theme</Label>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
              {Object.entries(COLOR_THEMES).map(([key, theme]) => (
                <div
                  key={key}
                  onClick={() => setProfile({ ...profile, colorTheme: key as any })}
                  className={`p-2 rounded-lg border cursor-pointer transition-all ${
                    profile.colorTheme === key 
                      ? 'border-purple-500 shadow-md' 
                      : 'border-gray-200 hover:border-purple-300'
                  }`}
                >
                  <div className={`h-6 w-full rounded ${theme.primary} mb-1`}></div>
                  <div className="text-xs font-medium">{theme.name}</div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Behavior Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-emerald-600" />
            Behavior Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* AI Adaptiveness */}
          <div className="space-y-2">
            <Label>AI Learning Adaptiveness (1-10)</Label>
            <div className="px-3">
              <Slider
                value={[profile.aiAdaptiveness]}
                onValueChange={([value]) => setProfile({ ...profile, aiAdaptiveness: value })}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Conservative</span>
                <span>Current: {profile.aiAdaptiveness}</span>
                <span>Highly Adaptive</span>
              </div>
            </div>
          </div>

          {/* Daily Check-in Time */}
          <div className="space-y-2">
            <Label htmlFor="motivationTime">Daily Motivation Time</Label>
            <Input
              id="motivationTime"
              type="time"
              value={profile.dailyMotivationTime}
              onChange={(e) => setProfile({ ...profile, dailyMotivationTime: e.target.value })}
            />
          </div>

          {/* Crisis Intervention Level */}
          <div className="space-y-2">
            <Label htmlFor="crisisLevel">Crisis Intervention Preference</Label>
            <Select 
              value={profile.crisisInterventionLevel} 
              onValueChange={(value: any) => setProfile({ ...profile, crisisInterventionLevel: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gentle">Gentle Support</SelectItem>
                <SelectItem value="moderate">Balanced Approach</SelectItem>
                <SelectItem value="intensive">Intensive Intervention</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Save Button */}
          <Button 
            onClick={savePersonalizationProfile} 
            disabled={isLoading}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
          >
            {isLoading ? "Saving..." : "Save Personalization Settings"}
          </Button>
        </CardContent>
      </Card>

      {/* AI-Generated Insights */}
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-600" />
            Personalized AI Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          {insights.length > 0 ? (
            <div className="space-y-3">
              {insights.map((insight, index) => (
                <div key={index} className="p-3 bg-white/70 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800">{insight}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <Sparkles className="h-12 w-12 text-blue-400 mx-auto mb-3" />
              <p className="text-blue-600 font-medium">Generating personalized insights...</p>
              <p className="text-sm text-blue-500 mt-1">
                Based on your behavior patterns and preferences
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Current Companion Preview */}
      <Card className="bg-gradient-to-r from-emerald-500/10 to-blue-500/10 border-emerald-500/20">
        <CardContent className="pt-6">
          <div className="text-center">
            <PersonalityIcon className={`h-16 w-16 mx-auto mb-3 ${selectedPersonality.color}`} />
            <h3 className="text-lg font-semibold text-emerald-800">
              Meet {profile.companionName}
            </h3>
            <p className="text-sm text-emerald-600 mb-3">{selectedPersonality.description}</p>
            <div className="flex justify-center gap-2">
              <Badge variant="secondary">{profile.voiceTone} voice</Badge>
              <Badge variant="secondary">{COLOR_THEMES[profile.colorTheme].name}</Badge>
              <Badge variant="secondary">Level {profile.aiAdaptiveness} AI</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}