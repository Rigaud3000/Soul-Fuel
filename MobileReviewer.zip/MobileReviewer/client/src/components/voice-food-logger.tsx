import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useTranslation } from '@/contexts/LanguageContext';

interface VoiceLoggerProps {
  onFoodLogged: (food: string) => void;
}

export default function VoiceLogger({ onFoodLogged }: VoiceLoggerProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const { toast } = useToast();
  const { t } = useTranslation();

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      toast({
        title: t('voiceLogger.errors.notSupported'),
        description: t('voiceLogger.errors.browserNotSupported'),
        variant: "destructive"
      });
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      setTranscript('');
    };

    recognition.onresult = (event) => {
      const current = event.resultIndex;
      const transcriptText = event.results[current][0].transcript;
      setTranscript(transcriptText);
    };

    recognition.onend = () => {
      setIsListening(false);
      if (transcript.trim()) {
        processVoiceInput(transcript);
      }
    };

    recognition.onerror = (event) => {
      setIsListening(false);
      toast({
        title: "Voice recognition error",
        description: "Please try again",
        variant: "destructive"
      });
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };

  const processVoiceInput = async (voiceText: string) => {
    setIsProcessing(true);
    try {
      // Use existing AI analysis endpoint to parse the voice input
      const response = await apiRequest('POST', '/api/analyze-text-food', {
        description: voiceText
      });

      if (response.ok) {
        const result = await response.json();
        onFoodLogged(result.foodName || voiceText);
        toast({
          title: t('voiceLogger.success.title'),
          description: `${t('voiceLogger.success.added')}: ${result.foodName || voiceText}`,
        });
        setTranscript('');
      }
    } catch (error) {
      toast({
        title: t('voiceLogger.errors.processingFailed'),
        description: t('voiceLogger.errors.couldNotProcess'),
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card className="bg-dark-800 border-dark-700">
      <CardContent className="p-4">
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Volume2 size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-dark-50">{t('voiceLogger.title')}</h3>
          </div>
          
          <p className="text-sm text-dark-400">
            {t('voiceLogger.instruction')}
          </p>

          {transcript && (
            <div className="bg-dark-700 rounded-lg p-3">
              <p className="text-dark-50 text-sm">{transcript}</p>
            </div>
          )}

          <Button
            onClick={isListening ? stopListening : startListening}
            disabled={isProcessing}
            className={`w-full ${
              isListening 
                ? 'bg-red-600 hover:bg-red-700' 
                : 'bg-primary hover:bg-primary/80'
            }`}
          >
            {isProcessing ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                {t('voiceLogger.processing')}
              </div>
            ) : isListening ? (
              <div className="flex items-center gap-2">
                <MicOff size={20} />
                {t('voiceLogger.listening')}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Mic size={20} />
                {t('voiceLogger.startRecording')}
              </div>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}