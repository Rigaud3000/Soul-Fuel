import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Bell, 
  BellOff, 
  Wifi, 
  WifiOff, 
  Clock, 
  Heart, 
  AlertTriangle, 
  TrendingUp,
  CheckCircle,
  Settings,
  TestTube
} from 'lucide-react';
import { notificationManager } from "@/lib/notification-manager";
import { simpleOfflineManager } from "@/lib/simple-offline-manager";
import { useToast } from "@/hooks/use-toast";

export function OfflineNotificationSettings() {
  const { toast } = useToast();
  const [notificationSettings, setNotificationSettings] = useState(notificationManager.getSettings());
  const [offlineStats, setOfflineStats] = useState({ totalEntries: 0, unsyncedEntries: 0, lastSync: null });
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>('default');

  useEffect(() => {
    // Initialize managers
    simpleOfflineManager.initialize();
    notificationManager.initialize();

    // Set up online/offline listener
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Load initial data
    updateOfflineStats();
    setPermissionStatus(Notification.permission);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const updateOfflineStats = () => {
    const stats = simpleOfflineManager.getOfflineStats();
    setOfflineStats(stats);
  };

  const handleNotificationPermission = async () => {
    const granted = await notificationManager.requestPermission();
    setPermissionStatus(Notification.permission);
    
    if (granted) {
      toast({
        title: "Notifications Enabled",
        description: "You'll now receive helpful wellness reminders and alerts.",
      });
    } else {
      toast({
        title: "Notifications Denied",
        description: "You can enable notifications later in your browser settings.",
        variant: "destructive"
      });
    }
  };

  const updateNotificationSettings = (key: keyof typeof notificationSettings, value: any) => {
    const newSettings = { ...notificationSettings, [key]: value };
    setNotificationSettings(newSettings);
    notificationManager.updateSettings(newSettings);
    
    toast({
      title: "Settings Updated",
      description: "Your notification preferences have been saved.",
    });
  };

  const updateCustomTime = (timeType: string, value: string) => {
    const newCustomTimes = { ...notificationSettings.customTimes, [timeType]: value };
    const newSettings = { ...notificationSettings, customTimes: newCustomTimes };
    setNotificationSettings(newSettings);
    notificationManager.updateSettings(newSettings);
  };

  const handleSyncNow = async () => {
    if (!isOnline) {
      toast({
        title: "No Connection",
        description: "Cannot sync while offline. Data will sync automatically when connection is restored.",
        variant: "destructive"
      });
      return;
    }

    await simpleOfflineManager.syncWithServer();
    updateOfflineStats();
    
    toast({
      title: "Sync Complete",
      description: "All offline data has been synchronized with the server.",
    });
  };

  const handleTestNotification = async () => {
    if (permissionStatus !== 'granted') {
      toast({
        title: "Permission Required",
        description: "Please enable notifications first to test them.",
        variant: "destructive"
      });
      return;
    }

    await notificationManager.sendTestNotification();
  };

  const clearOfflineData = () => {
    simpleOfflineManager.clearOfflineData();
    updateOfflineStats();
    
    toast({
      title: "Offline Data Cleared",
      description: "All local data has been removed.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <Card className={`border-2 ${isOnline ? 'border-green-200 bg-green-50' : 'border-amber-200 bg-amber-50'}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {isOnline ? <Wifi className="h-5 w-5 text-green-600" /> : <WifiOff className="h-5 w-5 text-amber-600" />}
            Connection Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Badge variant={isOnline ? "default" : "secondary"} className={isOnline ? "bg-green-600" : "bg-amber-600"}>
                {isOnline ? "Online" : "Offline"}
              </Badge>
              <p className="text-sm text-muted-foreground mt-1">
                {isOnline 
                  ? "All features available and data syncing automatically" 
                  : "Core features available offline. Data will sync when connection returns."}
              </p>
            </div>
            {!isOnline && offlineStats.unsyncedEntries > 0 && (
              <div className="text-right">
                <div className="text-sm font-medium text-amber-700">
                  {offlineStats.unsyncedEntries} items pending sync
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Offline Data Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-blue-600" />
            Offline Data Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{offlineStats.totalEntries}</div>
              <div className="text-sm text-blue-700">Total Offline Entries</div>
            </div>
            <div className="text-center p-3 bg-amber-50 rounded-lg">
              <div className="text-2xl font-bold text-amber-600">{offlineStats.unsyncedEntries}</div>
              <div className="text-sm text-amber-700">Unsynced Entries</div>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-sm text-green-700">Last Sync</div>
              <div className="text-sm font-medium text-green-600">
                {offlineStats.lastSync 
                  ? new Date(offlineStats.lastSync).toLocaleDateString()
                  : 'Never'}
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={handleSyncNow} 
              disabled={!isOnline || offlineStats.unsyncedEntries === 0}
              className="flex-1"
            >
              {isOnline ? "Sync Now" : "Cannot Sync (Offline)"}
            </Button>
            <Button 
              variant="outline" 
              onClick={clearOfflineData}
              className="text-red-600 hover:bg-red-50"
            >
              Clear Data
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {permissionStatus === 'granted' ? (
              <Bell className="h-5 w-5 text-emerald-600" />
            ) : (
              <BellOff className="h-5 w-5 text-gray-400" />
            )}
            Push Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Permission Status */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div>
              <div className="font-medium">Notification Permission</div>
              <div className="text-sm text-muted-foreground">
                {permissionStatus === 'granted' 
                  ? 'Notifications are enabled and working'
                  : permissionStatus === 'denied'
                  ? 'Notifications are blocked - enable in browser settings'
                  : 'Notifications not yet enabled'}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={permissionStatus === 'granted' ? "default" : "secondary"}>
                {permissionStatus}
              </Badge>
              {permissionStatus !== 'granted' && (
                <Button onClick={handleNotificationPermission} size="sm">
                  Enable
                </Button>
              )}
              {permissionStatus === 'granted' && (
                <Button onClick={handleTestNotification} size="sm" variant="outline">
                  <TestTube className="h-4 w-4 mr-1" />
                  Test
                </Button>
              )}
            </div>
          </div>

          <Separator />

          {/* Notification Type Settings */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-emerald-500" />
                <Label htmlFor="daily-reminders">Daily Reminders</Label>
              </div>
              <Switch
                id="daily-reminders"
                checked={notificationSettings.dailyReminders}
                onCheckedChange={(checked) => updateNotificationSettings('dailyReminders', checked)}
                disabled={permissionStatus !== 'granted'}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                <Label htmlFor="craving-alerts">Craving Prediction Alerts</Label>
              </div>
              <Switch
                id="craving-alerts"
                checked={notificationSettings.cravingAlerts}
                onCheckedChange={(checked) => updateNotificationSettings('cravingAlerts', checked)}
                disabled={permissionStatus !== 'granted'}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-pink-500" />
                <Label htmlFor="motivational-messages">Motivational Messages</Label>
              </div>
              <Switch
                id="motivational-messages"
                checked={notificationSettings.motivationalMessages}
                onCheckedChange={(checked) => updateNotificationSettings('motivationalMessages', checked)}
                disabled={permissionStatus !== 'granted'}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-blue-500" />
                <Label htmlFor="mood-checkins">Mood Check-ins</Label>
              </div>
              <Switch
                id="mood-checkins"
                checked={notificationSettings.moodCheckIns}
                onCheckedChange={(checked) => updateNotificationSettings('moodCheckIns', checked)}
                disabled={permissionStatus !== 'granted'}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-purple-500" />
                <Label htmlFor="weekly-progress">Weekly Progress Updates</Label>
              </div>
              <Switch
                id="weekly-progress"
                checked={notificationSettings.weeklyProgress}
                onCheckedChange={(checked) => updateNotificationSettings('weeklyProgress', checked)}
                disabled={permissionStatus !== 'granted'}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                <Label htmlFor="emergency-support">Emergency Support</Label>
              </div>
              <Switch
                id="emergency-support"
                checked={notificationSettings.emergencySupport}
                onCheckedChange={(checked) => updateNotificationSettings('emergencySupport', checked)}
                disabled={permissionStatus !== 'granted'}
              />
            </div>
          </div>

          <Separator />

          {/* Custom Timing */}
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Custom Notification Times
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="morning-time" className="text-sm">Morning Motivation</Label>
                <Input
                  id="morning-time"
                  type="time"
                  value={notificationSettings.customTimes.morningMotivation}
                  onChange={(e) => updateCustomTime('morningMotivation', e.target.value)}
                  disabled={permissionStatus !== 'granted'}
                />
              </div>

              <div>
                <Label htmlFor="evening-time" className="text-sm">Evening Reflection</Label>
                <Input
                  id="evening-time"
                  type="time"
                  value={notificationSettings.customTimes.eveningReflection}
                  onChange={(e) => updateCustomTime('eveningReflection', e.target.value)}
                  disabled={permissionStatus !== 'granted'}
                />
              </div>
            </div>

            <div>
              <Label className="text-sm">Craving Check Times</Label>
              <div className="text-xs text-muted-foreground mb-2">
                Current times: {notificationSettings.customTimes.cravingCheck.join(', ')}
              </div>
              <div className="text-xs text-blue-600">
                💡 You can customize these times in your advanced settings
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Offline Features Available */}
      <Card className="bg-emerald-50 border-emerald-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-emerald-800">
            <CheckCircle className="h-5 w-5" />
            Available Offline
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Sugar Tracking
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Mood Logging
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Craving Tracking
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Emergency Toolkit
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Mini-Games
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Breathing Exercises
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Progress Viewing
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Offline AI Responses
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}