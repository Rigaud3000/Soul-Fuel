import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wind, Play, Pause, RotateCcw } from "lucide-react";

interface BreathingOrbProps {
  onComplete: () => void;
  onExit: () => void;
}

export default function BreathingOrb({ onComplete, onExit }: BreathingOrbProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale' | 'pause'>('inhale');
  const [timeRemaining, setTimeRemaining] = useState(4);
  const [cycleCount, setCycleCount] = useState(0);
  const [totalCycles] = useState(5);

  const phases = {
    inhale: { duration: 4, next: 'hold', text: 'Breathe In', color: 'from-blue-500 to-cyan-500' },
    hold: { duration: 7, next: 'exhale', text: 'Hold', color: 'from-purple-500 to-pink-500' },
    exhale: { duration: 8, next: 'pause', text: 'Breathe Out', color: 'from-green-500 to-emerald-500' },
    pause: { duration: 1, next: 'inhale', text: 'Pause', color: 'from-gray-500 to-slate-500' }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    } else if (isPlaying && timeRemaining === 0) {
      const currentPhase = phases[phase];
      const nextPhase = currentPhase.next as keyof typeof phases;
      
      if (phase === 'pause') {
        setCycleCount(prev => prev + 1);
        if (cycleCount + 1 >= totalCycles) {
          setIsPlaying(false);
          onComplete();
          return;
        }
      }
      
      setPhase(nextPhase);
      setTimeRemaining(phases[nextPhase].duration);
    }

    return () => clearInterval(interval);
  }, [isPlaying, timeRemaining, phase, cycleCount, totalCycles, onComplete]);

  const currentPhase = phases[phase];
  const progress = ((currentPhase.duration - timeRemaining) / currentPhase.duration) * 100;
  const scale = phase === 'inhale' ? 1 + (progress / 100) * 0.5 : 
               phase === 'exhale' ? 1.5 - (progress / 100) * 0.5 : 
               1.5;

  const togglePlaying = () => {
    setIsPlaying(!isPlaying);
  };

  const reset = () => {
    setIsPlaying(false);
    setPhase('inhale');
    setTimeRemaining(4);
    setCycleCount(0);
  };

  return (
    <div className="min-h-screen bg-dark-900 text-white p-4 flex items-center justify-center">
      <Card className="bg-dark-800 border-dark-700 w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center text-primary">
            <Wind className="mr-2 h-6 w-6" />
            4-7-8 Breathing
          </CardTitle>
          <p className="text-dark-400 text-sm">
            Follow the orb to calm your mind and reduce cravings
          </p>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          {/* Breathing Orb */}
          <div className="relative flex items-center justify-center h-64">
            <div 
              className={`w-32 h-32 rounded-full bg-gradient-to-br ${currentPhase.color} transition-transform duration-1000 ease-in-out shadow-2xl`}
              style={{ 
                transform: `scale(${scale})`,
                filter: 'blur(1px)',
                opacity: 0.8
              }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-1">
                  {timeRemaining}
                </div>
                <div className="text-sm text-white/80">
                  {currentPhase.text}
                </div>
              </div>
            </div>
          </div>

          {/* Progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-dark-400">
              <span>Cycle {cycleCount + 1} of {totalCycles}</span>
              <span>{Math.round(((cycleCount + (100 - progress) / 100) / totalCycles) * 100)}%</span>
            </div>
            <div className="w-full bg-dark-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-primary to-primary/80 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((cycleCount + (100 - progress) / 100) / totalCycles) * 100}%` }}
              />
            </div>
          </div>

          {/* Instructions */}
          <div className="bg-dark-700 rounded-lg p-4 text-sm text-dark-300">
            <p className="mb-2">
              <strong className="text-primary">4-7-8 Technique:</strong>
            </p>
            <ul className="text-left space-y-1">
              <li>• Inhale for 4 seconds</li>
              <li>• Hold for 7 seconds</li>
              <li>• Exhale for 8 seconds</li>
              <li>• Brief pause, then repeat</li>
            </ul>
          </div>

          {/* Controls */}
          <div className="flex space-x-3">
            <Button
              onClick={togglePlaying}
              className={`flex-1 ${isPlaying ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-primary hover:bg-primary/80'}`}
            >
              {isPlaying ? (
                <>
                  <Pause className="mr-2 h-4 w-4" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Start
                </>
              )}
            </Button>
            <Button
              onClick={reset}
              variant="outline"
              className="px-4"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>

          <Button
            onClick={onExit}
            variant="ghost"
            className="w-full text-dark-400"
          >
            Back to Emergency Kit
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}