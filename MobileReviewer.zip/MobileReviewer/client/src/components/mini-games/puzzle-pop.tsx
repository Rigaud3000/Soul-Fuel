import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gamepad2, RotateCcw, Timer } from "lucide-react";

interface PuzzlePopProps {
  onComplete: () => void;
  onExit: () => void;
}

const HEALTHY_FOODS = [
  { emoji: "🥬", name: "Leafy Greens", points: 10 },
  { emoji: "🥕", name: "Carrots", points: 10 },
  { emoji: "🥦", name: "Broccoli", points: 10 },
  { emoji: "🍎", name: "Apple", points: 10 },
  { emoji: "🥑", name: "Avocado", points: 15 },
  { emoji: "🫐", name: "Blueberries", points: 15 },
  { emoji: "🥒", name: "Cucumber", points: 5 },
  { emoji: "🍊", name: "Orange", points: 10 }
];

const UNHEALTHY_FOODS = [
  { emoji: "🍕", name: "Pizza", points: -10 },
  { emoji: "🍔", name: "Burger", points: -10 },
  { emoji: "🍟", name: "Fries", points: -15 },
  { emoji: "🍩", name: "Donut", points: -20 },
  { emoji: "🍭", name: "Candy", points: -20 },
  { emoji: "🥤", name: "Soda", points: -15 },
  { emoji: "🍪", name: "Cookie", points: -15 },
  { emoji: "🧁", name: "Cupcake", points: -20 }
];

export default function PuzzlePop({ onComplete, onExit }: PuzzlePopProps) {
  const [gameBoard, setGameBoard] = useState<Array<{emoji: string, name: string, points: number, id: number, isHealthy: boolean}>>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameEnded, setGameEnded] = useState(false);
  const [correctClicks, setCorrectClicks] = useState(0);
  const [wrongClicks, setWrongClicks] = useState(0);

  useEffect(() => {
    if (gameStarted && !gameEnded) {
      generateNewBoard();
    }
  }, [gameStarted]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (gameStarted && timeLeft > 0 && !gameEnded) {
      interval = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            setGameEnded(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [gameStarted, timeLeft, gameEnded]);

  const generateNewBoard = () => {
    const board = [];
    const allFoods = [...HEALTHY_FOODS, ...UNHEALTHY_FOODS];
    
    for (let i = 0; i < 12; i++) {
      const randomFood = allFoods[Math.floor(Math.random() * allFoods.length)];
      board.push({
        ...randomFood,
        id: i,
        isHealthy: HEALTHY_FOODS.includes(randomFood)
      });
    }
    
    setGameBoard(board);
  };

  const handleFoodClick = (food: any) => {
    if (gameEnded) return;

    if (food.isHealthy) {
      setScore(prev => prev + food.points);
      setCorrectClicks(prev => prev + 1);
    } else {
      setScore(prev => Math.max(0, prev + food.points));
      setWrongClicks(prev => prev + 1);
    }

    // Remove clicked item and generate new board
    setTimeout(() => {
      generateNewBoard();
    }, 200);
  };

  const startGame = () => {
    setGameStarted(true);
    setScore(0);
    setTimeLeft(30);
    setGameEnded(false);
    setCorrectClicks(0);
    setWrongClicks(0);
  };

  const resetGame = () => {
    setGameStarted(false);
    setGameEnded(false);
    setScore(0);
    setTimeLeft(30);
    setCorrectClicks(0);
    setWrongClicks(0);
    setGameBoard([]);
  };

  if (gameEnded) {
    const accuracy = correctClicks + wrongClicks > 0 ? Math.round((correctClicks / (correctClicks + wrongClicks)) * 100) : 0;
    
    return (
      <div className="min-h-screen bg-dark-900 text-white p-4 flex items-center justify-center">
        <Card className="bg-dark-800 border-dark-700 w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-primary">Game Complete!</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="text-6xl">🎉</div>
            
            <div className="space-y-3">
              <div className="text-3xl font-bold text-primary">{score} points</div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-dark-700 rounded-lg p-3">
                  <div className="text-green-400 font-semibold">{correctClicks}</div>
                  <div className="text-dark-400">Healthy Picks</div>
                </div>
                <div className="bg-dark-700 rounded-lg p-3">
                  <div className="text-red-400 font-semibold">{wrongClicks}</div>
                  <div className="text-dark-400">Junk Food</div>
                </div>
              </div>
              <Badge className="bg-primary/20 text-primary">
                {accuracy}% Accuracy
              </Badge>
            </div>

            <div className="bg-dark-700 rounded-lg p-4 text-sm text-dark-300">
              <p className="font-semibold text-primary mb-2">Great job! 🌟</p>
              <p>You focused your mind on healthy choices and gave your brain positive stimulation instead of reaching for that craving.</p>
            </div>

            <div className="space-y-3">
              <Button onClick={onComplete} className="w-full bg-primary hover:bg-primary/80">
                Claim +{Math.max(10, score)} XP
              </Button>
              <Button onClick={resetGame} variant="outline" className="w-full">
                Play Again
              </Button>
              <Button onClick={onExit} variant="ghost" className="w-full text-dark-400">
                Back to Emergency Kit
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-white p-4">
      <div className="max-w-md mx-auto">
        <Card className="bg-dark-800 border-dark-700 mb-4">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center text-primary">
              <Gamepad2 className="mr-2 h-6 w-6" />
              Puzzle Pop
            </CardTitle>
            <p className="text-dark-400 text-sm">Tap only the healthy foods!</p>
          </CardHeader>
        </Card>

        {!gameStarted ? (
          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="text-center p-6 space-y-6">
              <div className="text-4xl">🎯</div>
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">How to Play</h3>
                <ul className="text-sm text-dark-300 text-left space-y-1">
                  <li>• Tap healthy foods (🥬🥕🍎) to earn points</li>
                  <li>• Avoid junk food (🍕🍟🍩) - they cost points!</li>
                  <li>• You have 30 seconds to score as high as possible</li>
                  <li>• Focus your mind and beat the craving!</li>
                </ul>
              </div>
              <Button onClick={startGame} className="w-full bg-primary hover:bg-primary/80">
                Start Game
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Game Header */}
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{score}</div>
                  <div className="text-xs text-dark-400">Score</div>
                </div>
                <div className="text-center">
                  <div className="flex items-center text-2xl font-bold text-orange-400">
                    <Timer className="mr-1 h-5 w-5" />
                    {timeLeft}
                  </div>
                  <div className="text-xs text-dark-400">Seconds</div>
                </div>
              </div>
              <Button onClick={resetGame} variant="outline" size="sm">
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>

            {/* Game Board */}
            <div className="grid grid-cols-3 gap-3 mb-4">
              {gameBoard.map((food) => (
                <Button
                  key={food.id}
                  onClick={() => handleFoodClick(food)}
                  className={`h-20 text-4xl transition-all transform hover:scale-105 ${
                    food.isHealthy 
                      ? 'bg-green-900/30 hover:bg-green-800/50 border-green-700/50' 
                      : 'bg-red-900/30 hover:bg-red-800/50 border-red-700/50'
                  }`}
                  variant="outline"
                >
                  {food.emoji}
                </Button>
              ))}
            </div>

            {/* Instructions */}
            <Card className="bg-dark-800 border-dark-700">
              <CardContent className="p-4 text-center">
                <p className="text-sm text-dark-300">
                  Tap the healthy foods! Avoid junk food that might trigger more cravings.
                </p>
              </CardContent>
            </Card>
          </>
        )}

        <Button onClick={onExit} variant="ghost" className="w-full mt-4 text-dark-400">
          Back to Emergency Kit
        </Button>
      </div>
    </div>
  );
}