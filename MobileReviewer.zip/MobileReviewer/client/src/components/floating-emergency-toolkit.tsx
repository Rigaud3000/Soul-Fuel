import React, { useState } from 'react';
import { Shield, X, Gamepad2, Wind, Brain, Phone, Music } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

interface EmergencyTool {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  action: () => void;
}

export function FloatingEmergencyToolkit() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [breathingActive, setBreathingActive] = useState(false);

  const emergencyTools: EmergencyTool[] = [
    {
      id: 'breathing',
      name: 'Breathing Exercise',
      icon: <Wind className="w-5 h-5" />,
      description: '4-7-8 breathing technique to calm cravings',
      color: 'bg-blue-500 hover:bg-blue-600',
      action: () => setBreathingActive(true)
    },
    {
      id: 'puzzle',
      name: 'Puzzle Pop',
      icon: <Gamepad2 className="w-5 h-5" />,
      description: 'Quick puzzle game to distract your mind',
      color: 'bg-purple-500 hover:bg-purple-600',
      action: () => setActiveGame('puzzle')
    },
    {
      id: 'meditation',
      name: 'Quick Meditation',
      icon: <Brain className="w-5 h-5" />,
      description: '2-minute mindfulness session',
      color: 'bg-emerald-500 hover:bg-emerald-600',
      action: () => setActiveGame('meditation')
    },
    {
      id: 'hotline',
      name: 'Support Line',
      icon: <Phone className="w-5 h-5" />,
      description: 'Connect with addiction support resources',
      color: 'bg-red-500 hover:bg-red-600',
      action: () => window.open('tel:1-800-662-4357', '_self')
    },
    {
      id: 'music',
      name: 'Calming Sounds',
      icon: <Music className="w-5 h-5" />,
      description: 'Nature sounds and calming music',
      color: 'bg-indigo-500 hover:bg-indigo-600',
      action: () => setActiveGame('sounds')
    }
  ];

  const BreathingExercise = () => {
    const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale' | 'rest'>('inhale');
    const [count, setCount] = useState(4);
    const [cycle, setCycle] = useState(1);

    React.useEffect(() => {
      if (!breathingActive) return;

      const timer = setInterval(() => {
        setCount(prev => {
          if (prev > 1) return prev - 1;
          
          // Move to next phase
          if (phase === 'inhale') {
            setPhase('hold');
            return 7;
          } else if (phase === 'hold') {
            setPhase('exhale');
            return 8;
          } else if (phase === 'exhale') {
            setPhase('rest');
            return 2;
          } else {
            if (cycle < 4) {
              setPhase('inhale');
              setCycle(cycle + 1);
              return 4;
            } else {
              setBreathingActive(false);
              setCycle(1);
              setPhase('inhale');
              return 4;
            }
          }
        });
      }, 1000);

      return () => clearInterval(timer);
    }, [phase, cycle, breathingActive]);

    const getPhaseColor = () => {
      switch (phase) {
        case 'inhale': return 'text-green-400';
        case 'hold': return 'text-yellow-400';
        case 'exhale': return 'text-blue-400';
        case 'rest': return 'text-purple-400';
      }
    };

    return (
      <div className="text-center p-8">
        <div className={`text-6xl font-bold mb-4 ${getPhaseColor()}`}>
          {count}
        </div>
        <div className="text-2xl mb-4 capitalize">{phase}</div>
        <div className="text-sm text-gray-400">Cycle {cycle} of 4</div>
        <div className={`w-32 h-32 mx-auto rounded-full border-4 transition-all duration-1000 ${
          phase === 'inhale' ? 'scale-110 border-green-400' :
          phase === 'hold' ? 'scale-110 border-yellow-400' :
          phase === 'exhale' ? 'scale-75 border-blue-400' :
          'scale-90 border-purple-400'
        }`} />
        <Button 
          onClick={() => setBreathingActive(false)}
          variant="outline" 
          className="mt-6"
        >
          Stop Exercise
        </Button>
      </div>
    );
  };

  const PuzzleGame = () => {
    const [score, setScore] = useState(0);
    const [tiles, setTiles] = useState(() => 
      Array.from({ length: 16 }, (_, i) => ({ id: i, color: `hsl(${i * 20}, 70%, 60%)` }))
        .sort(() => Math.random() - 0.5)
    );

    const handleTileClick = (id: number) => {
      setScore(prev => prev + 10);
      setTiles(prev => prev.sort(() => Math.random() - 0.5));
    };

    return (
      <div className="p-6">
        <div className="text-center mb-4">
          <Badge variant="secondary" className="text-lg px-4 py-2">
            Score: {score}
          </Badge>
        </div>
        <div className="grid grid-cols-4 gap-2 max-w-xs mx-auto">
          {tiles.map((tile) => (
            <button
              key={tile.id}
              onClick={() => handleTileClick(tile.id)}
              className="aspect-square rounded-lg transition-all duration-200 hover:scale-105"
              style={{ backgroundColor: tile.color }}
            />
          ))}
        </div>
        <div className="text-center mt-4 text-sm text-gray-400">
          Tap tiles to score points and distract from cravings
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Floating Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 shadow-lg hover:shadow-xl transition-all duration-300 animate-pulse"
          size="lg"
        >
          <Shield className="w-8 h-8" />
        </Button>
      </div>

      {/* Emergency Toolkit Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-md bg-slate-900 border-red-500/30">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-400">
              <Shield className="w-6 h-6" />
              Emergency Craving Toolkit
            </DialogTitle>
          </DialogHeader>

          {breathingActive ? (
            <BreathingExercise />
          ) : activeGame === 'puzzle' ? (
            <PuzzleGame />
          ) : activeGame === 'meditation' ? (
            <div className="text-center p-8">
              <div className="w-24 h-24 mx-auto rounded-full bg-emerald-500/20 flex items-center justify-center mb-4">
                <Brain className="w-12 h-12 text-emerald-400 animate-pulse" />
              </div>
              <h3 className="text-xl mb-4">Mindful Moment</h3>
              <p className="text-gray-300 mb-6">
                Close your eyes. Take three deep breaths. Notice five things you can hear, 
                four things you can touch, three things you can see.
              </p>
              <Button onClick={() => setActiveGame(null)} variant="outline">
                Feeling Better
              </Button>
            </div>
          ) : activeGame === 'sounds' ? (
            <div className="text-center p-8">
              <div className="w-24 h-24 mx-auto rounded-full bg-indigo-500/20 flex items-center justify-center mb-4">
                <Music className="w-12 h-12 text-indigo-400 animate-bounce" />
              </div>
              <h3 className="text-xl mb-4">Calming Sounds</h3>
              <div className="space-y-3">
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => window.open('https://youtu.be/UfcAVejslrU', '_blank')}
                >
                  Ocean Waves
                </Button>
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => window.open('https://youtu.be/WeANKhYOk0U', '_blank')}
                >
                  Forest Sounds
                </Button>
                <Button 
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  onClick={() => window.open('https://youtu.be/5qap5aO4i9A', '_blank')}
                >
                  Rain & Thunder
                </Button>
              </div>
              <Button 
                onClick={() => setActiveGame(null)} 
                variant="outline" 
                className="mt-4"
              >
                Back to Toolkit
              </Button>
            </div>
          ) : (
            <div className="grid gap-3">
              {emergencyTools.map((tool) => (
                <Button
                  key={tool.id}
                  onClick={tool.action}
                  className={`h-auto p-4 text-left justify-start ${tool.color}`}
                >
                  <div className="flex items-center gap-3">
                    {tool.icon}
                    <div>
                      <div className="font-semibold">{tool.name}</div>
                      <div className="text-sm opacity-90">{tool.description}</div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}