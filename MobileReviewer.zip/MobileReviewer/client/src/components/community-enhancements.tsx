import React, { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Flag, Heart, Laugh, ThumbsUp, Award, Star, MessageCircle, AlertTriangle, Sparkles } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorLevel: number;
  authorXP: number;
  content: string;
  imageUrl?: string;
  createdAt: Date;
  reactions: {
    heart: number;
    thumbsUp: number;
    laugh: number;
    star: number;
  };
  userReaction?: string;
  commentsCount: number;
  isReported: boolean;
  badges: string[];
}

interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorLevel: number;
  content: string;
  createdAt: Date;
  reactions: {
    heart: number;
    thumbsUp: number;
  };
  userReaction?: string;
  isReported: boolean;
}

interface ModerationReport {
  postId?: string;
  commentId?: string;
  reason: string;
  description: string;
}

export function CommunityEnhancements() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ type: 'post' | 'comment'; id: string } | null>(null);
  const [reportForm, setReportForm] = useState<ModerationReport>({
    reason: '',
    description: ''
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['/api/community/posts'],
    enabled: !!user?.uid,
  });

  const { data: comments = [] } = useQuery({
    queryKey: ['/api/community/comments'],
    enabled: !!user?.uid,
  });

  const addReactionMutation = useMutation({
    mutationFn: async ({ type, targetId, reaction }: { type: 'post' | 'comment'; targetId: string; reaction: string }) => {
      return apiRequest("POST", `/api/community/${type}s/${targetId}/reactions`, { reaction });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/community/posts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/community/comments'] });
    },
  });

  const reportContentMutation = useMutation({
    mutationFn: async (report: ModerationReport) => {
      return apiRequest("POST", "/api/community/reports", report);
    },
    onSuccess: () => {
      toast({
        title: "Report Submitted",
        description: "Thank you for helping keep our community safe. We'll review this content.",
      });
      setReportDialogOpen(false);
      setReportTarget(null);
      setReportForm({ reason: '', description: '' });
    },
  });

  const getUserLevel = (xp: number): { level: number; progress: number; nextLevelXP: number } => {
    const levels = [0, 100, 300, 600, 1000, 1500, 2200, 3000, 4000, 5200, 6600, 8200, 10000];
    
    let level = 1;
    for (let i = 0; i < levels.length - 1; i++) {
      if (xp >= levels[i] && xp < levels[i + 1]) {
        level = i + 1;
        break;
      } else if (xp >= levels[levels.length - 1]) {
        level = levels.length;
        break;
      }
    }
    
    const currentLevelXP = levels[level - 1] || 0;
    const nextLevelXP = levels[level] || levels[levels.length - 1];
    const progress = ((xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
    
    return { level, progress: Math.min(progress, 100), nextLevelXP };
  };

  const getLevelBadge = (level: number) => {
    if (level >= 10) return { icon: '👑', color: 'bg-purple-500', name: 'Master' };
    if (level >= 8) return { icon: '💎', color: 'bg-blue-500', name: 'Expert' };
    if (level >= 6) return { icon: '🌟', color: 'bg-yellow-500', name: 'Advanced' };
    if (level >= 4) return { icon: '🔥', color: 'bg-orange-500', name: 'Committed' };
    if (level >= 2) return { icon: '⭐', color: 'bg-green-500', name: 'Rising' };
    return { icon: '🌱', color: 'bg-gray-500', name: 'Beginner' };
  };

  const getSpecialBadges = (badges: string[]) => {
    const badgeMap: Record<string, { icon: string; color: string; name: string }> = {
      'streak_champion': { icon: '🔥', color: 'bg-red-500', name: 'Streak Champion' },
      'helpful_community': { icon: '💝', color: 'bg-pink-500', name: 'Community Helper' },
      'sugar_free_30': { icon: '🎯', color: 'bg-emerald-500', name: 'Sugar-Free 30' },
      'wellness_warrior': { icon: '⚔️', color: 'bg-indigo-500', name: 'Wellness Warrior' },
      'mindful_master': { icon: '🧘', color: 'bg-purple-500', name: 'Mindful Master' },
      'nutrition_expert': { icon: '🥗', color: 'bg-green-500', name: 'Nutrition Expert' },
    };
    
    return badges.map(badge => badgeMap[badge]).filter(Boolean);
  };

  const handleReaction = (type: 'post' | 'comment', targetId: string, reaction: string) => {
    addReactionMutation.mutate({ type, targetId, reaction });
  };

  const handleReport = (type: 'post' | 'comment', id: string) => {
    setReportTarget({ type, id });
    setReportDialogOpen(true);
  };

  const submitReport = () => {
    if (!reportTarget) return;
    
    const report: ModerationReport = {
      ...reportForm,
      ...(reportTarget.type === 'post' ? { postId: reportTarget.id } : { commentId: reportTarget.id })
    };
    
    reportContentMutation.mutate(report);
  };

  const ReactionButton = ({ 
    icon, 
    count, 
    isActive, 
    onClick 
  }: { 
    icon: React.ReactNode; 
    count: number; 
    isActive: boolean; 
    onClick: () => void;
  }) => (
    <Button
      variant={isActive ? "default" : "ghost"}
      size="sm"
      onClick={onClick}
      className={`flex items-center gap-1 ${isActive ? 'bg-emerald-500 text-white' : ''}`}
    >
      {icon}
      <span className="text-xs">{count}</span>
    </Button>
  );

  const UserAvatar = ({ 
    post, 
    size = "md" 
  }: { 
    post: CommunityPost | PostComment; 
    size?: "sm" | "md" | "lg" 
  }) => {
    const levelInfo = getUserLevel(post.authorXP || 0);
    const levelBadge = getLevelBadge(levelInfo.level);
    const specialBadges = getSpecialBadges(post.badges || []);
    
    const sizeClasses = {
      sm: "w-8 h-8",
      md: "w-10 h-10", 
      lg: "w-12 h-12"
    };

    return (
      <div className="flex items-center gap-3">
        <div className="relative">
          <Avatar className={sizeClasses[size]}>
            <AvatarImage src={post.authorAvatar} />
            <AvatarFallback className={levelBadge.color}>
              {post.authorName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          {/* Level indicator */}
          <div className={`absolute -bottom-1 -right-1 ${levelBadge.color} rounded-full w-5 h-5 flex items-center justify-center text-xs`}>
            {levelBadge.icon}
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-gray-900 dark:text-white">
              {post.authorName}
            </span>
            
            {/* Level badge */}
            <Badge variant="secondary" className="text-xs">
              Lv.{levelInfo.level} {levelBadge.name}
            </Badge>
            
            {/* Special badges */}
            {specialBadges.slice(0, 2).map((badge, index) => (
              <Badge key={index} className={`${badge.color} text-white text-xs`}>
                {badge.icon} {badge.name}
              </Badge>
            ))}
            
            {specialBadges.length > 2 && (
              <Badge variant="outline" className="text-xs">
                +{specialBadges.length - 2} more
              </Badge>
            )}
          </div>
          
          <div className="text-xs text-gray-500">
            {post.authorXP?.toLocaleString()} XP
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Community Posts */}
      <div className="space-y-4">
        {posts.map((post: CommunityPost) => (
          <Card key={post.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <UserAvatar post={post} />
                
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleReport('post', post.id)}
                    className="text-gray-500 hover:text-red-500"
                  >
                    <Flag className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-gray-900 dark:text-gray-100 leading-relaxed">
                {post.content}
              </p>
              
              {post.imageUrl && (
                <img 
                  src={post.imageUrl} 
                  alt="Post content" 
                  className="w-full max-h-96 object-cover rounded-lg"
                />
              )}
              
              {/* Reactions */}
              <div className="flex items-center justify-between pt-2 border-t">
                <div className="flex gap-2">
                  <ReactionButton
                    icon={<Heart className="w-4 h-4" />}
                    count={post.reactions.heart}
                    isActive={post.userReaction === 'heart'}
                    onClick={() => handleReaction('post', post.id, 'heart')}
                  />
                  <ReactionButton
                    icon={<ThumbsUp className="w-4 h-4" />}
                    count={post.reactions.thumbsUp}
                    isActive={post.userReaction === 'thumbsUp'}
                    onClick={() => handleReaction('post', post.id, 'thumbsUp')}
                  />
                  <ReactionButton
                    icon={<Laugh className="w-4 h-4" />}
                    count={post.reactions.laugh}
                    isActive={post.userReaction === 'laugh'}
                    onClick={() => handleReaction('post', post.id, 'laugh')}
                  />
                  <ReactionButton
                    icon={<Star className="w-4 h-4" />}
                    count={post.reactions.star}
                    isActive={post.userReaction === 'star'}
                    onClick={() => handleReaction('post', post.id, 'star')}
                  />
                </div>
                
                <Button variant="ghost" size="sm" className="text-gray-500">
                  <MessageCircle className="w-4 h-4 mr-1" />
                  {post.commentsCount} comments
                </Button>
              </div>
              
              <div className="text-xs text-gray-500">
                {new Date(post.createdAt).toLocaleString()}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Moderation Report Dialog */}
      <Dialog open={reportDialogOpen} onOpenChange={setReportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Report Content
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Help us maintain a positive community by reporting inappropriate content.
            </p>
            
            <div>
              <label className="block text-sm font-medium mb-2">Reason for report</label>
              <select 
                value={reportForm.reason}
                onChange={(e) => setReportForm(prev => ({ ...prev, reason: e.target.value }))}
                className="w-full p-2 border rounded-md"
              >
                <option value="">Select a reason</option>
                <option value="spam">Spam or promotional content</option>
                <option value="harassment">Harassment or bullying</option>
                <option value="hate_speech">Hate speech or discrimination</option>
                <option value="misinformation">Health misinformation</option>
                <option value="inappropriate">Inappropriate content</option>
                <option value="other">Other</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Additional details</label>
              <Textarea
                value={reportForm.description}
                onChange={(e) => setReportForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Please provide more details about why you're reporting this content..."
                rows={3}
              />
            </div>
            
            <div className="flex gap-2">
              <Button 
                onClick={submitReport}
                disabled={!reportForm.reason || reportContentMutation.isPending}
                className="flex-1"
                variant="destructive"
              >
                {reportContentMutation.isPending ? 'Submitting...' : 'Submit Report'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setReportDialogOpen(false)}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}