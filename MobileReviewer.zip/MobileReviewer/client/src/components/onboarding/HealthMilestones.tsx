import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Target, 
  Trophy, 
  Star, 
  CheckCircle, 
  Calendar,
  TrendingUp,
  Heart,
  Zap,
  Shield,
  Award
} from "lucide-react";

interface Milestone {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  targetDays: number;
  reward: string;
  color: string;
  isCompleted: boolean;
  progress: number;
}

interface HealthMilestonesProps {
  userStartDate: Date;
  onMilestoneComplete: (milestone: Milestone) => void;
}

const healthMilestones: Milestone[] = [
  {
    id: 'first-week',
    title: 'First Week Strong',
    description: 'Complete your first week of consistent tracking',
    icon: Calendar,
    targetDays: 7,
    reward: 'Consistency Badge',
    color: 'from-blue-500 to-purple-600',
    isCompleted: false,
    progress: 0
  },
  {
    id: 'sugar-reduction',
    title: 'Sugar Warrior',
    description: 'Reduce sugar intake by 25% from baseline',
    icon: Shield,
    targetDays: 14,
    reward: 'Sugar Reduction Badge',
    color: 'from-green-500 to-emerald-600',
    isCompleted: false,
    progress: 0
  },
  {
    id: 'mood-stability',
    title: 'Emotional Balance',
    description: 'Maintain positive mood scores for 10 days',
    icon: Heart,
    targetDays: 21,
    reward: 'Mood Master Badge',
    color: 'from-pink-500 to-rose-600',
    isCompleted: false,
    progress: 0
  },
  {
    id: 'energy-boost',
    title: 'Energy Champion',
    description: 'Report improved energy levels consistently',
    icon: Zap,
    targetDays: 21,
    reward: 'Energy Boost Badge',
    color: 'from-yellow-500 to-orange-600',
    isCompleted: false,
    progress: 0
  },
  {
    id: 'thirty-day',
    title: '30-Day Transformation',
    description: 'Complete 30 days of wellness journey',
    icon: Trophy,
    targetDays: 30,
    reward: 'Transformation Champion',
    color: 'from-purple-500 to-indigo-600',
    isCompleted: false,
    progress: 0
  },
  {
    id: 'wellness-expert',
    title: 'Wellness Expert',
    description: 'Achieve all milestone goals',
    icon: Award,
    targetDays: 60,
    reward: 'Wellness Expert Title',
    color: 'from-amber-500 to-yellow-600',
    isCompleted: false,
    progress: 0
  }
];

export function HealthMilestones({ userStartDate, onMilestoneComplete }: HealthMilestonesProps) {
  const [milestones, setMilestones] = useState<Milestone[]>(healthMilestones);
  const [selectedMilestone, setSelectedMilestone] = useState<Milestone | null>(null);
  const [celebrationAnimation, setCelebrationAnimation] = useState<string | null>(null);

  // Calculate progress based on days since start
  useEffect(() => {
    const daysSinceStart = Math.floor((new Date().getTime() - userStartDate.getTime()) / (1000 * 60 * 60 * 24));
    
    setMilestones(prev => prev.map(milestone => {
      const progress = Math.min((daysSinceStart / milestone.targetDays) * 100, 100);
      const isCompleted = progress >= 100;
      
      // Trigger celebration animation for newly completed milestones
      if (isCompleted && !milestone.isCompleted) {
        setCelebrationAnimation(milestone.id);
        setTimeout(() => setCelebrationAnimation(null), 3000);
        onMilestoneComplete({ ...milestone, isCompleted: true, progress: 100 });
      }
      
      return {
        ...milestone,
        progress,
        isCompleted
      };
    }));
  }, [userStartDate, onMilestoneComplete]);

  const completedCount = milestones.filter(m => m.isCompleted).length;
  const totalCount = milestones.length;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">Your Health Milestones</h2>
        <p className="text-slate-600">Track your wellness journey and celebrate achievements</p>
        <div className="flex justify-center">
          <Badge variant="outline" className="px-4 py-2 text-lg font-semibold">
            <Trophy className="w-5 h-5 mr-2" />
            {completedCount} of {totalCount} Completed
          </Badge>
        </div>
      </div>

      {/* Milestone Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {milestones.map((milestone) => (
          <MilestoneCard 
            key={milestone.id}
            milestone={milestone}
            isSelected={selectedMilestone?.id === milestone.id}
            isCelebrating={celebrationAnimation === milestone.id}
            onClick={() => setSelectedMilestone(milestone)}
          />
        ))}
      </div>

      {/* Detailed View Modal */}
      <AnimatePresence>
        {selectedMilestone && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setSelectedMilestone(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-lg max-w-md w-full p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <MilestoneDetailView 
                milestone={selectedMilestone}
                onClose={() => setSelectedMilestone(null)}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overall Progress */}
      <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
        <CardHeader>
          <CardTitle className="flex items-center text-emerald-800">
            <TrendingUp className="w-6 h-6 mr-2" />
            Your Wellness Journey
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-emerald-700 font-medium">Overall Progress</span>
              <span className="text-emerald-800 font-bold">
                {Math.round((completedCount / totalCount) * 100)}%
              </span>
            </div>
            <div className="w-full bg-emerald-200 rounded-full h-3">
              <motion.div
                className="bg-gradient-to-r from-emerald-500 to-teal-500 h-3 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${(completedCount / totalCount) * 100}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
            <p className="text-emerald-700 text-sm">
              Keep going! Each milestone brings you closer to your wellness goals.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface MilestoneCardProps {
  milestone: Milestone;
  isSelected: boolean;
  isCelebrating: boolean;
  onClick: () => void;
}

function MilestoneCard({ milestone, isSelected, isCelebrating, onClick }: MilestoneCardProps) {
  const IconComponent = milestone.icon;

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      animate={isCelebrating ? {
        scale: [1, 1.1, 1],
        rotate: [0, 5, -5, 0]
      } : {}}
      transition={{ duration: 0.5 }}
      className={`cursor-pointer ${isSelected ? 'ring-2 ring-blue-500' : ''}`}
      onClick={onClick}
    >
      <Card className={`h-full transition-all duration-300 ${
        milestone.isCompleted 
          ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200' 
          : 'hover:shadow-lg'
      }`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className={`p-3 rounded-full bg-gradient-to-r ${milestone.color} shadow-lg`}>
              <IconComponent className="w-6 h-6 text-white" />
            </div>
            {milestone.isCompleted && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              >
                <CheckCircle className="w-6 h-6 text-green-500" />
              </motion.div>
            )}
          </div>
          <CardTitle className="text-lg">{milestone.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600 mb-4">{milestone.description}</p>
          
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Progress</span>
              <span className="font-medium">{Math.round(milestone.progress)}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2">
              <motion.div
                className={`bg-gradient-to-r ${milestone.color} h-2 rounded-full`}
                initial={{ width: 0 }}
                animate={{ width: `${milestone.progress}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              />
            </div>
          </div>

          {/* Reward Badge */}
          <div className="mt-4">
            <Badge 
              variant={milestone.isCompleted ? "default" : "secondary"} 
              className={`text-xs ${milestone.isCompleted ? 'bg-green-500' : ''}`}
            >
              <Star className="w-3 h-3 mr-1" />
              {milestone.reward}
            </Badge>
          </div>

          {/* Celebration Effect */}
          {isCelebrating && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute inset-0 flex items-center justify-center bg-white/90 rounded-lg"
            >
              <div className="text-center">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="text-4xl mb-2"
                >
                  🎉
                </motion.div>
                <p className="text-lg font-bold text-green-600">Milestone Achieved!</p>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

function MilestoneDetailView({ milestone, onClose }: { milestone: Milestone; onClose: () => void }) {
  const IconComponent = milestone.icon;

  return (
    <div className="text-center space-y-4">
      <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r ${milestone.color} shadow-lg`}>
        <IconComponent className="w-8 h-8 text-white" />
      </div>
      
      <div>
        <h3 className="text-xl font-bold text-slate-800">{milestone.title}</h3>
        <p className="text-slate-600 mt-2">{milestone.description}</p>
      </div>

      <div className="bg-slate-50 p-4 rounded-lg">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-slate-600">Target: {milestone.targetDays} days</span>
          <span className="text-sm font-medium">{Math.round(milestone.progress)}% Complete</span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-3">
          <div 
            className={`bg-gradient-to-r ${milestone.color} h-3 rounded-full transition-all duration-500`}
            style={{ width: `${milestone.progress}%` }}
          />
        </div>
      </div>

      <div className="flex items-center justify-center">
        <Badge variant={milestone.isCompleted ? "default" : "secondary"} className="px-4 py-2">
          <Star className="w-4 h-4 mr-2" />
          {milestone.reward}
        </Badge>
      </div>

      <Button onClick={onClose} className="w-full">
        Close
      </Button>
    </div>
  );
}