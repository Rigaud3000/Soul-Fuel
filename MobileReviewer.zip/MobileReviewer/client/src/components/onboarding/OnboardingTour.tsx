import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Heart, 
  Target, 
  Trophy, 
  Sparkles, 
  ArrowRight, 
  Check, 
  Star,
  Flame,
  Apple,
  Activity,
  Calendar,
  Users
} from "lucide-react";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  milestone: string;
  color: string;
  interactive?: boolean;
  action?: () => void;
}

interface OnboardingTourProps {
  onComplete: () => void;
  onSkip: () => void;
  userName?: string;
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to SOULFUEL',
    description: 'Transform your relationship with food and discover your inner wellness warrior.',
    icon: Flame,
    milestone: 'Journey Begins',
    color: 'from-emerald-500 to-teal-600',
    interactive: true
  },
  {
    id: 'health-goals',
    title: 'Set Your Health Goals',
    description: 'Define what wellness means to you. Every journey starts with intention.',
    icon: Target,
    milestone: 'Goals Defined',
    color: 'from-blue-500 to-purple-600',
    interactive: true
  },
  {
    id: 'food-tracking',
    title: 'Smart Food Analysis',
    description: 'Discover the power of AI-driven food insights. Scan, analyze, and learn.',
    icon: Apple,
    milestone: 'First Scan Ready',
    color: 'from-green-500 to-emerald-600',
    interactive: true
  },
  {
    id: 'mood-wellness',
    title: 'Emotional Wellness',
    description: 'Track your mood and emotions. Your mental health is just as important.',
    icon: Heart,
    milestone: 'Mood Tracking Set',
    color: 'from-pink-500 to-rose-600',
    interactive: true
  },
  {
    id: 'ai-companion',
    title: 'Your AI Wellness Coach',
    description: 'Meet your personal coach. Get support whenever you need it.',
    icon: Sparkles,
    milestone: 'Coach Connected',
    color: 'from-purple-500 to-indigo-600',
    interactive: true
  },
  {
    id: 'community',
    title: 'Join the Community',
    description: 'Connect with others on similar journeys. Share experiences and celebrate wins.',
    icon: Users,
    milestone: 'Community Joined',
    color: 'from-orange-500 to-red-600',
    interactive: true
  },
  {
    id: 'ready',
    title: 'You\'re All Set!',
    description: 'Your wellness journey starts now. Remember: progress, not perfection.',
    icon: Trophy,
    milestone: 'Wellness Warrior',
    color: 'from-yellow-500 to-orange-600',
    interactive: false
  }
];

export function OnboardingTour({ onComplete, onSkip, userName = "Wellness Warrior" }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [isAnimating, setIsAnimating] = useState(false);

  const progress = ((currentStep + 1) / onboardingSteps.length) * 100;
  const step = onboardingSteps[currentStep];

  const handleNext = () => {
    if (isAnimating) return;
    
    setIsAnimating(true);
    setCompletedSteps(prev => [...prev, step.id]);
    
    setTimeout(() => {
      if (currentStep < onboardingSteps.length - 1) {
        setCurrentStep(currentStep + 1);
      } else {
        onComplete();
      }
      setIsAnimating(false);
    }, 500);
  };

  const handleSkip = () => {
    onSkip();
  };

  const IconComponent = step.icon;

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-white/20 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <Card className="w-full max-w-2xl mx-auto relative bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
        <CardHeader className="text-center pb-4">
          <div className="flex items-center justify-between mb-4">
            <Badge variant="secondary" className="text-xs">
              Step {currentStep + 1} of {onboardingSteps.length}
            </Badge>
            <Button variant="ghost" size="sm" onClick={handleSkip} className="text-slate-500">
              Skip Tour
            </Button>
          </div>
          
          <Progress value={progress} className="w-full h-2 mb-6" />
          
          <motion.div
            key={step.id}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br ${step.color} mb-4 shadow-lg`}>
              <IconComponent className="w-10 h-10 text-white" />
            </div>
            
            <CardTitle className="text-2xl font-bold text-slate-800 mb-2">
              {step.title}
            </CardTitle>
            <CardDescription className="text-slate-600 text-base">
              {step.description}
            </CardDescription>
          </motion.div>
        </CardHeader>

        <CardContent className="pt-0">
          {/* Milestone Badge */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex justify-center mb-6"
          >
            <Badge 
              variant="outline" 
              className={`px-4 py-2 text-sm font-medium bg-gradient-to-r ${step.color} text-white border-0`}
            >
              <Star className="w-4 h-4 mr-2" />
              {step.milestone}
            </Badge>
          </motion.div>

          {/* Interactive Elements */}
          <AnimatePresence mode="wait">
            {step.interactive && (
              <motion.div
                key={step.id}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -20, opacity: 0 }}
                transition={{ delay: 0.5 }}
                className="mb-6"
              >
                <InteractiveStepContent step={step} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Milestone Progress */}
          <div className="flex justify-center mb-6">
            <div className="flex space-x-2">
              {onboardingSteps.map((s, index) => (
                <motion.div
                  key={s.id}
                  className={`w-3 h-3 rounded-full ${
                    index <= currentStep 
                      ? 'bg-emerald-500' 
                      : completedSteps.includes(s.id)
                      ? 'bg-emerald-400'
                      : 'bg-slate-300'
                  }`}
                  initial={{ scale: 0.8 }}
                  animate={{ 
                    scale: index === currentStep ? 1.2 : 1,
                    backgroundColor: completedSteps.includes(s.id) ? '#10b981' : undefined
                  }}
                  transition={{ duration: 0.3 }}
                />
              ))}
            </div>
          </div>

          {/* Action Button */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="flex justify-center"
          >
            <Button
              onClick={handleNext}
              disabled={isAnimating}
              className={`px-8 py-3 text-lg font-semibold bg-gradient-to-r ${step.color} hover:shadow-lg transition-all duration-300 transform hover:scale-105`}
            >
              {currentStep === onboardingSteps.length - 1 ? (
                <>
                  <Trophy className="w-5 h-5 mr-2" />
                  Start Your Journey
                </>
              ) : (
                <>
                  Continue
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
          </motion.div>

          {/* Completion Message */}
          {currentStep === onboardingSteps.length - 1 && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.9 }}
              className="text-center mt-6 p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg border border-emerald-200"
            >
              <p className="text-emerald-800 font-medium">
                🎉 Welcome to your wellness transformation, {userName}!
              </p>
              <p className="text-emerald-700 text-sm mt-1">
                You now have access to all SOULFUEL features and 4 free AI services per week.
              </p>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Interactive content for each step
function InteractiveStepContent({ step }: { step: OnboardingStep }) {
  const [interactionComplete, setInteractionComplete] = useState(false);

  const handleInteraction = () => {
    setInteractionComplete(true);
  };

  switch (step.id) {
    case 'welcome':
      return (
        <div className="text-center space-y-4">
          <motion.div
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              repeatType: "reverse"
            }}
            className="text-6xl"
          >
            🔥
          </motion.div>
          <p className="text-slate-700">
            Your personalized wellness companion is ready to guide you every step of the way.
          </p>
        </div>
      );

    case 'health-goals':
      return (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {['Weight Management', 'Energy Boost', 'Better Sleep', 'Stress Relief'].map((goal) => (
              <motion.div
                key={goal}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200 cursor-pointer text-center text-sm font-medium text-blue-800"
                onClick={handleInteraction}
              >
                {goal}
              </motion.div>
            ))}
          </div>
        </div>
      );

    case 'food-tracking':
      return (
        <div className="text-center space-y-4">
          <motion.div
            animate={{ 
              y: [0, -10, 0],
              rotateY: [0, 180, 360]
            }}
            transition={{ 
              duration: 3,
              repeat: Infinity
            }}
            className="text-4xl"
          >
            📱
          </motion.div>
          <p className="text-slate-700">
            Snap a photo, scan a barcode, or describe your meal - AI will analyze it instantly.
          </p>
        </div>
      );

    case 'mood-wellness':
      return (
        <div className="text-center space-y-4">
          <div className="flex justify-center space-x-4">
            {['😊', '😐', '😔', '😴', '😤'].map((emoji, index) => (
              <motion.div
                key={emoji}
                animate={{ 
                  scale: [1, 1.2, 1],
                  y: [0, -5, 0]
                }}
                transition={{ 
                  duration: 1.5,
                  repeat: Infinity,
                  delay: index * 0.2
                }}
                className="text-3xl cursor-pointer"
                onClick={handleInteraction}
              >
                {emoji}
              </motion.div>
            ))}
          </div>
          <p className="text-slate-700">
            Track your emotional patterns and discover what affects your wellbeing.
          </p>
        </div>
      );

    case 'ai-companion':
      return (
        <div className="text-center space-y-4">
          <motion.div
            animate={{ 
              opacity: [0.7, 1, 0.7],
              scale: [0.9, 1.1, 0.9]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity
            }}
            className="text-4xl"
          >
            🤖
          </motion.div>
          <p className="text-slate-700">
            Your AI coach is available 24/7 for support, motivation, and personalized guidance.
          </p>
        </div>
      );

    case 'community':
      return (
        <div className="text-center space-y-4">
          <motion.div
            animate={{ 
              rotate: [0, 360]
            }}
            transition={{ 
              duration: 4,
              repeat: Infinity,
              ease: "linear"
            }}
            className="text-4xl"
          >
            🌟
          </motion.div>
          <p className="text-slate-700">
            Join thousands of wellness warriors sharing their journeys and celebrating victories.
          </p>
        </div>
      );

    default:
      return null;
  }
}