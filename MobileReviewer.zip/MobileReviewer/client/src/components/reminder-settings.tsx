import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Bell, 
  Heart, 
  Droplets, 
  Dumbbell, 
  Moon, 
  Pill, 
  Sparkles,
  Clock,
  Calendar,
  TestTube,
  Play,
  Settings
} from 'lucide-react';
import { reminderNotificationManager, type ReminderSettings } from '@/lib/reminder-notifications';
import { useToast } from '@/hooks/use-toast';

export function ReminderSettingsComponent() {
  const [settings, setSettings] = useState<ReminderSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = () => {
    try {
      const currentSettings = reminderNotificationManager.getSettings();
      setSettings(currentSettings);
    } catch (error) {
      console.error('Error loading reminder settings:', error);
      toast({
        title: "Error",
        description: "Failed to load reminder settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = (updates: Partial<ReminderSettings>) => {
    if (!settings) return;
    
    const newSettings = { ...settings, ...updates };
    setSettings(newSettings);
    reminderNotificationManager.saveSettings(updates);
    
    toast({
      title: "Settings updated",
      description: "Your reminder preferences have been saved",
    });
  };

  const handleTestNotification = async () => {
    try {
      await reminderNotificationManager.testNotification();
      toast({
        title: "Test notification sent",
        description: "Check if you received the notification",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send test notification",
        variant: "destructive"
      });
    }
  };

  const handleQuickReminder = async (type: string) => {
    try {
      await reminderNotificationManager.sendImmediateReminder(type);
      toast({
        title: "Reminder sent",
        description: "You should receive the notification shortly",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send reminder",
        variant: "destructive"
      });
    }
  };

  const addTime = (category: keyof ReminderSettings, field: string) => {
    if (!settings) return;
    
    const currentTimes = (settings[category] as any)[field] || [];
    const newTime = "12:00";
    
    updateSettings({
      [category]: {
        ...(settings[category] as any),
        [field]: [...currentTimes, newTime]
      }
    });
  };

  const updateTime = (category: keyof ReminderSettings, field: string, index: number, newTime: string) => {
    if (!settings) return;
    
    const currentTimes = [...((settings[category] as any)[field] || [])];
    currentTimes[index] = newTime;
    
    updateSettings({
      [category]: {
        ...(settings[category] as any),
        [field]: currentTimes
      }
    });
  };

  const removeTime = (category: keyof ReminderSettings, field: string, index: number) => {
    if (!settings) return;
    
    const currentTimes = [...((settings[category] as any)[field] || [])];
    currentTimes.splice(index, 1);
    
    updateSettings({
      [category]: {
        ...(settings[category] as any),
        [field]: currentTimes
      }
    });
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!settings) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">Failed to load reminder settings</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Master Control */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-600" />
            Reminder Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base font-medium">Enable all reminders</Label>
              <p className="text-sm text-muted-foreground">Master switch for all notification reminders</p>
            </div>
            <Switch
              checked={settings.enabled}
              onCheckedChange={(enabled) => updateSettings({ enabled })}
            />
          </div>
          
          <Separator />
          
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={handleTestNotification}>
              <TestTube className="h-4 w-4 mr-2" />
              Test Notification
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleQuickReminder('mood')}>
              <Heart className="h-4 w-4 mr-2" />
              Send Mood Reminder
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleQuickReminder('water')}>
              <Droplets className="h-4 w-4 mr-2" />
              Send Water Reminder
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Reminder Categories */}
      <Tabs defaultValue="mood" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
          <TabsTrigger value="mood">
            <Heart className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="sugar">
            <Settings className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="hydration">
            <Droplets className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="exercise">
            <Dumbbell className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="bedtime">
            <Moon className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="medication">
            <Pill className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="motivation">
            <Sparkles className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="craving">
            <Bell className="h-4 w-4" />
          </TabsTrigger>
        </TabsList>

        {/* Mood Check-in */}
        <TabsContent value="mood">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-pink-600" />
                Mood Check-in Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable mood reminders</Label>
                <Switch
                  checked={settings.moodCheckIn.enabled}
                  onCheckedChange={(enabled) => updateSettings({
                    moodCheckIn: { ...settings.moodCheckIn, enabled }
                  })}
                />
              </div>

              {settings.moodCheckIn.enabled && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium">Reminder Times</Label>
                    <div className="space-y-2 mt-2">
                      {settings.moodCheckIn.times.map((time, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Input
                            type="time"
                            value={time}
                            onChange={(e) => updateTime('moodCheckIn', 'times', index, e.target.value)}
                            className="w-32"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeTime('moodCheckIn', 'times', index)}
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => addTime('moodCheckIn', 'times')}
                      >
                        Add Time
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Frequency</Label>
                    <div className="flex gap-2 mt-2">
                      {['daily', 'weekdays', 'custom'].map((freq) => (
                        <Badge
                          key={freq}
                          variant={settings.moodCheckIn.frequency === freq ? 'default' : 'outline'}
                          className="cursor-pointer capitalize"
                          onClick={() => updateSettings({
                            moodCheckIn: { ...settings.moodCheckIn, frequency: freq as any }
                          })}
                        >
                          {freq}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sugar Tracking */}
        <TabsContent value="sugar">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-orange-600" />
                Sugar Tracking Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable sugar tracking reminders</Label>
                <Switch
                  checked={settings.sugarTracking.enabled}
                  onCheckedChange={(enabled) => updateSettings({
                    sugarTracking: { ...settings.sugarTracking, enabled }
                  })}
                />
              </div>

              {settings.sugarTracking.enabled && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium">Meal Times</Label>
                    <div className="space-y-2 mt-2">
                      {settings.sugarTracking.mealTimes.map((time, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Input
                            type="time"
                            value={time}
                            onChange={(e) => updateTime('sugarTracking', 'mealTimes', index, e.target.value)}
                            className="w-32"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeTime('sugarTracking', 'mealTimes', index)}
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => addTime('sugarTracking', 'mealTimes')}
                      >
                        Add Meal Time
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={settings.sugarTracking.beforeMeals}
                        onCheckedChange={(beforeMeals) => updateSettings({
                          sugarTracking: { ...settings.sugarTracking, beforeMeals }
                        })}
                      />
                      <Label className="text-sm">Before meals</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={settings.sugarTracking.afterMeals}
                        onCheckedChange={(afterMeals) => updateSettings({
                          sugarTracking: { ...settings.sugarTracking, afterMeals }
                        })}
                      />
                      <Label className="text-sm">After meals</Label>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Reminder offset (minutes)</Label>
                    <Input
                      type="number"
                      min="5"
                      max="60"
                      value={settings.sugarTracking.reminderOffset}
                      onChange={(e) => updateSettings({
                        sugarTracking: { 
                          ...settings.sugarTracking, 
                          reminderOffset: parseInt(e.target.value) || 15 
                        }
                      })}
                      className="w-24 mt-1"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hydration */}
        <TabsContent value="hydration">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Droplets className="h-5 w-5 text-blue-600" />
                Hydration Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable hydration reminders</Label>
                <Switch
                  checked={settings.hydration.enabled}
                  onCheckedChange={(enabled) => updateSettings({
                    hydration: { ...settings.hydration, enabled }
                  })}
                />
              </div>

              {settings.hydration.enabled && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Start time</Label>
                      <Input
                        type="time"
                        value={settings.hydration.startTime}
                        onChange={(e) => updateSettings({
                          hydration: { ...settings.hydration, startTime: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium">End time</Label>
                      <Input
                        type="time"
                        value={settings.hydration.endTime}
                        onChange={(e) => updateSettings({
                          hydration: { ...settings.hydration, endTime: e.target.value }
                        })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Interval (hours)</Label>
                      <Input
                        type="number"
                        min="1"
                        max="8"
                        value={settings.hydration.interval}
                        onChange={(e) => updateSettings({
                          hydration: { 
                            ...settings.hydration, 
                            interval: parseInt(e.target.value) || 2 
                          }
                        })}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Daily goal (glasses)</Label>
                      <Input
                        type="number"
                        min="4"
                        max="16"
                        value={settings.hydration.dailyGoal}
                        onChange={(e) => updateSettings({
                          hydration: { 
                            ...settings.hydration, 
                            dailyGoal: parseInt(e.target.value) || 8 
                          }
                        })}
                      />
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Exercise */}
        <TabsContent value="exercise">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dumbbell className="h-5 w-5 text-green-600" />
                Exercise Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable exercise reminders</Label>
                <Switch
                  checked={settings.exercise.enabled}
                  onCheckedChange={(enabled) => updateSettings({
                    exercise: { ...settings.exercise, enabled }
                  })}
                />
              </div>

              {settings.exercise.enabled && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Reminder time</Label>
                      <Input
                        type="time"
                        value={settings.exercise.reminderTime}
                        onChange={(e) => updateSettings({
                          exercise: { ...settings.exercise, reminderTime: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Duration (minutes)</Label>
                      <Input
                        type="number"
                        min="10"
                        max="120"
                        value={settings.exercise.duration}
                        onChange={(e) => updateSettings({
                          exercise: { 
                            ...settings.exercise, 
                            duration: parseInt(e.target.value) || 30 
                          }
                        })}
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Frequency</Label>
                    <div className="flex gap-2 mt-2">
                      {['daily', 'weekdays', 'custom'].map((freq) => (
                        <Badge
                          key={freq}
                          variant={settings.exercise.frequency === freq ? 'default' : 'outline'}
                          className="cursor-pointer capitalize"
                          onClick={() => updateSettings({
                            exercise: { ...settings.exercise, frequency: freq as any }
                          })}
                        >
                          {freq}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bedtime */}
        <TabsContent value="bedtime">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Moon className="h-5 w-5 text-indigo-600" />
                Bedtime Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable bedtime reminders</Label>
                <Switch
                  checked={settings.bedtime.enabled}
                  onCheckedChange={(enabled) => updateSettings({
                    bedtime: { ...settings.bedtime, enabled }
                  })}
                />
              </div>

              {settings.bedtime.enabled && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Bedtime</Label>
                      <Input
                        type="time"
                        value={settings.bedtime.reminderTime}
                        onChange={(e) => updateSettings({
                          bedtime: { ...settings.bedtime, reminderTime: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Wind-down time (minutes)</Label>
                      <Input
                        type="number"
                        min="15"
                        max="120"
                        value={settings.bedtime.windDownDuration}
                        onChange={(e) => updateSettings({
                          bedtime: { 
                            ...settings.bedtime, 
                            windDownDuration: parseInt(e.target.value) || 30 
                          }
                        })}
                      />
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Motivation */}
        <TabsContent value="motivation">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-yellow-600" />
                Motivational Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable motivation reminders</Label>
                <Switch
                  checked={settings.motivation.enabled}
                  onCheckedChange={(enabled) => updateSettings({
                    motivation: { ...settings.motivation, enabled }
                  })}
                />
              </div>

              {settings.motivation.enabled && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium">Frequency</Label>
                    <div className="flex gap-2 mt-2">
                      {['daily', 'twice_daily', 'hourly'].map((freq) => (
                        <Badge
                          key={freq}
                          variant={settings.motivation.frequency === freq ? 'default' : 'outline'}
                          className="cursor-pointer capitalize"
                          onClick={() => updateSettings({
                            motivation: { ...settings.motivation, frequency: freq as any }
                          })}
                        >
                          {freq.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Preferred Times</Label>
                    <div className="space-y-2 mt-2">
                      {settings.motivation.preferredTimes.map((time, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Input
                            type="time"
                            value={time}
                            onChange={(e) => updateTime('motivation', 'preferredTimes', index, e.target.value)}
                            className="w-32"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeTime('motivation', 'preferredTimes', index)}
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => addTime('motivation', 'preferredTimes')}
                      >
                        Add Time
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={settings.motivation.personalizedMessages}
                      onCheckedChange={(personalizedMessages) => updateSettings({
                        motivation: { ...settings.motivation, personalizedMessages }
                      })}
                    />
                    <Label className="text-sm">Personalized messages</Label>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Craving Support */}
        <TabsContent value="craving">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-red-600" />
                Craving Support Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable craving support reminders</Label>
                <Switch
                  checked={settings.cravingSupport.enabled}
                  onCheckedChange={(enabled) => updateSettings({
                    cravingSupport: { ...settings.cravingSupport, enabled }
                  })}
                />
              </div>

              {settings.cravingSupport.enabled && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium">High-risk Times</Label>
                    <div className="space-y-2 mt-2">
                      {settings.cravingSupport.riskTimes.map((time, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Input
                            type="time"
                            value={time}
                            onChange={(e) => updateTime('cravingSupport', 'riskTimes', index, e.target.value)}
                            className="w-32"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeTime('cravingSupport', 'riskTimes', index)}
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => addTime('cravingSupport', 'riskTimes')}
                      >
                        Add Risk Time
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={settings.cravingSupport.predictiveReminders}
                      onCheckedChange={(predictiveReminders) => updateSettings({
                        cravingSupport: { ...settings.cravingSupport, predictiveReminders }
                      })}
                    />
                    <Label className="text-sm">Predictive reminders (AI-based)</Label>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}