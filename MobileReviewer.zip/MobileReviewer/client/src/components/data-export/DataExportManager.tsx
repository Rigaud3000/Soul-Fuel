import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Download, 
  Shield, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  ExternalLink,
  Database,
  Calendar,
  Users
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface DataSummary {
  user: {
    id: number;
    username: string;
    email: string;
    subscriptionTier: string;
    createdAt: string;
    weeklyServicesUsed: number;
    lastServicesReset: string;
  };
  dataCounts: {
    sugarEntries: number;
    moodEntries: number;
    cravingEntries: number;
    chatMessages: number;
    foodAnalyses: number;
    total: number;
  };
  lastActivity: {
    estimated: string;
  };
}

interface ExportResult {
  success: boolean;
  exportId: string;
  downloadUrl: string;
  totalDataPoints: number;
  validUntil: string;
  message: string;
}

export function DataExportManager() {
  const [exportStatus, setExportStatus] = useState<'idle' | 'exporting' | 'completed' | 'error'>('idle');
  const [exportResult, setExportResult] = useState<ExportResult | null>(null);
  const { toast } = useToast();

  // Fetch user data summary
  const { data: dataSummary, isLoading: summaryLoading } = useQuery<DataSummary>({
    queryKey: ['/api/user-data-summary'],
    retry: 1
  });

  // Export user data mutation
  const exportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/export-user-data');
      return response.json();
    },
    onMutate: () => {
      setExportStatus('exporting');
    },
    onSuccess: (data: ExportResult) => {
      setExportResult(data);
      setExportStatus('completed');
      toast({
        title: "Data Export Complete",
        description: "Your data has been exported to a secure Google Sheet",
      });
    },
    onError: (error: any) => {
      setExportStatus('error');
      toast({
        title: "Export Failed",
        description: error.message || "Failed to export your data",
        variant: "destructive",
      });
    }
  });

  const handleExportData = () => {
    exportMutation.mutate();
  };

  const getExportProgress = () => {
    switch (exportStatus) {
      case 'exporting': return 75;
      case 'completed': return 100;
      case 'error': return 0;
      default: return 0;
    }
  };

  if (summaryLoading) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-8">
          <div className="flex items-center justify-center">
            <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
        <CardHeader>
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-500 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-emerald-800">Secure Data Export</CardTitle>
              <CardDescription className="text-emerald-700">
                Download all your SOULFUEL data in a secure, readable format
              </CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Data Summary */}
      {dataSummary && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="w-5 h-5 mr-2" />
              Your Data Overview
            </CardTitle>
            <CardDescription>
              Review what data will be included in your export
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <DataMetricCard
                title="Account Info"
                value="1 Profile"
                description={`${dataSummary.user.subscriptionTier} member since ${new Date(dataSummary.user.createdAt).toLocaleDateString()}`}
                icon={Users}
                color="blue"
              />
              <DataMetricCard
                title="Health Tracking"
                value={`${dataSummary.dataCounts.sugarEntries + dataSummary.dataCounts.moodEntries + dataSummary.dataCounts.cravingEntries} entries`}
                description="Sugar, mood, and craving logs"
                icon={Calendar}
                color="green"
              />
              <DataMetricCard
                title="AI Interactions"
                value={`${dataSummary.dataCounts.chatMessages} conversations`}
                description="Coaching sessions and support"
                icon={FileText}
                color="purple"
              />
              <DataMetricCard
                title="Food Analysis"
                value={`${dataSummary.dataCounts.foodAnalyses} scans`}
                description="Nutritional insights and recommendations"
                icon={Download}
                color="orange"
              />
              <DataMetricCard
                title="Total Data Points"
                value={dataSummary.dataCounts.total.toLocaleString()}
                description="All tracked information"
                icon={Database}
                color="teal"
              />
              <DataMetricCard
                title="Services Used"
                value={`${dataSummary.user.weeklyServicesUsed}/4`}
                description="Current week usage"
                icon={Clock}
                color="rose"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Export Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Download className="w-5 h-5 mr-2" />
            Export Your Data
          </CardTitle>
          <CardDescription>
            Generate a comprehensive export of all your SOULFUEL data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Export Status */}
          <AnimatePresence mode="wait">
            {exportStatus !== 'idle' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                <Progress value={getExportProgress()} className="w-full" />
                
                {exportStatus === 'exporting' && (
                  <Alert>
                    <Clock className="h-4 w-4" />
                    <AlertDescription>
                      Generating your data export... This may take a few moments.
                    </AlertDescription>
                  </Alert>
                )}

                {exportStatus === 'completed' && exportResult && (
                  <Alert className="border-green-200 bg-green-50">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">
                      <div className="space-y-2">
                        <p className="font-medium">{exportResult.message}</p>
                        <div className="flex items-center space-x-4 text-sm">
                          <span>Export ID: {exportResult.exportId}</span>
                          <span>Data Points: {exportResult.totalDataPoints.toLocaleString()}</span>
                          <span>Valid Until: {new Date(exportResult.validUntil).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                {exportStatus === 'error' && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Export failed. Please try again or contact support if the issue persists.
                    </AlertDescription>
                  </Alert>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Export Actions */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={handleExportData}
              disabled={exportMutation.isPending || exportStatus === 'exporting'}
              className="flex-1 bg-emerald-500 hover:bg-emerald-600"
            >
              {exportStatus === 'exporting' ? (
                <>
                  <div className="animate-spin w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                  Generating Export...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Export All My Data
                </>
              )}
            </Button>

            {exportResult && (
              <Button
                variant="outline"
                asChild
                className="flex-1"
              >
                <a 
                  href={exportResult.downloadUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open Google Sheet
                </a>
              </Button>
            )}
          </div>

          {/* Information */}
          <div className="bg-slate-50 p-4 rounded-lg space-y-3">
            <h4 className="font-medium text-slate-800">What's Included:</h4>
            <ul className="text-sm text-slate-600 space-y-1">
              <li>• Complete user profile and account information</li>
              <li>• All sugar intake, mood, and craving tracking data</li>
              <li>• AI coaching conversations and recommendations</li>
              <li>• Food analysis results and nutritional insights</li>
              <li>• Usage statistics and milestone progress</li>
              <li>• Export summary with data verification</li>
            </ul>
            <div className="mt-3 p-3 bg-blue-50 rounded border border-blue-200">
              <p className="text-xs text-blue-800">
                <Shield className="w-3 h-3 inline mr-1" />
                Your data is exported to a secure Google Sheet that only you can access. 
                The link expires after 30 days for your security.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Privacy Information */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-blue-800 flex items-center">
            <Shield className="w-5 h-5 mr-2" />
            Privacy & Security
          </CardTitle>
        </CardHeader>
        <CardContent className="text-blue-700 space-y-3">
          <p className="text-sm">
            This data export complies with GDPR and CCPA regulations. Your exported data includes 
            everything we store about you and your SOULFUEL usage.
          </p>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="border-blue-300 text-blue-700">
              GDPR Compliant
            </Badge>
            <Badge variant="outline" className="border-blue-300 text-blue-700">
              CCPA Compliant
            </Badge>
            <Badge variant="outline" className="border-blue-300 text-blue-700">
              30-Day Access
            </Badge>
            <Badge variant="outline" className="border-blue-300 text-blue-700">
              Secure Export
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface DataMetricCardProps {
  title: string;
  value: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
}

function DataMetricCard({ title, value, description, icon: Icon, color }: DataMetricCardProps) {
  const colorClasses = {
    blue: 'from-blue-500 to-blue-600',
    green: 'from-green-500 to-green-600',
    purple: 'from-purple-500 to-purple-600',
    orange: 'from-orange-500 to-orange-600',
    teal: 'from-teal-500 to-teal-600',
    rose: 'from-rose-500 to-rose-600'
  };

  return (
    <Card className="h-full">
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <div className={`p-2 rounded-lg bg-gradient-to-r ${colorClasses[color as keyof typeof colorClasses]} shadow-sm`}>
            <Icon className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-700">{title}</p>
            <p className="text-lg font-bold text-slate-900">{value}</p>
            <p className="text-xs text-slate-500">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}