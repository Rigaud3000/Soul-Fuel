import React, { useState, useEffect } from 'react';
import { Flame, Calendar, Target, Award, Bell, X, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface HabitStreak {
  id: string;
  habitName: string;
  currentStreak: number;
  longestStreak: number;
  lastActivityDate: Date;
  isActive: boolean;
  notificationsEnabled: boolean;
  reminderTime?: string;
  streakGoal?: number;
}

interface StreakNotification {
  id: string;
  type: 'milestone' | 'reminder' | 'break' | 'encouragement';
  title: string;
  message: string;
  habitId: string;
  isRead: boolean;
  createdAt: Date;
  priority: 'low' | 'medium' | 'high';
}

export function HabitStreakNotifications() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [notifications, setNotifications] = useState<StreakNotification[]>([]);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const { data: streaks = [] } = useQuery({
    queryKey: ['/api/habit-streaks', user?.uid],
    enabled: !!user?.uid,
  });

  const { data: recentNotifications = [] } = useQuery({
    queryKey: ['/api/streak-notifications', user?.uid],
    enabled: !!user?.uid,
  });

  useEffect(() => {
    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    // Check for streak milestones and generate notifications
    checkStreakMilestones();
    
    // Set up daily streak check
    const dailyCheck = setInterval(checkDailyStreaks, 24 * 60 * 60 * 1000);
    
    return () => clearInterval(dailyCheck);
  }, [streaks]);

  const updateStreakMutation = useMutation({
    mutationFn: async ({ habitId, action }: { habitId: string; action: 'increment' | 'reset' }) => {
      return apiRequest("POST", `/api/habit-streaks/${habitId}/${action}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/habit-streaks'] });
    },
  });

  const markNotificationReadMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      return apiRequest("PATCH", `/api/streak-notifications/${notificationId}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/streak-notifications'] });
    },
  });

  const checkStreakMilestones = () => {
    streaks.forEach((streak: HabitStreak) => {
      const milestones = [7, 14, 30, 60, 100, 365]; // Common milestone days
      
      if (milestones.includes(streak.currentStreak)) {
        showStreakMilestoneNotification(streak);
      }

      // Check if streak is at risk (no activity in 18+ hours)
      const lastActivity = new Date(streak.lastActivityDate);
      const hoursAgo = (Date.now() - lastActivity.getTime()) / (1000 * 60 * 60);
      
      if (hoursAgo >= 18 && hoursAgo < 24 && streak.notificationsEnabled) {
        showStreakReminderNotification(streak);
      }

      // Check if streak was broken
      if (hoursAgo >= 24 && streak.currentStreak > 0) {
        showStreakBreakNotification(streak);
      }
    });
  };

  const checkDailyStreaks = () => {
    const now = new Date();
    const today = now.toDateString();

    streaks.forEach((streak: HabitStreak) => {
      const lastActivity = new Date(streak.lastActivityDate);
      const wasYesterday = lastActivity.toDateString() === new Date(now.getTime() - 24 * 60 * 60 * 1000).toDateString();
      const wasToday = lastActivity.toDateString() === today;

      if (!wasToday && !wasYesterday && streak.currentStreak > 0) {
        // Streak broken
        updateStreakMutation.mutate({ habitId: streak.id, action: 'reset' });
        showStreakBreakNotification(streak);
      }
    });
  };

  const showStreakMilestoneNotification = (streak: HabitStreak) => {
    const notification: StreakNotification = {
      id: `milestone_${streak.id}_${Date.now()}`,
      type: 'milestone',
      title: `🔥 ${streak.currentStreak} Day Streak!`,
      message: `Amazing! You've maintained your ${streak.habitName} habit for ${streak.currentStreak} days straight!`,
      habitId: streak.id,
      isRead: false,
      createdAt: new Date(),
      priority: 'high'
    };

    addNotification(notification);
    showBrowserNotification(notification);
  };

  const showStreakReminderNotification = (streak: HabitStreak) => {
    const notification: StreakNotification = {
      id: `reminder_${streak.id}_${Date.now()}`,
      type: 'reminder',
      title: `⏰ Don't Break Your Streak!`,
      message: `Your ${streak.currentStreak}-day ${streak.habitName} streak is waiting for you. Complete it today!`,
      habitId: streak.id,
      isRead: false,
      createdAt: new Date(),
      priority: 'medium'
    };

    addNotification(notification);
    showBrowserNotification(notification);
  };

  const showStreakBreakNotification = (streak: HabitStreak) => {
    const notification: StreakNotification = {
      id: `break_${streak.id}_${Date.now()}`,
      type: 'break',
      title: `💔 Streak Ended`,
      message: `Your ${streak.currentStreak}-day ${streak.habitName} streak has ended. But don't worry - start fresh today!`,
      habitId: streak.id,
      isRead: false,
      createdAt: new Date(),
      priority: 'low'
    };

    addNotification(notification);
  };

  const addNotification = (notification: StreakNotification) => {
    setNotifications(prev => [notification, ...prev.slice(0, 19)]); // Keep last 20
  };

  const showBrowserNotification = (notification: StreakNotification) => {
    if (!notificationsEnabled || Notification.permission !== 'granted') return;

    new Notification(notification.title, {
      body: notification.message,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      tag: notification.habitId,
    });
  };

  const getStreakEmoji = (days: number) => {
    if (days >= 365) return '🏆';
    if (days >= 100) return '💎';
    if (days >= 60) return '🌟';
    if (days >= 30) return '🔥';
    if (days >= 14) return '⚡';
    if (days >= 7) return '💪';
    return '🌱';
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'milestone': return <Award className="w-4 h-4 text-yellow-500" />;
      case 'reminder': return <Bell className="w-4 h-4 text-blue-500" />;
      case 'break': return <TrendingUp className="w-4 h-4 text-red-500" />;
      case 'encouragement': return <Target className="w-4 h-4 text-green-500" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="space-y-6">
      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Streak Notifications
            {unreadCount > 0 && (
              <Badge variant="destructive">{unreadCount}</Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="notifications-toggle">Enable Notifications</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get reminders and celebrate milestones
              </p>
            </div>
            <Switch
              id="notifications-toggle"
              checked={notificationsEnabled}
              onCheckedChange={setNotificationsEnabled}
            />
          </div>
        </CardContent>
      </Card>

      {/* Active Streaks */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Flame className="w-5 h-5" />
            Active Streaks
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {streaks.map((streak: HabitStreak) => (
              <div key={streak.id} className="p-4 border rounded-lg bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950 dark:to-red-950">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">{streak.habitName}</h4>
                  <span className="text-2xl">{getStreakEmoji(streak.currentStreak)}</span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Current Streak</span>
                    <span className="font-bold text-orange-600 dark:text-orange-400">
                      {streak.currentStreak} days
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                    <span>Best Streak</span>
                    <span>{streak.longestStreak} days</span>
                  </div>

                  {streak.streakGoal && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Goal Progress</span>
                        <span>{streak.currentStreak}/{streak.streakGoal} days</span>
                      </div>
                      <Progress 
                        value={(streak.currentStreak / streak.streakGoal) * 100} 
                        className="h-2"
                      />
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      onClick={() => updateStreakMutation.mutate({ habitId: streak.id, action: 'increment' })}
                      className="flex-1"
                    >
                      <Flame className="w-3 h-3 mr-1" />
                      Continue Streak
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Notifications */}
      {notifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Notifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {notifications.slice(0, 10).map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 border rounded-lg flex items-start gap-3 ${
                    !notification.isRead ? 'bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800' : ''
                  }`}
                >
                  {getNotificationIcon(notification.type)}
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <h4 className="font-medium text-sm">{notification.title}</h4>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => markNotificationReadMutation.mutate(notification.id)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {notification.message}
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      {new Date(notification.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Streak Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Streak Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-orange-100 to-red-100 dark:from-orange-900 dark:to-red-900 rounded-lg">
              <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                {streaks.reduce((sum: number, s: HabitStreak) => sum + s.currentStreak, 0)}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Total Active Days</div>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-yellow-100 to-orange-100 dark:from-yellow-900 dark:to-orange-900 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                {Math.max(...streaks.map((s: HabitStreak) => s.longestStreak), 0)}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Longest Streak</div>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900 dark:to-emerald-900 rounded-lg">
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {streaks.filter((s: HabitStreak) => s.isActive).length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Active Habits</div>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-blue-100 to-indigo-100 dark:from-blue-900 dark:to-indigo-900 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {streaks.filter((s: HabitStreak) => s.currentStreak >= 7).length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Week+ Streaks</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}