import { useState, useRef, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX,
  Heart, 
  Brain,
  Play,
  Pause,
  RotateCcw,
  Sparkles
} from "lucide-react";

interface VoiceMessage {
  id: string;
  transcript: string;
  aiResponse: string;
  audioUrl?: string;
  timestamp: Date;
  mood?: string;
}

export function VoiceSoulTalk() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isRecording, setIsRecording] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [voiceMessages, setVoiceMessages] = useState<VoiceMessage[]>([]);
  const [companionVoice, setCompanionVoice] = useState("nurturing");
  const [companionName, setCompanionName] = useState("Luna");
  const [speechEnabled, setSpeechEnabled] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recognitionRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setTranscript(finalTranscript);
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast({
          title: "Voice Recognition Error",
          description: "There was an issue with voice recognition. Please try again.",
          variant: "destructive"
        });
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    // Initialize speech synthesis
    if ('speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, [toast]);

  // AI Soul Talk mutation
  const soulTalkMutation = useMutation({
    mutationFn: async ({ message, voice, name }: { message: string; voice: string; name: string }) => {
      const response = await apiRequest('POST', '/api/soul-talk', {
        message,
        companionVoice: voice,
        companionName: name,
        isVoiceInput: true
      });
      return response.json();
    },
    onSuccess: (data) => {
      setAiResponse(data.response);
      const newMessage: VoiceMessage = {
        id: Date.now().toString(),
        transcript,
        aiResponse: data.response,
        timestamp: new Date(),
        mood: data.detectedMood
      };
      setVoiceMessages(prev => [newMessage, ...prev]);
      
      // Speak the AI response
      if (speechEnabled && synthRef.current) {
        speakResponse(data.response);
      }
      
      setIsProcessing(false);
      queryClient.invalidateQueries({ queryKey: ['/api/chat-messages'] });
    },
    onError: (error) => {
      console.error('Soul talk error:', error);
      setIsProcessing(false);
      toast({
        title: "Connection Error",
        description: "Unable to connect with your Soul Companion. Please try again.",
        variant: "destructive"
      });
    }
  });

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setTranscript("");
      setAiResponse("");
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      
      if (transcript.trim()) {
        setIsProcessing(true);
        soulTalkMutation.mutate({
          message: transcript,
          voice: companionVoice,
          name: companionName
        });
      }
    }
  };

  const speakResponse = (text: string) => {
    if (synthRef.current && speechEnabled) {
      synthRef.current.cancel(); // Stop any ongoing speech
      
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Configure voice based on companion personality
      const voices = synthRef.current.getVoices();
      const femaleVoice = voices.find(voice => 
        voice.name.includes('Female') || 
        voice.name.includes('Samantha') || 
        voice.name.includes('Victoria')
      );
      
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }
      
      utterance.rate = 0.9;
      utterance.pitch = 1.1;
      utterance.volume = 0.8;
      
      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);
      
      synthRef.current.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsPlaying(false);
    }
  };

  const getVoicePersonality = (voice: string) => {
    switch (voice) {
      case 'nurturing': return '🤗 Nurturing & Warm';
      case 'spiritual': return '🕯️ Spiritual & Wise';
      case 'energetic': return '⚡ Energetic & Motivating';
      default: return '💫 Balanced & Supportive';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 rounded-full flex items-center justify-center">
              <Mic className="text-white" size={24} />
            </div>
            <h1 className="text-3xl font-bold text-white">Voice Soul Talk</h1>
          </div>
          <p className="text-dark-300 text-lg">Speak your heart to {companionName}, your AI Soul Companion</p>
        </div>

        {/* Companion Settings */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="text-purple-400" size={20} />
              Companion Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-dark-300 mb-2 block">Companion Name</label>
                <Select value={companionName} onValueChange={setCompanionName}>
                  <SelectTrigger className="bg-dark-700 border-dark-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Luna">Luna</SelectItem>
                    <SelectItem value="Sage">Sage</SelectItem>
                    <SelectItem value="Aurora">Aurora</SelectItem>
                    <SelectItem value="Phoenix">Phoenix</SelectItem>
                    <SelectItem value="Serenity">Serenity</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium text-dark-300 mb-2 block">Voice Personality</label>
                <Select value={companionVoice} onValueChange={setCompanionVoice}>
                  <SelectTrigger className="bg-dark-700 border-dark-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nurturing">🤗 Nurturing</SelectItem>
                    <SelectItem value="spiritual">🕯️ Spiritual</SelectItem>
                    <SelectItem value="energetic">⚡ Energetic</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end">
                <Button
                  onClick={() => setSpeechEnabled(!speechEnabled)}
                  variant="outline"
                  className={`border-dark-600 ${speechEnabled ? 'text-primary' : 'text-dark-400'}`}
                >
                  {speechEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
                  {speechEnabled ? 'Voice On' : 'Voice Off'}
                </Button>
              </div>
            </div>
            
            <div className="text-center text-sm text-dark-400">
              {companionName} • {getVoicePersonality(companionVoice)}
            </div>
          </CardContent>
        </Card>

        {/* Voice Interface */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardContent className="p-8">
            <div className="text-center space-y-6">
              
              {/* Recording Button */}
              <div className="relative">
                <Button
                  onClick={isListening ? stopListening : startListening}
                  disabled={isProcessing}
                  className={`w-32 h-32 rounded-full ${
                    isListening 
                      ? 'bg-red-600 hover:bg-red-700 animate-pulse' 
                      : 'bg-gradient-to-br from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700'
                  } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
                  variant="ghost"
                >
                  {isProcessing ? (
                    <Brain className="text-white animate-spin" size={40} />
                  ) : isListening ? (
                    <MicOff className="text-white" size={40} />
                  ) : (
                    <Mic className="text-white" size={40} />
                  )}
                </Button>
                
                {isListening && (
                  <div className="absolute inset-0 w-32 h-32 rounded-full border-4 border-red-400 animate-ping opacity-75" />
                )}
              </div>

              {/* Status */}
              <div className="space-y-2">
                {isListening && (
                  <Badge className="bg-red-600 text-white">
                    🎤 Listening... Speak your heart
                  </Badge>
                )}
                {isProcessing && (
                  <Badge className="bg-purple-600 text-white">
                    🧠 {companionName} is thinking...
                  </Badge>
                )}
                {isPlaying && (
                  <Badge className="bg-blue-600 text-white">
                    🗣️ {companionName} is speaking...
                  </Badge>
                )}
              </div>

              {/* Instructions */}
              <div className="text-dark-300 text-sm max-w-md mx-auto">
                {!isListening && !isProcessing && (
                  <p>
                    Tap the microphone and speak freely about what's on your heart. 
                    {companionName} will listen with compassion and respond with wisdom.
                  </p>
                )}
                {isListening && (
                  <p>
                    "I'm craving sugar and feeling sad..." or whatever you need to express. 
                    Tap again when you're done speaking.
                  </p>
                )}
              </div>

            </div>
          </CardContent>
        </Card>

        {/* Current Conversation */}
        {(transcript || aiResponse) && (
          <Card className="bg-dark-800 border border-dark-700 rounded-xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Heart className="text-pink-400" size={20} />
                Current Conversation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {transcript && (
                <div className="bg-dark-700 rounded-lg p-4">
                  <div className="text-dark-300 text-sm mb-1">You said:</div>
                  <div className="text-white">{transcript}</div>
                </div>
              )}
              
              {aiResponse && (
                <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg p-4 border border-purple-500/30">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-purple-300 text-sm">{companionName} responds:</div>
                    <div className="flex gap-2">
                      {speechEnabled && (
                        <Button
                          onClick={() => isPlaying ? stopSpeaking() : speakResponse(aiResponse)}
                          variant="ghost"
                          size="sm"
                          className="text-purple-300 hover:text-purple-200"
                        >
                          {isPlaying ? <Pause size={16} /> : <Play size={16} />}
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="text-white leading-relaxed">{aiResponse}</div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Recent Voice Messages */}
        {voiceMessages.length > 0 && (
          <Card className="bg-dark-800 border border-dark-700 rounded-xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <RotateCcw className="text-primary" size={20} />
                Recent Soul Conversations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-64 overflow-y-auto">
                {voiceMessages.map((message) => (
                  <div key={message.id} className="border-b border-dark-600 pb-4 last:border-b-0">
                    <div className="text-xs text-dark-400 mb-2">
                      {new Date(message.timestamp).toLocaleString()}
                      {message.mood && (
                        <Badge variant="outline" className="ml-2 text-xs">
                          {message.mood}
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-dark-200 mb-2">
                      <strong>You:</strong> {message.transcript}
                    </div>
                    <div className="text-sm text-purple-200">
                      <strong>{companionName}:</strong> {message.aiResponse}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

      </div>
    </div>
  );
}