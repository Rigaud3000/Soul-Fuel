import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, ScanLine, Heart, Users, MessageCircle } from "lucide-react";
import { useTranslation } from "@/contexts/LanguageContext";

const getNavItems = (t: (key: string) => string) => [
  { path: "/", icon: Home, label: t("nav.dashboard") },
  { path: "/scanner", icon: ScanLine, label: t("nav.scanner") },
  { path: "/tracking", icon: Heart, label: t("nav.tracking") },
  { path: "/community", icon: Users, label: t("nav.community") },
  { path: "/coach", icon: MessageCircle, label: t("nav.coach") },
];

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();
  const { t } = useTranslation();
  const navItems = getNavItems(t);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      <div className="bg-dark-900/95 backdrop-blur-lg border-t border-dark-700/50 shadow-2xl">
        <div className="max-w-md mx-auto px-4 py-1">
          <div className="grid grid-cols-5 gap-1">
            {navItems.map((item) => {
              const isActive = location === item.path;
              const Icon = item.icon;
              
              return (
                <Button
                  key={item.path}
                  onClick={() => setLocation(item.path)}
                  className={`
                    flex flex-col items-center justify-center h-12 rounded-xl
                    transition-all duration-300 ease-out
                    ${isActive 
                      ? "bg-primary/20 text-primary border border-primary/30 shadow-lg shadow-primary/20" 
                      : "text-dark-400 hover:text-dark-200 hover:bg-dark-800/50"
                    }
                  `}
                  variant="ghost"
                  size="sm"
                >
                  <Icon 
                    size={isActive ? 22 : 20} 
                    className={`mb-1 transition-all duration-300 ${
                      isActive ? "drop-shadow-md" : ""
                    }`} 
                  />
                  <span className={`
                    text-[10px] font-medium tracking-wide leading-tight
                    ${isActive ? "text-primary" : "text-dark-500"}
                    transition-colors duration-300
                  `}>
                    {item.label}
                  </span>
                </Button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
