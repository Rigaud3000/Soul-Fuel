import { useAuth } from "@/lib/auth";
import soulFuelLogo from "/src/assets/soulfuel-logo.png";

interface SoulFuelHeaderProps {
  subtitle?: string;
  showGreeting?: boolean;
}

export default function SoulFuelHeader({ 
  subtitle = "Transform Your Life", 
  showGreeting = true 
}: SoulFuelHeaderProps) {
  const { user } = useAuth();

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 18) return "Good Afternoon";
    return "Good Evening";
  };

  return (
    <div className="flex items-center justify-center mb-8">
      <div className="text-center">
        {/* SOULFUEL Logo with Glow Effect */}
        <div className="relative mb-4">
          <img 
            src={soulFuelLogo} 
            alt="SOULFUEL" 
            className="w-24 h-24 mx-auto filter drop-shadow-[0_0_30px_rgba(0,255,179,0.6)]"
          />
          {/* Additional glow layers for enhanced effect */}
          <div className="absolute inset-0 w-24 h-24 mx-auto rounded-full bg-primary/20 blur-xl animate-pulse" />
          <div className="absolute inset-0 w-32 h-32 -top-4 -left-4 mx-auto rounded-full bg-secondary/10 blur-2xl animate-pulse" style={{ animationDelay: '0.5s' }} />
        </div>

        {/* SOULFUEL Text Logo */}
        <div className="mb-3">
          <span className="text-3xl font-bold text-secondary tracking-wider">SOUL</span>
          <span className="text-3xl font-bold text-primary tracking-wider">FUEL</span>
        </div>

        {/* Tagline */}
        <p className="text-lg text-gray-300 mb-4 font-medium">
          {subtitle}
        </p>

        {/* Personalized Greeting */}
        {showGreeting && user && (
          <div className="text-white">
            <h2 className="text-xl font-semibold">
              {getGreeting()}, {user.username}
            </h2>
            <p className="text-blue-200 text-sm mt-1">
              Ready to fuel your soul today?
            </p>
          </div>
        )}
      </div>
    </div>
  );
}