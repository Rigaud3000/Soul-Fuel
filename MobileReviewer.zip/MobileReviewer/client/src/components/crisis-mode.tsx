import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { 
  AlertTriangle, 
  MessageCircle, 
  Gamepad2, 
  Users, 
  Heart,
  Clock,
  Phone,
  Brain,
  Shield,
  Zap,
  CheckCircle
} from "lucide-react";

interface CrisisContact {
  name: string;
  phone: string;
  relationship: string;
}

export function CrisisMode() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedTier, setSelectedTier] = useState<number | null>(null);
  const [crisisContacts, setCrisisContacts] = useState<CrisisContact[]>([]);
  const [newContact, setNewContact] = useState({ name: "", phone: "", relationship: "" });
  const [isAddingContact, setIsAddingContact] = useState(false);
  const [crisisReason, setCrisisReason] = useState("");
  const [urgencyLevel, setUrgencyLevel] = useState<'mild' | 'moderate' | 'severe'>('mild');

  // Load saved crisis contacts
  useEffect(() => {
    const savedContacts = localStorage.getItem('soulfuel-crisis-contacts');
    if (savedContacts) {
      setCrisisContacts(JSON.parse(savedContacts));
    }
  }, []);

  // Save crisis contacts
  const saveContacts = (contacts: CrisisContact[]) => {
    localStorage.setItem('soulfuel-crisis-contacts', JSON.stringify(contacts));
    setCrisisContacts(contacts);
  };

  // Crisis intervention mutation
  const crisisInterventionMutation = useMutation({
    mutationFn: async ({ tier, reason, urgency }: { tier: number; reason: string; urgency: string }) => {
      const response = await apiRequest('POST', '/api/crisis-intervention', {
        tier,
        reason,
        urgencyLevel: urgency,
        timestamp: new Date().toISOString()
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Crisis Support Activated",
        description: data.message || "Your support system has been notified.",
      });
    },
    onError: (error) => {
      console.error('Crisis intervention error:', error);
      toast({
        title: "Crisis Support Available",
        description: "System logged your crisis moment. Support resources are always available.",
        variant: "destructive"
      });
    }
  });

  const activateTier1 = () => {
    setSelectedTier(1);
    setLocation('/soul-companion');
    crisisInterventionMutation.mutate({
      tier: 1,
      reason: crisisReason || "Emotional support needed",
      urgency: urgencyLevel
    });
  };

  const activateTier2 = () => {
    setSelectedTier(2);
    setLocation('/healing-games');
    crisisInterventionMutation.mutate({
      tier: 2,
      reason: crisisReason || "Distraction and coping needed",
      urgency: urgencyLevel
    });
  };

  const activateTier3 = () => {
    setSelectedTier(3);
    if (crisisContacts.length === 0) {
      toast({
        title: "No Emergency Contacts",
        description: "Please add at least one trusted contact for crisis support.",
        variant: "destructive"
      });
      return;
    }
    
    // Send SMS to crisis contacts (simulated)
    crisisContacts.forEach(contact => {
      const message = `SoulFuel Crisis Alert: Your friend needs support right now. They're going through a difficult moment with emotional eating/cravings. A caring check-in would mean the world. 💙`;
      
      // In a real app, this would integrate with SMS API like Twilio
      console.log(`Sending crisis alert to ${contact.name} (${contact.phone}): ${message}`);
    });
    
    crisisInterventionMutation.mutate({
      tier: 3,
      reason: crisisReason || "Emergency support requested",
      urgency: urgencyLevel
    });
    
    toast({
      title: "Emergency Contacts Notified",
      description: `Crisis alert sent to ${crisisContacts.length} trusted contact(s).`,
    });
  };

  const addCrisisContact = () => {
    if (newContact.name && newContact.phone) {
      const updatedContacts = [...crisisContacts, newContact];
      saveContacts(updatedContacts);
      setNewContact({ name: "", phone: "", relationship: "" });
      setIsAddingContact(false);
      toast({
        title: "Contact Added",
        description: `${newContact.name} has been added to your crisis support team.`,
      });
    }
  };

  const removeCrisisContact = (index: number) => {
    const updatedContacts = crisisContacts.filter((_, i) => i !== index);
    saveContacts(updatedContacts);
    toast({
      title: "Contact Removed",
      description: "Crisis contact has been removed from your support team.",
    });
  };

  const getUrgencyColor = (level: string) => {
    switch (level) {
      case 'severe': return 'bg-red-900/20 border-red-800/30 text-red-400';
      case 'moderate': return 'bg-orange-900/20 border-orange-800/30 text-orange-400';
      case 'mild': return 'bg-yellow-900/20 border-yellow-800/30 text-yellow-400';
      default: return 'bg-dark-700 border-dark-600 text-dark-300';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 via-orange-600 to-yellow-600 rounded-full flex items-center justify-center animate-pulse">
              <Shield className="text-white" size={24} />
            </div>
            <h1 className="text-3xl font-bold text-white">Crisis Support System</h1>
          </div>
          <p className="text-dark-300 text-lg">Three-tier intervention for overwhelming moments</p>
        </div>

        {/* Crisis Assessment */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Heart className="text-red-400" size={20} />
              How are you feeling right now?
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-dark-300">What's happening? (Optional)</Label>
              <Input
                value={crisisReason}
                onChange={(e) => setCrisisReason(e.target.value)}
                placeholder="I'm having strong cravings, feeling overwhelmed..."
                className="bg-dark-700 border-dark-600 text-white mt-2"
              />
            </div>
            
            <div>
              <Label className="text-dark-300 mb-3 block">Urgency Level</Label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { level: 'mild', label: 'Mild Discomfort', desc: 'I need some support' },
                  { level: 'moderate', label: 'Moderate Distress', desc: 'I\'m struggling right now' },
                  { level: 'severe', label: 'Severe Crisis', desc: 'I need immediate help' }
                ].map(({ level, label, desc }) => (
                  <Button
                    key={level}
                    onClick={() => setUrgencyLevel(level as any)}
                    variant="outline"
                    className={`h-auto p-4 flex-col gap-2 ${
                      urgencyLevel === level 
                        ? getUrgencyColor(level) 
                        : 'border-dark-600 text-dark-300 hover:border-dark-500'
                    }`}
                  >
                    <span className="font-medium">{label}</span>
                    <span className="text-xs opacity-75">{desc}</span>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Three-Tier Crisis Response */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="text-primary" size={20} />
              Choose Your Support Level
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              
              {/* Tier 1: Emotional Talk */}
              <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border border-blue-700/30 cursor-pointer hover:border-blue-600/50 transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                        <MessageCircle className="text-white" size={24} />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">TIER 1: Emotional Talk</h3>
                        <p className="text-blue-200 text-sm">Chat with your SoulFuel AI Companion</p>
                      </div>
                    </div>
                    <Badge className="bg-blue-600 text-white">Gentle</Badge>
                  </div>
                  
                  <p className="text-blue-100 text-sm mb-4">
                    Have a compassionate conversation with your AI companion. Share what you're feeling, 
                    get emotional support, and receive personalized coping strategies.
                  </p>
                  
                  <Button
                    onClick={activateTier1}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Start Emotional Support
                  </Button>
                </CardContent>
              </Card>

              {/* Tier 2: Emergency Game */}
              <Card className="bg-gradient-to-r from-green-900/20 to-teal-900/20 border border-green-700/30 cursor-pointer hover:border-green-600/50 transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                        <Gamepad2 className="text-white" size={24} />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">TIER 2: Emergency Game</h3>
                        <p className="text-green-200 text-sm">Brain-pulling distraction games</p>
                      </div>
                    </div>
                    <Badge className="bg-green-600 text-white">Active</Badge>
                  </div>
                  
                  <p className="text-green-100 text-sm mb-4">
                    Launch engaging healing games designed to redirect your brain from cravings. 
                    Puzzle Pop, Breathing Orb, and other therapeutic mini-games await.
                  </p>
                  
                  <Button
                    onClick={activateTier2}
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Gamepad2 className="mr-2 h-4 w-4" />
                    Launch Emergency Games
                  </Button>
                </CardContent>
              </Card>

              {/* Tier 3: Friend Alert */}
              <Card className="bg-gradient-to-r from-red-900/20 to-orange-900/20 border border-red-700/30 cursor-pointer hover:border-red-600/50 transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
                        <Users className="text-white" size={24} />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">TIER 3: Friend Alert</h3>
                        <p className="text-red-200 text-sm">Send SOS to trusted contacts</p>
                      </div>
                    </div>
                    <Badge className="bg-red-600 text-white">Urgent</Badge>
                  </div>
                  
                  <p className="text-red-100 text-sm mb-4">
                    Send a caring crisis alert to your trusted contacts. They'll receive a message 
                    letting them know you need support right now.
                  </p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-red-200 text-sm">
                      {crisisContacts.length} contact(s) configured
                    </span>
                    <Button
                      onClick={() => setIsAddingContact(true)}
                      variant="outline"
                      size="sm"
                      className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                    >
                      Add Contact
                    </Button>
                  </div>
                  
                  <Button
                    onClick={activateTier3}
                    disabled={crisisContacts.length === 0}
                    className="w-full bg-red-600 hover:bg-red-700 text-white disabled:opacity-50"
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    Send Crisis Alert
                  </Button>
                </CardContent>
              </Card>

            </div>
          </CardContent>
        </Card>

        {/* Crisis Contacts Management */}
        <Card className="bg-dark-800 border border-dark-700 rounded-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Users className="text-primary" size={20} />
              Crisis Support Team
            </CardTitle>
          </CardHeader>
          <CardContent>
            
            {/* Add New Contact */}
            {isAddingContact && (
              <div className="mb-6 p-4 bg-dark-700 rounded-lg space-y-3">
                <h4 className="font-medium text-white">Add Trusted Contact</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <Input
                    placeholder="Name"
                    value={newContact.name}
                    onChange={(e) => setNewContact(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-dark-600 border-dark-500 text-white"
                  />
                  <Input
                    placeholder="Phone number"
                    value={newContact.phone}
                    onChange={(e) => setNewContact(prev => ({ ...prev, phone: e.target.value }))}
                    className="bg-dark-600 border-dark-500 text-white"
                  />
                  <Input
                    placeholder="Relationship"
                    value={newContact.relationship}
                    onChange={(e) => setNewContact(prev => ({ ...prev, relationship: e.target.value }))}
                    className="bg-dark-600 border-dark-500 text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={addCrisisContact} className="bg-primary hover:bg-primary/80">
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Add Contact
                  </Button>
                  <Button onClick={() => setIsAddingContact(false)} variant="outline" className="border-dark-500">
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {/* Existing Contacts */}
            <div className="space-y-3">
              {crisisContacts.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="text-dark-400 mx-auto mb-3" size={48} />
                  <h3 className="text-lg font-semibold text-dark-300 mb-2">No Crisis Contacts</h3>
                  <p className="text-dark-400 mb-4">Add trusted friends or family for emergency support</p>
                  <Button onClick={() => setIsAddingContact(true)} className="bg-primary hover:bg-primary/80">
                    Add Your First Contact
                  </Button>
                </div>
              ) : (
                crisisContacts.map((contact, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-dark-700 rounded-lg">
                    <div>
                      <div className="font-medium text-white">{contact.name}</div>
                      <div className="text-sm text-dark-300">{contact.relationship} • {contact.phone}</div>
                    </div>
                    <Button
                      onClick={() => removeCrisisContact(index)}
                      variant="outline"
                      size="sm"
                      className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                    >
                      Remove
                    </Button>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Crisis Resources */}
        <Alert className="bg-dark-800 border-dark-600">
          <AlertTriangle className="h-4 w-4 text-yellow-400" />
          <AlertDescription className="text-dark-200">
            <strong className="text-yellow-400">Important:</strong> If you're having thoughts of self-harm, 
            please reach out immediately to a crisis helpline: <br />
            <strong className="text-white">National Crisis Text Line:</strong> Text HOME to 741741<br />
            <strong className="text-white">National Suicide Prevention Lifeline:</strong> 988
          </AlertDescription>
        </Alert>

      </div>
    </div>
  );
}