import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Bell, 
  X, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  Lightbulb,
  TrendingUp,
  TrendingDown,
  Target,
  Clock
} from "lucide-react";

interface Notification {
  id: string;
  type: 'warning' | 'success' | 'info' | 'tip' | 'trend' | 'goal';
  title: string;
  message: string;
  actionText?: string;
  actionUrl?: string;
  timestamp: Date;
  priority: 'high' | 'medium' | 'low';
  category: 'health' | 'habit' | 'community' | 'feature' | 'goal';
}

interface IntelligentNotificationsProps {
  weeklyStats: {
    totalSugar: number;
    avgMood: number;
    moodCheckIns: number;
    cravingIntensity: number;
    streakDays: number;
  };
  userTier: string;
  onActionClick?: (url: string) => void;
}

export default function IntelligentNotifications({ 
  weeklyStats, 
  userTier,
  onActionClick 
}: IntelligentNotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    generateIntelligentNotifications();
  }, [weeklyStats, userTier]);

  const generateIntelligentNotifications = () => {
    const newNotifications: Notification[] = [];
    const now = new Date();

    // Sugar intake analysis
    if (weeklyStats.totalSugar > 175) {
      newNotifications.push({
        id: 'sugar-high',
        type: 'warning',
        title: 'High Sugar Week',
        message: `You've consumed ${Math.round(weeklyStats.totalSugar)}g of sugar this week. Consider reducing by 25g daily.`,
        actionText: 'View Healthy Recipes',
        actionUrl: '/recipes',
        timestamp: now,
        priority: 'high',
        category: 'health'
      });
    } else if (weeklyStats.totalSugar < 100) {
      newNotifications.push({
        id: 'sugar-good',
        type: 'success',
        title: 'Excellent Sugar Control',
        message: 'You\'re maintaining healthy sugar levels. Keep up the great work!',
        timestamp: now,
        priority: 'medium',
        category: 'health'
      });
    }

    // Mood trend analysis
    if (weeklyStats.avgMood < 2.5 && weeklyStats.moodCheckIns >= 3) {
      newNotifications.push({
        id: 'mood-low',
        type: 'warning',
        title: 'Mood Pattern Alert',
        message: 'Your mood has been lower than usual. Consider stress management techniques.',
        actionText: 'Chat with AI Coach',
        actionUrl: '/coach',
        timestamp: now,
        priority: 'high',
        category: 'health'
      });
    } else if (weeklyStats.avgMood > 4 && weeklyStats.moodCheckIns >= 3) {
      newNotifications.push({
        id: 'mood-great',
        type: 'success',
        title: 'Positive Mood Streak',
        message: 'Your mood has been consistently positive this week!',
        timestamp: now,
        priority: 'low',
        category: 'health'
      });
    }

    // Streak encouragement
    if (weeklyStats.streakDays >= 7) {
      newNotifications.push({
        id: 'streak-milestone',
        type: 'success',
        title: `${weeklyStats.streakDays} Day Streak!`,
        message: 'You\'re building powerful healthy habits. Consistency is key to lasting change.',
        timestamp: now,
        priority: 'medium',
        category: 'habit'
      });
    } else if (weeklyStats.streakDays === 0) {
      newNotifications.push({
        id: 'streak-restart',
        type: 'tip',
        title: 'Fresh Start Opportunity',
        message: 'Every day is a chance to begin again. Start your streak today!',
        actionText: 'Log Today\'s Mood',
        actionUrl: '/tracking',
        timestamp: now,
        priority: 'medium',
        category: 'habit'
      });
    }

    // Craving intensity alerts
    if (weeklyStats.cravingIntensity > 7) {
      newNotifications.push({
        id: 'craving-high',
        type: 'warning',
        title: 'Intense Cravings Detected',
        message: 'High craving intensity can indicate withdrawal. Try our coping strategies.',
        actionText: 'Emergency Toolkit',
        actionUrl: '/emergency',
        timestamp: now,
        priority: 'high',
        category: 'health'
      });
    }

    // Tier-specific notifications
    if (userTier === 'silver') {
      newNotifications.push({
        id: 'upgrade-suggestion',
        type: 'info',
        title: 'Unlock Advanced Features',
        message: 'Upgrade to Gold for unlimited food scans and community posting.',
        actionText: 'View Plans',
        actionUrl: '/subscription',
        timestamp: now,
        priority: 'low',
        category: 'feature'
      });
    }

    // Weekly goal suggestions
    const currentHour = now.getHours();
    if (currentHour >= 6 && currentHour <= 10 && weeklyStats.moodCheckIns < 3) {
      newNotifications.push({
        id: 'morning-checkin',
        type: 'tip',
        title: 'Morning Check-in',
        message: 'Start your day with a mood check-in to track your wellness journey.',
        actionText: 'Log Mood',
        actionUrl: '/tracking',
        timestamp: now,
        priority: 'medium',
        category: 'habit'
      });
    }

    // Trend analysis
    if (weeklyStats.totalSugar > 0 && weeklyStats.avgMood > 0) {
      const sugarMoodCorrelation = weeklyStats.totalSugar > 150 && weeklyStats.avgMood < 3;
      if (sugarMoodCorrelation) {
        newNotifications.push({
          id: 'trend-analysis',
          type: 'trend',
          title: 'Pattern Detected',
          message: 'Higher sugar intake may be affecting your mood. Consider gradual reduction.',
          actionText: 'View Insights',
          actionUrl: '/progress',
          timestamp: now,
          priority: 'medium',
          category: 'health'
        });
      }
    }

    setNotifications(newNotifications.slice(0, 5)); // Limit to 5 notifications
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertTriangle className="h-4 w-4 text-orange-400" />;
      case 'success': return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'info': return <Info className="h-4 w-4 text-blue-400" />;
      case 'tip': return <Lightbulb className="h-4 w-4 text-yellow-400" />;
      case 'trend': return <TrendingUp className="h-4 w-4 text-purple-400" />;
      case 'goal': return <Target className="h-4 w-4 text-primary" />;
      default: return <Bell className="h-4 w-4 text-gray-400" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-l-red-500';
      case 'medium': return 'border-l-yellow-500';
      case 'low': return 'border-l-green-500';
      default: return 'border-l-gray-500';
    }
  };

  if (notifications.length === 0) return null;

  return (
    <Card className="bg-dark-800 border border-dark-700 rounded-xl">
      <div className="p-4">
        <div 
          className="flex items-center justify-between cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <h3 className="font-semibold text-dark-50">Smart Insights</h3>
            <Badge className="bg-primary/20 text-primary text-xs">
              {notifications.length}
            </Badge>
          </div>
          <div className="text-dark-400 text-sm">
            {isExpanded ? 'Collapse' : 'Expand'}
          </div>
        </div>

        {isExpanded && (
          <div className="mt-4 space-y-3">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`bg-dark-700 rounded-lg p-3 border-l-4 ${getPriorityColor(notification.priority)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    {getNotificationIcon(notification.type)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-dark-50 text-sm">
                          {notification.title}
                        </h4>
                        <Badge 
                          className={`text-xs ${
                            notification.category === 'health' ? 'bg-red-500/20 text-red-400' :
                            notification.category === 'habit' ? 'bg-blue-500/20 text-blue-400' :
                            notification.category === 'community' ? 'bg-purple-500/20 text-purple-400' :
                            notification.category === 'feature' ? 'bg-green-500/20 text-green-400' :
                            'bg-yellow-500/20 text-yellow-400'
                          }`}
                        >
                          {notification.category}
                        </Badge>
                      </div>
                      <p className="text-dark-300 text-xs leading-relaxed">
                        {notification.message}
                      </p>
                      {notification.actionText && notification.actionUrl && (
                        <Button
                          onClick={() => onActionClick?.(notification.actionUrl!)}
                          className="mt-2 h-7 px-3 text-xs bg-primary/20 hover:bg-primary/30 text-primary"
                          variant="ghost"
                          size="sm"
                        >
                          {notification.actionText}
                        </Button>
                      )}
                    </div>
                  </div>
                  <Button
                    onClick={() => dismissNotification(notification.id)}
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 text-dark-400 hover:text-dark-200"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
}