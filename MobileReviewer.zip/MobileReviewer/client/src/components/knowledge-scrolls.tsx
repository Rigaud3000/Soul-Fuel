import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  BookOpen, 
  Brain, 
  Heart, 
  Lightbulb,
  Clock,
  ArrowRight,
  Star,
  CheckCircle,
  Sparkles
} from "lucide-react";

interface WisdomCard {
  id: string;
  title: string;
  category: 'psychology' | 'science' | 'spirituality' | 'practical';
  readTime: number; // minutes
  content: string[];
  keyTakeaway: string;
  completed: boolean;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

const wisdomCards: WisdomCard[] = [
  {
    id: 'dopamine-hijack',
    title: 'How Dopamine Hijacks Your Brain',
    category: 'science',
    readTime: 2,
    difficulty: 'beginner',
    completed: false,
    content: [
      'Every time you eat ultra-processed food, your brain releases dopamine - the "reward" chemical. This creates a powerful cycle that feels impossible to break.',
      'Sugar triggers the same brain pathways as addictive substances. Your brain literally learns to crave these foods, creating neural pathways that demand more.',
      'But here\'s the empowering truth: neuroplasticity means you can rewire these pathways. Every healthy choice you make creates new neural connections.',
      'When you resist a craving, you\'re not just avoiding sugar - you\'re literally building a stronger, more resilient brain.'
    ],
    keyTakeaway: 'Your brain is designed to change. Every healthy choice rewires your neural pathways toward freedom.'
  },
  {
    id: 'night-cravings',
    title: 'Why We Crave at Night',
    category: 'psychology',
    readTime: 2,
    difficulty: 'beginner',
    completed: false,
    content: [
      'Evening cravings aren\'t about hunger - they\'re about emotions. After a long day, your willpower is depleted and your guard is down.',
      'Your brain associates nighttime with reward and relaxation. It\'s seeking comfort after stress, not nutrition.',
      'The hormone cortisol (stress) naturally rises in the evening, while serotonin (happiness) drops. This creates the perfect storm for emotional eating.',
      'Creating a nurturing evening ritual - tea, gentle music, journaling - can satisfy your brain\'s need for comfort without food.'
    ],
    keyTakeaway: 'Night cravings are emotional, not physical. Nurture your soul with rituals, not sugar.'
  },
  {
    id: 'gut-brain-connection',
    title: 'The Gut-Brain Sacred Connection',
    category: 'spirituality',
    readTime: 3,
    difficulty: 'intermediate',
    completed: false,
    content: [
      'Your gut produces 90% of your body\'s serotonin - the "happiness" neurotransmitter. What you eat directly affects how you feel.',
      'Ancient wisdom traditions called the gut the "second brain." Modern science proves they were right - your gut has its own nervous system.',
      'When you eat processed foods, you\'re feeding harmful bacteria that send anxiety and craving signals to your brain.',
      'Nourishing foods feed beneficial bacteria that produce feel-good chemicals naturally. You\'re not just changing your diet - you\'re changing your emotional baseline.',
      'This is why eating well feels like a spiritual practice. You\'re literally communing with the ecosystem inside you.'
    ],
    keyTakeaway: 'Your gut is your second brain. Feed it with love, and it will return peace to your mind.'
  },
  {
    id: 'trauma-eating',
    title: 'Healing the Wounded Inner Child',
    category: 'psychology',
    readTime: 3,
    difficulty: 'advanced',
    completed: false,
    content: [
      'Often, emotional eating stems from childhood experiences of using food for comfort, celebration, or filling emotional voids.',
      'Your "inner child" still lives within you, seeking the safety and love it needed long ago. Sometimes food feels like the only reliable comfort.',
      'Recognition is the first step to healing: "This craving isn\'t about the cookie. It\'s about the comfort I needed when I was small."',
      'Speak to your inner child with the compassion you needed then: "I see you. I understand why you want this. Let me give you what you really need."',
      'True healing happens when you become the loving parent to yourself that you always deserved.'
    ],
    keyTakeaway: 'Emotional eating often serves a wounded inner child. Heal with love, not judgment.'
  },
  {
    id: 'self-worth-food',
    title: 'Your Worth Is Not Your Weight',
    category: 'spirituality',
    readTime: 2,
    difficulty: 'beginner',
    completed: false,
    content: [
      'Society taught you that your value depends on how you look, what you weigh, or how "perfectly" you eat. This is a lie.',
      'Your worth was established the moment you were born. It cannot be earned, lost, or measured on any scale.',
      'Every time you choose health, do it from love - not self-punishment. There\'s a profound difference between the two.',
      'You deserve nourishment, joy, and freedom not because you\'ve "earned" it, but because you exist.'
    ],
    keyTakeaway: 'Your worth is inherent and unchangeable. Choose health from love, never from shame.'
  },
  {
    id: 'energy-cycles',
    title: 'Understanding Your Energy Rhythms',
    category: 'practical',
    readTime: 2,
    difficulty: 'intermediate',
    completed: false,
    content: [
      'Your body has natural energy peaks and valleys throughout the day. Most people crash around 3 PM - this isn\'t weakness, it\'s biology.',
      'Instead of reaching for sugar during energy dips, try protein, movement, or 5 minutes of sunlight.',
      'Your circadian rhythm affects everything: mood, metabolism, and cravings. Honoring these natural cycles reduces the need for artificial energy.',
      'Plan your most important tasks during your natural energy peaks, and be gentle with yourself during the valleys.'
    ],
    keyTakeaway: 'Work with your natural rhythms, not against them. Energy dips are normal - sugar crashes are optional.'
  }
];

export function KnowledgeScrolls() {
  const [selectedCard, setSelectedCard] = useState<WisdomCard | null>(null);
  const [completedCards, setCompletedCards] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(0);

  const markAsCompleted = (cardId: string) => {
    if (!completedCards.includes(cardId)) {
      setCompletedCards(prev => [...prev, cardId]);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'science': return <Brain className="text-blue-400" size={20} />;
      case 'psychology': return <Heart className="text-purple-400" size={20} />;
      case 'spirituality': return <Sparkles className="text-yellow-400" size={20} />;
      case 'practical': return <Lightbulb className="text-green-400" size={20} />;
      default: return <BookOpen className="text-primary" size={20} />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'science': return 'bg-blue-900/20 border-blue-800/30 text-blue-400';
      case 'psychology': return 'bg-purple-900/20 border-purple-800/30 text-purple-400';
      case 'spirituality': return 'bg-yellow-900/20 border-yellow-800/30 text-yellow-400';
      case 'practical': return 'bg-green-900/20 border-green-800/30 text-green-400';
      default: return 'bg-dark-700 border-dark-600 text-dark-300';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-600 text-white';
      case 'intermediate': return 'bg-orange-600 text-white';
      case 'advanced': return 'bg-red-600 text-white';
      default: return 'bg-dark-600 text-white';
    }
  };

  if (selectedCard) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900 p-4">
        <div className="max-w-4xl mx-auto">
          
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Button
              onClick={() => setSelectedCard(null)}
              variant="outline"
              className="border-dark-600 text-dark-300"
            >
              ← Back to Scrolls
            </Button>
            <Badge className={getDifficultyColor(selectedCard.difficulty)}>
              {selectedCard.difficulty}
            </Badge>
          </div>

          {/* Reading Card */}
          <Card className="bg-dark-800 border border-dark-700 rounded-xl">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  {getCategoryIcon(selectedCard.category)}
                  <div>
                    <CardTitle className="text-white text-xl">{selectedCard.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Clock size={16} className="text-dark-400" />
                      <span className="text-dark-400 text-sm">{selectedCard.readTime} min read</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* Content Paragraphs */}
              <div className="space-y-4">
                {selectedCard.content.map((paragraph, index) => (
                  <div key={index} className="space-y-2">
                    <p className="text-dark-200 leading-relaxed text-lg">
                      {paragraph}
                    </p>
                    {index < selectedCard.content.length - 1 && (
                      <div className="w-12 h-px bg-gradient-to-r from-primary to-transparent mx-auto my-4 opacity-30" />
                    )}
                  </div>
                ))}
              </div>

              {/* Key Takeaway */}
              <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 rounded-lg p-6">
                <div className="flex items-start gap-3">
                  <Star className="text-primary mt-1" size={20} />
                  <div>
                    <h4 className="font-semibold text-primary mb-2">Key Takeaway</h4>
                    <p className="text-white leading-relaxed">{selectedCard.keyTakeaway}</p>
                  </div>
                </div>
              </div>

              {/* Complete Button */}
              <div className="text-center pt-4">
                {completedCards.includes(selectedCard.id) ? (
                  <div className="flex items-center justify-center gap-2 text-green-400">
                    <CheckCircle size={20} />
                    <span>Wisdom Absorbed</span>
                  </div>
                ) : (
                  <Button
                    onClick={() => markAsCompleted(selectedCard.id)}
                    className="bg-primary hover:bg-primary/80 text-white px-8"
                  >
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Mark as Completed
                  </Button>
                )}
              </div>

            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-600 via-orange-600 to-red-600 rounded-full flex items-center justify-center">
              <BookOpen className="text-white" size={24} />
            </div>
            <h1 className="text-3xl font-bold text-white">SoulFuel Knowledge Scrolls</h1>
          </div>
          <p className="text-dark-300 text-lg">Curated wisdom for your healing journey</p>
          <div className="mt-4">
            <div className="flex items-center justify-center gap-2 text-sm text-dark-400">
              <span>{completedCards.length} of {wisdomCards.length} scrolls completed</span>
            </div>
            <Progress 
              value={(completedCards.length / wisdomCards.length) * 100} 
              className="h-2 mt-2 max-w-xs mx-auto"
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {['all', 'science', 'psychology', 'spirituality', 'practical'].map(category => (
            <Badge
              key={category}
              variant="outline"
              className="cursor-pointer border-dark-600 text-dark-300 hover:border-primary hover:text-primary capitalize"
            >
              {category === 'all' ? 'All Scrolls' : category}
            </Badge>
          ))}
        </div>

        {/* Wisdom Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {wisdomCards.map((card) => (
            <Card 
              key={card.id} 
              className={`bg-dark-800 border border-dark-700 rounded-xl cursor-pointer hover:border-primary/50 transition-all group ${
                completedCards.includes(card.id) ? 'ring-2 ring-green-500/30' : ''
              }`}
              onClick={() => setSelectedCard(card)}
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {getCategoryIcon(card.category)}
                    <Badge className={getCategoryColor(card.category)} variant="outline">
                      {card.category}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getDifficultyColor(card.difficulty)} variant="outline">
                      {card.difficulty}
                    </Badge>
                    {completedCards.includes(card.id) && (
                      <CheckCircle className="text-green-400" size={16} />
                    )}
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-primary transition-colors">
                  {card.title}
                </h3>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-dark-400">
                    <Clock size={16} />
                    <span className="text-sm">{card.readTime} min read</span>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-primary hover:text-primary hover:bg-primary/10 group-hover:translate-x-1 transition-all"
                  >
                    Read <ArrowRight size={16} className="ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Completion Milestone */}
        {completedCards.length > 0 && (
          <Card className="bg-gradient-to-r from-green-900/20 to-blue-900/20 border border-green-700/30 rounded-xl">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-3 mb-3">
                <Sparkles className="text-green-400" size={24} />
                <h3 className="text-xl font-semibold text-green-400">Wisdom Journey Progress</h3>
              </div>
              <p className="text-green-200 mb-4">
                You've absorbed {completedCards.length} wisdom scrolls. Each piece of knowledge strengthens your soul.
              </p>
              {completedCards.length === wisdomCards.length && (
                <Badge className="bg-gold text-dark-900 font-bold">
                  🏆 Soul Scholar - All Scrolls Completed!
                </Badge>
              )}
            </CardContent>
          </Card>
        )}

      </div>
    </div>
  );
}