import { useState, useRef, useCallback, useEffect } from "react";
import { Camera, X, Zap, Target, Scan } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuthenticatedRequest } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";

interface ARNutritionData {
  foodName: string;
  healthScore: 'A' | 'B' | 'C' | 'D' | 'F';
  calories: number;
  sugar: number;
  isUltraProcessed: boolean;
  redFlags: string[];
  confidence: number;
}

interface ARFoodScannerProps {
  onClose: () => void;
  onAnalysisComplete?: (data: ARNutritionData) => void;
}

export default function ARFoodScanner({ onClose, onAnalysisComplete }: ARFoodScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<ARNutritionData | null>(null);
  const [scanningProgress, setScanningProgress] = useState(0);
  const [showOverlay, setShowOverlay] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { toast } = useToast();
  const { getAuthHeaders } = useAuthenticatedRequest();

  // Initialize camera stream
  useEffect(() => {
    initializeCamera();
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const initializeCamera = async () => {
    try {
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera not supported by browser');
      }

      // Try simpler camera constraints first
      let stream;
      try {
        // Start with basic constraints
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'environment',
            width: { min: 640, ideal: 1280, max: 1920 },
            height: { min: 480, ideal: 720, max: 1080 }
          },
          audio: false
        });
      } catch (backCameraError) {
        console.log('Back camera failed, trying front camera:', backCameraError);
        try {
          // Try front camera
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: 'user',
              width: { min: 640, ideal: 1280 },
              height: { min: 480, ideal: 720 }
            },
            audio: false
          });
        } catch (frontCameraError) {
          console.log('Front camera failed, trying any camera:', frontCameraError);
          // Last resort - any camera with minimal constraints
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false
          });
        }
      }
      
      if (videoRef.current && stream) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        
        // Enhanced video setup
        const video = videoRef.current;
        video.setAttribute('playsinline', 'true');
        video.setAttribute('webkit-playsinline', 'true');
        video.muted = true;
        
        // Wait for video to load and start playing
        const handleCanPlay = () => {
          video.play().then(() => {
            console.log('Video started playing successfully');
            setCameraReady(true);
            setCameraError(null);
          }).catch((playError) => {
            console.error('Video play error:', playError);
            setCameraError('Failed to start video playback');
          });
        };
        
        video.addEventListener('canplay', handleCanPlay);
        video.addEventListener('loadedmetadata', () => {
          console.log('Video metadata loaded');
        });
        
        // Force load
        video.load();
      }
    } catch (error: any) {
      console.error('Camera initialization error:', error);
      let errorMessage = "Unable to access camera.";
      
      if (error?.name === 'NotAllowedError') {
        errorMessage = "Camera permission denied. Please allow camera access and refresh.";
      } else if (error?.name === 'NotFoundError') {
        errorMessage = "No camera found on this device.";
      } else if (error?.name === 'NotSupportedError') {
        errorMessage = "Camera not supported by this browser.";
      }
      
      setCameraError(errorMessage);
      setCameraReady(false);
      
      toast({
        title: "Camera Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const retryCamera = () => {
    setCameraError(null);
    setCameraReady(false);
    initializeCamera();
  };

  const captureAndAnalyze = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current) return;

    setIsScanning(true);
    setShowOverlay(true);
    setScanningProgress(0);

    // Simulate scanning animation
    const progressInterval = setInterval(() => {
      setScanningProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 10;
      });
    }, 100);

    try {
      // Capture frame from video
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context?.drawImage(video, 0, 0);
      
      // Convert to blob
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => resolve(blob!), 'image/jpeg', 0.8);
      });

      // Create form data
      const formData = new FormData();
      formData.append('image', blob, 'ar-scan.jpg');

      // Send to analysis endpoint
      const response = await apiRequest('POST', '/api/analyze-food-image', formData);
      
      if (response.ok) {
        const result = await response.json();
        
        const arData: ARNutritionData = {
          foodName: result.foodName || 'Unknown Food',
          healthScore: result.healthScore || 'C',
          calories: result.nutritionFacts?.calories || 0,
          sugar: result.nutritionFacts?.totalSugars || 0,
          isUltraProcessed: result.isUltraProcessed || false,
          redFlags: result.redFlags || [],
          confidence: result.confidence || 0.5
        };

        setAnalysisResult(arData);
        onAnalysisComplete?.(arData);
        
        toast({
          title: "Food Analyzed!",
          description: `Identified: ${arData.foodName}`,
        });
      } else {
        throw new Error('Analysis failed');
      }
    } catch (error) {
      toast({
        title: "Analysis Error",
        description: "Failed to analyze food. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsScanning(false);
      setShowOverlay(false);
      setScanningProgress(0);
      clearInterval(progressInterval);
    }
  }, [toast, onAnalysisComplete]);

  const getHealthScoreColor = (score: string) => {
    switch (score) {
      case 'A': return 'bg-green-500';
      case 'B': return 'bg-lime-500';
      case 'C': return 'bg-yellow-500';
      case 'D': return 'bg-orange-500';
      case 'F': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* AR Camera View */}
      <div className="relative w-full h-full">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover"
        />
        <canvas ref={canvasRef} className="hidden" />

        {/* Camera Error Display */}
        {cameraError && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/90">
            <div className="text-center p-6 max-w-sm">
              <Camera size={48} className="mx-auto mb-4 text-red-400" />
              <h3 className="text-white font-bold text-xl mb-2">Camera Not Available</h3>
              <p className="text-white/80 mb-6">{cameraError}</p>
              <Button
                onClick={retryCamera}
                className="bg-primary hover:bg-primary/80 text-white font-semibold px-6 py-2 mr-2"
              >
                Try Again
              </Button>
              <Button
                onClick={onClose}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 px-6 py-2"
              >
                Close
              </Button>
            </div>
          </div>
        )}

        {/* Camera Loading Display */}
        {!cameraReady && !cameraError && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/90">
            <div className="text-center">
              <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-white">Initializing camera...</p>
            </div>
          </div>
        )}

        {/* AR Overlay Effects */}
        {showOverlay && (
          <div className="absolute inset-0 pointer-events-none">
            {/* Scanning Grid */}
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/10 to-transparent animate-pulse" />
            
            {/* Scanning Line */}
            <div 
              className="absolute left-0 right-0 h-1 bg-primary shadow-[0_0_10px_#00FFB3] transition-all duration-100"
              style={{ top: `${scanningProgress}%` }}
            />
            
            {/* Corner Brackets */}
            <div className="absolute top-20 left-20 w-8 h-8 border-l-2 border-t-2 border-primary" />
            <div className="absolute top-20 right-20 w-8 h-8 border-r-2 border-t-2 border-primary" />
            <div className="absolute bottom-20 left-20 w-8 h-8 border-l-2 border-b-2 border-primary" />
            <div className="absolute bottom-20 right-20 w-8 h-8 border-r-2 border-b-2 border-primary" />
          </div>
        )}

        {/* AR UI Controls */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center bg-gradient-to-b from-black/50 to-transparent">
          <Button
            onClick={onClose}
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
          >
            <X size={24} />
          </Button>
          
          <div className="text-center">
            <h2 className="text-white font-bold text-lg">AR Food Scanner</h2>
            <p className="text-white/80 text-sm">Point camera at food item</p>
          </div>
          
          <div className="w-10" /> {/* Spacer */}
        </div>

        {/* Analysis Result Overlay */}
        {analysisResult && (
          <Card className="absolute bottom-20 left-4 right-4 p-4 bg-black/80 backdrop-blur-sm border-primary/30">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-bold text-lg">{analysisResult.foodName}</h3>
              <Badge className={`${getHealthScoreColor(analysisResult.healthScore)} text-white`}>
                Grade {analysisResult.healthScore}
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-white text-sm">
              <div>
                <span className="text-primary">Calories:</span> {analysisResult.calories}
              </div>
              <div>
                <span className="text-primary">Sugar:</span> {analysisResult.sugar}g
              </div>
            </div>
            
            {analysisResult.isUltraProcessed && (
              <div className="mt-2 text-secondary text-sm font-medium">
                ⚠️ Ultra-processed food detected
              </div>
            )}
            
            {analysisResult.redFlags.length > 0 && (
              <div className="mt-2">
                <p className="text-orange-400 text-xs font-medium mb-1">Red Flags:</p>
                <p className="text-white text-xs">{analysisResult.redFlags.join(', ')}</p>
              </div>
            )}
            
            <div className="mt-3 flex justify-center">
              <div className="text-xs text-white/60">
                Confidence: {Math.round(analysisResult.confidence * 100)}%
              </div>
            </div>
          </Card>
        )}

        {/* Scan Button */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <Button
            onClick={captureAndAnalyze}
            disabled={isScanning || !cameraReady || cameraError}
            className="w-20 h-20 rounded-full bg-primary hover:bg-primary/80 disabled:opacity-50"
          >
            {isScanning ? (
              <div className="animate-spin">
                <Scan size={32} />
              </div>
            ) : (
              <Target size={32} />
            )}
          </Button>
        </div>

        {/* Scanning Status */}
        {isScanning && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="text-center text-white">
              <div className="animate-pulse mb-2">
                <Zap size={48} className="mx-auto text-primary" />
              </div>
              <p className="font-medium">Analyzing Food...</p>
              <div className="w-32 h-2 bg-white/20 rounded-full mt-2 overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-100"
                  style={{ width: `${scanningProgress}%` }}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}