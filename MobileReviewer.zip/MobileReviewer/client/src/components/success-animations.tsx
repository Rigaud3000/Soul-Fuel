import React, { useEffect, useState } from 'react';
import { CheckCircle, Sparkles, Trophy, Target, Heart } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface SuccessAnimationProps {
  type: 'scan' | 'mood' | 'goal' | 'streak' | 'level';
  message: string;
  onComplete?: () => void;
  autoHide?: boolean;
  duration?: number;
}

export function SuccessAnimation({ 
  type, 
  message, 
  onComplete, 
  autoHide = true, 
  duration = 3000 
}: SuccessAnimationProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [phase, setPhase] = useState<'enter' | 'display' | 'exit'>('enter');

  useEffect(() => {
    const timer1 = setTimeout(() => setPhase('display'), 100);
    
    if (autoHide) {
      const timer2 = setTimeout(() => setPhase('exit'), duration - 500);
      const timer3 = setTimeout(() => {
        setIsVisible(false);
        onComplete?.();
      }, duration);
      
      return () => {
        clearTimeout(timer1);
        clearTimeout(timer2);
        clearTimeout(timer3);
      };
    }
    
    return () => clearTimeout(timer1);
  }, [autoHide, duration, onComplete]);

  if (!isVisible) return null;

  const getIcon = () => {
    switch (type) {
      case 'scan': return <CheckCircle className="w-16 h-16 text-emerald-400" />;
      case 'mood': return <Heart className="w-16 h-16 text-pink-400" />;
      case 'goal': return <Target className="w-16 h-16 text-blue-400" />;
      case 'streak': return <Trophy className="w-16 h-16 text-yellow-400" />;
      case 'level': return <Sparkles className="w-16 h-16 text-purple-400" />;
      default: return <CheckCircle className="w-16 h-16 text-emerald-400" />;
    }
  };

  const getColor = () => {
    switch (type) {
      case 'scan': return 'from-emerald-500/20 to-green-500/20 border-emerald-500/30';
      case 'mood': return 'from-pink-500/20 to-rose-500/20 border-pink-500/30';
      case 'goal': return 'from-blue-500/20 to-cyan-500/20 border-blue-500/30';
      case 'streak': return 'from-yellow-500/20 to-orange-500/20 border-yellow-500/30';
      case 'level': return 'from-purple-500/20 to-indigo-500/20 border-purple-500/30';
      default: return 'from-emerald-500/20 to-green-500/20 border-emerald-500/30';
    }
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center transition-all duration-500 ${
      phase === 'enter' ? 'opacity-0 scale-75' :
      phase === 'display' ? 'opacity-100 scale-100' :
      'opacity-0 scale-125'
    }`}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      
      <Card className={`relative bg-gradient-to-br ${getColor()} p-8 max-w-sm mx-4 text-center border-2`}>
        <div className={`mb-4 transition-all duration-700 ${
          phase === 'display' ? 'animate-bounce' : ''
        }`}>
          {getIcon()}
        </div>
        
        <h3 className="text-2xl font-bold text-white mb-2">Success!</h3>
        <p className="text-gray-300 text-lg">{message}</p>
        
        {/* Sparkle effects */}
        <div className="absolute top-4 left-4 w-2 h-2 bg-white rounded-full animate-ping" />
        <div className="absolute top-8 right-6 w-1 h-1 bg-white rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
        <div className="absolute bottom-6 left-8 w-1.5 h-1.5 bg-white rounded-full animate-ping" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-4 right-4 w-1 h-1 bg-white rounded-full animate-ping" style={{ animationDelay: '1.5s' }} />
      </Card>
    </div>
  );
}

interface ScanFeedbackProps {
  isScanning: boolean;
  result?: string;
  confidence?: number;
}

export function ScanFeedback({ isScanning, result, confidence }: ScanFeedbackProps) {
  if (!isScanning && !result) return null;

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-sm">
      {isScanning ? (
        <Card className="bg-slate-900/90 border-emerald-500/30 p-6 text-center">
          <div className="w-16 h-16 mx-auto mb-4 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          <h3 className="text-xl font-semibold text-emerald-400 mb-2">Analyzing Food...</h3>
          <p className="text-gray-300">AI is examining your scan</p>
        </Card>
      ) : result ? (
        <Card className="bg-slate-900/90 border-emerald-500/30 p-6 text-center max-w-sm mx-4">
          <CheckCircle className="w-16 h-16 mx-auto mb-4 text-emerald-400 animate-pulse" />
          <h3 className="text-xl font-semibold text-white mb-2">Scan Complete!</h3>
          <p className="text-emerald-400 text-lg font-medium mb-2">{result}</p>
          {confidence && (
            <div className="flex items-center justify-center gap-2">
              <span className="text-sm text-gray-300">Confidence:</span>
              <div className="bg-gray-700 rounded-full h-2 w-24">
                <div 
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${confidence}%` }}
                />
              </div>
              <span className="text-sm text-emerald-400">{confidence}%</span>
            </div>
          )}
        </Card>
      ) : null}
    </div>
  );
}

export function MoodSuccessAnimation({ mood, onComplete }: { mood: string; onComplete?: () => void }) {
  return (
    <SuccessAnimation
      type="mood"
      message={`Mood "${mood}" logged successfully!`}
      onComplete={onComplete}
    />
  );
}

export function GoalSuccessAnimation({ goal, onComplete }: { goal: string; onComplete?: () => void }) {
  return (
    <SuccessAnimation
      type="goal"
      message={`Goal "${goal}" completed!`}
      onComplete={onComplete}
    />
  );
}

export function StreakAnimation({ days, onComplete }: { days: number; onComplete?: () => void }) {
  return (
    <SuccessAnimation
      type="streak"
      message={`${days} day streak achieved!`}
      onComplete={onComplete}
      duration={4000}
    />
  );
}

export function LevelUpAnimation({ level, onComplete }: { level: number; onComplete?: () => void }) {
  return (
    <SuccessAnimation
      type="level"
      message={`Level ${level} unlocked!`}
      onComplete={onComplete}
      duration={5000}
    />
  );
}