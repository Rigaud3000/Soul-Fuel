import { useMemo } from "react";
import type { SugarEntry } from "@shared/schema";

interface SugarChartProps {
  entries: SugarEntry[];
}

export default function SugarChart({ entries }: SugarChartProps) {
  const chartData = useMemo(() => {
    const now = new Date();
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    // Get start of current week (Monday)
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    weekStart.setHours(0, 0, 0, 0);
    
    return days.map((day, index) => {
      const dayDate = new Date(weekStart);
      dayDate.setDate(weekStart.getDate() + index);
      
      // Filter entries for this specific day
      const dayEntries = entries.filter(entry => {
        const entryDate = new Date(entry.date);
        return entryDate.toDateString() === dayDate.toDateString();
      });
      
      // Sum up sugar for the day
      const totalSugar = dayEntries.reduce((sum, entry) => sum + entry.amount, 0);
      
      // Calculate height percentage (max 40g for scale)
      const maxSugar = 40;
      const heightPercent = Math.min((totalSugar / maxSugar) * 100, 100);
      
      const isToday = dayDate.toDateString() === now.toDateString();
      
      return {
        day,
        amount: Math.round(totalSugar),
        height: heightPercent,
        isToday,
      };
    });
  }, [entries]);

  const weeklyAverage = useMemo(() => {
    const totalSugar = chartData.reduce((sum, day) => sum + day.amount, 0);
    const daysWithData = chartData.filter(day => day.amount > 0).length;
    return daysWithData > 0 ? Math.round(totalSugar / 7) : 0;
  }, [chartData]);

  return (
    <div className="w-full">
      <div className="flex items-end justify-between h-32 mb-2">
        {chartData.map((data, index) => (
          <div key={index} className="flex flex-col items-center flex-1">
            <div 
              className={`w-6 chart-bar mb-1 rounded-t transition-all duration-300 ${
                data.isToday 
                  ? 'bg-secondary' 
                  : 'bg-primary'
              }`}
              style={{ height: `${data.height}%` }}
              title={`${data.day}: ${data.amount}g sugar`}
            />
            <span className="text-xs text-dark-400">{data.day}</span>
          </div>
        ))}
      </div>
      
      {/* Chart Legend */}
      <div className="flex justify-between items-center text-xs text-dark-400 mt-2">
        <span>Weekly Avg: {weeklyAverage}g</span>
        <span>Goal: 25g/day</span>
      </div>
      
      {/* Interactive Data Points */}
      <div className="mt-3 text-xs text-dark-500">
        <div className="flex justify-between">
          {chartData.map((data, index) => (
            data.amount > 0 && (
              <div key={index} className="text-center">
                <div className="font-medium text-dark-300">{data.amount}g</div>
              </div>
            )
          ))}
        </div>
      </div>
    </div>
  );
}
