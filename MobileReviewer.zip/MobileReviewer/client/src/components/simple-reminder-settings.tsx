import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Bell, 
  Heart, 
  Droplets, 
  Dumbbell, 
  Moon, 
  Sparkles,
  TestTube,
  Settings,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { simpleReminderSystem } from '@/lib/simple-reminder-system';
import { useToast } from '@/hooks/use-toast';

export function SimpleReminderSettings() {
  const [settings, setSettings] = useState(simpleReminderSystem.getSettings());
  const [status, setStatus] = useState(simpleReminderSystem.getStatus());
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    updateStatus();
  }, []);

  const updateStatus = () => {
    setStatus(simpleReminderSystem.getStatus());
  };

  const updateSettings = (updates: any) => {
    const newSettings = { ...settings, ...updates };
    setSettings(newSettings);
    simpleReminderSystem.updateSettings(updates);
    updateStatus();
    
    toast({
      title: "Settings updated",
      description: "Your reminder preferences have been saved",
    });
  };

  const handleEnableReminders = async () => {
    setLoading(true);
    try {
      const granted = await simpleReminderSystem.requestPermission();
      if (granted) {
        updateSettings({ enabled: true });
        toast({
          title: "Reminders enabled",
          description: "You'll now receive wellness reminders",
        });
      } else {
        toast({
          title: "Permission denied",
          description: "Please enable notifications in your browser settings",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to enable reminders",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      updateStatus();
    }
  };

  const handleTestNotification = async () => {
    try {
      await simpleReminderSystem.testNotification();
      toast({
        title: "Test notification sent",
        description: "Check if you received the notification",
      });
    } catch (error) {
      toast({
        title: "Test failed",
        description: "Please enable notifications first",
        variant: "destructive"
      });
    }
  };

  const handleQuickReminder = async (type: string) => {
    try {
      await simpleReminderSystem.sendImmediateReminder(type);
      toast({
        title: "Reminder sent",
        description: "You should receive the notification shortly",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Please enable notifications first",
        variant: "destructive"
      });
    }
  };

  const addTime = (category: string, field: string) => {
    const currentTimes = [...(settings[category as keyof typeof settings][field as keyof any] || [])];
    currentTimes.push("12:00");
    
    updateSettings({
      [category]: {
        ...settings[category as keyof typeof settings],
        [field]: currentTimes
      }
    });
  };

  const updateTime = (category: string, field: string, index: number, newTime: string) => {
    const currentTimes = [...(settings[category as keyof typeof settings][field as keyof any] || [])];
    currentTimes[index] = newTime;
    
    updateSettings({
      [category]: {
        ...settings[category as keyof typeof settings],
        [field]: currentTimes
      }
    });
  };

  const removeTime = (category: string, field: string, index: number) => {
    const currentTimes = [...(settings[category as keyof typeof settings][field as keyof any] || [])];
    currentTimes.splice(index, 1);
    
    updateSettings({
      [category]: {
        ...settings[category as keyof typeof settings],
        [field]: currentTimes
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Status Card */}
      <Card className={`border-2 ${status.canSendNotifications ? 'border-green-200 bg-green-50' : 'border-amber-200 bg-amber-50'}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {status.canSendNotifications ? (
              <CheckCircle className="h-5 w-5 text-green-600" />
            ) : (
              <AlertCircle className="h-5 w-5 text-amber-600" />
            )}
            Reminder System Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium">Permission</Label>
              <Badge variant={status.permission === 'granted' ? 'default' : 'secondary'}>
                {status.permission}
              </Badge>
            </div>
            <div>
              <Label className="text-sm font-medium">Active Reminders</Label>
              <Badge variant="outline">{status.scheduledCount}</Badge>
            </div>
          </div>

          {status.permission === 'default' && (
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800 mb-3">
                Enable notifications to receive wellness reminders throughout your day.
              </p>
              <Button 
                onClick={handleEnableReminders} 
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? 'Requesting...' : 'Enable Notifications'}
              </Button>
            </div>
          )}

          {status.permission === 'denied' && (
            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <p className="text-sm text-red-800">
                Notifications are blocked. Please enable them in your browser settings to receive reminders.
              </p>
            </div>
          )}

          {status.canSendNotifications && (
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={handleTestNotification}>
                <TestTube className="h-4 w-4 mr-2" />
                Test Notification
              </Button>
              <Button variant="outline" size="sm" onClick={() => handleQuickReminder('mood')}>
                <Heart className="h-4 w-4 mr-2" />
                Mood Reminder
              </Button>
              <Button variant="outline" size="sm" onClick={() => handleQuickReminder('water')}>
                <Droplets className="h-4 w-4 mr-2" />
                Water Reminder
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Master Control */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-600" />
            Reminder Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base font-medium">Enable reminders</Label>
              <p className="text-sm text-muted-foreground">Master switch for all wellness reminders</p>
            </div>
            <Switch
              checked={settings.enabled}
              onCheckedChange={(enabled) => updateSettings({ enabled })}
              disabled={status.permission !== 'granted'}
            />
          </div>

          <Separator />

          {/* Mood Check-ins */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-pink-600" />
              <Label className="text-base font-medium">Mood Check-ins</Label>
              <Switch
                checked={settings.moodChecks.enabled}
                onCheckedChange={(enabled) => updateSettings({
                  moodChecks: { ...settings.moodChecks, enabled }
                })}
              />
            </div>

            {settings.moodChecks.enabled && (
              <div className="ml-7 space-y-2">
                <Label className="text-sm font-medium">Reminder Times</Label>
                {settings.moodChecks.times.map((time, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      type="time"
                      value={time}
                      onChange={(e) => updateTime('moodChecks', 'times', index, e.target.value)}
                      className="w-32"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeTime('moodChecks', 'times', index)}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => addTime('moodChecks', 'times')}
                >
                  Add Time
                </Button>
              </div>
            )}
          </div>

          <Separator />

          {/* Sugar Tracking */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-orange-600" />
              <Label className="text-base font-medium">Sugar Tracking</Label>
              <Switch
                checked={settings.sugarTracking.enabled}
                onCheckedChange={(enabled) => updateSettings({
                  sugarTracking: { ...settings.sugarTracking, enabled }
                })}
              />
            </div>

            {settings.sugarTracking.enabled && (
              <div className="ml-7 space-y-2">
                <Label className="text-sm font-medium">Meal Times</Label>
                {settings.sugarTracking.times.map((time, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      type="time"
                      value={time}
                      onChange={(e) => updateTime('sugarTracking', 'times', index, e.target.value)}
                      className="w-32"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeTime('sugarTracking', 'times', index)}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => addTime('sugarTracking', 'times')}
                >
                  Add Meal Time
                </Button>
              </div>
            )}
          </div>

          <Separator />

          {/* Hydration */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Droplets className="h-5 w-5 text-blue-600" />
              <Label className="text-base font-medium">Hydration Reminders</Label>
              <Switch
                checked={settings.hydration.enabled}
                onCheckedChange={(enabled) => updateSettings({
                  hydration: { ...settings.hydration, enabled }
                })}
              />
            </div>

            {settings.hydration.enabled && (
              <div className="ml-7 grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Start time</Label>
                  <Input
                    type="time"
                    value={settings.hydration.startTime}
                    onChange={(e) => updateSettings({
                      hydration: { ...settings.hydration, startTime: e.target.value }
                    })}
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium">End time</Label>
                  <Input
                    type="time"
                    value={settings.hydration.endTime}
                    onChange={(e) => updateSettings({
                      hydration: { ...settings.hydration, endTime: e.target.value }
                    })}
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium">Interval (hours)</Label>
                  <Input
                    type="number"
                    min="1"
                    max="8"
                    value={settings.hydration.interval}
                    onChange={(e) => updateSettings({
                      hydration: { 
                        ...settings.hydration, 
                        interval: parseInt(e.target.value) || 2 
                      }
                    })}
                  />
                </div>
              </div>
            )}
          </div>

          <Separator />

          {/* Exercise */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Dumbbell className="h-5 w-5 text-green-600" />
              <Label className="text-base font-medium">Exercise Reminders</Label>
              <Switch
                checked={settings.exercise.enabled}
                onCheckedChange={(enabled) => updateSettings({
                  exercise: { ...settings.exercise, enabled }
                })}
              />
            </div>

            {settings.exercise.enabled && (
              <div className="ml-7">
                <Label className="text-sm font-medium">Reminder time</Label>
                <Input
                  type="time"
                  value={settings.exercise.time}
                  onChange={(e) => updateSettings({
                    exercise: { ...settings.exercise, time: e.target.value }
                  })}
                  className="w-32"
                />
              </div>
            )}
          </div>

          <Separator />

          {/* Bedtime */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Moon className="h-5 w-5 text-indigo-600" />
              <Label className="text-base font-medium">Bedtime Reminders</Label>
              <Switch
                checked={settings.bedtime.enabled}
                onCheckedChange={(enabled) => updateSettings({
                  bedtime: { ...settings.bedtime, enabled }
                })}
              />
            </div>

            {settings.bedtime.enabled && (
              <div className="ml-7">
                <Label className="text-sm font-medium">Bedtime</Label>
                <Input
                  type="time"
                  value={settings.bedtime.time}
                  onChange={(e) => updateSettings({
                    bedtime: { ...settings.bedtime, time: e.target.value }
                  })}
                  className="w-32"
                />
              </div>
            )}
          </div>

          <Separator />

          {/* Motivation */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-yellow-600" />
              <Label className="text-base font-medium">Motivational Messages</Label>
              <Switch
                checked={settings.motivation.enabled}
                onCheckedChange={(enabled) => updateSettings({
                  motivation: { ...settings.motivation, enabled }
                })}
              />
            </div>

            {settings.motivation.enabled && (
              <div className="ml-7 space-y-2">
                <Label className="text-sm font-medium">Message Times</Label>
                {settings.motivation.times.map((time, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      type="time"
                      value={time}
                      onChange={(e) => updateTime('motivation', 'times', index, e.target.value)}
                      className="w-32"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeTime('motivation', 'times', index)}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => addTime('motivation', 'times')}
                >
                  Add Time
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}