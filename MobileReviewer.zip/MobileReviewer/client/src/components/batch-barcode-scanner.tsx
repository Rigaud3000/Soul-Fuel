import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Scan,
  Camera,
  Package,
  Trash2,
  CheckCircle,
  AlertTriangle,
  Loader,
  BarChart3
} from "lucide-react";

interface ScannedItem {
  id: string;
  barcode: string;
  name: string;
  brand?: string;
  category: string;
  healthScore: 'A' | 'B' | 'C' | 'D' | 'F';
  sugarContent: number;
  isUltraProcessed: boolean;
  timestamp: Date;
  confidence: number;
}

interface BatchScannerProps {
  onScanComplete: (items: ScannedItem[]) => void;
  onItemAnalyzed: (item: ScannedItem) => void;
}

export default function BatchBarcodeScanner({ onScanComplete, onItemAnalyzed }: BatchScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedItems, setScannedItems] = useState<ScannedItem[]>([]);
  const [currentScan, setCurrentScan] = useState<string>('');
  const [scanningProgress, setScanningProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();

  // Mock barcode data for demonstration
  const mockBarcodeData: Record<string, Partial<ScannedItem>> = {
    '123456789012': {
      name: 'Coca-Cola Classic',
      brand: 'Coca-Cola',
      category: 'Beverages',
      healthScore: 'F',
      sugarContent: 39,
      isUltraProcessed: true,
      confidence: 98
    },
    '098765432109': {
      name: 'Organic Almonds',
      brand: 'Nature Valley',
      category: 'Nuts & Seeds',
      healthScore: 'A',
      sugarContent: 2,
      isUltraProcessed: false,
      confidence: 95
    },
    '555666777888': {
      name: 'Whole Wheat Bread',
      brand: 'Dave\'s Killer Bread',
      category: 'Bakery',
      healthScore: 'B',
      sugarContent: 3,
      isUltraProcessed: false,
      confidence: 92
    },
    '111222333444': {
      name: 'Oreo Cookies',
      brand: 'Nabisco',
      category: 'Cookies & Crackers',
      healthScore: 'F',
      sugarContent: 25,
      isUltraProcessed: true,
      confidence: 99
    }
  };

  const startBatchScanning = async () => {
    setIsScanning(true);
    setScanningProgress(0);
    
    try {
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      toast({
        title: "Batch scanning started",
        description: "Point camera at multiple barcodes. Tap to scan each one.",
      });

      // Simulate continuous scanning capability
      simulateBatchScanning();
      
    } catch (error) {
      toast({
        title: "Camera access denied",
        description: "Please allow camera access to scan barcodes",
        variant: "destructive"
      });
      setIsScanning(false);
    }
  };

  const simulateBatchScanning = () => {
    const barcodes = Object.keys(mockBarcodeData);
    let currentIndex = 0;

    const scanInterval = setInterval(() => {
      if (currentIndex >= barcodes.length) {
        clearInterval(scanInterval);
        completeBatchScan();
        return;
      }

      const barcode = barcodes[currentIndex];
      const mockData = mockBarcodeData[barcode];
      
      if (mockData) {
        const newItem: ScannedItem = {
          id: `item-${Date.now()}-${currentIndex}`,
          barcode,
          name: mockData.name!,
          brand: mockData.brand,
          category: mockData.category!,
          healthScore: mockData.healthScore!,
          sugarContent: mockData.sugarContent!,
          isUltraProcessed: mockData.isUltraProcessed!,
          timestamp: new Date(),
          confidence: mockData.confidence!
        };

        setScannedItems(prev => [...prev, newItem]);
        onItemAnalyzed(newItem);
        setScanningProgress(((currentIndex + 1) / barcodes.length) * 100);
        
        toast({
          title: `Scanned: ${newItem.name}`,
          description: `Health Score: ${newItem.healthScore} | Sugar: ${newItem.sugarContent}g`,
        });
      }

      currentIndex++;
    }, 2000); // Scan every 2 seconds
  };

  const completeBatchScan = () => {
    setIsScanning(false);
    setScanningProgress(100);
    
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }

    onScanComplete(scannedItems);
    
    toast({
      title: "Batch scan complete!",
      description: `Successfully scanned ${scannedItems.length} items`,
    });
  };

  const removeItem = (itemId: string) => {
    setScannedItems(prev => prev.filter(item => item.id !== itemId));
  };

  const clearAllItems = () => {
    setScannedItems([]);
    setScanningProgress(0);
  };

  const getHealthScoreColor = (score: string) => {
    switch (score) {
      case 'A': return 'bg-green-500/20 text-green-400';
      case 'B': return 'bg-blue-500/20 text-blue-400';
      case 'C': return 'bg-yellow-500/20 text-yellow-400';
      case 'D': return 'bg-orange-500/20 text-orange-400';
      case 'F': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getCategoryStats = () => {
    const categories = scannedItems.reduce((acc, item) => {
      acc[item.category] = (acc[item.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(categories).map(([category, count]) => ({ category, count }));
  };

  const getHealthStats = () => {
    const ultraProcessedCount = scannedItems.filter(item => item.isUltraProcessed).length;
    const avgSugar = scannedItems.length > 0 
      ? scannedItems.reduce((sum, item) => sum + item.sugarContent, 0) / scannedItems.length 
      : 0;
    
    return {
      ultraProcessedCount,
      ultraProcessedPercentage: scannedItems.length > 0 ? (ultraProcessedCount / scannedItems.length) * 100 : 0,
      avgSugar: Math.round(avgSugar * 10) / 10,
      totalItems: scannedItems.length
    };
  };

  const stats = getHealthStats();
  const categoryStats = getCategoryStats();

  return (
    <div className="space-y-6">
      {/* Scanner Control */}
      <Card className="bg-dark-800 border-dark-700">
        <CardHeader>
          <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
            <Scan className="h-5 w-5 text-primary" />
            Enhanced Batch Barcode Scanner
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Camera View */}
            {isScanning && (
              <div className="relative bg-black rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-64 object-cover"
                  autoPlay
                  playsInline
                  muted
                />
                <div className="absolute inset-0 border-2 border-primary rounded-lg pointer-events-none">
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-4 border-primary rounded-lg"></div>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <Progress value={scanningProgress} className="h-2" />
                  <p className="text-white text-sm text-center mt-2">
                    Scanning... {Math.round(scanningProgress)}%
                  </p>
                </div>
              </div>
            )}

            {/* Control Buttons */}
            <div className="flex gap-3">
              {!isScanning ? (
                <Button 
                  onClick={startBatchScanning}
                  className="bg-primary hover:bg-primary/80 flex-1"
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Start Batch Scanning
                </Button>
              ) : (
                <Button 
                  onClick={completeBatchScan}
                  variant="outline"
                  className="border-dark-600 flex-1"
                >
                  Stop Scanning
                </Button>
              )}
              
              {scannedItems.length > 0 && (
                <Button 
                  onClick={clearAllItems}
                  variant="outline"
                  className="border-dark-600"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear All
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Scanning Statistics */}
      {scannedItems.length > 0 && (
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-blue-400" />
              Batch Analysis Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center p-3 bg-dark-700 rounded-lg">
                <div className="text-2xl font-bold text-primary">{stats.totalItems}</div>
                <div className="text-sm text-dark-400">Items Scanned</div>
              </div>
              <div className="text-center p-3 bg-dark-700 rounded-lg">
                <div className="text-2xl font-bold text-red-400">{stats.ultraProcessedCount}</div>
                <div className="text-sm text-dark-400">Ultra-Processed</div>
              </div>
              <div className="text-center p-3 bg-dark-700 rounded-lg">
                <div className="text-2xl font-bold text-yellow-400">{stats.avgSugar}g</div>
                <div className="text-sm text-dark-400">Avg Sugar</div>
              </div>
              <div className="text-center p-3 bg-dark-700 rounded-lg">
                <div className="text-2xl font-bold text-orange-400">{Math.round(stats.ultraProcessedPercentage)}%</div>
                <div className="text-sm text-dark-400">Processed</div>
              </div>
            </div>

            {/* Category Breakdown */}
            {categoryStats.length > 0 && (
              <div>
                <h4 className="font-medium text-dark-50 mb-3">Category Breakdown</h4>
                <div className="space-y-2">
                  {categoryStats.map(({ category, count }) => (
                    <div key={category} className="flex items-center justify-between">
                      <span className="text-dark-300">{category}</span>
                      <Badge className="bg-blue-500/20 text-blue-400">{count} items</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Scanned Items List */}
      {scannedItems.length > 0 && (
        <Card className="bg-dark-800 border-dark-700">
          <CardHeader>
            <CardTitle className="text-lg text-dark-50 flex items-center gap-2">
              <Package className="h-5 w-5 text-green-400" />
              Scanned Items ({scannedItems.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {scannedItems.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                      <Package className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium text-dark-50">{item.name}</h4>
                      {item.brand && (
                        <p className="text-dark-400 text-sm">{item.brand}</p>
                      )}
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className={getHealthScoreColor(item.healthScore)}>
                          Grade {item.healthScore}
                        </Badge>
                        <Badge className="bg-gray-500/20 text-gray-400 text-xs">
                          {item.category}
                        </Badge>
                        {item.isUltraProcessed && (
                          <Badge className="bg-red-500/20 text-red-400 text-xs">
                            Ultra-Processed
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-lg font-bold text-dark-50">{item.sugarContent}g</div>
                      <div className="text-xs text-dark-400">Sugar</div>
                    </div>
                    <Button
                      onClick={() => removeItem(item.id)}
                      variant="outline"
                      size="sm"
                      className="border-dark-600"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Smart Categorization Results */}
      {scannedItems.length > 3 && (
        <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <CheckCircle className="h-6 w-6 text-green-400 mt-1" />
              <div>
                <h3 className="text-lg font-semibold text-dark-50 mb-2">Smart Categorization Complete</h3>
                <p className="text-dark-300 text-sm mb-3">
                  AI analysis shows {stats.ultraProcessedPercentage > 50 ? 'high' : 'moderate'} ultra-processed food 
                  content in your batch. Consider replacing items with Grade D/F scores with healthier alternatives.
                </p>
                {stats.ultraProcessedPercentage > 60 && (
                  <div className="flex items-center gap-2 text-sm text-orange-400">
                    <AlertTriangle className="h-4 w-4" />
                    <span>
                      {stats.ultraProcessedPercentage.toFixed(0)}% of scanned items are ultra-processed. 
                      Consider healthier swaps for better nutrition.
                    </span>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}