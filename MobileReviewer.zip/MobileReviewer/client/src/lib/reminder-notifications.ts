import { notificationManager } from './notification-manager';

export interface ReminderSettings {
  enabled: boolean;
  moodCheckIn: {
    enabled: boolean;
    times: string[]; // ["09:00", "14:00", "20:00"]
    frequency: 'daily' | 'weekdays' | 'custom';
    customDays: number[]; // [0,1,2,3,4] for Mon-Fri
  };
  sugarTracking: {
    enabled: boolean;
    mealTimes: string[]; // ["08:00", "12:00", "18:00"]
    beforeMeals: boolean;
    afterMeals: boolean;
    reminderOffset: number; // minutes before/after meal
  };
  cravingSupport: {
    enabled: boolean;
    riskTimes: string[]; // High-risk craving times
    intensityThreshold: number; // 1-10 scale
    predictiveReminders: boolean;
  };
  hydration: {
    enabled: boolean;
    interval: number; // hours between reminders
    startTime: string; // "07:00"
    endTime: string; // "22:00"
    dailyGoal: number; // glasses
  };
  exercise: {
    enabled: boolean;
    reminderTime: string; // "18:00"
    frequency: 'daily' | 'weekdays' | 'custom';
    customDays: number[];
    duration: number; // minutes
  };
  bedtime: {
    enabled: boolean;
    reminderTime: string; // "22:00"
    windDownDuration: number; // minutes before bedtime
  };
  medication: {
    enabled: boolean;
    times: string[];
    medications: Array<{
      name: string;
      dosage: string;
      times: string[];
    }>;
  };
  motivation: {
    enabled: boolean;
    frequency: 'daily' | 'twice_daily' | 'hourly';
    preferredTimes: string[];
    personalizedMessages: boolean;
  };
}

export class ReminderNotificationManager {
  private settings: ReminderSettings;
  private scheduledReminders: Map<string, number> = new Map();

  constructor() {
    this.settings = this.loadSettings();
    this.initializeReminders();
  }

  private loadSettings(): ReminderSettings {
    const stored = localStorage.getItem('soulfuel_reminder_settings');
    if (stored) {
      return JSON.parse(stored);
    }
    
    return {
      enabled: true,
      moodCheckIn: {
        enabled: true,
        times: ["09:00", "14:00", "20:00"],
        frequency: 'daily',
        customDays: [1, 2, 3, 4, 5]
      },
      sugarTracking: {
        enabled: true,
        mealTimes: ["08:00", "12:30", "18:00"],
        beforeMeals: true,
        afterMeals: false,
        reminderOffset: 15
      },
      cravingSupport: {
        enabled: true,
        riskTimes: ["15:00", "21:00"],
        intensityThreshold: 6,
        predictiveReminders: true
      },
      hydration: {
        enabled: true,
        interval: 2,
        startTime: "07:00",
        endTime: "22:00",
        dailyGoal: 8
      },
      exercise: {
        enabled: true,
        reminderTime: "18:00",
        frequency: 'weekdays',
        customDays: [1, 2, 3, 4, 5],
        duration: 30
      },
      bedtime: {
        enabled: true,
        reminderTime: "22:00",
        windDownDuration: 30
      },
      medication: {
        enabled: false,
        times: [],
        medications: []
      },
      motivation: {
        enabled: true,
        frequency: 'twice_daily',
        preferredTimes: ["09:00", "15:00"],
        personalizedMessages: true
      }
    };
  }

  public saveSettings(newSettings: Partial<ReminderSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    localStorage.setItem('soulfuel_reminder_settings', JSON.stringify(this.settings));
    this.rescheduleReminders();
  }

  public getSettings(): ReminderSettings {
    return this.settings;
  }

  private async initializeReminders() {
    if (!this.settings.enabled) return;

    await this.scheduleAllReminders();
  }

  private async sendNotificationSafely(notification: any) {
    try {
      await notificationManager.sendNotification(notification.title, notification.body, "reminder");
    } catch (error) {
      console.error('Failed to send notification:', error);
    }
  }

  private async scheduleAllReminders() {
    // Clear existing reminders
    this.clearAllReminders();

    // Schedule each type of reminder
    if (this.settings.moodCheckIn.enabled) {
      this.scheduleMoodCheckInReminders();
    }

    if (this.settings.sugarTracking.enabled) {
      this.scheduleSugarTrackingReminders();
    }

    if (this.settings.cravingSupport.enabled) {
      this.scheduleCravingSupportReminders();
    }

    if (this.settings.hydration.enabled) {
      this.scheduleHydrationReminders();
    }

    if (this.settings.exercise.enabled) {
      this.scheduleExerciseReminders();
    }

    if (this.settings.bedtime.enabled) {
      this.scheduleBedtimeReminders();
    }

    if (this.settings.medication.enabled) {
      this.scheduleMedicationReminders();
    }

    if (this.settings.motivation.enabled) {
      this.scheduleMotivationReminders();
    }
  }

  private scheduleMoodCheckInReminders() {
    const { times, frequency, customDays } = this.settings.moodCheckIn;
    
    times.forEach((time, index) => {
      const id = `mood_checkin_${index}`;
      this.scheduleRecurringReminder(id, time, frequency, customDays, {
        title: '🧘 How are you feeling?',
        body: 'Take a moment to check in with your emotions and log your mood.',
        icon: '🧘',
        tag: 'mood-checkin',
        action: '/mood-tracker'
      });
    });
  }

  private scheduleSugarTrackingReminders() {
    const { mealTimes, beforeMeals, afterMeals, reminderOffset } = this.settings.sugarTracking;
    
    mealTimes.forEach((mealTime, index) => {
      if (beforeMeals) {
        const beforeTime = this.subtractMinutes(mealTime, reminderOffset);
        const id = `sugar_before_${index}`;
        this.scheduleRecurringReminder(id, beforeTime, 'daily', [], {
          title: '🍽️ Meal time approaching',
          body: 'Plan your healthy meal choices and track your sugar intake.',
          icon: '🍽️',
          tag: 'sugar-tracking',
          action: '/sugar-tracker'
        });
      }

      if (afterMeals) {
        const afterTime = this.addMinutes(mealTime, reminderOffset);
        const id = `sugar_after_${index}`;
        this.scheduleRecurringReminder(id, afterTime, 'daily', [], {
          title: '📝 Log your meal',
          body: 'How did your meal go? Track your sugar intake and mood.',
          icon: '📝',
          tag: 'sugar-tracking',
          action: '/sugar-tracker'
        });
      }
    });
  }

  private scheduleCravingSupportReminders() {
    const { riskTimes, predictiveReminders } = this.settings.cravingSupport;
    
    riskTimes.forEach((time, index) => {
      const id = `craving_support_${index}`;
      this.scheduleRecurringReminder(id, time, 'daily', [], {
        title: '💪 Stay strong',
        body: 'This is a common time for cravings. Take a deep breath and remember your goals.',
        icon: '💪',
        tag: 'craving-support',
        action: '/emergency'
      });
    });

    if (predictiveReminders) {
      // Schedule predictive reminders based on user patterns
      this.schedulePredictiveCravingReminders();
    }
  }

  private scheduleHydrationReminders() {
    const { interval, startTime, endTime, dailyGoal } = this.settings.hydration;
    
    const start = this.parseTime(startTime);
    const end = this.parseTime(endTime);
    const totalHours = end - start;
    const reminderCount = Math.floor(totalHours / interval);
    
    for (let i = 0; i < reminderCount; i++) {
      const reminderTime = this.addHours(startTime, i * interval);
      const id = `hydration_${i}`;
      this.scheduleRecurringReminder(id, reminderTime, 'daily', [], {
        title: '💧 Hydration reminder',
        body: `Time for a glass of water! Daily goal: ${dailyGoal} glasses.`,
        icon: '💧',
        tag: 'hydration',
        action: '/tracking'
      });
    }
  }

  private scheduleExerciseReminders() {
    const { reminderTime, frequency, customDays, duration } = this.settings.exercise;
    
    this.scheduleRecurringReminder('exercise_reminder', reminderTime, frequency, customDays, {
      title: '🏃‍♂️ Time to move!',
      body: `Ready for your ${duration}-minute workout? Exercise helps manage cravings!`,
      icon: '🏃‍♂️',
      tag: 'exercise',
      action: '/tracking'
    });
  }

  private scheduleBedtimeReminders() {
    const { reminderTime, windDownDuration } = this.settings.bedtime;
    
    // Wind-down reminder
    const windDownTime = this.subtractMinutes(reminderTime, windDownDuration);
    this.scheduleRecurringReminder('bedtime_winddown', windDownTime, 'daily', [], {
      title: '🌙 Wind down time',
      body: `Start preparing for bed in ${windDownDuration} minutes. Good sleep helps control cravings.`,
      icon: '🌙',
      tag: 'bedtime',
      action: '/tracking'
    });

    // Bedtime reminder
    this.scheduleRecurringReminder('bedtime_reminder', reminderTime, 'daily', [], {
      title: '😴 Time for bed',
      body: 'A good night\'s sleep is crucial for your wellness journey. Sweet dreams!',
      icon: '😴',
      tag: 'bedtime',
      action: '/tracking'
    });
  }

  private scheduleMedicationReminders() {
    const { medications } = this.settings.medication;
    
    medications.forEach((medication, medIndex) => {
      medication.times.forEach((time, timeIndex) => {
        const id = `medication_${medIndex}_${timeIndex}`;
        this.scheduleRecurringReminder(id, time, 'daily', [], {
          title: '💊 Medication reminder',
          body: `Time to take ${medication.name} (${medication.dosage})`,
          icon: '💊',
          tag: 'medication',
          action: '/tracking',
          urgency: 'high'
        });
      });
    });
  }

  private scheduleMotivationReminders() {
    const { frequency, preferredTimes, personalizedMessages } = this.settings.motivation;
    
    let times: string[] = [];
    
    switch (frequency) {
      case 'daily':
        times = preferredTimes.slice(0, 1);
        break;
      case 'twice_daily':
        times = preferredTimes.slice(0, 2);
        break;
      case 'hourly':
        times = this.generateHourlyTimes();
        break;
    }

    times.forEach((time, index) => {
      const id = `motivation_${index}`;
      this.scheduleRecurringReminder(id, time, 'daily', [], {
        title: '✨ You\'ve got this!',
        body: personalizedMessages ? this.getPersonalizedMotivation() : 'Keep going on your wellness journey!',
        icon: '✨',
        tag: 'motivation',
        action: '/'
      });
    });
  }

  private scheduleRecurringReminder(
    id: string, 
    time: string, 
    frequency: 'daily' | 'weekdays' | 'custom',
    customDays: number[],
    notification: any
  ) {
    const now = new Date();
    const [hours, minutes] = time.split(':').map(Number);
    
    // Calculate next occurrence
    const nextOccurrence = new Date();
    nextOccurrence.setHours(hours, minutes, 0, 0);
    
    if (nextOccurrence <= now) {
      nextOccurrence.setDate(nextOccurrence.getDate() + 1);
    }

    // Check if should schedule based on frequency
    if (!this.shouldScheduleForDay(nextOccurrence, frequency, customDays)) {
      return;
    }

    const delay = nextOccurrence.getTime() - now.getTime();
    
    const timeoutId = window.setTimeout(() => {
      this.sendNotificationSafely(notification);
      // Reschedule for next occurrence
      this.scheduleRecurringReminder(id, time, frequency, customDays, notification);
    }, delay);

    this.scheduledReminders.set(id, Number(timeoutId));
  }

  private shouldScheduleForDay(date: Date, frequency: string, customDays: number[]): boolean {
    const dayOfWeek = date.getDay();
    
    switch (frequency) {
      case 'daily':
        return true;
      case 'weekdays':
        return dayOfWeek >= 1 && dayOfWeek <= 5;
      case 'custom':
        return customDays.includes(dayOfWeek);
      default:
        return true;
    }
  }

  private schedulePredictiveCravingReminders() {
    // Analyze user patterns and schedule predictive reminders
    const userPatterns = this.analyzeUserCravingPatterns();
    
    userPatterns.forEach((pattern, index) => {
      const warningTime = this.subtractMinutes(pattern.predictedTime, 15);
      const id = `predictive_craving_${index}`;
      
      this.scheduleRecurringReminder(id, warningTime, 'daily', [], {
        title: '🚨 Craving alert',
        body: 'Based on your patterns, you might experience a craving soon. Prepare with healthy alternatives!',
        icon: '🚨',
        tag: 'predictive-craving',
        action: '/emergency',
        urgency: 'high'
      });
    });
  }

  private analyzeUserCravingPatterns(): Array<{ predictedTime: string; confidence: number }> {
    // In a real implementation, this would analyze historical data
    // For now, return common craving times
    return [
      { predictedTime: '15:30', confidence: 0.8 },
      { predictedTime: '21:15', confidence: 0.7 }
    ];
  }

  private clearAllReminders() {
    this.scheduledReminders.forEach((timeoutId) => {
      clearTimeout(timeoutId);
    });
    this.scheduledReminders.clear();
  }

  private rescheduleReminders() {
    this.scheduleAllReminders();
  }

  // Utility functions
  private parseTime(timeStr: string): number {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours + minutes / 60;
  }

  private addMinutes(timeStr: string, minutes: number): string {
    const [hours, mins] = timeStr.split(':').map(Number);
    const totalMinutes = hours * 60 + mins + minutes;
    const newHours = Math.floor(totalMinutes / 60) % 24;
    const newMins = totalMinutes % 60;
    return `${newHours.toString().padStart(2, '0')}:${newMins.toString().padStart(2, '0')}`;
  }

  private subtractMinutes(timeStr: string, minutes: number): string {
    return this.addMinutes(timeStr, -minutes);
  }

  private addHours(timeStr: string, hours: number): string {
    return this.addMinutes(timeStr, hours * 60);
  }

  private generateHourlyTimes(): string[] {
    const times = [];
    for (let hour = 8; hour <= 20; hour++) {
      times.push(`${hour.toString().padStart(2, '0')}:00`);
    }
    return times;
  }

  private getPersonalizedMotivation(): string {
    const messages = [
      'Every small step counts on your wellness journey! 🌟',
      'You\'re stronger than your cravings. Keep going! 💪',
      'Remember why you started - you\'ve got this! ✨',
      'Your future self will thank you for the choices you make today! 🌈',
      'Progress, not perfection. You\'re doing amazing! 🎯'
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  }

  // Public methods for manual triggers
  public async testNotification() {
    await notificationManager.sendNotification(
      '🧪 Test Notification',
      'This is a test notification from SOULFUEL. All systems working!',
      'reminder'
    );
  }

  public async sendImmediateReminder(type: string) {
    const reminders = {
      mood: {
        title: '🧘 Quick mood check',
        body: 'How are you feeling right now? Take a moment to log your mood.'
      },
      sugar: {
        title: '📝 Sugar intake reminder',
        body: 'Don\'t forget to track your sugar intake for today!'
      },
      water: {
        title: '💧 Hydration break',
        body: 'Time for a refreshing glass of water!'
      },
      exercise: {
        title: '🏃‍♂️ Movement reminder',
        body: 'A quick walk or stretch can help manage cravings!'
      }
    };

    const reminder = reminders[type as keyof typeof reminders];
    if (reminder) {
      await notificationManager.sendNotification(
        reminder.title,
        reminder.body,
        'reminder'
      );
    }
  }
}

export const reminderNotificationManager = new ReminderNotificationManager();