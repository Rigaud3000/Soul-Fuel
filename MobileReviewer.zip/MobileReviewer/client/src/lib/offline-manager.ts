interface OfflineEntry {
  id: string;
  userId: number;
  type: 'sugar' | 'mood' | 'craving' | 'chat' | 'settings';
  data: any;
  timestamp: string;
  synced: boolean;
}

interface UserSettings {
  userId: number;
  companionName: string;
  personalityType: string;
  voiceTone: string;
  colorTheme: string;
  lastSync: string;
}

class OfflineManager {
  private storageKey = 'soulfuel_offline_data';
  private isOnline = navigator.onLine;
  private syncQueue: Array<{ type: string; data: any; timestamp: string }> = [];

  async initialize(): Promise<void> {
    // Listen for online/offline events
    window.addEventListener('online', this.handleOnline.bind(this));
    window.addEventListener('offline', this.handleOffline.bind(this));

    // Load sync queue from localStorage
    this.loadSyncQueue();

    // Attempt initial sync if online
    if (this.isOnline) {
      await this.syncWithServer();
    }
  }

  private handleOnline(): void {
    this.isOnline = true;
    console.log('Connection restored - syncing offline data');
    this.syncWithServer();
  }

  private handleOffline(): void {
    this.isOnline = false;
    console.log('Connection lost - entering offline mode');
  }

  // Sugar Entries
  async saveSugarEntry(entry: Omit<OfflineDBSchema['sugarEntries']['value'], 'id' | 'synced'>): Promise<string> {
    if (!this.db) throw new Error('Database not initialized');

    const id = `sugar_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const offlineEntry = {
      ...entry,
      id,
      synced: false,
      timestamp: new Date().toISOString()
    };

    await this.db.put('sugarEntries', offlineEntry);

    if (this.isOnline) {
      this.queueForSync('sugar', offlineEntry);
    }

    return id;
  }

  async getSugarEntries(userId: number): Promise<OfflineDBSchema['sugarEntries']['value'][]> {
    if (!this.db) return [];

    const entries = await this.db.getAll('sugarEntries');
    return entries.filter(entry => entry.userId === userId);
  }

  // Mood Entries
  async saveMoodEntry(entry: Omit<OfflineDBSchema['moodEntries']['value'], 'id' | 'synced'>): Promise<string> {
    if (!this.db) throw new Error('Database not initialized');

    const id = `mood_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const offlineEntry = {
      ...entry,
      id,
      synced: false,
      timestamp: new Date().toISOString()
    };

    await this.db.put('moodEntries', offlineEntry);

    if (this.isOnline) {
      this.queueForSync('mood', offlineEntry);
    }

    return id;
  }

  async getMoodEntries(userId: number): Promise<OfflineDBSchema['moodEntries']['value'][]> {
    if (!this.db) return [];

    const entries = await this.db.getAll('moodEntries');
    return entries.filter(entry => entry.userId === userId);
  }

  // Craving Entries
  async saveCravingEntry(entry: Omit<OfflineDBSchema['cravingEntries']['value'], 'id' | 'synced'>): Promise<string> {
    if (!this.db) throw new Error('Database not initialized');

    const id = `craving_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const offlineEntry = {
      ...entry,
      id,
      synced: false,
      timestamp: new Date().toISOString()
    };

    await this.db.put('cravingEntries', offlineEntry);

    if (this.isOnline) {
      this.queueForSync('craving', offlineEntry);
    }

    return id;
  }

  async getCravingEntries(userId: number): Promise<OfflineDBSchema['cravingEntries']['value'][]> {
    if (!this.db) return [];

    const entries = await this.db.getAll('cravingEntries');
    return entries.filter(entry => entry.userId === userId);
  }

  // Chat Messages
  async saveChatMessage(message: Omit<OfflineDBSchema['chatMessages']['value'], 'id' | 'synced'>): Promise<string> {
    if (!this.db) throw new Error('Database not initialized');

    const id = `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const offlineMessage = {
      ...message,
      id,
      synced: false,
      timestamp: new Date().toISOString()
    };

    await this.db.put('chatMessages', offlineMessage);

    if (this.isOnline) {
      this.queueForSync('chat', offlineMessage);
    }

    return id;
  }

  async getChatMessages(userId: number, limit: number = 50): Promise<OfflineDBSchema['chatMessages']['value'][]> {
    if (!this.db) return [];

    const messages = await this.db.getAll('chatMessages');
    return messages
      .filter(msg => msg.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  // User Settings
  async saveUserSettings(settings: OfflineDBSchema['userSettings']['value']): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    await this.db.put('userSettings', {
      ...settings,
      lastSync: new Date().toISOString()
    });

    if (this.isOnline) {
      this.queueForSync('settings', settings);
    }
  }

  async getUserSettings(userId: number): Promise<OfflineDBSchema['userSettings']['value'] | undefined> {
    if (!this.db) return undefined;

    return await this.db.get('userSettings', userId.toString());
  }

  // Sync functionality
  private queueForSync(type: string, data: any): void {
    this.syncQueue.push({
      type,
      data,
      timestamp: new Date().toISOString()
    });

    // Process sync queue with debouncing
    setTimeout(() => this.processSyncQueue(), 1000);
  }

  private async processSyncQueue(): Promise<void> {
    if (!this.isOnline || this.syncQueue.length === 0) return;

    const batch = this.syncQueue.splice(0, 10); // Process in batches of 10

    for (const item of batch) {
      try {
        await this.syncItem(item);
      } catch (error) {
        console.error('Sync failed for item:', item, error);
        // Re-queue failed items
        this.syncQueue.unshift(item);
      }
    }
  }

  private async syncItem(item: { type: string; data: any; timestamp: string }): Promise<void> {
    const { type, data } = item;

    try {
      switch (type) {
        case 'sugar':
          await fetch('/api/sugar-entries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              amount: data.amount,
              mealType: data.mealType,
              timestamp: data.timestamp
            })
          });
          await this.markAsSynced('sugarEntries', data.id);
          break;

        case 'mood':
          await fetch('/api/mood-entries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              mood: data.mood,
              notes: data.notes,
              timestamp: data.timestamp
            })
          });
          await this.markAsSynced('moodEntries', data.id);
          break;

        case 'craving':
          await fetch('/api/craving-entries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              intensity: data.intensity,
              trigger: data.trigger,
              copingStrategy: data.copingStrategy,
              timestamp: data.timestamp
            })
          });
          await this.markAsSynced('cravingEntries', data.id);
          break;

        case 'chat':
          await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: data.message,
              response: data.response,
              coachType: data.coachType,
              timestamp: data.timestamp
            })
          });
          await this.markAsSynced('chatMessages', data.id);
          break;

        case 'settings':
          await fetch('/api/personalization-profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
          });
          break;
      }
    } catch (error) {
      throw error; // Re-throw to handle in processSyncQueue
    }
  }

  private async markAsSynced(store: keyof OfflineDBSchema, id: string): Promise<void> {
    if (!this.db) return;

    const tx = this.db.transaction(store, 'readwrite');
    const item = await tx.store.get(id);
    if (item) {
      (item as any).synced = true;
      await tx.store.put(item);
    }
  }

  async syncWithServer(): Promise<void> {
    if (!this.isOnline || !this.db) return;

    try {
      // Get all unsynced entries
      const unsyncedSugar = (await this.db.getAll('sugarEntries')).filter(entry => !entry.synced);
      const unsyncedMood = (await this.db.getAll('moodEntries')).filter(entry => !entry.synced);
      const unsyncedCraving = (await this.db.getAll('cravingEntries')).filter(entry => !entry.synced);
      const unsyncedChat = (await this.db.getAll('chatMessages')).filter(entry => !entry.synced);

      // Queue all unsynced items
      unsyncedSugar.forEach(entry => this.queueForSync('sugar', entry));
      unsyncedMood.forEach(entry => this.queueForSync('mood', entry));
      unsyncedCraving.forEach(entry => this.queueForSync('craving', entry));
      unsyncedChat.forEach(entry => this.queueForSync('chat', entry));

      console.log(`Queued ${unsyncedSugar.length + unsyncedMood.length + unsyncedCraving.length + unsyncedChat.length} items for sync`);
    } catch (error) {
      console.error('Sync with server failed:', error);
    }
  }

  // Utility methods
  isOffline(): boolean {
    return !this.isOnline;
  }

  async getOfflineStats(): Promise<{
    totalEntries: number;
    unsyncedEntries: number;
    lastSync: string | null;
  }> {
    if (!this.db) return { totalEntries: 0, unsyncedEntries: 0, lastSync: null };

    const sugar = await this.db.getAll('sugarEntries');
    const mood = await this.db.getAll('moodEntries');
    const craving = await this.db.getAll('cravingEntries');
    const chat = await this.db.getAll('chatMessages');

    const totalEntries = sugar.length + mood.length + craving.length + chat.length;
    const unsyncedEntries = [
      ...sugar.filter(e => !e.synced),
      ...mood.filter(e => !e.synced),
      ...craving.filter(e => !e.synced),
      ...chat.filter(e => !e.synced)
    ].length;

    const settings = await this.db.getAll('userSettings');
    const lastSync = settings.length > 0 ? settings[0].lastSync : null;

    return { totalEntries, unsyncedEntries, lastSync };
  }

  async clearOfflineData(): Promise<void> {
    if (!this.db) return;

    const stores: (keyof OfflineDBSchema)[] = ['sugarEntries', 'moodEntries', 'cravingEntries', 'chatMessages', 'userSettings'];
    
    for (const store of stores) {
      await this.db.clear(store);
    }
  }
}

export const offlineManager = new OfflineManager();