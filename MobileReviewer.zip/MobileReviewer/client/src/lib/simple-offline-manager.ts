interface OfflineEntry {
  id: string;
  userId: number;
  type: 'sugar' | 'mood' | 'craving' | 'chat' | 'settings';
  data: any;
  timestamp: string;
  synced: boolean;
}

class SimpleOfflineManager {
  private storageKey = 'soulfuel_offline_data';
  private syncQueueKey = 'soulfuel_sync_queue';
  private isOnline = navigator.onLine;
  private syncInProgress = false;

  async initialize(): Promise<void> {
    // Listen for online/offline events
    window.addEventListener('online', this.handleOnline.bind(this));
    window.addEventListener('offline', this.handleOffline.bind(this));

    // Attempt initial sync if online
    if (this.isOnline) {
      await this.syncWithServer();
    }
  }

  private handleOnline(): void {
    this.isOnline = true;
    console.log('Connection restored - syncing offline data');
    this.syncWithServer();
  }

  private handleOffline(): void {
    this.isOnline = false;
    console.log('Connection lost - entering offline mode');
  }

  // Core storage methods
  private saveToStorage(data: OfflineEntry[]): void {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save offline data:', error);
    }
  }

  private loadFromStorage(): OfflineEntry[] {
    try {
      const data = localStorage.getItem(this.storageKey);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Failed to load offline data:', error);
      return [];
    }
  }

  private generateId(type: string): string {
    return `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Sugar Entries
  async saveSugarEntry(entry: { userId: number; amount: number; mealType: string }): Promise<string> {
    const id = this.generateId('sugar');
    const offlineEntry: OfflineEntry = {
      id,
      userId: entry.userId,
      type: 'sugar',
      data: entry,
      timestamp: new Date().toISOString(),
      synced: false
    };

    const entries = this.loadFromStorage();
    entries.push(offlineEntry);
    this.saveToStorage(entries);

    if (this.isOnline) {
      this.queueForSync(offlineEntry);
    }

    return id;
  }

  getSugarEntries(userId: number): OfflineEntry[] {
    const entries = this.loadFromStorage();
    return entries.filter(entry => entry.userId === userId && entry.type === 'sugar');
  }

  // Mood Entries
  async saveMoodEntry(entry: { userId: number; mood: number; notes?: string }): Promise<string> {
    const id = this.generateId('mood');
    const offlineEntry: OfflineEntry = {
      id,
      userId: entry.userId,
      type: 'mood',
      data: entry,
      timestamp: new Date().toISOString(),
      synced: false
    };

    const entries = this.loadFromStorage();
    entries.push(offlineEntry);
    this.saveToStorage(entries);

    if (this.isOnline) {
      this.queueForSync(offlineEntry);
    }

    return id;
  }

  getMoodEntries(userId: number): OfflineEntry[] {
    const entries = this.loadFromStorage();
    return entries.filter(entry => entry.userId === userId && entry.type === 'mood');
  }

  // Craving Entries
  async saveCravingEntry(entry: { userId: number; intensity: number; trigger?: string; copingStrategy?: string }): Promise<string> {
    const id = this.generateId('craving');
    const offlineEntry: OfflineEntry = {
      id,
      userId: entry.userId,
      type: 'craving',
      data: entry,
      timestamp: new Date().toISOString(),
      synced: false
    };

    const entries = this.loadFromStorage();
    entries.push(offlineEntry);
    this.saveToStorage(entries);

    if (this.isOnline) {
      this.queueForSync(offlineEntry);
    }

    return id;
  }

  getCravingEntries(userId: number): OfflineEntry[] {
    const entries = this.loadFromStorage();
    return entries.filter(entry => entry.userId === userId && entry.type === 'craving');
  }

  // Chat Messages
  async saveChatMessage(message: { userId: number; message: string; response: string; coachType: string }): Promise<string> {
    const id = this.generateId('chat');
    const offlineEntry: OfflineEntry = {
      id,
      userId: message.userId,
      type: 'chat',
      data: message,
      timestamp: new Date().toISOString(),
      synced: false
    };

    const entries = this.loadFromStorage();
    entries.push(offlineEntry);
    this.saveToStorage(entries);

    if (this.isOnline) {
      this.queueForSync(offlineEntry);
    }

    return id;
  }

  getChatMessages(userId: number, limit: number = 50): OfflineEntry[] {
    const entries = this.loadFromStorage();
    return entries
      .filter(entry => entry.userId === userId && entry.type === 'chat')
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  // Sync functionality
  private queueForSync(entry: OfflineEntry): void {
    if (this.syncInProgress) return;

    setTimeout(() => this.syncEntry(entry), 1000);
  }

  private async syncEntry(entry: OfflineEntry): Promise<void> {
    if (!this.isOnline) return;

    try {
      let endpoint = '';
      let payload = {};

      switch (entry.type) {
        case 'sugar':
          endpoint = '/api/sugar-entries';
          payload = {
            amount: entry.data.amount,
            mealType: entry.data.mealType,
            timestamp: entry.timestamp
          };
          break;

        case 'mood':
          endpoint = '/api/mood-entries';
          payload = {
            mood: entry.data.mood,
            notes: entry.data.notes,
            timestamp: entry.timestamp
          };
          break;

        case 'craving':
          endpoint = '/api/craving-entries';
          payload = {
            intensity: entry.data.intensity,
            trigger: entry.data.trigger,
            copingStrategy: entry.data.copingStrategy,
            timestamp: entry.timestamp
          };
          break;

        case 'chat':
          endpoint = '/api/chat';
          payload = {
            message: entry.data.message,
            response: entry.data.response,
            coachType: entry.data.coachType,
            timestamp: entry.timestamp
          };
          break;

        default:
          return;
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        this.markAsSynced(entry.id);
        console.log(`Synced ${entry.type} entry:`, entry.id);
      }
    } catch (error) {
      console.error('Sync failed for entry:', entry.id, error);
    }
  }

  private markAsSynced(id: string): void {
    const entries = this.loadFromStorage();
    const entry = entries.find(e => e.id === id);
    if (entry) {
      entry.synced = true;
      this.saveToStorage(entries);
    }
  }

  async syncWithServer(): Promise<void> {
    if (!this.isOnline || this.syncInProgress) return;

    this.syncInProgress = true;

    try {
      const entries = this.loadFromStorage();
      const unsyncedEntries = entries.filter(entry => !entry.synced);

      console.log(`Starting sync of ${unsyncedEntries.length} unsynced entries`);

      for (const entry of unsyncedEntries) {
        await this.syncEntry(entry);
        // Small delay to avoid overwhelming the server
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      console.log('Sync completed successfully');
    } catch (error) {
      console.error('Sync with server failed:', error);
    } finally {
      this.syncInProgress = false;
    }
  }

  // Utility methods
  isOffline(): boolean {
    return !this.isOnline;
  }

  getOfflineStats(): {
    totalEntries: number;
    unsyncedEntries: number;
    lastSync: string | null;
  } {
    const entries = this.loadFromStorage();
    const unsyncedEntries = entries.filter(entry => !entry.synced);
    
    // Get the most recent sync timestamp
    const syncedEntries = entries.filter(entry => entry.synced);
    const lastSync = syncedEntries.length > 0 
      ? syncedEntries.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0].timestamp
      : null;

    return {
      totalEntries: entries.length,
      unsyncedEntries: unsyncedEntries.length,
      lastSync
    };
  }

  clearOfflineData(): void {
    localStorage.removeItem(this.storageKey);
    localStorage.removeItem(this.syncQueueKey);
  }

  // Emergency offline AI responses
  getEmergencyResponse(type: 'craving' | 'mood' | 'motivation'): string {
    const responses = {
      craving: [
        "Take 5 deep breaths. This craving will pass - they always do.",
        "Drink a glass of water and wait 10 minutes. You're stronger than you think.",
        "Remember why you started this journey. Your future self is counting on you.",
        "This feeling is temporary. Your commitment to health is permanent."
      ],
      mood: [
        "It's okay to feel this way. Emotions are temporary visitors, not permanent residents.",
        "You've overcome difficult moments before, and you will again.",
        "Be gentle with yourself today. Progress isn't always linear.",
        "Your feelings are valid. Take one moment at a time."
      ],
      motivation: [
        "Every small step counts. You're building a healthier life one choice at a time.",
        "You're stronger than your cravings and wiser than your impulses.",
        "Healing happens in the in-between moments. Keep going.",
        "Your body is learning to trust you again. Be patient with the process."
      ]
    };

    const typeResponses = responses[type];
    return typeResponses[Math.floor(Math.random() * typeResponses.length)];
  }
}

export const simpleOfflineManager = new SimpleOfflineManager();