interface NotificationSettings {
  enabled: boolean;
  dailyReminders: boolean;
  cravingAlerts: boolean;
  motivationalMessages: boolean;
  emergencySupport: boolean;
  moodCheckIns: boolean;
  weeklyProgress: boolean;
  customTimes: {
    morningMotivation: string;
    eveningReflection: string;
    cravingCheck: string[];
  };
}

interface ScheduledNotification {
  id: string;
  title: string;
  body: string;
  type: 'motivation' | 'reminder' | 'emergency' | 'progress' | 'mood';
  scheduledTime: Date;
  recurring: boolean;
  data?: any;
}

class NotificationManager {
  private permission: NotificationPermission = 'default';
  private settings: NotificationSettings;
  private scheduledNotifications: Map<string, number> = new Map();
  private isServiceWorkerRegistered = false;

  constructor() {
    this.settings = this.loadSettings();
    this.initialize();
  }

  async initialize(): Promise<void> {
    // Check if notifications are supported
    if (!('Notification' in window)) {
      console.warn('Browser does not support notifications');
      return;
    }

    // Check current permission
    this.permission = Notification.permission;

    // Register service worker for background notifications
    if ('serviceWorker' in navigator) {
      try {
        await navigator.serviceWorker.register('/sw.js');
        this.isServiceWorkerRegistered = true;
        console.log('Service Worker registered for notifications');
      } catch (error) {
        console.error('Service Worker registration failed:', error);
      }
    }

    // Set up recurring notifications if enabled
    if (this.settings.enabled) {
      this.scheduleRecurringNotifications();
    }
  }

  async requestPermission(): Promise<boolean> {
    if (this.permission === 'granted') {
      return true;
    }

    const permission = await Notification.requestPermission();
    this.permission = permission;

    if (permission === 'granted') {
      this.settings.enabled = true;
      this.saveSettings();
      this.scheduleRecurringNotifications();
      return true;
    }

    return false;
  }

  updateSettings(newSettings: Partial<NotificationSettings>): void {
    this.settings = { ...this.settings, ...newSettings };
    this.saveSettings();

    if (this.settings.enabled) {
      this.scheduleRecurringNotifications();
    } else {
      this.clearAllNotifications();
    }
  }

  getSettings(): NotificationSettings {
    return { ...this.settings };
  }

  // Send immediate notification
  async sendNotification(
    title: string,
    body: string,
    type: 'motivation' | 'reminder' | 'emergency' | 'progress' | 'mood' = 'reminder',
    data?: any
  ): Promise<void> {
    if (!this.canSendNotifications()) {
      console.warn('Cannot send notification - permission not granted');
      return;
    }

    const notification = new Notification(title, {
      body,
      icon: '/icon-192.png',
      badge: '/icon-badge.png',
      tag: type,
      data: { type, ...data },
      requireInteraction: type === 'emergency',
      actions: this.getNotificationActions(type)
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
      this.handleNotificationClick(type, data);
    };

    // Auto-close after 10 seconds (except emergency)
    if (type !== 'emergency') {
      setTimeout(() => notification.close(), 10000);
    }
  }

  // Schedule a notification for later
  scheduleNotification(notification: ScheduledNotification): void {
    const now = new Date();
    const delay = notification.scheduledTime.getTime() - now.getTime();

    if (delay <= 0) {
      // If scheduled time has passed, send immediately
      this.sendNotification(notification.title, notification.body, notification.type, notification.data);
      return;
    }

    const timeoutId = setTimeout(() => {
      this.sendNotification(notification.title, notification.body, notification.type, notification.data);

      // If recurring, schedule next occurrence
      if (notification.recurring) {
        const nextTime = new Date(notification.scheduledTime);
        nextTime.setDate(nextTime.getDate() + 1); // Daily recurrence
        this.scheduleNotification({ ...notification, scheduledTime: nextTime });
      }
    }, delay);

    this.scheduledNotifications.set(notification.id, timeoutId);
  }

  // Smart notifications based on user behavior
  async sendCravingPredictionAlert(intensity: number, predictedTime: Date): Promise<void> {
    if (!this.settings.cravingAlerts) return;

    const now = new Date();
    const timeUntil = Math.round((predictedTime.getTime() - now.getTime()) / (1000 * 60));

    let title = '🚨 Craving Alert';
    let body = '';

    if (intensity >= 8) {
      title = '🔥 High Craving Risk';
      body = `Strong craving predicted in ${timeUntil} minutes. Prepare your coping strategies now.`;
    } else if (intensity >= 6) {
      title = '⚠️ Moderate Craving Risk';
      body = `Craving likely in ${timeUntil} minutes. Consider having a healthy snack ready.`;
    } else {
      title = '💙 Gentle Reminder';
      body = `Mild craving possible in ${timeUntil} minutes. Stay mindful of your choices.`;
    }

    await this.sendNotification(title, body, 'emergency', { intensity, predictedTime });
  }

  async sendMotivationalBoost(companionName: string, personalizedMessage?: string): Promise<void> {
    if (!this.settings.motivationalMessages) return;

    const messages = [
      `${companionName} believes in your strength today! 💪`,
      `Remember your 'why' - ${companionName} is here to support you`,
      `You've overcome cravings before, and you will again! - ${companionName}`,
      `Every healthy choice is a victory. ${companionName} celebrates with you! 🎉`,
      `Your body is learning to trust you again. Keep going! - ${companionName}`
    ];

    const message = personalizedMessage || messages[Math.floor(Math.random() * messages.length)];

    await this.sendNotification(
      `Message from ${companionName}`,
      message,
      'motivation',
      { companionName }
    );
  }

  async sendMoodCheckIn(): Promise<void> {
    if (!this.settings.moodCheckIns) return;

    const messages = [
      'How are you feeling right now? Take a moment to check in with yourself.',
      'Your emotions matter. Would you like to log your current mood?',
      'Taking time for self-reflection is a gift to yourself. How\'s your mood today?',
      'A quick mood check can help you understand your patterns better.'
    ];

    const message = messages[Math.floor(Math.random() * messages.length)];

    await this.sendNotification(
      '💚 Mood Check-In',
      message,
      'mood'
    );
  }

  async sendWeeklyProgress(stats: { streakDays: number; goalsAchieved: number; totalGoals: number }): Promise<void> {
    if (!this.settings.weeklyProgress) return;

    const completion = Math.round((stats.goalsAchieved / stats.totalGoals) * 100);

    await this.sendNotification(
      '📊 Weekly Progress Update',
      `Amazing work! ${stats.streakDays} day streak, ${completion}% goals achieved this week!`,
      'progress',
      stats
    );
  }

  // Emergency intervention notification
  async sendEmergencySupport(): Promise<void> {
    if (!this.settings.emergencySupport) return;

    await this.sendNotification(
      '🆘 Crisis Support Available',
      'Feeling overwhelmed? Tap for immediate coping strategies and emergency toolkit.',
      'emergency',
      { immediate: true }
    );
  }

  // Schedule recurring daily notifications
  private scheduleRecurringNotifications(): void {
    this.clearAllNotifications();

    if (this.settings.dailyReminders) {
      // Morning motivation
      this.scheduleDailyNotification(
        'morning-motivation',
        '🌅 Good Morning!',
        'Start your day with intention. Your wellness journey continues today!',
        this.settings.customTimes.morningMotivation || '08:00',
        'motivation'
      );

      // Evening reflection
      this.scheduleDailyNotification(
        'evening-reflection',
        '🌙 Evening Reflection',
        'Take a moment to acknowledge today\'s progress, no matter how small.',
        this.settings.customTimes.eveningReflection || '20:00',
        'mood'
      );
    }

    // Craving check-ins at custom times
    if (this.settings.cravingAlerts && this.settings.customTimes.cravingCheck.length > 0) {
      this.settings.customTimes.cravingCheck.forEach((time, index) => {
        this.scheduleDailyNotification(
          `craving-check-${index}`,
          '🧘 Mindful Moment',
          'How are you feeling? Remember your coping strategies are always available.',
          time,
          'reminder'
        );
      });
    }
  }

  private scheduleDailyNotification(
    id: string,
    title: string,
    body: string,
    time: string,
    type: 'motivation' | 'reminder' | 'emergency' | 'progress' | 'mood'
  ): void {
    const [hours, minutes] = time.split(':').map(Number);
    const now = new Date();
    const scheduledTime = new Date();
    scheduledTime.setHours(hours, minutes, 0, 0);

    // If time has passed today, schedule for tomorrow
    if (scheduledTime <= now) {
      scheduledTime.setDate(scheduledTime.getDate() + 1);
    }

    this.scheduleNotification({
      id,
      title,
      body,
      type,
      scheduledTime,
      recurring: true
    });
  }

  private clearAllNotifications(): void {
    this.scheduledNotifications.forEach((timeoutId) => {
      clearTimeout(timeoutId);
    });
    this.scheduledNotifications.clear();
  }

  private canSendNotifications(): boolean {
    return this.permission === 'granted' && this.settings.enabled;
  }

  private getNotificationActions(type: string): NotificationAction[] {
    switch (type) {
      case 'emergency':
        return [
          { action: 'coping', title: 'Coping Strategies' },
          { action: 'emergency', title: 'Emergency Toolkit' }
        ];
      case 'mood':
        return [
          { action: 'log-mood', title: 'Log Mood' },
          { action: 'skip', title: 'Skip' }
        ];
      case 'motivation':
        return [
          { action: 'view', title: 'View Progress' },
          { action: 'dismiss', title: 'Thanks!' }
        ];
      default:
        return [];
    }
  }

  private handleNotificationClick(type: string, data?: any): void {
    // Navigate based on notification type
    switch (type) {
      case 'emergency':
        window.location.hash = '#/emergency-toolkit';
        break;
      case 'mood':
        window.location.hash = '#/tracking';
        break;
      case 'motivation':
      case 'progress':
        window.location.hash = '#/dashboard';
        break;
      default:
        window.location.hash = '#/dashboard';
    }
  }

  private loadSettings(): NotificationSettings {
    try {
      const saved = localStorage.getItem('soulfuel_notification_settings');
      if (saved) {
        return { ...this.getDefaultSettings(), ...JSON.parse(saved) };
      }
    } catch (error) {
      console.error('Failed to load notification settings:', error);
    }
    return this.getDefaultSettings();
  }

  private saveSettings(): void {
    try {
      localStorage.setItem('soulfuel_notification_settings', JSON.stringify(this.settings));
    } catch (error) {
      console.error('Failed to save notification settings:', error);
    }
  }

  private getDefaultSettings(): NotificationSettings {
    return {
      enabled: false,
      dailyReminders: true,
      cravingAlerts: true,
      motivationalMessages: true,
      emergencySupport: true,
      moodCheckIns: true,
      weeklyProgress: true,
      customTimes: {
        morningMotivation: '08:00',
        eveningReflection: '20:00',
        cravingCheck: ['12:00', '15:00', '18:00']
      }
    };
  }

  // Test notification (for settings)
  async sendTestNotification(): Promise<void> {
    await this.sendNotification(
      '✅ Test Notification',
      'Great! Your notifications are working perfectly.',
      'reminder'
    );
  }
}

export const notificationManager = new NotificationManager();