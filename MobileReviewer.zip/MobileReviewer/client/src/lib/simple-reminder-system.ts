interface SimpleReminderSettings {
  enabled: boolean;
  moodChecks: { enabled: boolean; times: string[] };
  sugarTracking: { enabled: boolean; times: string[] };
  hydration: { enabled: boolean; interval: number; startTime: string; endTime: string };
  exercise: { enabled: boolean; time: string };
  bedtime: { enabled: boolean; time: string };
  motivation: { enabled: boolean; times: string[] };
}

class SimpleReminderSystem {
  private settings: SimpleReminderSettings;
  private scheduledReminders: Map<string, number> = new Map();
  private permission: NotificationPermission = 'default';

  constructor() {
    this.settings = this.loadSettings();
    this.initializeSystem();
  }

  private loadSettings(): SimpleReminderSettings {
    const stored = localStorage.getItem('simple_reminder_settings');
    if (stored) {
      return JSON.parse(stored);
    }
    
    return {
      enabled: true,
      moodChecks: {
        enabled: true,
        times: ["09:00", "14:00", "20:00"]
      },
      sugarTracking: {
        enabled: true,
        times: ["08:00", "12:30", "18:00"]
      },
      hydration: {
        enabled: true,
        interval: 2,
        startTime: "07:00",
        endTime: "22:00"
      },
      exercise: {
        enabled: true,
        time: "18:00"
      },
      bedtime: {
        enabled: true,
        time: "22:00"
      },
      motivation: {
        enabled: true,
        times: ["09:00", "15:00"]
      }
    };
  }

  private async initializeSystem() {
    this.permission = Notification.permission;
    
    if (this.permission === 'default') {
      // Don't auto-request permission, wait for user action
      return;
    }

    if (this.permission === 'granted' && this.settings.enabled) {
      this.scheduleAllReminders();
    }
  }

  public async requestPermission(): Promise<boolean> {
    if (this.permission === 'granted') {
      return true;
    }

    try {
      const permission = await Notification.requestPermission();
      this.permission = permission;

      if (permission === 'granted') {
        this.scheduleAllReminders();
        return true;
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
    }

    return false;
  }

  public updateSettings(newSettings: Partial<SimpleReminderSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    localStorage.setItem('simple_reminder_settings', JSON.stringify(this.settings));
    
    if (this.settings.enabled && this.permission === 'granted') {
      this.scheduleAllReminders();
    } else {
      this.clearAllReminders();
    }
  }

  public getSettings(): SimpleReminderSettings {
    return { ...this.settings };
  }

  private scheduleAllReminders() {
    this.clearAllReminders();

    if (this.settings.moodChecks.enabled) {
      this.settings.moodChecks.times.forEach((time, index) => {
        this.scheduleDaily(`mood_${index}`, time, {
          title: '🧘 Mood Check-in',
          body: 'How are you feeling? Take a moment to log your mood.',
          icon: '🧘'
        });
      });
    }

    if (this.settings.sugarTracking.enabled) {
      this.settings.sugarTracking.times.forEach((time, index) => {
        this.scheduleDaily(`sugar_${index}`, time, {
          title: '📝 Sugar Tracking',
          body: 'Time to log your meal and track your sugar intake.',
          icon: '📝'
        });
      });
    }

    if (this.settings.hydration.enabled) {
      this.scheduleHydrationReminders();
    }

    if (this.settings.exercise.enabled) {
      this.scheduleDaily('exercise', this.settings.exercise.time, {
        title: '🏃‍♂️ Exercise Time',
        body: 'Ready for your workout? Exercise helps manage cravings!',
        icon: '🏃‍♂️'
      });
    }

    if (this.settings.bedtime.enabled) {
      this.scheduleDaily('bedtime', this.settings.bedtime.time, {
        title: '🌙 Bedtime Reminder',
        body: 'Time to wind down for better sleep and wellness.',
        icon: '🌙'
      });
    }

    if (this.settings.motivation.enabled) {
      this.settings.motivation.times.forEach((time, index) => {
        this.scheduleDaily(`motivation_${index}`, time, {
          title: '✨ Stay Motivated',
          body: this.getRandomMotivation(),
          icon: '✨'
        });
      });
    }
  }

  private scheduleHydrationReminders() {
    const start = this.parseTime(this.settings.hydration.startTime);
    const end = this.parseTime(this.settings.hydration.endTime);
    const interval = this.settings.hydration.interval;
    
    let currentTime = start;
    let index = 0;
    
    while (currentTime < end) {
      const timeStr = this.formatTime(currentTime);
      this.scheduleDaily(`hydration_${index}`, timeStr, {
        title: '💧 Hydration Reminder',
        body: 'Time for a glass of water! Stay hydrated for better health.',
        icon: '💧'
      });
      
      currentTime += interval;
      index++;
    }
  }

  private scheduleDaily(id: string, time: string, notification: { title: string; body: string; icon: string }) {
    const [hours, minutes] = time.split(':').map(Number);
    const now = new Date();
    const scheduledTime = new Date();
    
    scheduledTime.setHours(hours, minutes, 0, 0);
    
    // If time has passed today, schedule for tomorrow
    if (scheduledTime <= now) {
      scheduledTime.setDate(scheduledTime.getDate() + 1);
    }

    const delay = scheduledTime.getTime() - now.getTime();
    
    const timeoutId = window.setTimeout(() => {
      this.showNotification(notification);
      // Reschedule for next day
      this.scheduleDaily(id, time, notification);
    }, delay);

    this.scheduledReminders.set(id, timeoutId);
  }

  private showNotification(notification: { title: string; body: string; icon: string }) {
    if (this.permission !== 'granted') {
      return;
    }

    try {
      new Notification(notification.title, {
        body: notification.body,
        icon: '/icon-192x192.png',
        badge: '/badge-72x72.png',
        tag: 'soulfuel-reminder',
        requireInteraction: false,
        silent: false
      });
    } catch (error) {
      console.error('Error showing notification:', error);
    }
  }

  private clearAllReminders() {
    this.scheduledReminders.forEach((timeoutId) => {
      clearTimeout(timeoutId);
    });
    this.scheduledReminders.clear();
  }

  // Test notification
  public async testNotification() {
    if (this.permission !== 'granted') {
      const granted = await this.requestPermission();
      if (!granted) {
        throw new Error('Notification permission not granted');
      }
    }

    this.showNotification({
      title: '🧪 Test Notification',
      body: 'SOULFUEL reminder system is working perfectly!',
      icon: '🧪'
    });
  }

  // Send immediate reminder
  public async sendImmediateReminder(type: string) {
    if (this.permission !== 'granted') {
      const granted = await this.requestPermission();
      if (!granted) {
        throw new Error('Notification permission not granted');
      }
    }

    const reminders = {
      mood: {
        title: '🧘 Quick Mood Check',
        body: 'How are you feeling right now?',
        icon: '🧘'
      },
      sugar: {
        title: '📝 Sugar Tracking',
        body: 'Don\'t forget to log your sugar intake!',
        icon: '📝'
      },
      water: {
        title: '💧 Hydration Break',
        body: 'Time for a refreshing glass of water!',
        icon: '💧'
      },
      exercise: {
        title: '🏃‍♂️ Movement Break',
        body: 'A quick stretch can help manage cravings!',
        icon: '🏃‍♂️'
      }
    };

    const reminder = reminders[type as keyof typeof reminders];
    if (reminder) {
      this.showNotification(reminder);
    }
  }

  // Utility methods
  private parseTime(timeStr: string): number {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours + minutes / 60;
  }

  private formatTime(time: number): string {
    const hours = Math.floor(time);
    const minutes = Math.round((time - hours) * 60);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  }

  private getRandomMotivation(): string {
    const messages = [
      'You\'re doing amazing on your wellness journey! 🌟',
      'Every small step counts toward your goals! 💪',
      'Remember why you started - you\'ve got this! ✨',
      'Your future self will thank you! 🌈',
      'Progress, not perfection. Keep going! 🎯',
      'You\'re stronger than your cravings! 💪',
      'Healthy choices today, better tomorrow! 🌱',
      'Your wellness journey is inspiring! ⭐'
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  }

  // Get current status
  public getStatus() {
    return {
      permission: this.permission,
      enabled: this.settings.enabled,
      scheduledCount: this.scheduledReminders.size,
      canSendNotifications: this.permission === 'granted' && this.settings.enabled
    };
  }
}

export const simpleReminderSystem = new SimpleReminderSystem();