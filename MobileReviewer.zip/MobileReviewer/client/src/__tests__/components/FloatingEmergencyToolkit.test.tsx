import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { FloatingEmergencyToolkit } from '@/components/floating-emergency-toolkit';

describe('FloatingEmergencyToolkit', () => {
  it('renders the emergency button', () => {
    render(<FloatingEmergencyToolkit />);
    
    const emergencyButton = screen.getByRole('button');
    expect(emergencyButton).toBeInTheDocument();
    expect(emergencyButton).toHaveClass('bg-red-500');
  });

  it('opens toolkit dialog when clicked', async () => {
    render(<FloatingEmergencyToolkit />);
    
    const emergencyButton = screen.getByRole('button');
    fireEvent.click(emergencyButton);
    
    await waitFor(() => {
      expect(screen.getByText('Emergency Toolkit')).toBeInTheDocument();
    });
  });

  it('displays all emergency tools', async () => {
    render(<FloatingEmergencyToolkit />);
    
    const emergencyButton = screen.getByRole('button');
    fireEvent.click(emergencyButton);
    
    await waitFor(() => {
      expect(screen.getByText('Breathing Exercise')).toBeInTheDocument();
      expect(screen.getByText('Puzzle Pop')).toBeInTheDocument();
      expect(screen.getByText('Mindful Moment')).toBeInTheDocument();
      expect(screen.getByText('Crisis Support')).toBeInTheDocument();
    });
  });

  it('starts breathing exercise when clicked', async () => {
    render(<FloatingEmergencyToolkit />);
    
    const emergencyButton = screen.getByRole('button');
    fireEvent.click(emergencyButton);
    
    await waitFor(() => {
      const breathingButton = screen.getByText('Breathing Exercise');
      fireEvent.click(breathingButton);
      expect(screen.getByText('Breathe In')).toBeInTheDocument();
    });
  });

  it('shows puzzle game when selected', async () => {
    render(<FloatingEmergencyToolkit />);
    
    const emergencyButton = screen.getByRole('button');
    fireEvent.click(emergencyButton);
    
    await waitFor(() => {
      const puzzleButton = screen.getByText('Puzzle Pop');
      fireEvent.click(puzzleButton);
      expect(screen.getByText('Score:')).toBeInTheDocument();
    });
  });
});