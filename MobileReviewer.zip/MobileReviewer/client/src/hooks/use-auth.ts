import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";

export function useAuthenticatedRequest() {
  const { firebaseUser } = useAuth();
  
  const getAuthHeaders = () => {
    if (!firebaseUser) return {};
    return {
      'X-Firebase-UID': firebaseUser.uid
    };
  };

  return { getAuthHeaders };
}

export function useUserData() {
  const { user, loading } = useAuth();
  return { user, loading };
}
