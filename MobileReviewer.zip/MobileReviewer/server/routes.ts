import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerFoodAnalysisRoutes } from "./routes/food-analysis";
import { registerWearableIntegrationRoutes } from "./routes/wearable-integration";
import { registerPredictiveWellnessRoutes } from "./routes/predictive-wellness";
import { emotionalAICompanion } from "./services/emotional-ai-companion";
import { 
  insertUserSchema,
  insertSugarEntrySchema,
  insertMoodEntrySchema,
  insertCravingEntrySchema,
  insertChatMessageSchema,
  insertFoodAnalysisSchema,
  insertWeeklyGoalSchema
} from "@shared/schema";
import { GoogleGenAI } from "@google/genai";

// Using Gemini AI for chat and food analysis
const genai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "dummy_key" });

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication middleware - temporarily bypassed for testing
  const requireAuth = async (req: any, res: any, next: any) => {
    // Temporarily create a demo user for testing (free tier)
    req.user = {
      id: 1,
      username: "demo_user",
      email: "demo@example.com",
      firebaseUid: "demo_uid",
      subscriptionTier: "free",
      stripeCustomerId: null,
      stripeSubscriptionId: null
    };
    next();
  };

  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/user", requireAuth, async (req: any, res) => {
    res.json(req.user);
  });

  // Sugar tracking routes
  app.post("/api/sugar-entries", requireAuth, async (req: any, res) => {
    try {
      const entryData = insertSugarEntrySchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date || new Date())
      });
      const entry = await storage.createSugarEntry(entryData);
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Sugar entry alias for compatibility
  app.post("/api/sugar-entry", requireAuth, async (req: any, res) => {
    try {
      const entryData = insertSugarEntrySchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date || new Date())
      });
      const entry = await storage.createSugarEntry(entryData);
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/sugar-entries", requireAuth, async (req: any, res) => {
    try {
      const { startDate, endDate } = req.query;
      const entries = await storage.getUserSugarEntries(
        req.user.id,
        startDate ? new Date(startDate) : undefined,
        endDate ? new Date(endDate) : undefined
      );
      res.json(entries);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Mood tracking routes
  app.post("/api/mood-entries", requireAuth, async (req: any, res) => {
    try {
      const entryData = insertMoodEntrySchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date || new Date())
      });
      const entry = await storage.createMoodEntry(entryData);
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Mood entry alias for compatibility
  app.post("/api/mood-entry", requireAuth, async (req: any, res) => {
    try {
      const entryData = insertMoodEntrySchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date || new Date())
      });
      const entry = await storage.createMoodEntry(entryData);
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/mood-entries", requireAuth, async (req: any, res) => {
    try {
      const { startDate, endDate } = req.query;
      const entries = await storage.getUserMoodEntries(
        req.user.id,
        startDate ? new Date(startDate) : undefined,
        endDate ? new Date(endDate) : undefined
      );
      res.json(entries);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Craving tracking routes
  app.post("/api/craving-entries", requireAuth, async (req: any, res) => {
    try {
      const entryData = insertCravingEntrySchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date || new Date())
      });
      const entry = await storage.createCravingEntry(entryData);
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Craving entry alias for compatibility
  app.post("/api/craving-entry", requireAuth, async (req: any, res) => {
    try {
      const entryData = insertCravingEntrySchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date || new Date())
      });
      const entry = await storage.createCravingEntry(entryData);
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/craving-entries", requireAuth, async (req: any, res) => {
    try {
      const { startDate, endDate } = req.query;
      const entries = await storage.getUserCravingEntries(
        req.user.id,
        startDate ? new Date(startDate) : undefined,
        endDate ? new Date(endDate) : undefined
      );
      res.json(entries);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // AI Coach routes
  app.post("/api/ai-chat", requireAuth, async (req: any, res) => {
    try {
      const { message } = req.body;
      
      // Check service usage for free tier users
      const usage = await storage.checkAndUpdateServiceUsage(req.user.id);
      
      if (!usage.canUse) {
        return res.status(403).json({ 
          error: 'You have used all 4 free services this week. Upgrade to Pro for unlimited access.',
          sessionsRemaining: 0
        });
      }

      const prompt = `You are SoulFuel's AI wellness coach specializing in mindful eating, sugar reduction, and emotional well-being. Provide supportive, actionable advice in a warm, encouraging tone. Keep responses concise and practical. Focus on healthy alternatives, mindfulness techniques, and positive reinforcement.

User message: ${message}`;

      const result = await genai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      const aiResponse = result.text || "I'm here to help you on your wellness journey.";
      
      const chatMessage = await storage.createChatMessage({
        userId: req.user.id,
        message,
        response: aiResponse,
        coachType: req.body.coachType || 'general'
      });

      // Increment service usage for free tier users
      if (req.user.subscriptionTier === 'free') {
        await storage.incrementServiceUsage(req.user.id);
      }

      res.json({ 
        response: aiResponse, 
        messageId: chatMessage.id,
        sessionsRemaining: usage.servicesRemaining - (req.user.subscriptionTier === 'free' ? 1 : 0)
      });
    } catch (error: any) {
      res.status(500).json({ error: "AI service temporarily unavailable" });
    }
  });

  app.get("/api/chat-history", requireAuth, async (req: any, res) => {
    try {
      const coachType = req.query.coachType as string;
      const messages = await storage.getUserChatMessages(req.user.id, coachType);
      res.json(messages);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Chat messages endpoint (for compatibility)
  app.get("/api/chat-messages", requireAuth, async (req: any, res) => {
    try {
      const coachType = req.query.coachType as string;
      const messages = await storage.getUserChatMessages(req.user.id, coachType);
      res.json(messages);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Chat endpoint alias for compatibility with test suite
  app.post("/api/chat", requireAuth, async (req: any, res) => {
    try {
      const { message } = req.body;
      
      // Check service usage for free tier users
      const usage = await storage.checkAndUpdateServiceUsage(req.user.id);
      
      if (!usage.canUse) {
        return res.status(403).json({ 
          error: 'You have used all 4 free services this week. Upgrade to Pro for unlimited access.',
          sessionsRemaining: 0
        });
      }

      const genai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

      const prompt = `You are SoulFuel's AI wellness coach specializing in mindful eating, sugar reduction, and emotional well-being. Provide supportive, actionable advice in a warm, encouraging tone. Keep responses concise and practical. Focus on healthy alternatives, mindfulness techniques, and positive reinforcement.

User message: ${message}`;

      const result = await genai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      const aiResponse = result.text || "I'm here to help you on your wellness journey.";
      
      const chatMessage = await storage.createChatMessage({
        userId: req.user.id,
        message,
        response: aiResponse,
        coachType: req.body.coachType || 'general'
      });

      // Increment service usage for free tier users
      if (req.user.subscriptionTier === 'free') {
        await storage.incrementServiceUsage(req.user.id);
      }

      res.json({ 
        response: aiResponse, 
        messageId: chatMessage.id,
        sessionsRemaining: usage.servicesRemaining - (req.user.subscriptionTier === 'free' ? 1 : 0)
      });
    } catch (error: any) {
      res.status(500).json({ error: "AI service temporarily unavailable" });
    }
  });

  app.get("/api/ai-coaching-status", requireAuth, async (req: any, res) => {
    try {
      const usage = await storage.checkAndUpdateServiceUsage(req.user.id);
      res.json({
        canUseAI: usage.canUse,
        sessionsRemaining: usage.servicesRemaining,
        subscriptionTier: req.user.subscriptionTier
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Soul Check-in with Emotional AI Companion
  app.post("/api/soul-checkin", requireAuth, async (req: any, res) => {
    try {
      const { message, timeOfDay } = req.body;
      
      if (!message || message.trim().length === 0) {
        return res.status(400).json({ error: "Message is required for soul check-in" });
      }

      // Check service usage limits for free tier
      if (req.user.subscriptionTier === 'free') {
        const usage = await storage.checkAndUpdateServiceUsage(req.user.id);
        if (!usage.canUse) {
          return res.status(403).json({ 
            error: "You've reached your 4 free services this week. Upgrade to Pro for unlimited access.",
            sessionsRemaining: usage.servicesRemaining
          });
        }
      }

      const soulResponse = await emotionalAICompanion.soulCheckIn(
        req.user.id, 
        message, 
        timeOfDay
      );

      // Store this as a chat message for history
      await storage.createChatMessage({
        userId: req.user.id,
        message: message,
        response: soulResponse.response,
        coachType: 'soul-companion'
      });

      // Increment service usage for free tier
      if (req.user.subscriptionTier === 'free') {
        await storage.incrementServiceUsage(req.user.id);
      }

      res.json(soulResponse);
    } catch (error: any) {
      console.error('Soul check-in error:', error);
      res.status(500).json({ error: "Soul companion temporarily unavailable" });
    }
  });

  // Get power moments from soul history
  app.get("/api/soul-power-moment", requireAuth, async (req: any, res) => {
    try {
      const powerMoment = await emotionalAICompanion.recallPowerMoment(req.user.id);
      
      if (!powerMoment) {
        return res.json({ 
          message: "Keep building your soul journey! Your first power moments are being created with each positive choice you make." 
        });
      }

      res.json(powerMoment);
    } catch (error: any) {
      console.error('Power moment recall error:', error);
      res.status(500).json({ error: "Unable to recall power moment" });
    }
  });

  // Get craving pattern predictions
  app.get("/api/soul-craving-insights", requireAuth, async (req: any, res) => {
    try {
      const insights = await emotionalAICompanion.detectCravingPatterns(req.user.id);
      res.json(insights);
    } catch (error: any) {
      console.error('Craving insights error:', error);
      res.status(500).json({ error: "Unable to generate craving insights" });
    }
  });

  // AI Status endpoint for compatibility
  app.get("/api/ai-status", requireAuth, async (req: any, res) => {
    try {
      const usage = await storage.checkAndUpdateServiceUsage(req.user.id);
      res.json({
        canUseAI: usage.canUse,
        servicesRemaining: usage.servicesRemaining,
        subscriptionTier: req.user.subscriptionTier
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Weekly Goals endpoints
  app.get("/api/weekly-goals", requireAuth, async (req: any, res) => {
    try {
      const weekStart = req.query.weekStart ? new Date(req.query.weekStart) : new Date();
      const goal = await storage.getUserWeeklyGoal(req.user.id, weekStart);
      res.json(goal || {});
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/weekly-goals", requireAuth, async (req: any, res) => {
    try {
      const goalData = insertWeeklyGoalSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      const goal = await storage.createWeeklyGoal(goalData);
      res.json(goal);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Craving Prediction endpoint
  app.get("/api/craving-prediction", requireAuth, async (req: any, res) => {
    try {
      const predictions = await emotionalAICompanion.detectCravingPatterns(req.user.id);
      res.json(predictions);
    } catch (error: any) {
      console.error('Craving prediction error:', error);
      res.status(500).json({ error: "Unable to generate predictions" });
    }
  });

  // Food analysis routes
  app.post("/api/analyze-food", requireAuth, async (req: any, res) => {
    try {
      const { foodDescription } = req.body;
      
      if (req.user.subscriptionTier === 'free') {
        return res.status(403).json({ error: 'Food analysis requires Pro subscription' });
      }

      const prompt = `You are a nutrition expert analyzing food for sugar content and healthiness. Analyze this food: ${foodDescription}

Respond with JSON containing:
- foodName (string): name of the food
- sugarContent (number): grams of sugar
- isHealthy (string): 'healthy', 'moderate', or 'unhealthy'
- analysis (object): detailed breakdown with calories, protein, fiber, and recommendations

Format as valid JSON only.`;

      const result = await genai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              foodName: { type: "string" },
              sugarContent: { type: "number" },
              isHealthy: { type: "string" },
              analysis: { type: "object" },
            },
            required: ["foodName", "sugarContent", "isHealthy", "analysis"],
          },
        },
      });

      const analysis = JSON.parse(result.text || '{}');
      
      // Map the old response format to new schema
      const healthScore = analysis.isHealthy === 'healthy' ? 'A' : 
                         analysis.isHealthy === 'moderate' ? 'C' : 'D';
      
      const foodAnalysis = await storage.createFoodAnalysis({
        userId: req.user.id,
        foodName: analysis.foodName || foodDescription,
        healthScore: healthScore,
        analysisMethod: 'text',
        confidence: 0.8,
        sugarContent: analysis.sugarContent || 0,
        isUltraProcessed: analysis.sugarContent > 10, // Simple heuristic
        ingredients: [],
        redFlags: analysis.sugarContent > 15 ? ['High sugar content'] : [],
        recommendations: analysis.analysis?.recommendations ? [analysis.analysis.recommendations] : ['Consider healthier alternatives']
      });

      res.json(foodAnalysis);
    } catch (error: any) {
      res.status(500).json({ error: "Food analysis service temporarily unavailable" });
    }
  });

  app.get("/api/food-analyses", requireAuth, async (req: any, res) => {
    try {
      const analyses = await storage.getUserFoodAnalyses(req.user.id);
      res.json(analyses);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Enhanced Recipe routes with filtering
  app.get("/api/recipes", async (req, res) => {
    try {
      const { mealType, dietaryTypes, healthFocus, tags, limit, offset } = req.query;
      
      const filters = {
        mealType: mealType as string,
        dietaryTypes: Array.isArray(dietaryTypes) ? dietaryTypes as string[] : dietaryTypes ? [dietaryTypes as string] : undefined,
        healthFocus: Array.isArray(healthFocus) ? healthFocus as string[] : healthFocus ? [healthFocus as string] : undefined,
        tags: Array.isArray(tags) ? tags as string[] : tags ? [tags as string] : undefined,
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      };
      
      const recipes = await storage.getRecipes(filters);
      res.json(recipes);
    } catch (error: any) {
      console.error("Error getting recipes:", error);
      res.status(500).json({ message: "Failed to get recipes" });
    }
  });

  // Get single recipe
  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const recipeId = parseInt(req.params.id);
      const recipe = await storage.getRecipeById(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      res.json(recipe);
    } catch (error: any) {
      console.error("Error getting recipe:", error);
      res.status(500).json({ message: "Failed to get recipe" });
    }
  });

  // Recipe interactions (bookmark, tried it)
  app.post("/api/recipes/interactions", requireAuth, async (req: any, res) => {
    try {
      const { recipeId, isBookmarked, hasTriedIt, rating, notes, triedAt } = req.body;
      const userId = req.user.id;

      // Check if interaction already exists
      const existingInteraction = await storage.getUserRecipeInteraction(userId, recipeId);
      
      if (existingInteraction) {
        // Update existing interaction
        const updatedInteraction = await storage.updateRecipeInteraction(userId, recipeId, {
          isBookmarked: isBookmarked !== undefined ? isBookmarked : existingInteraction.isBookmarked,
          hasTriedIt: hasTriedIt !== undefined ? hasTriedIt : existingInteraction.hasTriedIt,
          rating: rating !== undefined ? rating : existingInteraction.rating,
          notes: notes !== undefined ? notes : existingInteraction.notes,
          triedAt: triedAt ? new Date(triedAt) : existingInteraction.triedAt,
        });
        res.json(updatedInteraction);
      } else {
        // Create new interaction
        const newInteraction = await storage.createRecipeInteraction({
          userId,
          recipeId,
          isBookmarked: isBookmarked || false,
          hasTriedIt: hasTriedIt || false,
          rating,
          notes,
          triedAt: triedAt ? new Date(triedAt) : undefined,
        });
        res.json(newInteraction);
      }
    } catch (error: any) {
      console.error("Error handling recipe interaction:", error);
      res.status(500).json({ message: "Failed to update recipe interaction" });
    }
  });

  // Weekly goals routes
  app.post("/api/weekly-goals", requireAuth, async (req: any, res) => {
    try {
      const goalData = insertWeeklyGoalSchema.parse({
        ...req.body,
        userId: req.user.id,
        weekStartDate: new Date(req.body.weekStartDate)
      });
      const goal = await storage.createWeeklyGoal(goalData);
      res.json(goal);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/weekly-goals/:weekStart", requireAuth, async (req: any, res) => {
    try {
      const weekStart = new Date(req.params.weekStart);
      const goal = await storage.getUserWeeklyGoal(req.user.id, weekStart);
      res.json(goal || null);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Analytics route
  app.get("/api/analytics", requireAuth, async (req: any, res) => {
    try {
      const now = new Date();
      const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
      const weekEnd = new Date(weekStart.getTime() + 7 * 24 * 60 * 60 * 1000);

      const [sugarEntries, moodEntries, cravingEntries] = await Promise.all([
        storage.getUserSugarEntries(req.user.id, weekStart, weekEnd),
        storage.getUserMoodEntries(req.user.id, weekStart, weekEnd),
        storage.getUserCravingEntries(req.user.id, weekStart, weekEnd)
      ]);

      const totalSugar = sugarEntries.reduce((sum, entry) => sum + entry.amount, 0);
      const avgSugar = sugarEntries.length > 0 ? totalSugar / 7 : 0;
      const moodCheckIns = moodEntries.length;
      const avgCraving = cravingEntries.length > 0 
        ? cravingEntries.reduce((sum, entry) => sum + entry.intensity, 0) / cravingEntries.length 
        : 0;

      res.json({
        weeklyStats: {
          totalSugar,
          avgSugar,
          moodCheckIns,
          avgCraving,
          sugarEntries: sugarEntries.length,
          cravingEntries: cravingEntries.length
        },
        entries: {
          sugar: sugarEntries,
          mood: moodEntries,
          cravings: cravingEntries
        }
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Register food analysis routes
  registerFoodAnalysisRoutes(app, requireAuth);

  // Data Export and Customer Service Routes
  app.post("/api/export-user-data", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Collect all user data
      const [sugarEntries, moodEntries, cravingEntries, chatMessages, foodAnalyses] = await Promise.all([
        storage.getUserSugarEntries(req.user.id),
        storage.getUserMoodEntries(req.user.id),
        storage.getUserCravingEntries(req.user.id),
        storage.getUserChatMessages(req.user.id, undefined, 1000),
        storage.getUserFoodAnalyses(req.user.id, 1000)
      ]);

      const totalDataPoints = sugarEntries.length + moodEntries.length + 
                             cravingEntries.length + chatMessages.length + foodAnalyses.length;

      const userData = {
        user,
        sugarEntries,
        moodEntries,
        cravingEntries,
        chatMessages,
        foodAnalyses,
        exportDate: new Date().toISOString(),
        totalDataPoints
      };

      // Use mock service for development
      const { mockGoogleSheetsService } = await import('./services/mock-google-sheets-service');
      const spreadsheetUrl = await mockGoogleSheetsService.exportUserData(userData);
      
      const exportId = `export_${req.user.id}_${Date.now()}`;
      const validUntil = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      res.json({
        success: true,
        exportId,
        downloadUrl: spreadsheetUrl,
        totalDataPoints,
        categories: ['User Profile', 'Sugar Tracking', 'Mood Tracking', 'Craving Tracking', 'AI Conversations', 'Food Analysis'],
        generatedAt: new Date().toISOString(),
        validUntil: validUntil.toISOString(),
        message: "Your data export has been prepared and will be available for 30 days."
      });
    } catch (error: any) {
      console.error("Data export error:", error);
      res.status(500).json({ 
        error: "Failed to export user data",
        details: error.message 
      });
    }
  });

  app.get("/api/user-data-summary", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const [sugarCount, moodCount, cravingCount, chatCount, analysisCount] = await Promise.all([
        storage.getUserSugarEntries(req.user.id).then(entries => entries.length),
        storage.getUserMoodEntries(req.user.id).then(entries => entries.length),
        storage.getUserCravingEntries(req.user.id).then(entries => entries.length),
        storage.getUserChatMessages(req.user.id).then(messages => messages.length),
        storage.getUserFoodAnalyses(req.user.id).then(analyses => analyses.length)
      ]);

      const summary = {
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          subscriptionTier: user.subscriptionTier,
          createdAt: user.createdAt,
          weeklyServicesUsed: user.weeklyServicesUsed,
          lastServicesReset: user.lastServicesReset
        },
        dataCounts: {
          sugarEntries: sugarCount,
          moodEntries: moodCount,
          cravingEntries: cravingCount,
          chatMessages: chatCount,
          foodAnalyses: analysisCount,
          total: sugarCount + moodCount + cravingCount + chatCount + analysisCount
        },
        lastActivity: {
          estimated: new Date()
        }
      };

      res.json(summary);
    } catch (error: any) {
      console.error("User data summary error:", error);
      res.status(500).json({ 
        error: "Failed to get user data summary",
        details: error.message 
      });
    }
  });

  // Customer Service Data Export (admin only)
  app.post("/api/admin/export-customer-data", async (req, res) => {
    try {
      // In production, add proper admin authentication
      const { userId, requestedBy } = req.body;
      
      if (!userId || !requestedBy) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const user = await storage.getUser(parseInt(userId));
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Get last 90 days of data for customer service
      const startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
      const endDate = new Date();

      const [sugarEntries, moodEntries, cravingEntries, chatMessages, foodAnalyses] = await Promise.all([
        storage.getUserSugarEntries(parseInt(userId), startDate, endDate),
        storage.getUserMoodEntries(parseInt(userId), startDate, endDate),
        storage.getUserCravingEntries(parseInt(userId), startDate, endDate),
        storage.getUserChatMessages(parseInt(userId), undefined, 100),
        storage.getUserFoodAnalyses(parseInt(userId), 50)
      ]);

      const totalDataPoints = sugarEntries.length + moodEntries.length + 
                             cravingEntries.length + chatMessages.length + foodAnalyses.length;

      const userData = {
        user,
        sugarEntries,
        moodEntries,
        cravingEntries,
        chatMessages,
        foodAnalyses,
        exportDate: new Date().toISOString(),
        totalDataPoints
      };

      // Use mock service for development
      const { mockGoogleSheetsService } = await import('./services/mock-google-sheets-service');
      const spreadsheetUrl = await mockGoogleSheetsService.exportUserData(userData);
      
      // Log the admin export
      await mockGoogleSheetsService.logSystemEvent('admin_data_export', {
        userId: parseInt(userId),
        requestedBy,
        totalDataPoints,
        spreadsheetUrl
      }, 'info');

      const exportId = `admin_export_${userId}_${Date.now()}`;
      
      res.json({
        success: true,
        exportId,
        downloadUrl: spreadsheetUrl,
        totalDataPoints,
        categories: ['User Profile', 'Sugar Tracking', 'Mood Tracking', 'Craving Tracking', 'AI Conversations', 'Food Analysis'],
        generatedAt: new Date().toISOString()
      });
    } catch (error: any) {
      console.error("Customer service export error:", error);
      res.status(500).json({ 
        error: "Failed to export customer data",
        details: error.message 
      });
    }
  });

  // Game Progress Routes
  app.get("/api/game-progress", requireAuth, async (req, res) => {
    try {
      const user = req.user!;
      const progress = await storage.getUserGameProgress(user.id);
      res.json(progress);
    } catch (error) {
      console.error("Game progress fetch error:", error);
      res.status(500).json({ error: "Failed to fetch game progress" });
    }
  });

  app.post("/api/game-progress", requireAuth, async (req, res) => {
    try {
      const user = req.user!;
      const { gameId, score, level, achievements } = req.body;
      
      const progress = await storage.updateGameProgress(user.id, {
        gameId,
        score,
        level,
        achievements
      });
      
      res.json(progress);
    } catch (error) {
      console.error("Game progress update error:", error);
      res.status(500).json({ error: "Failed to update game progress" });
    }
  });

  // Register wearable integration routes
  registerWearableIntegrationRoutes(app, requireAuth);
  
  // Register predictive wellness routes
  registerPredictiveWellnessRoutes(app, requireAuth);

  // CraveClock API - Craving prediction timeline
  app.get('/api/craving-predictions', requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      
      // Get recent data for analysis
      const recentSugar = await storage.getUserSugarEntries(userId, 
        new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      );
      const recentMood = await storage.getUserMoodEntries(userId,
        new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      );
      const recentCravings = await storage.getUserCravingEntries(userId,
        new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      );
      
      // Analyze patterns to predict craving times
      const currentHour = new Date().getHours();
      const predictions = [];
      
      // Common craving patterns based on time
      const riskTimes = [
        { hour: 15, probability: 75, triggers: ['Energy crash', 'Afternoon stress'], severity: 'medium' },
        { hour: 21, probability: 60, triggers: ['Evening boredom', 'End of day fatigue'], severity: 'low' },
        { hour: 11, probability: 45, triggers: ['Pre-lunch hunger', 'Morning stress'], severity: 'low' }
      ];
      
      const upcoming = riskTimes.map(risk => {
        const targetTime = new Date();
        targetTime.setHours(risk.hour, 0, 0, 0);
        if (targetTime.getTime() <= Date.now()) {
          targetTime.setDate(targetTime.getDate() + 1);
        }
        
        const timeUntil = Math.floor((targetTime.getTime() - Date.now()) / 60000);
        
        return {
          time: targetTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          probability: risk.probability,
          triggers: risk.triggers,
          preventionTips: [
            'Drink a large glass of water',
            'Take 5 deep breaths',
            'Play a quick game',
            'Journal your feelings'
          ],
          severity: risk.severity,
          timeUntil
        };
      }).sort((a, b) => a.timeUntil - b.timeUntil);
      
      const nextPrediction = upcoming[0];
      
      res.json({
        nextPrediction,
        upcoming: upcoming.slice(0, 3),
        accuracy: '73%',
        lastUpdated: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('Craving prediction error:', error);
      res.status(500).json({ message: 'Failed to generate craving predictions' });
    }
  });

  // Voice Soul Talk API
  app.post('/api/soul-talk', requireAuth, async (req: any, res) => {
    try {
      const { message, companionVoice, companionName, isVoiceInput } = req.body;
      const userId = req.user.id;
      
      // Analyze sentiment and detect mood
      const moodKeywords = {
        sad: ['sad', 'depressed', 'down', 'crying', 'tears'],
        anxious: ['anxious', 'worried', 'nervous', 'stressed', 'panic'],
        angry: ['angry', 'mad', 'frustrated', 'annoyed', 'furious'],
        craving: ['craving', 'want', 'need', 'urge', 'tempted']
      };
      
      let detectedMood = 'neutral';
      const lowerMessage = message.toLowerCase();
      for (const [mood, keywords] of Object.entries(moodKeywords)) {
        if (keywords.some(keyword => lowerMessage.includes(keyword))) {
          detectedMood = mood;
          break;
        }
      }
      
      // Generate personalized response based on companion personality
      let responseStyle = '';
      switch (companionVoice) {
        case 'nurturing':
          responseStyle = 'warm, caring, and motherly';
          break;
        case 'spiritual':
          responseStyle = 'wise, mindful, and spiritually grounded';
          break;
        case 'energetic':
          responseStyle = 'enthusiastic, motivating, and upbeat';
          break;
        default:
          responseStyle = 'balanced, supportive, and understanding';
      }
      
      const prompt = `You are ${companionName}, an AI soul companion with a ${responseStyle} personality. 
      The user just said: "${message}"
      
      Their detected mood seems to be: ${detectedMood}
      This was shared via ${isVoiceInput ? 'voice input' : 'text'}.
      
      Respond with deep empathy and practical support. Keep it conversational and personal.
      Focus on:
      1. Validating their feelings
      2. Offering gentle guidance
      3. Suggesting a small, actionable step
      
      Keep your response to 2-3 sentences, warm and authentic.`;
      
      // Use Gemini AI for response (using correct API structure)
      const aiResponse = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' + process.env.GEMINI_API_KEY, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }]
        })
      });
      
      const aiData = await aiResponse.json();
      const response = aiData.candidates?.[0]?.content?.parts?.[0]?.text || 
        `I hear you, and I want you to know that what you're feeling is completely valid. You're not alone in this journey, and every moment of awareness like this is actually a step forward. Would you like to try a gentle breathing exercise together?`;
      
      // Store the conversation
      await storage.createChatMessage({
        userId,
        message,
        response,
        isVoiceInput,
        coachType: 'soul-companion'
      });
      
      res.json({
        response,
        detectedMood,
        companionName,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('Soul talk error:', error);
      res.status(500).json({ 
        message: 'Unable to connect with soul companion',
        response: "I'm here for you, even when technology isn't perfect. Your feelings matter, and you're taking a brave step by reaching out. Take a deep breath with me - you've got this."
      });
    }
  });

  // Crisis Intervention API
  app.post('/api/crisis-intervention', requireAuth, async (req: any, res) => {
    try {
      const { tier, reason, urgencyLevel } = req.body;
      const userId = req.user.id;
      
      // Log crisis intervention
      console.log(`Crisis intervention activated - User: ${userId}, Tier: ${tier}, Urgency: ${urgencyLevel}, Reason: ${reason}`);
      
      let message = '';
      switch (tier) {
        case 1:
          message = 'Emotional support activated. Your AI companion is ready to listen.';
          break;
        case 2:
          message = 'Emergency games launched. Focus on the present moment.';
          break;
        case 3:
          message = 'Crisis alert sent to your support network. Help is on the way.';
          break;
        default:
          message = 'Crisis support system activated.';
      }
      
      res.json({
        success: true,
        message,
        tier,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('Crisis intervention error:', error);
      res.status(500).json({ 
        message: 'Crisis support logged. You are not alone.',
        success: false 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
