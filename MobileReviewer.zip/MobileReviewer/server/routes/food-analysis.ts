import type { Express } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { geminiAIService } from "../services/gemini-ai";
import { storage as dbStorage } from "../storage";

// Configure multer for image uploads
const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/food-images';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage: multerStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only JPEG, PNG, and JPG images are allowed'));
    }
  }
});

export function registerFoodAnalysisRoutes(app: Express, requireAuth: any) {
  
  // Check scan usage endpoint
  app.get("/api/scan-usage", requireAuth, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const user = await dbStorage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Reset weekly services if needed
      await dbStorage.resetWeeklyServicesIfNeeded(userId);
      const updatedUser = await dbStorage.getUser(userId);

      const isPro = updatedUser?.subscriptionTier === 'pro' || updatedUser?.subscriptionTier === 'gold' || updatedUser?.subscriptionTier === 'platinum' || updatedUser?.subscriptionTier === 'diamond';
      const maxServices = 4;
      const servicesUsed = updatedUser?.weeklyServicesUsed || 0;
      const servicesRemaining = isPro ? -1 : Math.max(0, maxServices - servicesUsed);
      
      res.json({
        canScan: isPro || servicesRemaining > 0,
        scansRemaining: servicesRemaining,
        isPro,
        scansUsed: servicesUsed
      });
    } catch (error: any) {
      console.error("Error checking scan usage:", error);
      res.status(500).json({ error: "Failed to check scan usage" });
    }
  });
  
  // Analyze food by image
  app.post('/api/analyze-food-image', requireAuth, upload.single('foodImage'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No image file provided' });
      }

      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Check service usage before proceeding
      const serviceUsage = await dbStorage.checkAndUpdateServiceUsage(userId);
      if (!serviceUsage.canUse) {
        return res.status(429).json({ 
          error: 'Service limit reached',
          message: 'You have reached your 4 weekly service limit. Upgrade to Pro for unlimited access.',
          scansRemaining: serviceUsage.servicesRemaining
        });
      }

      const imagePath = req.file.path;
      
      // Analyze with Gemini AI + USDA
      const analysis = await geminiAIService.analyzeImageBasedFood(imagePath);
      
      // Increment service usage after successful analysis
      await dbStorage.incrementServiceUsage(userId);
      
      // Clean up uploaded file
      try {
        fs.unlinkSync(imagePath);
      } catch (error) {
        console.warn('Failed to delete uploaded file:', error);
      }

      res.json({
        success: true,
        analysis: {
          foodName: analysis.foodName,
          healthScore: analysis.healthScore,
          isUltraProcessed: analysis.isUltraProcessed,
          redFlags: analysis.redFlags,
          recommendations: analysis.healthySuggestions,
          coachingMessage: analysis.coachingMessage,
          confidence: analysis.confidence,
          nutritionFacts: analysis.nutritionAnalysis?.nutritionFacts
        }
      });

    } catch (error) {
      console.error('Food image analysis error:', error);
      
      // Clean up uploaded file on error
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (cleanupError) {
          console.warn('Failed to delete uploaded file after error:', cleanupError);
        }
      }

      res.status(500).json({ 
        error: 'Failed to analyze food image',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Analyze food by barcode
  app.post('/api/analyze-food-barcode', requireAuth, async (req, res) => {
    try {
      const { barcode } = req.body;
      
      if (!barcode) {
        return res.status(400).json({ error: 'Barcode is required' });
      }

      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Check service usage before proceeding
      const serviceUsage = await dbStorage.checkAndUpdateServiceUsage(userId);
      if (!serviceUsage.canUse) {
        return res.status(429).json({ 
          error: 'Service limit reached',
          message: 'You have reached your 4 weekly service limit. Upgrade to Pro for unlimited access.',
          scansRemaining: serviceUsage.servicesRemaining
        });
      }

      // Analyze with USDA + Gemini AI
      const analysis = await geminiAIService.analyzeBarcodeFood(barcode);
      
      // Increment service usage after successful analysis
      await dbStorage.incrementServiceUsage(userId);

      res.json({
        success: true,
        analysis: {
          foodName: analysis.foodName,
          brandOwner: analysis.nutritionAnalysis?.brandOwner,
          healthScore: analysis.healthScore,
          isUltraProcessed: analysis.isUltraProcessed,
          redFlags: analysis.redFlags,
          recommendations: analysis.healthySuggestions,
          coachingMessage: analysis.coachingMessage,
          confidence: analysis.confidence,
          nutritionFacts: analysis.nutritionAnalysis?.nutritionFacts,
          ingredients: analysis.nutritionAnalysis?.ingredients
        }
      });

    } catch (error) {
      console.error('Barcode analysis error:', error);
      res.status(500).json({ 
        error: 'Failed to analyze barcode',
        details: error instanceof Error ? error.message : 'Product not found or analysis failed'
      });
    }
  });

  // Analyze food by text description (main endpoint)
  app.post('/api/analyze-food-text', requireAuth, async (req, res) => {
    try {
      const { foodDescription } = req.body;
      
      if (!foodDescription) {
        return res.status(400).json({ error: 'Food description is required' });
      }

      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Check service usage before proceeding
      const serviceUsage = await dbStorage.checkAndUpdateServiceUsage(userId);
      if (!serviceUsage.canUse) {
        return res.status(429).json({ 
          error: 'Service limit reached',
          message: 'You have reached your 4 weekly service limit. Upgrade to Pro for unlimited access.',
          scansRemaining: serviceUsage.servicesRemaining
        });
      }

      // Analyze with Gemini AI + USDA
      const analysis = await geminiAIService.analyzeTextBasedFood(foodDescription);
      
      // Increment service usage after successful analysis
      await dbStorage.incrementServiceUsage(userId);

      res.json({
        success: true,
        analysis: {
          foodName: analysis.foodName,
          healthScore: analysis.healthScore,
          isUltraProcessed: analysis.isUltraProcessed,
          redFlags: analysis.redFlags,
          recommendations: analysis.healthySuggestions,
          coachingMessage: analysis.coachingMessage,
          confidence: analysis.confidence,
          nutritionFacts: analysis.nutritionAnalysis?.nutritionFacts
        }
      });

    } catch (error) {
      console.error('Text analysis error:', error);
      res.status(500).json({ 
        error: 'Failed to analyze food description',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Alias for compatibility with test suite
  app.post('/api/food-analysis/text', requireAuth, async (req, res) => {
    try {
      const { description } = req.body;
      
      if (!description) {
        return res.status(400).json({ error: 'Food description is required' });
      }

      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Check service usage before proceeding
      const serviceUsage = await dbStorage.checkAndUpdateServiceUsage(userId);
      if (!serviceUsage.canUse) {
        return res.status(429).json({ 
          error: 'Service limit reached',
          message: 'You have reached your 4 weekly service limit. Upgrade to Pro for unlimited access.',
          scansRemaining: serviceUsage.servicesRemaining
        });
      }

      // Analyze with Gemini AI + USDA
      const analysis = await geminiAIService.analyzeTextBasedFood(description);
      
      // Increment service usage after successful analysis
      await dbStorage.incrementServiceUsage(userId);

      res.json({
        success: true,
        analysis: {
          foodName: analysis.foodName,
          healthScore: analysis.healthScore,
          isUltraProcessed: analysis.isUltraProcessed,
          redFlags: analysis.redFlags,
          recommendations: analysis.healthySuggestions,
          coachingMessage: analysis.coachingMessage,
          confidence: analysis.confidence,
          nutritionFacts: analysis.nutritionAnalysis?.nutritionFacts
        }
      });

    } catch (error) {
      console.error('Text analysis error:', error);
      res.status(500).json({ 
        error: 'Failed to analyze food description',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
}