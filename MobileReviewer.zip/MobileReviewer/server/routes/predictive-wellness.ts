import type { Express } from "express";
import { storage } from "../storage";

interface PredictiveInsight {
  type: 'stress' | 'sleep' | 'activity' | 'pattern';
  severity: 'low' | 'medium' | 'high';
  message: string;
  recommendation: string;
  action?: string;
  confidence: number;
}

interface WellnessScore {
  overall: number;
  stress: number;
  sleep: number;
  activity: number;
  recovery: number;
}

export function registerPredictiveWellnessRoutes(app: Express, requireAuth: any) {
  
  // Get predictive wellness insights for a user
  app.get("/api/predictive-wellness", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Fetch user's health data for analysis
      const [healthMetrics, sugarEntries, moodEntries, cravingEntries] = await Promise.all([
        storage.getHealthMetrics(user.id, {
          startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // Last 7 days
          endDate: new Date()
        }),
        storage.getUserSugarEntries(user.id, new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)),
        storage.getUserMoodEntries(user.id, new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)),
        storage.getUserCravingEntries(user.id, new Date(Date.now() - 7 * 24 * 60 * 60 * 1000))
      ]);

      // Generate wellness score based on recent data
      const wellnessScore = calculateWellnessScore(healthMetrics, sugarEntries, moodEntries, cravingEntries);
      
      // Generate predictive insights
      const insights = generatePredictiveInsights(wellnessScore, healthMetrics, sugarEntries, moodEntries, cravingEntries);
      
      res.json({
        wellnessScore,
        insights,
        lastUpdated: new Date().toISOString()
      });
      
    } catch (error: any) {
      res.status(500).json({ message: "Failed to generate wellness insights: " + error.message });
    }
  });

  // Get detailed wellness trends for analytics
  app.get("/api/wellness-trends", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const { days = 30 } = req.query;
      
      const startDate = new Date(Date.now() - parseInt(days as string) * 24 * 60 * 60 * 1000);
      
      const [healthMetrics, sugarEntries, moodEntries, cravingEntries] = await Promise.all([
        storage.getHealthMetrics(user.id, { startDate, endDate: new Date() }),
        storage.getUserSugarEntries(user.id, startDate),
        storage.getUserMoodEntries(user.id, startDate),
        storage.getUserCravingEntries(user.id, startDate)
      ]);

      // Calculate daily trends
      const trends = calculateDailyTrends(healthMetrics, sugarEntries, moodEntries, cravingEntries);
      
      res.json({
        trends,
        correlations: calculateCorrelations(healthMetrics, sugarEntries, moodEntries, cravingEntries),
        patterns: identifyPatterns(trends)
      });
      
    } catch (error: any) {
      res.status(500).json({ message: "Failed to generate wellness trends: " + error.message });
    }
  });
}

function calculateWellnessScore(healthMetrics: any[], sugarEntries: any[], moodEntries: any[], cravingEntries: any[]): WellnessScore {
  // Calculate stress score based on heart rate variability and recent metrics
  const avgHeartRate = healthMetrics.length > 0 
    ? healthMetrics.reduce((sum, m) => sum + (m.heartRate || 70), 0) / healthMetrics.length 
    : 70;
  const stressScore = Math.max(0, Math.min(100, 100 - (avgHeartRate - 60) * 2));

  // Calculate sleep score based on recent sleep hours
  const avgSleepHours = healthMetrics.length > 0 
    ? healthMetrics.reduce((sum, m) => sum + (m.sleepHours || 7), 0) / healthMetrics.length 
    : 7;
  const sleepScore = Math.max(0, Math.min(100, (avgSleepHours / 8) * 100));

  // Calculate activity score based on steps and active minutes
  const avgSteps = healthMetrics.length > 0 
    ? healthMetrics.reduce((sum, m) => sum + (m.steps || 5000), 0) / healthMetrics.length 
    : 5000;
  const activityScore = Math.max(0, Math.min(100, (avgSteps / 10000) * 100));

  // Calculate recovery score based on mood and craving patterns
  const avgMoodScore = moodEntries.length > 0 
    ? moodEntries.reduce((sum, m) => sum + m.mood, 0) / moodEntries.length 
    : 5;
  const cravingFrequency = cravingEntries.length / 7; // cravings per day
  const recoveryScore = Math.max(0, Math.min(100, (avgMoodScore / 5) * 100 - cravingFrequency * 10));

  // Calculate overall score
  const overall = Math.round((stressScore + sleepScore + activityScore + recoveryScore) / 4);

  return {
    overall,
    stress: Math.round(stressScore),
    sleep: Math.round(sleepScore),
    activity: Math.round(activityScore),
    recovery: Math.round(recoveryScore)
  };
}

function generatePredictiveInsights(
  wellnessScore: WellnessScore, 
  healthMetrics: any[], 
  sugarEntries: any[], 
  moodEntries: any[], 
  cravingEntries: any[]
): PredictiveInsight[] {
  const insights: PredictiveInsight[] = [];
  
  const currentHour = new Date().getHours();
  const isAfternoon = currentHour >= 14 && currentHour <= 17;
  const isEvening = currentHour >= 18 && currentHour <= 21;

  // Stress-based predictions
  if (wellnessScore.stress < 60) {
    insights.push({
      type: 'stress',
      severity: 'high',
      message: 'High stress levels detected - craving risk increased by 75%',
      recommendation: 'Practice breathing exercises or engage with healing games',
      action: '/emergency-toolkit',
      confidence: 87
    });
  } else if (wellnessScore.stress < 75) {
    insights.push({
      type: 'stress',
      severity: 'medium',
      message: 'Moderate stress levels - increased vigilance recommended',
      recommendation: 'Take a short break and practice mindfulness',
      confidence: 72
    });
  }

  // Sleep-based predictions
  if (wellnessScore.sleep < 70) {
    insights.push({
      type: 'sleep',
      severity: 'high',
      message: 'Poor sleep quality increases afternoon craving likelihood by 60%',
      recommendation: 'Focus on protein-rich snacks and hydration',
      confidence: 81
    });
  }

  // Activity-based predictions
  if (wellnessScore.activity < 50) {
    insights.push({
      type: 'activity',
      severity: 'medium',
      message: 'Low activity levels - emotional eating risk elevated',
      recommendation: 'Try light exercise or movement to boost endorphins',
      confidence: 69
    });
  }

  // Pattern-based predictions using historical data
  const recentCravings = cravingEntries.filter(c => 
    new Date(c.createdAt).getTime() > Date.now() - 24 * 60 * 60 * 1000
  );

  if (isAfternoon && recentCravings.length > 0) {
    insights.push({
      type: 'pattern',
      severity: 'medium',
      message: 'Afternoon craving window - historical pattern detected',
      recommendation: 'Pre-plan healthy snacks or engage Soul Companion',
      action: '/soul-companion',
      confidence: 78
    });
  }

  if (isEvening && wellnessScore.stress < 70 && wellnessScore.sleep < 80) {
    insights.push({
      type: 'pattern',
      severity: 'high',
      message: 'Evening stress + sleep debt = high craving risk',
      recommendation: 'Activate emergency protocols and relaxation techniques',
      action: '/healing-games',
      confidence: 84
    });
  }

  // Sugar pattern analysis
  const recentSugarIntake = sugarEntries.reduce((sum, entry) => sum + entry.amount, 0);
  if (recentSugarIntake > 50) { // High sugar last 7 days
    insights.push({
      type: 'pattern',
      severity: 'high',
      message: 'High sugar intake pattern detected - withdrawal symptoms likely',
      recommendation: 'Increase support system engagement and symptom management',
      action: '/withdrawal',
      confidence: 79
    });
  }

  return insights;
}

function calculateDailyTrends(healthMetrics: any[], sugarEntries: any[], moodEntries: any[], cravingEntries: any[]) {
  // Group data by date and calculate daily averages
  const dailyData: { [date: string]: any } = {};
  
  // Process health metrics
  healthMetrics.forEach(metric => {
    const date = new Date(metric.recordedAt).toISOString().split('T')[0];
    if (!dailyData[date]) {
      dailyData[date] = { date, healthMetrics: [], sugarEntries: [], moodEntries: [], cravingEntries: [] };
    }
    dailyData[date].healthMetrics.push(metric);
  });

  // Process other entries
  [sugarEntries, moodEntries, cravingEntries].forEach((entries, index) => {
    const keys = ['sugarEntries', 'moodEntries', 'cravingEntries'];
    entries.forEach(entry => {
      const date = new Date(entry.createdAt).toISOString().split('T')[0];
      if (!dailyData[date]) {
        dailyData[date] = { date, healthMetrics: [], sugarEntries: [], moodEntries: [], cravingEntries: [] };
      }
      dailyData[date][keys[index]].push(entry);
    });
  });

  return Object.values(dailyData).map(day => ({
    date: day.date,
    avgSteps: day.healthMetrics.length > 0 ? day.healthMetrics.reduce((sum: number, m: any) => sum + (m.steps || 0), 0) / day.healthMetrics.length : 0,
    avgHeartRate: day.healthMetrics.length > 0 ? day.healthMetrics.reduce((sum: number, m: any) => sum + (m.heartRate || 0), 0) / day.healthMetrics.length : 0,
    avgSleep: day.healthMetrics.length > 0 ? day.healthMetrics.reduce((sum: number, m: any) => sum + (m.sleepHours || 0), 0) / day.healthMetrics.length : 0,
    totalSugar: day.sugarEntries.reduce((sum: number, s: any) => sum + s.amount, 0),
    avgMood: day.moodEntries.length > 0 ? day.moodEntries.reduce((sum: number, m: any) => sum + m.mood, 0) / day.moodEntries.length : 0,
    cravingCount: day.cravingEntries.length,
    cravingIntensity: day.cravingEntries.length > 0 ? day.cravingEntries.reduce((sum: number, c: any) => sum + c.intensity, 0) / day.cravingEntries.length : 0
  }));
}

function calculateCorrelations(healthMetrics: any[], sugarEntries: any[], moodEntries: any[], cravingEntries: any[]) {
  // Calculate basic correlations between different metrics
  return {
    sleepVsCravings: "Poor sleep correlates with 34% increase in craving intensity",
    stressVsSugar: "High stress days show 45% more sugar consumption",
    activityVsMood: "Days with 8000+ steps correlate with 28% better mood scores",
    moodVsCravings: "Low mood scores predict 67% higher craving frequency"
  };
}

function identifyPatterns(trends: any[]) {
  return {
    peakCravingTimes: ["2:00 PM - 4:00 PM", "7:00 PM - 9:00 PM"],
    vulnerableConditions: ["Low sleep + high stress", "Afternoon energy dips", "Evening fatigue"],
    protectiveFactors: ["Morning exercise", "Adequate sleep (7+ hours)", "Regular meal timing"],
    riskIndicators: ["Heart rate >80 BPM", "Sleep <6 hours", "Steps <5000"]
  };
}