import { db } from "../db";
import { recipes } from "@shared/schema";
import { healthyRecipes } from "../data/healthy-recipes";

async function populateRecipes() {
  try {
    // Clear existing recipes
    await db.delete(recipes);
    console.log("Cleared existing recipes");

    // Insert all 50 healthy recipes
    const insertPromises = healthyRecipes.map(recipe => 
      db.insert(recipes).values({
        name: recipe.name,
        description: recipe.description,
        ingredients: recipe.ingredients,
        instructions: recipe.instructions,
        sugarContent: recipe.sugarContent,
        prepTime: recipe.prepTime,
        cookTime: recipe.cookTime,
        servings: recipe.servings,
        mealType: recipe.mealType,
        category: recipe.category,
        dietaryTypes: recipe.dietaryTypes,
        healthFocus: recipe.healthFocus,
        benefits: recipe.benefits,
        nutritionFacts: recipe.nutritionFacts,
        tags: { general: recipe.mealType },
        imageUrl: recipe.imageUrl || null
      })
    );

    await Promise.all(insertPromises);
    console.log(`Successfully inserted ${healthyRecipes.length} healthy recipes`);

    process.exit(0);
  } catch (error) {
    console.error("Error populating recipes:", error);
    process.exit(1);
  }
}

populateRecipes();