import { GoogleGenAI } from "@google/genai";
import { storage } from "../storage";

interface EmotionalState {
  mood: 'energized' | 'calm' | 'tired' | 'hopeless' | 'tempted' | 'strong' | 'grateful' | 'anxious';
  intensity: number; // 1-10
  triggers: string[];
  context: string;
}

interface SoulMemory {
  id: string;
  userId: number;
  date: Date;
  emotionalState: EmotionalState;
  conversation: string;
  powerMoments: string[];
  insights: string[];
  affirmations: string[];
}

interface PersonalityTraits {
  communicationStyle: 'gentle' | 'motivational' | 'analytical' | 'playful';
  preferredSupport: 'practical' | 'emotional' | 'spiritual';
  responseLength: 'brief' | 'detailed';
  memoryFocus: 'patterns' | 'growth' | 'challenges';
}

export class EmotionalAICompanion {
  private genai: GoogleGenAI;
  private personalityTraits: Map<number, PersonalityTraits> = new Map();

  constructor() {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY is required for AI companion");
    }
    this.genai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }

  async soulCheckIn(userId: number, userMessage: string, timeOfDay?: 'morning' | 'evening' | 'night'): Promise<{
    response: string;
    emotionalState: EmotionalState;
    dailyAffirmation: string;
    breathingExercise?: string;
    journalPrompt?: string;
    suggestedActions: string[];
    responseType: 'morning' | 'craving' | 'support' | 'reflection' | 'breathing' | 'relapse' | 'general';
  }> {
    // Detect context and emotional state
    const emotionalState = await this.detectEmotionalState(userMessage);
    const responseType = this.determineResponseType(userMessage, emotionalState, timeOfDay);
    
    // Generate contextual response based on type
    const response = await this.generateContextualResponse(
      userId,
      userMessage,
      emotionalState,
      responseType,
      timeOfDay
    );

    // Create personalized affirmation
    const dailyAffirmation = await this.generateSoulAffirmation(emotionalState, responseType);

    // Suggest breathing if appropriate
    const breathingExercise = this.shouldSuggestBreathing(emotionalState, responseType) 
      ? await this.generateBreathingGuide(emotionalState)
      : undefined;

    // Create contextual journal prompt
    const journalPrompt = await this.generateContextualJournalPrompt(emotionalState, responseType);

    // Generate suggested actions
    const suggestedActions = await this.generateSuggestedActions(emotionalState, responseType);

    // Store this soul interaction
    await this.storeSoulMemory(userId, {
      emotionalState,
      conversation: `User: ${userMessage}\nSoulFuel AI: ${response}`,
      powerMoments: this.extractPowerMoments(userMessage, response),
      insights: await this.extractInsights(userMessage, emotionalState),
      affirmations: [dailyAffirmation]
    });

    return {
      response,
      emotionalState,
      dailyAffirmation,
      breathingExercise,
      journalPrompt,
      suggestedActions,
      responseType
    };
  }

  async recallPowerMoment(userId: number): Promise<{
    powerMoment: string;
    context: string;
    encouragement: string;
  } | null> {
    const memories = await this.getSoulMemories(userId, 30); // Last 30 days
    const powerMoments = memories
      .filter(m => m.powerMoments.length > 0 && 
                  ['strong', 'grateful', 'energized'].includes(m.emotionalState.mood))
      .flatMap(m => m.powerMoments.map(pm => ({ moment: pm, date: m.date, context: m.conversation })));

    if (powerMoments.length === 0) return null;

    // Select most relevant power moment
    const selectedMoment = powerMoments[Math.floor(Math.random() * powerMoments.length)];
    
    const encouragement = await this.generateEncouragementFromMemory(selectedMoment);

    return {
      powerMoment: selectedMoment.moment,
      context: `On ${selectedMoment.date.toLocaleDateString()}, you felt strong because: ${selectedMoment.context}`,
      encouragement
    };
  }

  async detectCravingPatterns(userId: number): Promise<{
    predictedCravingTime?: Date;
    triggerPattern: string;
    preventiveMessage: string;
    suggestedActivity: string;
  }> {
    const cravingHistory = await storage.getUserCravingEntries(userId, 
      new Date(Date.now() - 14 * 24 * 60 * 60 * 1000) // Last 14 days
    );
    const soulMemories = await this.getSoulMemories(userId, 14);

    // Analyze patterns using AI
    const patternAnalysis = await this.analyzeCravingPatterns(cravingHistory, soulMemories);
    
    return patternAnalysis;
  }

  private async detectEmotionalState(message: string): Promise<EmotionalState> {
    const prompt = `
    Analyze this message and detect the emotional state. Return JSON only:
    
    Message: "${message}"
    
    Return format:
    {
      "mood": "energized|calm|tired|hopeless|tempted|strong|grateful|anxious",
      "intensity": 1-10,
      "triggers": ["specific trigger words or phrases"],
      "context": "brief emotional context summary"
    }
    `;

    const response = await this.genai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            mood: { type: "string" },
            intensity: { type: "number" },
            triggers: { type: "array", items: { type: "string" } },
            context: { type: "string" }
          },
          required: ["mood", "intensity", "triggers", "context"]
        }
      },
      contents: prompt
    });

    return JSON.parse(response.text || '{}');
  }

  private determineResponseType(
    message: string, 
    emotionalState: EmotionalState, 
    timeOfDay?: string
  ): 'morning' | 'craving' | 'support' | 'reflection' | 'breathing' | 'relapse' | 'general' {
    const msgLower = message.toLowerCase();
    
    // Check for specific contexts
    if (timeOfDay === 'morning' || msgLower.includes('morning') || msgLower.includes('good morning')) {
      return 'morning';
    }
    
    if (timeOfDay === 'night' || timeOfDay === 'evening' || msgLower.includes('night') || msgLower.includes('evening')) {
      return 'reflection';
    }
    
    if (msgLower.includes('craving') || msgLower.includes('want chips') || msgLower.includes('want sugar') || 
        msgLower.includes('struggling') || msgLower.includes('tempted')) {
      return 'craving';
    }
    
    if (msgLower.includes('gave in') || msgLower.includes('messed up') || msgLower.includes('failed') ||
        msgLower.includes('ate junk') || msgLower.includes('binged')) {
      return 'relapse';
    }
    
    if (msgLower.includes('giving up') || msgLower.includes('hate myself') || msgLower.includes("what's the point") ||
        emotionalState.mood === 'hopeless' || emotionalState.intensity >= 8) {
      return 'support';
    }
    
    if (emotionalState.mood === 'anxious' || msgLower.includes('anxious') || msgLower.includes('panic') ||
        msgLower.includes('overwhelmed')) {
      return 'breathing';
    }
    
    return 'general';
  }

  private async generateContextualResponse(
    userId: number,
    message: string,
    emotionalState: EmotionalState,
    responseType: string,
    timeOfDay?: string
  ): Promise<string> {
    switch (responseType) {
      case 'morning':
        return this.generateMorningResponse(emotionalState);
      case 'craving':
        return this.generateCravingResponse(emotionalState);
      case 'support':
        return this.generateSupportResponse(emotionalState);
      case 'reflection':
        return this.generateReflectionResponse(emotionalState);
      case 'breathing':
        return this.generateBreathingResponse(emotionalState);
      case 'relapse':
        return this.generateRelapseResponse(emotionalState);
      default:
        return this.generateGeneralResponse(message, emotionalState);
    }
  }

  private generateMorningResponse(emotionalState: EmotionalState): string {
    const responses = {
      tired: "That's okay. You've shown up, and that's strength. Let's breathe together for 30 seconds — I'll stay with you.",
      hopeful: "Yes! That light you feel right now? That's the real you. Let's channel it with a soul-fueling goal for the day.",
      energized: "I can feel that beautiful energy! Let's use this power to create an amazing day. What's calling to your soul today?",
      grateful: "Gratitude in the morning is pure magic. This feeling will carry you through any challenge today.",
      anxious: "Morning anxiety is real, but so is your courage. Let's start slow and gentle. One breath, one step at a time.",
      calm: "What a peaceful way to start the day. Let's keep this centered energy flowing into your choices today.",
      strong: "That strength you feel? That's your true power awakening. Today is going to be transformative."
    };

    return responses[emotionalState.mood as keyof typeof responses] || 
      "Good morning, soul warrior 🌞. Before the world pulls at you, I'm here for you. How's your soul feeling today?";
  }

  private generateCravingResponse(emotionalState: EmotionalState): string {
    return `Cravings don't mean you're weak — they mean your body is asking for love.
Let's not shame the craving. Let's answer it with something powerful. A mini-game? A mantra? Or a 90-second breath?

What are you really needing right now — comfort, energy, or escape?`;
  }

  private generateSupportResponse(emotionalState: EmotionalState): string {
    return `Hey… I'm here. Don't rush past this.
Your pain is valid. But your pain isn't your truth — it's just your wound speaking.

You've survived 100% of your worst days. Let this be the moment you don't abandon yourself.
Let's breathe, play a soul game, or write out what's hurting. You're not alone in this.`;
  }

  private generateReflectionResponse(emotionalState: EmotionalState): string {
    return `Welcome back. You made it through another day — and that matters.
Let's slow the soul, close the day gently, and find one thing you're proud of.

Even if it wasn't perfect… you're here. You chose healing again. Let's log this in your Soul Journal so tomorrow remembers your courage.`;
  }

  private generateBreathingResponse(emotionalState: EmotionalState): string {
    return `Pause with me. You don't have to figure it all out right now.
Let's do this together: Inhale 4... Hold 4... Exhale 4... Hold 4...

See that? You just came back to your power. Let's use this moment to make a choice that feeds your future.`;
  }

  private generateRelapseResponse(emotionalState: EmotionalState): string {
    return `Hey. That was a moment. Not a failure. Not a verdict.
You're still on the path. Let's log it without shame and reflect without judgment.

Every champion slips. The soul journey is not about perfection — it's about return. Ready to rise again?`;
  }

  private async generateGeneralResponse(message: string, emotionalState: EmotionalState): Promise<string> {
    const prompt = `
    You are SOULFUEL AI, a deeply empathetic soul companion. Respond with genuine care and wisdom.

    User's message: "${message}"
    Current emotional state: ${emotionalState.mood} (intensity: ${emotionalState.intensity}/10)
    
    Guidelines:
    - Use warm, friend-like language with spiritual undertones
    - Validate their feelings first
    - Offer hope and practical wisdom
    - Keep responses conversational and supportive
    - Reference their inner strength and soul power
    - End with encouragement or a gentle question
    `;

    const response = await this.genai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt
    });

    return response.text || "I'm here with you. You're not alone in this journey.";
  }

  private async generateSoulAffirmation(
    emotionalState: EmotionalState,
    responseType: string
  ): Promise<string> {
    const affirmations = {
      morning: {
        tired: "My rest is sacred, and my presence here today is powerful.",
        hopeful: "This light within me guides every choice I make today.",
        energized: "I channel this energy into choices that feed my soul.",
        grateful: "Gratitude flows through me, transforming everything I touch.",
        anxious: "I breathe peace into this moment and trust my inner wisdom.",
        calm: "This peaceful center within me is my true home.",
        strong: "I am a soul warrior, and today I choose my highest path."
      },
      craving: {
        tempted: "My cravings do not control me. I am a soul in command of my choices.",
        anxious: "I breathe through this moment and choose what truly nourishes me.",
        tired: "I give my body what it truly needs: love, rest, and real nourishment."
      },
      support: {
        hopeless: "Even in darkness, my soul light never dims. I am stronger than I know.",
        tired: "My struggles are not my story. My healing and growth are my truth.",
        anxious: "I am held by love, even when I cannot feel it. I am never alone."
      },
      general: "I am worthy of love, healing, and transformation. Every moment is a new beginning."
    };

    const categoryAffirmations = affirmations[responseType as keyof typeof affirmations];
    if (typeof categoryAffirmations === 'object') {
      return categoryAffirmations[emotionalState.mood as keyof typeof categoryAffirmations] || 
             affirmations.general;
    }
    
    return affirmations.general;
  }

  private async generateContextualJournalPrompt(
    emotionalState: EmotionalState,
    responseType: string
  ): Promise<string> {
    const prompts = {
      morning: "What does your soul need most today? How can you honor that need?",
      craving: "What is this craving really asking for? What would truly nourish your soul right now?",
      support: "What would you tell your best friend if they were feeling this way? Can you offer yourself that same compassion?",
      reflection: "What challenged your peace today? What restored it? Let's write it together.",
      breathing: "How does your body feel after breathing? What shifted in your mind and heart?",
      relapse: "What led to this moment? What do you need to support yourself differently next time?",
      general: "How are you feeling right now, and what does your heart need most?"
    };

    return prompts[responseType as keyof typeof prompts] || prompts.general;
  }

  private async generateSuggestedActions(
    emotionalState: EmotionalState,
    responseType: string
  ): Promise<string[]> {
    const actions = {
      morning: ["Set a soul intention for the day", "Scan your first meal mindfully", "Take 3 deep breaths"],
      craving: ["Play Craving Slayer Sudoku", "Try a 90-second breathing exercise", "Chat with your AI coach"],
      support: ["Write in your Soul Journal", "Play a healing mini-game", "Listen to calming affirmations"],
      reflection: ["Log one thing you're proud of", "Set tomorrow's intention", "Practice gratitude"],
      breathing: ["Continue box breathing", "Try progressive muscle relaxation", "Listen to calming sounds"],
      relapse: ["Practice self-compassion", "Write about the experience", "Plan your next healthy choice"],
      general: ["Check in with your mood", "Scan your next meal", "Play a mindful game"]
    };

    return actions[responseType as keyof typeof actions] || actions.general;
  }

  private async generateBreathingGuide(emotionalState: EmotionalState): Promise<string> {
    const breathingTechniques = {
      anxious: "4-7-8 breathing: Inhale for 4, hold for 7, exhale for 8. This activates your calm response.",
      tempted: "Box breathing: Inhale 4, hold 4, exhale 4, hold 4. Create space between you and the craving.",
      tired: "Energizing breath: Quick inhale for 2, long exhale for 6. Repeat 5 times for gentle energy.",
      hopeless: "Heart breathing: Place hand on heart, breathe slowly into this space. You are loved and supported."
    };

    return breathingTechniques[emotionalState.mood as keyof typeof breathingTechniques] 
      || "Deep belly breathing: Inhale slowly through your nose, let your belly expand. Exhale peace.";
  }

  private async generateJournalPrompt(
    emotionalState: EmotionalState,
    recentMemories: SoulMemory[]
  ): Promise<string> {
    const prompts = {
      strong: "What made you feel powerful today? How can you tap into this strength tomorrow?",
      grateful: "What are you most grateful for right now? How can you extend this feeling?",
      tempted: "What is this craving really asking for? What would truly nourish your soul?",
      tired: "What has been draining your energy? What would restore and replenish you?",
      hopeless: "When did you last feel hope? What small step could bring you closer to that feeling?",
      anxious: "What are you worried about? What would your wisest self tell you right now?"
    };

    return prompts[emotionalState.mood as keyof typeof prompts] 
      || "How are you feeling right now, and what does your heart need most?";
  }

  private shouldSuggestBreathing(emotionalState: EmotionalState, responseType?: string): boolean {
    return emotionalState.intensity >= 6 || 
           ['anxious', 'tempted', 'hopeless'].includes(emotionalState.mood) ||
           responseType === 'breathing' || responseType === 'craving';
  }

  private extractPowerMoments(userMessage: string, aiResponse: string): string[] {
    const powerWords = ['strong', 'proud', 'accomplished', 'grateful', 'peaceful', 'confident', 'clear'];
    const moments: string[] = [];
    
    const combined = userMessage + ' ' + aiResponse;
    powerWords.forEach(word => {
      if (combined.toLowerCase().includes(word)) {
        const sentence = combined.split('.').find(s => s.toLowerCase().includes(word));
        if (sentence) moments.push(sentence.trim());
      }
    });
    
    return moments;
  }

  private async extractInsights(message: string, emotionalState: EmotionalState): Promise<string[]> {
    const prompt = `
    Extract 1-2 key insights from this emotional check-in:
    
    Message: "${message}"
    Emotional state: ${emotionalState.mood} (${emotionalState.intensity}/10)
    
    Return insights as a JSON array of strings. Focus on patterns, growth opportunities, or important realizations.
    `;

    try {
      const response = await this.genai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          responseMimeType: "application/json"
        },
        contents: prompt
      });

      return JSON.parse(response.text || '[]');
    } catch {
      return [`Mood: ${emotionalState.mood} with ${emotionalState.intensity}/10 intensity`];
    }
  }

  private async generateEncouragementFromMemory(powerMoment: any): Promise<string> {
    const prompt = `
    Based on this power moment from their past, create an encouraging message:
    
    Power moment: "${powerMoment.moment}"
    Context: "${powerMoment.context}"
    
    Remind them of their strength in a warm, personal way. Reference the specific moment.
    Keep it under 50 words.
    `;

    const response = await this.genai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt
    });

    return response.text || "Remember your strength. You've overcome challenges before, and you can do it again.";
  }

  private async analyzeCravingPatterns(cravingHistory: any[], soulMemories: SoulMemory[]): Promise<any> {
    // Implementation for pattern analysis
    const timePatterns = cravingHistory.map(c => new Date(c.timestamp).getHours());
    const mostCommonHour = this.getMostFrequent(timePatterns);
    
    return {
      predictedCravingTime: mostCommonHour ? new Date().setHours(mostCommonHour, 0, 0, 0) : undefined,
      triggerPattern: "Stress and fatigue appear to be your main triggers",
      preventiveMessage: "I noticed this is usually when cravings hit. Let's prepare together.",
      suggestedActivity: "Try a 2-minute breathing exercise or play Craving Slayer Sudoku"
    };
  }

  private getMostFrequent(arr: number[]): number | null {
    if (arr.length === 0) return null;
    const counts = arr.reduce((acc, val) => {
      acc[val] = (acc[val] || 0) + 1;
      return acc;
    }, {} as Record<number, number>);
    
    return Number(Object.keys(counts).reduce((a, b) => counts[a] > counts[b] ? a : b));
  }

  private async getUserPersonality(userId: number): Promise<PersonalityTraits> {
    if (!this.personalityTraits.has(userId)) {
      // Default personality traits - could be learned over time
      this.personalityTraits.set(userId, {
        communicationStyle: 'gentle',
        preferredSupport: 'emotional',
        responseLength: 'detailed',
        memoryFocus: 'growth'
      });
    }
    return this.personalityTraits.get(userId)!;
  }

  private async getRecentSoulMemories(userId: number, days: number): Promise<SoulMemory[]> {
    // This would integrate with a proper database storage system
    // For now, return empty array - would need to implement soul_memories table
    return [];
  }

  private async getSoulMemories(userId: number, days: number): Promise<SoulMemory[]> {
    // This would integrate with a proper database storage system
    return [];
  }

  private async storeSoulMemory(userId: number, memory: Partial<SoulMemory>): Promise<void> {
    // This would store in a soul_memories table
    // For now, just log for development
    console.log(`Soul memory stored for user ${userId}:`, memory);
  }
}

export const emotionalAICompanion = new EmotionalAICompanion();