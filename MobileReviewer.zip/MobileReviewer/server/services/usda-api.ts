// USDA FoodData Central API Integration
interface USDAFoodItem {
  fdcId: number;
  description: string;
  brandOwner?: string;
  ingredients?: string;
  foodNutrients: Array<{
    nutrientId: number;
    nutrientName: string;
    value: number;
    unitName: string;
  }>;
  foodCategory?: {
    description: string;
  };
}

interface NutritionAnalysis {
  fdcId: number;
  foodName: string;
  brandOwner?: string;
  ingredients: string[];
  nutritionFacts: {
    calories?: number;
    totalSugars?: number;
    addedSugars?: number;
    sodium?: number;
    saturatedFat?: number;
    transFat?: number;
    fiber?: number;
    protein?: number;
  };
  healthScore: 'A' | 'B' | 'C' | 'D' | 'F';
  isUltraProcessed: boolean;
  redFlags: string[];
  recommendations: string[];
}

const ULTRA_PROCESSED_INDICATORS = [
  'high fructose corn syrup',
  'modified corn starch',
  'maltodextrin',
  'monosodium glutamate',
  'sodium benzoate',
  'potassium sorbate',
  'artificial flavors',
  'natural flavors',
  'carrageenan',
  'xanthan gum',
  'guar gum',
  'sucralose',
  'aspartame',
  'acesulfame potassium',
  'red dye',
  'yellow dye',
  'blue dye',
  'caramel color',
  'sodium nitrite',
  'sodium nitrate',
  'phosphoric acid',
  'hydrogenated',
  'partially hydrogenated'
];

export class USDAService {
  private apiKey: string;
  private baseUrl = 'https://api.nal.usda.gov/fdc/v1';

  constructor() {
    this.apiKey = process.env.USDA_API_KEY || '';
    if (!this.apiKey) {
      console.warn('USDA_API_KEY not provided - food analysis will be limited');
    }
  }

  async searchFoodByBarcode(upc: string): Promise<USDAFoodItem[]> {
    if (!this.apiKey) {
      throw new Error('USDA API key not configured');
    }

    try {
      const response = await fetch(
        `${this.baseUrl}/foods/search?query=${upc}&dataType=Branded&pageSize=25&api_key=${this.apiKey}`
      );

      if (!response.ok) {
        throw new Error(`USDA API error: ${response.status}`);
      }

      const data = await response.json();
      return data.foods || [];
    } catch (error) {
      console.error('USDA barcode search failed:', error);
      throw error;
    }
  }

  async searchFoodByName(foodName: string): Promise<USDAFoodItem[]> {
    if (!this.apiKey) {
      throw new Error('USDA API key not configured');
    }

    try {
      const response = await fetch(
        `${this.baseUrl}/foods/search?query=${encodeURIComponent(foodName)}&dataType=Branded,Foundation&pageSize=10&api_key=${this.apiKey}`
      );

      if (!response.ok) {
        throw new Error(`USDA API error: ${response.status}`);
      }

      const data = await response.json();
      return data.foods || [];
    } catch (error) {
      console.error('USDA food search failed:', error);
      throw error;
    }
  }

  async getFoodDetails(fdcId: number): Promise<USDAFoodItem | null> {
    if (!this.apiKey) {
      throw new Error('USDA API key not configured');
    }

    try {
      const response = await fetch(
        `${this.baseUrl}/food/${fdcId}?api_key=${this.apiKey}`
      );

      if (!response.ok) {
        throw new Error(`USDA API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('USDA food details failed:', error);
      return null;
    }
  }

  analyzeFood(foodItem: USDAFoodItem): NutritionAnalysis {
    const ingredients = this.parseIngredients(foodItem.ingredients || '');
    const nutritionFacts = this.extractNutritionFacts(foodItem.foodNutrients);
    const redFlags = this.identifyRedFlags(ingredients, nutritionFacts);
    const isUltraProcessed = this.checkUltraProcessed(ingredients, redFlags);
    const healthScore = this.calculateHealthScore(nutritionFacts, redFlags, isUltraProcessed);
    const recommendations = this.generateRecommendations(nutritionFacts, redFlags, isUltraProcessed);

    return {
      fdcId: foodItem.fdcId,
      foodName: foodItem.description,
      brandOwner: foodItem.brandOwner,
      ingredients,
      nutritionFacts,
      healthScore,
      isUltraProcessed,
      redFlags,
      recommendations
    };
  }

  private parseIngredients(ingredientString: string): string[] {
    if (!ingredientString) return [];
    
    return ingredientString
      .toLowerCase()
      .split(/[,;]/)
      .map(ingredient => ingredient.trim())
      .filter(ingredient => ingredient.length > 0);
  }

  private extractNutritionFacts(nutrients: USDAFoodItem['foodNutrients']) {
    const facts: NutritionAnalysis['nutritionFacts'] = {};

    nutrients.forEach(nutrient => {
      switch (nutrient.nutrientId) {
        case 1008: // Energy (calories)
          facts.calories = nutrient.value;
          break;
        case 2000: // Total sugars
          facts.totalSugars = nutrient.value;
          break;
        case 1235: // Added sugars
          facts.addedSugars = nutrient.value;
          break;
        case 1093: // Sodium
          facts.sodium = nutrient.value;
          break;
        case 1258: // Saturated fat
          facts.saturatedFat = nutrient.value;
          break;
        case 1257: // Trans fat
          facts.transFat = nutrient.value;
          break;
        case 1079: // Fiber
          facts.fiber = nutrient.value;
          break;
        case 1003: // Protein
          facts.protein = nutrient.value;
          break;
      }
    });

    return facts;
  }

  private identifyRedFlags(ingredients: string[], nutritionFacts: NutritionAnalysis['nutritionFacts']): string[] {
    const flags: string[] = [];

    // Check ingredients for ultra-processed indicators
    ingredients.forEach(ingredient => {
      ULTRA_PROCESSED_INDICATORS.forEach(indicator => {
        if (ingredient.includes(indicator)) {
          flags.push(`Contains ${indicator}`);
        }
      });
    });

    // Check nutrition red flags
    if (nutritionFacts.addedSugars && nutritionFacts.addedSugars > 10) {
      flags.push('High added sugars (>10g)');
    }
    if (nutritionFacts.sodium && nutritionFacts.sodium > 400) {
      flags.push('High sodium (>400mg)');
    }
    if (nutritionFacts.saturatedFat && nutritionFacts.saturatedFat > 5) {
      flags.push('High saturated fat (>5g)');
    }
    if (nutritionFacts.transFat && nutritionFacts.transFat > 0) {
      flags.push('Contains trans fat');
    }

    return flags;
  }

  private checkUltraProcessed(ingredients: string[], redFlags: string[]): boolean {
    // More than 5 ingredients usually indicates processing
    if (ingredients.length > 5) return true;
    
    // Contains ultra-processed indicators
    if (redFlags.some(flag => 
      ULTRA_PROCESSED_INDICATORS.some(indicator => flag.toLowerCase().includes(indicator))
    )) {
      return true;
    }

    return false;
  }

  private calculateHealthScore(
    nutritionFacts: NutritionAnalysis['nutritionFacts'], 
    redFlags: string[], 
    isUltraProcessed: boolean
  ): NutritionAnalysis['healthScore'] {
    let score = 100;

    // Deduct points for red flags
    score -= redFlags.length * 15;

    // Deduct for ultra-processed
    if (isUltraProcessed) score -= 30;

    // Deduct for high sugar
    if (nutritionFacts.addedSugars && nutritionFacts.addedSugars > 15) score -= 20;

    // Add points for fiber
    if (nutritionFacts.fiber && nutritionFacts.fiber > 3) score += 10;

    // Add points for protein
    if (nutritionFacts.protein && nutritionFacts.protein > 5) score += 5;

    // Convert to letter grade
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }

  private generateRecommendations(
    nutritionFacts: NutritionAnalysis['nutritionFacts'], 
    redFlags: string[], 
    isUltraProcessed: boolean
  ): string[] {
    const recommendations: string[] = [];

    if (isUltraProcessed) {
      recommendations.push('Choose whole, minimally processed alternatives');
    }

    if (nutritionFacts.addedSugars && nutritionFacts.addedSugars > 10) {
      recommendations.push('Look for options with less added sugar');
    }

    if (nutritionFacts.sodium && nutritionFacts.sodium > 400) {
      recommendations.push('Consider lower sodium alternatives');
    }

    if (redFlags.some(flag => flag.includes('artificial'))) {
      recommendations.push('Opt for foods with natural ingredients');
    }

    if (recommendations.length === 0) {
      recommendations.push('This appears to be a good choice! Continue reading labels.');
    }

    return recommendations;
  }
}

export const usdaService = new USDAService();