import { GoogleAuth } from 'google-auth-library';
import { sheets_v4, google } from 'googleapis';
import type { User, SugarEntry, MoodEntry, CravingEntry, ChatMessage, FoodAnalysis } from '@shared/schema';

interface UserDataExport {
  user: User;
  sugarEntries: SugarEntry[];
  moodEntries: MoodEntry[];
  cravingEntries: CravingEntry[];
  chatMessages: ChatMessage[];
  foodAnalyses: FoodAnalysis[];
  exportDate: string;
  totalDataPoints: number;
}

export class GoogleSheetsService {
  private auth: GoogleAuth;
  private sheets: sheets_v4.Sheets;
  private spreadsheetId: string;

  constructor() {
    // Initialize Google Auth with service account
    this.auth = new GoogleAuth({
      credentials: {
        type: 'service_account',
        project_id: process.env.GOOGLE_PROJECT_ID,
        private_key_id: process.env.GOOGLE_PRIVATE_KEY_ID,
        private_key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
        client_email: process.env.GOOGLE_CLIENT_EMAIL,
        client_id: process.env.GOOGLE_CLIENT_ID,
        auth_uri: 'https://accounts.google.com/o/oauth2/auth',
        token_uri: 'https://oauth2.googleapis.com/token',
        auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${process.env.GOOGLE_CLIENT_EMAIL}`
      },
      scopes: ['https://www.googleapis.com/auth/spreadsheets']
    });

    this.sheets = google.sheets({ version: 'v4', auth: this.auth });
    this.spreadsheetId = process.env.GOOGLE_SHEETS_ID || '';
  }

  /**
   * Create a new spreadsheet for user data exports
   */
  async createUserDataSpreadsheet(userId: number, userName: string): Promise<string> {
    try {
      const resource = {
        properties: {
          title: `SOULFUEL_UserData_${userId}_${userName}_${new Date().toISOString().split('T')[0]}`
        },
        sheets: [
          { properties: { title: 'User_Profile' } },
          { properties: { title: 'Sugar_Tracking' } },
          { properties: { title: 'Mood_Tracking' } },
          { properties: { title: 'Craving_Tracking' } },
          { properties: { title: 'AI_Conversations' } },
          { properties: { title: 'Food_Analysis' } },
          { properties: { title: 'Export_Summary' } }
        ]
      };

      const response = await this.sheets.spreadsheets.create({
        resource,
        auth: this.auth
      });

      const spreadsheetId = response.data.spreadsheetId!;
      
      // Set up headers for each sheet
      await this.setupSheetHeaders(spreadsheetId);
      
      return spreadsheetId;
    } catch (error) {
      console.error('Error creating spreadsheet:', error);
      throw new Error('Failed to create user data spreadsheet');
    }
  }

  /**
   * Export complete user data to Google Sheets
   */
  async exportUserData(userData: UserDataExport): Promise<string> {
    try {
      const spreadsheetId = await this.createUserDataSpreadsheet(
        userData.user.id, 
        userData.user.username || 'user'
      );

      // Export each data type to its respective sheet
      await Promise.all([
        this.exportUserProfile(spreadsheetId, userData.user),
        this.exportSugarData(spreadsheetId, userData.sugarEntries),
        this.exportMoodData(spreadsheetId, userData.moodEntries),
        this.exportCravingData(spreadsheetId, userData.cravingEntries),
        this.exportChatData(spreadsheetId, userData.chatMessages),
        this.exportFoodAnalysisData(spreadsheetId, userData.foodAnalyses),
        this.exportSummary(spreadsheetId, userData)
      ]);

      // Make spreadsheet accessible with link sharing
      await this.setSpreadsheetPermissions(spreadsheetId);

      return `https://docs.google.com/spreadsheets/d/${spreadsheetId}`;
    } catch (error) {
      console.error('Error exporting user data:', error);
      throw new Error('Failed to export user data to Google Sheets');
    }
  }

  /**
   * Store user interaction logs for customer service
   */
  async logUserInteraction(userId: number, interactionType: string, details: any): Promise<void> {
    try {
      if (!this.spreadsheetId) {
        console.warn('No main spreadsheet configured for logging');
        return;
      }

      const timestamp = new Date().toISOString();
      const values = [[
        timestamp,
        userId,
        interactionType,
        JSON.stringify(details),
        details.sessionId || '',
        details.userAgent || '',
        details.ipAddress || 'not_tracked'
      ]];

      await this.sheets.spreadsheets.values.append({
        spreadsheetId: this.spreadsheetId,
        range: 'UserInteractions!A:G',
        valueInputOption: 'RAW',
        requestBody: { values }
      });
    } catch (error) {
      console.error('Error logging user interaction:', error);
      // Don't throw - logging failures shouldn't break the app
    }
  }

  /**
   * Log system events and errors for monitoring
   */
  async logSystemEvent(eventType: string, details: any, severity: 'info' | 'warning' | 'error' = 'info'): Promise<void> {
    try {
      if (!this.spreadsheetId) return;

      const timestamp = new Date().toISOString();
      const values = [[
        timestamp,
        eventType,
        severity,
        JSON.stringify(details),
        process.env.NODE_ENV || 'development'
      ]];

      await this.sheets.spreadsheets.values.append({
        spreadsheetId: this.spreadsheetId,
        range: 'SystemLogs!A:E',
        valueInputOption: 'RAW',
        requestBody: { values }
      });
    } catch (error) {
      console.error('Error logging system event:', error);
    }
  }

  private async setupSheetHeaders(spreadsheetId: string): Promise<void> {
    const headers = {
      'User_Profile': [
        ['ID', 'Username', 'Email', 'Firebase UID', 'Subscription Tier', 'Created Date', 'Weekly Services Used', 'Last Reset']
      ],
      'Sugar_Tracking': [
        ['Date', 'Amount (g)', 'Meal Type', 'Notes', 'Recorded At']
      ],
      'Mood_Tracking': [
        ['Date', 'Mood', 'Energy Level', 'Notes', 'Recorded At']
      ],
      'Craving_Tracking': [
        ['Date', 'Intensity (1-10)', 'Trigger', 'Coping Strategy', 'Duration (min)', 'Recorded At']
      ],
      'AI_Conversations': [
        ['Date', 'User Message', 'AI Response', 'Coach Type', 'Session ID']
      ],
      'Food_Analysis': [
        ['Date', 'Food Name', 'Health Score', 'Ultra Processed', 'Analysis Method', 'Confidence', 'Recommendations']
      ],
      'Export_Summary': [
        ['Export Date', 'User ID', 'Total Data Points', 'Data Categories', 'Export Reason', 'Requested By']
      ]
    };

    const requests = Object.entries(headers).map(([sheetName, headerRow]) => ({
      updateCells: {
        range: {
          sheetId: this.getSheetId(sheetName),
          startRowIndex: 0,
          endRowIndex: 1,
          startColumnIndex: 0,
          endColumnIndex: headerRow[0].length
        },
        rows: [{
          values: headerRow[0].map(header => ({
            userEnteredValue: { stringValue: header },
            userEnteredFormat: {
              backgroundColor: { red: 0.9, green: 0.9, blue: 0.9 },
              textFormat: { bold: true }
            }
          }))
        }],
        fields: 'userEnteredValue,userEnteredFormat'
      }
    }));

    await this.sheets.spreadsheets.batchUpdate({
      spreadsheetId,
      requestBody: { requests }
    });
  }

  private async exportUserProfile(spreadsheetId: string, user: User): Promise<void> {
    const values = [[
      user.id,
      user.username || '',
      user.email || '',
      user.firebaseUid || '',
      user.subscriptionTier || 'free',
      user.createdAt?.toISOString() || '',
      user.weeklyServicesUsed || 0,
      user.lastServicesReset?.toISOString() || ''
    ]];

    await this.sheets.spreadsheets.values.append({
      spreadsheetId,
      range: 'User_Profile!A2:H2',
      valueInputOption: 'RAW',
      requestBody: { values }
    });
  }

  private async exportSugarData(spreadsheetId: string, entries: SugarEntry[]): Promise<void> {
    if (entries.length === 0) return;

    const values = entries.map(entry => [
      entry.date.toISOString().split('T')[0],
      entry.amount,
      entry.mealType || '',
      entry.notes || '',
      entry.createdAt?.toISOString() || ''
    ]);

    await this.sheets.spreadsheets.values.append({
      spreadsheetId,
      range: 'Sugar_Tracking!A2:E',
      valueInputOption: 'RAW',
      requestBody: { values }
    });
  }

  private async exportMoodData(spreadsheetId: string, entries: MoodEntry[]): Promise<void> {
    if (entries.length === 0) return;

    const values = entries.map(entry => [
      entry.date.toISOString().split('T')[0],
      entry.mood,
      entry.energyLevel || '',
      entry.notes || '',
      entry.createdAt?.toISOString() || ''
    ]);

    await this.sheets.spreadsheets.values.append({
      spreadsheetId,
      range: 'Mood_Tracking!A2:E',
      valueInputOption: 'RAW',
      requestBody: { values }
    });
  }

  private async exportCravingData(spreadsheetId: string, entries: CravingEntry[]): Promise<void> {
    if (entries.length === 0) return;

    const values = entries.map(entry => [
      entry.date.toISOString().split('T')[0],
      entry.intensity,
      entry.trigger || '',
      entry.copingStrategy || '',
      entry.duration || '',
      entry.createdAt?.toISOString() || ''
    ]);

    await this.sheets.spreadsheets.values.append({
      spreadsheetId,
      range: 'Craving_Tracking!A2:F',
      valueInputOption: 'RAW',
      requestBody: { values }
    });
  }

  private async exportChatData(spreadsheetId: string, messages: ChatMessage[]): Promise<void> {
    if (messages.length === 0) return;

    const values = messages.map(msg => [
      msg.createdAt?.toISOString().split('T')[0] || '',
      msg.message,
      msg.response,
      msg.coachType || 'general',
      msg.id.toString()
    ]);

    await this.sheets.spreadsheets.values.append({
      spreadsheetId,
      range: 'AI_Conversations!A2:E',
      valueInputOption: 'RAW',
      requestBody: { values }
    });
  }

  private async exportFoodAnalysisData(spreadsheetId: string, analyses: FoodAnalysis[]): Promise<void> {
    if (analyses.length === 0) return;

    const values = analyses.map(analysis => [
      analysis.createdAt?.toISOString().split('T')[0] || '',
      analysis.foodName,
      analysis.healthScore,
      analysis.isUltraProcessed ? 'Yes' : 'No',
      analysis.analysisMethod,
      analysis.confidence,
      analysis.recommendations.join('; ')
    ]);

    await this.sheets.spreadsheets.values.append({
      spreadsheetId,
      range: 'Food_Analysis!A2:G',
      valueInputOption: 'RAW',
      requestBody: { values }
    });
  }

  private async exportSummary(spreadsheetId: string, userData: UserDataExport): Promise<void> {
    const values = [[
      userData.exportDate,
      userData.user.id,
      userData.totalDataPoints,
      'User Profile, Sugar Tracking, Mood Tracking, Craving Tracking, AI Conversations, Food Analysis',
      'User Data Export Request',
      'SOULFUEL System'
    ]];

    await this.sheets.spreadsheets.values.append({
      spreadsheetId,
      range: 'Export_Summary!A2:F',
      valueInputOption: 'RAW',
      requestBody: { values }
    });
  }

  private async setSpreadsheetPermissions(spreadsheetId: string): Promise<void> {
    // This would require the Google Drive API
    // For now, we'll create with default permissions
    console.log(`Spreadsheet created: https://docs.google.com/spreadsheets/d/${spreadsheetId}`);
  }

  private getSheetId(sheetName: string): number {
    // Simple mapping - in production, you'd get these from the API response
    const sheetIds: { [key: string]: number } = {
      'User_Profile': 0,
      'Sugar_Tracking': 1,
      'Mood_Tracking': 2,
      'Craving_Tracking': 3,
      'AI_Conversations': 4,
      'Food_Analysis': 5,
      'Export_Summary': 6
    };
    return sheetIds[sheetName] || 0;
  }
}

export const googleSheetsService = new GoogleSheetsService();