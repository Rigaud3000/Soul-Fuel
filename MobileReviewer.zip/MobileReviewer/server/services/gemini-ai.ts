import { GoogleGenAI } from "@google/genai";
import { usdaService } from "./usda-api";
import * as fs from "fs";

interface FoodAnalysisResult {
  foodName: string;
  confidence: number;
  nutritionAnalysis?: any;
  healthScore: 'A' | 'B' | 'C' | 'D' | 'F';
  isUltraProcessed: boolean;
  redFlags: string[];
  healthySuggestions: string[];
  coachingMessage: string;
}

interface WithdrawalSymptom {
  type: 'craving' | 'mood' | 'energy' | 'physical';
  intensity: number;
  description: string;
  timestamp: Date;
}

interface CoachingContext {
  userProfile: {
    goals: string[];
    currentStage: 'beginner' | 'intermediate' | 'advanced';
    preferences: string[];
    restrictions: string[];
  };
  recentActivity: {
    sugarIntake: number;
    moodEntries: any[];
    cravingEntries: any[];
    withdrawalSymptoms: WithdrawalSymptom[];
  };
}

export class GeminiAIService {
  private genai: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY || '';
    if (!apiKey) {
      console.warn('GEMINI_API_KEY not provided - AI features will be limited');
    }
    this.genai = new GoogleGenAI({ apiKey });
  }

  async analyzeImageBasedFood(imagePath: string): Promise<FoodAnalysisResult> {
    try {
      const imageBytes = fs.readFileSync(imagePath);
      
      const contents = [
        {
          inlineData: {
            data: imageBytes.toString("base64"),
            mimeType: "image/jpeg",
          },
        },
        `Analyze this food image and provide detailed information. Return JSON with:
        {
          "foodName": "exact food/product name",
          "confidence": 0.95,
          "ingredients": ["list", "of", "visible", "ingredients"],
          "brandName": "if visible",
          "estimatedSugar": "grams if packaged food",
          "processingLevel": "minimal/moderate/high/ultra-processed",
          "healthConcerns": ["list", "of", "concerns"],
          "isUltraProcessed": true/false
        }`,
      ];

      const response = await this.genai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: contents,
        config: {
          responseMimeType: "application/json",
        },
      });

      const analysis = JSON.parse(response.text || '{}');
      
      // Enhance with USDA data if available
      let nutritionAnalysis = null;
      try {
        const usdaResults = await usdaService.searchFoodByName(analysis.foodName);
        if (usdaResults.length > 0) {
          nutritionAnalysis = usdaService.analyzeFood(usdaResults[0]);
        }
      } catch (error) {
        console.log('USDA lookup failed, using Gemini analysis only');
      }

      const healthScore = nutritionAnalysis?.healthScore || this.calculateHealthScoreFromImage(analysis);
      const isUltraProcessed = nutritionAnalysis?.isUltraProcessed ?? analysis.isUltraProcessed;
      const redFlags = nutritionAnalysis?.redFlags || analysis.healthConcerns || [];

      const healthySuggestions = await this.generateHealthySuggestions(analysis.foodName, isUltraProcessed);
      const coachingMessage = await this.generateCoachingMessage(analysis, isUltraProcessed);

      return {
        foodName: analysis.foodName,
        confidence: analysis.confidence,
        nutritionAnalysis,
        healthScore,
        isUltraProcessed,
        redFlags,
        healthySuggestions,
        coachingMessage
      };

    } catch (error) {
      console.error('Gemini image analysis failed:', error);
      throw new Error('Failed to analyze food image');
    }
  }

  async analyzeBarcodeFood(barcode: string): Promise<FoodAnalysisResult> {
    try {
      // First try USDA database
      const usdaResults = await usdaService.searchFoodByBarcode(barcode);
      
      if (usdaResults.length > 0) {
        const nutritionAnalysis = usdaService.analyzeFood(usdaResults[0]);
        const healthySuggestions = await this.generateHealthySuggestions(nutritionAnalysis.foodName, nutritionAnalysis.isUltraProcessed);
        const coachingMessage = await this.generateCoachingMessage(nutritionAnalysis, nutritionAnalysis.isUltraProcessed);

        return {
          foodName: nutritionAnalysis.foodName,
          confidence: 0.95,
          nutritionAnalysis,
          healthScore: nutritionAnalysis.healthScore,
          isUltraProcessed: nutritionAnalysis.isUltraProcessed,
          redFlags: nutritionAnalysis.redFlags,
          healthySuggestions,
          coachingMessage
        };
      } else {
        throw new Error('Product not found in USDA database');
      }
    } catch (error) {
      console.error('Barcode analysis failed:', error);
      throw error;
    }
  }

  async analyzeTextBasedFood(foodDescription: string): Promise<FoodAnalysisResult> {
    try {
      // First try USDA search
      let nutritionAnalysis = null;
      try {
        const usdaResults = await usdaService.searchFoodByName(foodDescription);
        if (usdaResults.length > 0) {
          nutritionAnalysis = usdaService.analyzeFood(usdaResults[0]);
        }
      } catch (error) {
        console.log('USDA lookup failed, using Gemini analysis only');
      }

      // Use Gemini for additional analysis
      const response = await this.genai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Analyze this food: "${foodDescription}". Provide JSON with:
        {
          "foodName": "standardized name",
          "confidence": 0.9,
          "isUltraProcessed": true/false,
          "processingLevel": "minimal/moderate/high/ultra-processed",
          "healthConcerns": ["list", "of", "concerns"],
          "estimatedSugar": "grams if known",
          "category": "fruit/vegetable/grain/protein/dairy/snack/beverage"
        }`,
        config: {
          responseMimeType: "application/json",
        },
      });

      const geminiAnalysis = JSON.parse(response.text || '{}');
      
      const healthScore = nutritionAnalysis?.healthScore || this.calculateHealthScoreFromText(geminiAnalysis);
      const isUltraProcessed = nutritionAnalysis?.isUltraProcessed ?? geminiAnalysis.isUltraProcessed;
      const redFlags = nutritionAnalysis?.redFlags || geminiAnalysis.healthConcerns || [];

      const healthySuggestions = await this.generateHealthySuggestions(geminiAnalysis.foodName, isUltraProcessed);
      const coachingMessage = await this.generateCoachingMessage(geminiAnalysis, isUltraProcessed);

      return {
        foodName: geminiAnalysis.foodName,
        confidence: geminiAnalysis.confidence,
        nutritionAnalysis,
        healthScore,
        isUltraProcessed,
        redFlags,
        healthySuggestions,
        coachingMessage
      };

    } catch (error) {
      console.error('Gemini text analysis failed:', error);
      throw new Error('Failed to analyze food description');
    }
  }

  async generatePersonalizedCoaching(context: CoachingContext, userMessage: string): Promise<string> {
    try {
      const systemPrompt = `You are an expert wellness coach specializing in helping people quit ultra-processed foods and sugar. 

User Profile:
- Goals: ${context.userProfile.goals.join(', ')}
- Stage: ${context.userProfile.currentStage}
- Preferences: ${context.userProfile.preferences.join(', ')}
- Restrictions: ${context.userProfile.restrictions.join(', ')}

Recent Activity:
- Daily sugar intake: ${context.recentActivity.sugarIntake}g
- Recent mood: ${context.recentActivity.moodEntries.length > 0 ? 'tracked' : 'not tracked'}
- Cravings: ${context.recentActivity.cravingEntries.length} recent entries
- Withdrawal symptoms: ${context.recentActivity.withdrawalSymptoms.length} tracked

Provide supportive, science-based advice. Be encouraging but realistic. Focus on practical tips and acknowledge their progress.`;

      const response = await this.genai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction: systemPrompt,
        },
        contents: userMessage,
      });

      return response.text || "I'm here to support your wellness journey. How can I help you today?";

    } catch (error) {
      console.error('Gemini coaching failed:', error);
      return "I'm experiencing some technical difficulties. Please try again in a moment.";
    }
  }

  async analyzeWithdrawalSymptoms(symptoms: WithdrawalSymptom[]): Promise<{
    severity: 'mild' | 'moderate' | 'severe';
    recommendations: string[];
    expectedDuration: string;
    copingStrategies: string[];
  }> {
    try {
      const symptomDescription = symptoms.map(s => 
        `${s.type}: intensity ${s.intensity}/10 - ${s.description}`
      ).join(', ');

      const response = await this.genai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: `Analyze these sugar/processed food withdrawal symptoms: ${symptomDescription}
        
        Provide JSON response with:
        {
          "severity": "mild/moderate/severe",
          "recommendations": ["practical advice"],
          "expectedDuration": "timeline for improvement",
          "copingStrategies": ["specific strategies"]
        }`,
        config: {
          responseMimeType: "application/json",
        },
      });

      return JSON.parse(response.text || '{}');

    } catch (error) {
      console.error('Withdrawal analysis failed:', error);
      return {
        severity: 'mild',
        recommendations: ['Stay hydrated', 'Get adequate sleep', 'Consider gentle exercise'],
        expectedDuration: '3-7 days for most symptoms',
        copingStrategies: ['Deep breathing', 'Healthy snacks', 'Social support']
      };
    }
  }

  private async generateHealthySuggestions(foodName: string, isUltraProcessed: boolean): Promise<string[]> {
    try {
      const response = await this.genai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Suggest 3 healthy alternatives to "${foodName}" ${isUltraProcessed ? '(ultra-processed food)' : ''}. 
        Provide practical, accessible swaps. Return as JSON array: ["suggestion1", "suggestion2", "suggestion3"]`,
        config: {
          responseMimeType: "application/json",
        },
      });

      return JSON.parse(response.text || '[]');
    } catch (error) {
      return ['Choose whole foods when possible', 'Read ingredient labels carefully', 'Cook at home more often'];
    }
  }

  private async generateCoachingMessage(analysis: any, isUltraProcessed: boolean): Promise<string> {
    try {
      const response = await this.genai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Create a supportive, encouraging message about ${analysis.foodName}. 
        ${isUltraProcessed ? 'This is ultra-processed - acknowledge without judgment and provide motivation.' : 'This is a better choice - celebrate and encourage.'}
        Keep it under 100 words, personal and motivating.`,
      });

      return response.text || "Every small step towards better nutrition counts. You're making progress!";
    } catch (error) {
      return "You're doing great by being mindful of your food choices!";
    }
  }

  private calculateHealthScoreFromImage(analysis: any): 'A' | 'B' | 'C' | 'D' | 'F' {
    if (analysis.isUltraProcessed) return 'D';
    if (analysis.healthConcerns?.length > 2) return 'C';
    if (analysis.processingLevel === 'minimal') return 'A';
    return 'B';
  }

  private calculateHealthScoreFromText(analysis: any): 'A' | 'B' | 'C' | 'D' | 'F' {
    if (analysis.isUltraProcessed) return 'D';
    if (analysis.category === 'fruit' || analysis.category === 'vegetable') return 'A';
    if (analysis.processingLevel === 'minimal') return 'B';
    return 'C';
  }
}

export const geminiAIService = new GeminiAIService();