// Mock Google Sheets Service for Development/Demo
// This simulates the Google Sheets functionality without requiring actual API keys

import type { User, SugarEntry, MoodEntry, CravingEntry, ChatMessage, FoodAnalysis } from '@shared/schema';

interface UserDataExport {
  user: User;
  sugarEntries: SugarEntry[];
  moodEntries: MoodEntry[];
  cravingEntries: CravingEntry[];
  chatMessages: ChatMessage[];
  foodAnalyses: FoodAnalysis[];
  exportDate: string;
  totalDataPoints: number;
}

export class MockGoogleSheetsService {
  
  /**
   * Simulate creating a Google Sheet export with realistic data
   */
  async exportUserData(userData: UserDataExport): Promise<string> {
    // Simulate API processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Generate a realistic mock Google Sheets URL
    const mockSpreadsheetId = this.generateMockSpreadsheetId();
    const mockUrl = `https://docs.google.com/spreadsheets/d/${mockSpreadsheetId}/edit#gid=0`;
    
    // Log the simulated export for debugging
    console.log('🔄 Mock Google Sheets Export Created:');
    console.log(`📊 Spreadsheet URL: ${mockUrl}`);
    console.log(`👤 User: ${userData.user.username || 'Unknown'} (ID: ${userData.user.id})`);
    console.log(`📈 Total Data Points: ${userData.totalDataPoints}`);
    console.log('📋 Data Categories:');
    console.log(`   • User Profile: 1 record`);
    console.log(`   • Sugar Tracking: ${userData.sugarEntries.length} entries`);
    console.log(`   • Mood Tracking: ${userData.moodEntries.length} entries`);
    console.log(`   • Craving Tracking: ${userData.cravingEntries.length} entries`);
    console.log(`   • AI Conversations: ${userData.chatMessages.length} messages`);
    console.log(`   • Food Analysis: ${userData.foodAnalyses.length} analyses`);
    
    // Store export data in memory for potential retrieval
    this.storeExportData(mockSpreadsheetId, userData);
    
    return mockUrl;
  }

  /**
   * Log user interactions for customer service (simulated)
   */
  async logUserInteraction(userId: number, interactionType: string, details: any): Promise<void> {
    console.log(`📝 Mock User Interaction Log:`);
    console.log(`   User ID: ${userId}`);
    console.log(`   Type: ${interactionType}`);
    console.log(`   Details:`, details);
    console.log(`   Timestamp: ${new Date().toISOString()}`);
  }

  /**
   * Log system events (simulated)
   */
  async logSystemEvent(eventType: string, details: any, severity: 'info' | 'warning' | 'error' = 'info'): Promise<void> {
    const emoji = {
      info: 'ℹ️',
      warning: '⚠️',
      error: '❌'
    };
    
    console.log(`${emoji[severity]} Mock System Event Log:`);
    console.log(`   Event: ${eventType}`);
    console.log(`   Severity: ${severity}`);
    console.log(`   Details:`, details);
    console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`   Timestamp: ${new Date().toISOString()}`);
  }

  /**
   * Generate a realistic-looking spreadsheet ID
   */
  private generateMockSpreadsheetId(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    let result = '';
    for (let i = 0; i < 44; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  /**
   * Store export data in memory for demo purposes
   */
  private storeExportData(spreadsheetId: string, userData: UserDataExport): void {
    // In a real implementation, this would be stored in a database or cache
    // For demo purposes, we'll just store it in memory
    if (!global.mockExports) {
      global.mockExports = new Map();
    }
    
    global.mockExports.set(spreadsheetId, {
      ...userData,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
    });
  }

  /**
   * Simulate retrieving export data (for demo/testing)
   */
  async getExportData(spreadsheetId: string): Promise<any> {
    if (!global.mockExports) {
      return null;
    }
    
    const exportData = global.mockExports.get(spreadsheetId);
    if (!exportData) {
      return null;
    }
    
    // Check if export has expired
    if (new Date() > new Date(exportData.expiresAt)) {
      global.mockExports.delete(spreadsheetId);
      return null;
    }
    
    return exportData;
  }

  /**
   * Generate a comprehensive mock CSV-style export for download
   */
  generateMockCSVExport(userData: UserDataExport): string {
    let csv = '';
    
    // Export Summary
    csv += '=== SOULFUEL DATA EXPORT ===\n';
    csv += `Export Date: ${userData.exportDate}\n`;
    csv += `User: ${userData.user.username || 'Unknown'} (ID: ${userData.user.id})\n`;
    csv += `Total Data Points: ${userData.totalDataPoints}\n`;
    csv += '\n';
    
    // User Profile
    csv += '=== USER PROFILE ===\n';
    csv += 'ID,Username,Email,Subscription,Created,Services Used,Last Reset\n';
    csv += `${userData.user.id},"${userData.user.username || ''}","${userData.user.email || ''}","${userData.user.subscriptionTier || 'free'}","${userData.user.createdAt || ''}",${userData.user.weeklyServicesUsed || 0},"${userData.user.lastServicesReset || ''}"\n`;
    csv += '\n';
    
    // Sugar Tracking
    if (userData.sugarEntries.length > 0) {
      csv += '=== SUGAR TRACKING ===\n';
      csv += 'Date,Amount (g),Meal Type,Notes,Recorded At\n';
      userData.sugarEntries.forEach(entry => {
        csv += `"${entry.date.toISOString().split('T')[0]}",${entry.amount},"${entry.mealType || ''}","${entry.notes || ''}","${entry.createdAt?.toISOString() || ''}"\n`;
      });
      csv += '\n';
    }
    
    // Mood Tracking
    if (userData.moodEntries.length > 0) {
      csv += '=== MOOD TRACKING ===\n';
      csv += 'Date,Mood,Energy Level,Notes,Recorded At\n';
      userData.moodEntries.forEach(entry => {
        csv += `"${entry.date.toISOString().split('T')[0]}","${entry.mood}","${entry.energyLevel || ''}","${entry.notes || ''}","${entry.createdAt?.toISOString() || ''}"\n`;
      });
      csv += '\n';
    }
    
    // Craving Tracking
    if (userData.cravingEntries.length > 0) {
      csv += '=== CRAVING TRACKING ===\n';
      csv += 'Date,Intensity,Trigger,Coping Strategy,Duration,Recorded At\n';
      userData.cravingEntries.forEach(entry => {
        csv += `"${entry.date.toISOString().split('T')[0]}",${entry.intensity},"${entry.trigger || ''}","${entry.copingStrategy || ''}","${entry.duration || ''}","${entry.createdAt?.toISOString() || ''}"\n`;
      });
      csv += '\n';
    }
    
    // AI Conversations (limited for privacy)
    if (userData.chatMessages.length > 0) {
      csv += '=== AI CONVERSATIONS (SUMMARY) ===\n';
      csv += 'Date,Coach Type,Message Count\n';
      const conversationSummary = userData.chatMessages.reduce((acc, msg) => {
        const date = msg.createdAt?.toISOString().split('T')[0] || 'unknown';
        const key = `${date}-${msg.coachType || 'general'}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      Object.entries(conversationSummary).forEach(([key, count]) => {
        const [date, coachType] = key.split('-');
        csv += `"${date}","${coachType}",${count}\n`;
      });
      csv += '\n';
    }
    
    // Food Analysis Summary
    if (userData.foodAnalyses.length > 0) {
      csv += '=== FOOD ANALYSIS SUMMARY ===\n';
      csv += 'Date,Food Name,Health Score,Ultra Processed,Method,Confidence\n';
      userData.foodAnalyses.forEach(analysis => {
        csv += `"${analysis.createdAt?.toISOString().split('T')[0] || ''}","${analysis.foodName}",${analysis.healthScore},"${analysis.isUltraProcessed ? 'Yes' : 'No'}","${analysis.analysisMethod}",${analysis.confidence}\n`;
      });
      csv += '\n';
    }
    
    csv += '=== END OF EXPORT ===\n';
    csv += `Generated by SOULFUEL Data Export Service\n`;
    csv += `Compliant with GDPR and CCPA regulations\n`;
    
    return csv;
  }
}

// Create singleton instance
export const mockGoogleSheetsService = new MockGoogleSheetsService();

// Type declaration for global mock storage
declare global {
  var mockExports: Map<string, any> | undefined;
}