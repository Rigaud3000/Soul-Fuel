// Enhanced nutrition data integration with multiple APIs
import { usdaService } from './usda-api';

interface EdamamNutritionData {
  calories: number;
  totalNutrients: {
    [key: string]: {
      label: string;
      quantity: number;
      unit: string;
    };
  };
  totalDaily: {
    [key: string]: {
      label: string;
      quantity: number;
      unit: string;
    };
  };
  ingredients: Array<{
    parsed: Array<{
      quantity: number;
      measure: string;
      food: string;
      foodMatch: string;
      weight: number;
    }>;
  }>;
}

interface OpenFoodFactsData {
  code: string;
  status: number;
  product?: {
    product_name: string;
    brands: string;
    ingredients_text: string;
    nutriments: {
      energy_100g?: number;
      'energy-kcal_100g'?: number;
      sugars_100g?: number;
      'added-sugars_100g'?: number;
      salt_100g?: number;
      sodium_100g?: number;
      'saturated-fat_100g'?: number;
      fiber_100g?: number;
      proteins_100g?: number;
    };
    nova_group?: number;
    additives_tags?: string[];
    nutrient_levels?: {
      fat?: string;
      salt?: string;
      'saturated-fat'?: string;
      sugars?: string;
    };
  };
}

interface ComprehensiveNutritionData {
  foodName: string;
  brandOwner?: string;
  barcode?: string;
  ingredients: string[];
  nutritionFacts: {
    calories?: number;
    totalSugars?: number;
    addedSugars?: number;
    sodium?: number;
    saturatedFat?: number;
    transFat?: number;
    fiber?: number;
    protein?: number;
    carbohydrates?: number;
    totalFat?: number;
    cholesterol?: number;
    vitaminC?: number;
    calcium?: number;
    iron?: number;
  };
  healthMetrics: {
    novaGroup?: number; // 1-4 scale for ultra-processing
    nutrientLevels: {
      fat?: 'low' | 'moderate' | 'high';
      salt?: 'low' | 'moderate' | 'high';
      saturatedFat?: 'low' | 'moderate' | 'high';
      sugars?: 'low' | 'moderate' | 'high';
    };
    additives: string[];
    preservatives: string[];
    artificialIngredients: string[];
  };
  confidence: number;
  dataSources: string[];
}

export class NutritionAggregatorService {
  private edamamAppId: string;
  private edamamAppKey: string;

  constructor() {
    this.edamamAppId = process.env.EDAMAM_APP_ID || '';
    this.edamamAppKey = process.env.EDAMAM_APP_KEY || '';
  }

  async getComprehensiveNutrition(
    query: string, 
    barcode?: string
  ): Promise<ComprehensiveNutritionData> {
    const results: Partial<ComprehensiveNutritionData> = {
      foodName: query,
      ingredients: [],
      nutritionFacts: {},
      healthMetrics: {
        nutrientLevels: {},
        additives: [],
        preservatives: [],
        artificialIngredients: []
      },
      dataSources: [],
      confidence: 0
    };

    const promises = [];

    // 1. USDA API (highest priority for US foods)
    promises.push(this.getUSDAData(query, barcode).catch(() => null));

    // 2. OpenFoodFacts (excellent for packaged foods with barcodes)
    if (barcode) {
      promises.push(this.getOpenFoodFactsData(barcode).catch(() => null));
    }

    // 3. Edamam (good for recipe analysis and comprehensive nutrients)
    if (this.edamamAppId && this.edamamAppKey) {
      promises.push(this.getEdamamData(query).catch(() => null));
    }

    const [usdaData, offData, edamamData] = await Promise.all(promises);

    // Merge data with priority: USDA > OpenFoodFacts > Edamam
    this.mergeNutritionData(results, usdaData, 'USDA');
    this.mergeNutritionData(results, offData, 'OpenFoodFacts');
    this.mergeNutritionData(results, edamamData, 'Edamam');

    // Calculate confidence based on data completeness and source reliability
    results.confidence = this.calculateConfidence(results);

    return results as ComprehensiveNutritionData;
  }

  private async getUSDAData(query: string, barcode?: string) {
    try {
      let foods = [];
      
      if (barcode) {
        foods = await usdaService.searchFoodByBarcode(barcode);
      }
      
      if (foods.length === 0) {
        foods = await usdaService.searchFoodByName(query);
      }

      if (foods.length > 0) {
        const analysis = usdaService.analyzeFood(foods[0]);
        return {
          source: 'USDA',
          foodName: analysis.foodName,
          brandOwner: analysis.brandOwner,
          ingredients: analysis.ingredients,
          nutritionFacts: analysis.nutritionFacts,
          healthScore: analysis.healthScore,
          isUltraProcessed: analysis.isUltraProcessed,
          redFlags: analysis.redFlags
        };
      }
    } catch (error) {
      console.warn('USDA API error:', error);
    }
    return null;
  }

  private async getOpenFoodFactsData(barcode: string) {
    try {
      const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`);
      const data: OpenFoodFactsData = await response.json();

      if (data.status === 1 && data.product) {
        const product = data.product;
        
        return {
          source: 'OpenFoodFacts',
          foodName: product.product_name || 'Unknown Product',
          brandOwner: product.brands,
          ingredients: this.parseOFFIngredients(product.ingredients_text || ''),
          nutritionFacts: {
            calories: product.nutriments['energy-kcal_100g'],
            totalSugars: product.nutriments.sugars_100g,
            addedSugars: product.nutriments['added-sugars_100g'],
            sodium: product.nutriments.sodium_100g,
            saturatedFat: product.nutriments['saturated-fat_100g'],
            fiber: product.nutriments.fiber_100g,
            protein: product.nutriments.proteins_100g
          },
          healthMetrics: {
            novaGroup: product.nova_group,
            nutrientLevels: product.nutrient_levels || {},
            additives: product.additives_tags || [],
            preservatives: this.extractPreservatives(product.additives_tags || []),
            artificialIngredients: this.extractArtificialIngredients(product.ingredients_text || '')
          }
        };
      }
    } catch (error) {
      console.warn('OpenFoodFacts API error:', error);
    }
    return null;
  }

  private async getEdamamData(query: string) {
    try {
      if (!this.edamamAppId || !this.edamamAppKey) return null;

      const url = `https://api.edamam.com/api/nutrition-data?app_id=${this.edamamAppId}&app_key=${this.edamamAppKey}&ingr=${encodeURIComponent(query)}`;
      const response = await fetch(url);
      const data: EdamamNutritionData = await response.json();

      if (data.calories > 0) {
        return {
          source: 'Edamam',
          nutritionFacts: {
            calories: data.calories,
            totalFat: data.totalNutrients.FAT?.quantity,
            saturatedFat: data.totalNutrients.FASAT?.quantity,
            transFat: data.totalNutrients.FATRN?.quantity,
            cholesterol: data.totalNutrients.CHOLE?.quantity,
            sodium: data.totalNutrients.NA?.quantity,
            carbohydrates: data.totalNutrients.CHOCDF?.quantity,
            fiber: data.totalNutrients.FIBTG?.quantity,
            totalSugars: data.totalNutrients.SUGAR?.quantity,
            protein: data.totalNutrients.PROCNT?.quantity,
            vitaminC: data.totalNutrients.VITC?.quantity,
            calcium: data.totalNutrients.CA?.quantity,
            iron: data.totalNutrients.FE?.quantity
          }
        };
      }
    } catch (error) {
      console.warn('Edamam API error:', error);
    }
    return null;
  }

  private mergeNutritionData(
    target: Partial<ComprehensiveNutritionData>, 
    source: any, 
    sourceName: string
  ) {
    if (!source) return;

    target.dataSources!.push(sourceName);

    // Merge basic info (prioritize earlier sources)
    if (source.foodName && !target.foodName) {
      target.foodName = source.foodName;
    }
    if (source.brandOwner && !target.brandOwner) {
      target.brandOwner = source.brandOwner;
    }

    // Merge ingredients
    if (source.ingredients && source.ingredients.length > 0) {
      target.ingredients = [...(target.ingredients || []), ...source.ingredients];
      target.ingredients = [...new Set(target.ingredients)]; // Remove duplicates
    }

    // Merge nutrition facts (use first available value for each nutrient)
    if (source.nutritionFacts) {
      Object.keys(source.nutritionFacts).forEach(key => {
        if (source.nutritionFacts[key] !== undefined && target.nutritionFacts![key] === undefined) {
          target.nutritionFacts![key] = source.nutritionFacts[key];
        }
      });
    }

    // Merge health metrics
    if (source.healthMetrics) {
      const targetHealth = target.healthMetrics!;
      const sourceHealth = source.healthMetrics;

      if (sourceHealth.novaGroup && !targetHealth.novaGroup) {
        targetHealth.novaGroup = sourceHealth.novaGroup;
      }

      // Merge nutrient levels
      Object.assign(targetHealth.nutrientLevels, sourceHealth.nutrientLevels || {});

      // Merge arrays
      targetHealth.additives.push(...(sourceHealth.additives || []));
      targetHealth.preservatives.push(...(sourceHealth.preservatives || []));
      targetHealth.artificialIngredients.push(...(sourceHealth.artificialIngredients || []));

      // Remove duplicates
      targetHealth.additives = [...new Set(targetHealth.additives)];
      targetHealth.preservatives = [...new Set(targetHealth.preservatives)];
      targetHealth.artificialIngredients = [...new Set(targetHealth.artificialIngredients)];
    }
  }

  private calculateConfidence(data: Partial<ComprehensiveNutritionData>): number {
    let score = 0;
    
    // Base score for having data sources
    score += (data.dataSources?.length || 0) * 0.2;
    
    // Nutrition completeness (max 0.4)
    const nutritionKeys = Object.keys(data.nutritionFacts || {});
    const completeness = Math.min(nutritionKeys.length / 10, 1);
    score += completeness * 0.4;
    
    // Ingredients data (0.2)
    if (data.ingredients && data.ingredients.length > 0) {
      score += 0.2;
    }
    
    // Health metrics (0.2)
    const healthMetrics = data.healthMetrics;
    if (healthMetrics) {
      if (healthMetrics.novaGroup) score += 0.05;
      if (Object.keys(healthMetrics.nutrientLevels).length > 0) score += 0.05;
      if (healthMetrics.additives.length > 0) score += 0.05;
      if (healthMetrics.preservatives.length > 0) score += 0.05;
    }
    
    return Math.min(score, 1.0);
  }

  private parseOFFIngredients(ingredientsText: string): string[] {
    if (!ingredientsText) return [];
    
    return ingredientsText
      .split(',')
      .map(ingredient => ingredient.trim())
      .filter(ingredient => ingredient.length > 0);
  }

  private extractPreservatives(additives: string[]): string[] {
    const preservativeKeywords = [
      'preservative', 'antioxidant', 'e2', 'e3', 'benzoate', 'sorbate', 
      'sulfite', 'nitrite', 'nitrate', 'bht', 'bha', 'tbhq'
    ];
    
    return additives.filter(additive => 
      preservativeKeywords.some(keyword => 
        additive.toLowerCase().includes(keyword)
      )
    );
  }

  private extractArtificialIngredients(ingredientsText: string): string[] {
    const artificialKeywords = [
      'artificial', 'synthetic', 'modified', 'high fructose corn syrup',
      'aspartame', 'sucralose', 'acesulfame', 'saccharin', 'neotame',
      'monosodium glutamate', 'msg', 'natural flavor', 'artificial flavor'
    ];
    
    const ingredients = this.parseOFFIngredients(ingredientsText);
    
    return ingredients.filter(ingredient => 
      artificialKeywords.some(keyword => 
        ingredient.toLowerCase().includes(keyword)
      )
    );
  }
}

export const nutritionAggregator = new NutritionAggregatorService();