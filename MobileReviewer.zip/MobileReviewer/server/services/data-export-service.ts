import { storage } from '../storage';
import { googleSheetsService } from './google-sheets-service';
import type { User } from '@shared/schema';

export interface DataExportRequest {
  userId: number;
  requestType: 'gdpr' | 'ccpa' | 'customer_service' | 'user_request';
  requestedBy: string;
  includeDeleted?: boolean;
  dateRange?: {
    start: Date;
    end: Date;
  };
}

export interface DataExportResult {
  exportId: string;
  spreadsheetUrl: string;
  totalDataPoints: number;
  categories: string[];
  generatedAt: Date;
  validUntil: Date;
}

export class DataExportService {
  
  /**
   * Export complete user data to Google Sheets
   */
  async exportUserData(request: DataExportRequest): Promise<DataExportResult> {
    try {
      const user = await storage.getUser(request.userId);
      if (!user) {
        throw new Error('User not found');
      }

      // Collect all user data
      const [sugarEntries, moodEntries, cravingEntries, chatMessages, foodAnalyses] = await Promise.all([
        storage.getUserSugarEntries(request.userId, request.dateRange?.start, request.dateRange?.end),
        storage.getUserMoodEntries(request.userId, request.dateRange?.start, request.dateRange?.end),
        storage.getUserCravingEntries(request.userId, request.dateRange?.start, request.dateRange?.end),
        storage.getUserChatMessages(request.userId, undefined, 1000), // Get all messages
        storage.getUserFoodAnalyses(request.userId, 1000) // Get all analyses
      ]);

      const totalDataPoints = sugarEntries.length + moodEntries.length + 
                             cravingEntries.length + chatMessages.length + foodAnalyses.length;

      const userData = {
        user,
        sugarEntries,
        moodEntries,
        cravingEntries,
        chatMessages,
        foodAnalyses,
        exportDate: new Date().toISOString(),
        totalDataPoints
      };

      // Export to Google Sheets
      const spreadsheetUrl = await googleSheetsService.exportUserData(userData);
      
      const exportId = `export_${request.userId}_${Date.now()}`;
      const generatedAt = new Date();
      const validUntil = new Date(generatedAt.getTime() + (30 * 24 * 60 * 60 * 1000)); // 30 days

      // Log the export for compliance
      await this.logDataExport(request, exportId, spreadsheetUrl, totalDataPoints);

      return {
        exportId,
        spreadsheetUrl,
        totalDataPoints,
        categories: ['User Profile', 'Sugar Tracking', 'Mood Tracking', 'Craving Tracking', 'AI Conversations', 'Food Analysis'],
        generatedAt,
        validUntil
      };

    } catch (error) {
      console.error('Data export failed:', error);
      throw new Error('Failed to export user data');
    }
  }

  /**
   * Create a secure data package for customer service
   */
  async createCustomerServicePackage(userId: number, requestedBy: string): Promise<DataExportResult> {
    const request: DataExportRequest = {
      userId,
      requestType: 'customer_service',
      requestedBy,
      dateRange: {
        start: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000), // Last 90 days
        end: new Date()
      }
    };

    return this.exportUserData(request);
  }

  /**
   * Handle GDPR data portability request
   */
  async handleGDPRRequest(userId: number): Promise<DataExportResult> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const request: DataExportRequest = {
      userId,
      requestType: 'gdpr',
      requestedBy: user.email || user.username || `user_${userId}`,
      includeDeleted: true
    };

    const result = await this.exportUserData(request);

    // Send notification email (if email service is configured)
    await this.notifyUserOfExport(user, result);

    return result;
  }

  /**
   * Handle CCPA data request
   */
  async handleCCPARequest(userId: number): Promise<DataExportResult> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const request: DataExportRequest = {
      userId,
      requestType: 'ccpa',
      requestedBy: user.email || user.username || `user_${userId}`,
      includeDeleted: true
    };

    return this.exportUserData(request);
  }

  /**
   * Get user data summary for quick customer service
   */
  async getUserDataSummary(userId: number): Promise<any> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const [sugarCount, moodCount, cravingCount, chatCount, analysisCount] = await Promise.all([
      storage.getUserSugarEntries(userId).then(entries => entries.length),
      storage.getUserMoodEntries(userId).then(entries => entries.length),
      storage.getUserCravingEntries(userId).then(entries => entries.length),
      storage.getUserChatMessages(userId).then(messages => messages.length),
      storage.getUserFoodAnalyses(userId).then(analyses => analyses.length)
    ]);

    return {
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        subscriptionTier: user.subscriptionTier,
        createdAt: user.createdAt,
        weeklyServicesUsed: user.weeklyServicesUsed,
        lastServicesReset: user.lastServicesReset
      },
      dataCounts: {
        sugarEntries: sugarCount,
        moodEntries: moodCount,
        cravingEntries: cravingCount,
        chatMessages: chatCount,
        foodAnalyses: analysisCount,
        total: sugarCount + moodCount + cravingCount + chatCount + analysisCount
      },
      lastActivity: {
        // This could be enhanced to track actual last activity
        estimated: new Date()
      }
    };
  }

  private async logDataExport(
    request: DataExportRequest, 
    exportId: string, 
    spreadsheetUrl: string, 
    totalDataPoints: number
  ): Promise<void> {
    try {
      await googleSheetsService.logSystemEvent('data_export', {
        exportId,
        userId: request.userId,
        requestType: request.requestType,
        requestedBy: request.requestedBy,
        spreadsheetUrl,
        totalDataPoints,
        timestamp: new Date().toISOString()
      }, 'info');
    } catch (error) {
      console.error('Failed to log data export:', error);
    }
  }

  private async notifyUserOfExport(user: User, result: DataExportResult): Promise<void> {
    // Placeholder for email notification
    // In production, integrate with your email service
    console.log(`Data export ready for user ${user.email}: ${result.spreadsheetUrl}`);
  }
}

export const dataExportService = new DataExportService();