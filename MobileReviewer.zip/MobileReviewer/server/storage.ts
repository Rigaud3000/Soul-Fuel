import { 
  users, 
  sugarEntries, 
  moodEntries, 
  cravingEntries, 
  chatMessages, 
  foodAnalyses, 
  recipes, 
  weeklyGoals,
  userRecipeInteractions,
  gameProgress,
  wearableDevices,
  healthMetrics,
  type User, 
  type InsertUser,
  type SugarEntry,
  type InsertSugarEntry,
  type MoodEntry,
  type InsertMoodEntry,
  type CravingEntry,
  type InsertCravingEntry,
  type ChatMessage,
  type InsertChatMessage,
  type FoodAnalysis,
  type InsertFoodAnalysis,
  type Recipe,
  type WeeklyGoal,
  type InsertWeeklyGoal,
  type UserRecipeInteraction,
  type InsertUserRecipeInteraction,
  type GameProgress,
  type InsertGameProgress,
  type WearableDevice,
  type InsertWearableDevice,
  type HealthMetric,
  type InsertHealthMetric
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserSubscription(id: number, tier: string): Promise<User>;
  updateUserStripeInfo(id: number, customerId: string, subscriptionId?: string): Promise<User>;
  checkAndUpdateServiceUsage(userId: number): Promise<{ canUse: boolean; servicesRemaining: number }>;
  resetWeeklyServicesIfNeeded(userId: number): Promise<User>;
  incrementServiceUsage(userId: number): Promise<User>;
  
  // Sugar tracking methods
  createSugarEntry(entry: InsertSugarEntry): Promise<SugarEntry>;
  getUserSugarEntries(userId: number, startDate?: Date, endDate?: Date): Promise<SugarEntry[]>;
  
  // Mood tracking methods
  createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry>;
  getUserMoodEntries(userId: number, startDate?: Date, endDate?: Date): Promise<MoodEntry[]>;
  
  // Craving tracking methods
  createCravingEntry(entry: InsertCravingEntry): Promise<CravingEntry>;
  getUserCravingEntries(userId: number, startDate?: Date, endDate?: Date): Promise<CravingEntry[]>;
  
  // Chat methods
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getUserChatMessages(userId: number, coachType?: string, limit?: number): Promise<ChatMessage[]>;
  
  // Food analysis methods
  createFoodAnalysis(analysis: InsertFoodAnalysis): Promise<FoodAnalysis>;
  getUserFoodAnalyses(userId: number, limit?: number): Promise<FoodAnalysis[]>;
  
  // Recipe methods
  getRecipes(filters?: {
    mealType?: string;
    dietaryTypes?: string[];
    healthFocus?: string[];
    tags?: string[];
    limit?: number;
    offset?: number;
  }): Promise<Recipe[]>;
  getRecipeById(id: number): Promise<Recipe | undefined>;
  getUserRecipeInteraction(userId: number, recipeId: number): Promise<UserRecipeInteraction | undefined>;
  createRecipeInteraction(interaction: InsertUserRecipeInteraction): Promise<UserRecipeInteraction>;
  updateRecipeInteraction(userId: number, recipeId: number, updates: Partial<InsertUserRecipeInteraction>): Promise<UserRecipeInteraction>;
  
  // Weekly goals methods
  getUserWeeklyGoal(userId: number, weekStart: Date): Promise<WeeklyGoal | undefined>;
  createWeeklyGoal(goal: InsertWeeklyGoal): Promise<WeeklyGoal>;
  updateWeeklyGoalProgress(id: number, completed: number): Promise<WeeklyGoal>;
  
  // Game progress methods
  getUserGameProgress(userId: number): Promise<GameProgress[]>;
  updateGameProgress(userId: number, progress: { gameId: string; score: number; level?: number; achievements?: string }): Promise<GameProgress>;
  
  // Wearable device methods
  getUserWearableDevices(userId: number): Promise<WearableDevice[]>;
  connectWearableDevice(userId: number, device: InsertWearableDevice): Promise<WearableDevice>;
  disconnectWearableDevice(userId: number, deviceId: string): Promise<void>;
  updateWearableDeviceTokens(deviceId: number, accessToken: string, refreshToken?: string, expiresAt?: Date): Promise<WearableDevice>;
  
  // Health metrics methods
  storeHealthMetrics(userId: number, metrics: InsertHealthMetric): Promise<HealthMetric>;
  getHealthMetrics(userId: number, filters?: {
    startDate?: Date;
    endDate?: Date;
    metricType?: string;
    deviceId?: number;
  }): Promise<HealthMetric[]>;
  getLatestHealthMetrics(userId: number): Promise<HealthMetric | undefined>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Seed recipes on first run
    this.seedRecipes();
  }

  private async seedRecipes() {
    try {
      // Check if recipes already exist
      const existingRecipes = await db.select().from(recipes).limit(1);
      if (existingRecipes.length > 0) {
        return; // Already seeded
      }

      const recipesData = [
        {
          name: "Rainbow Veggie Stir-Fry",
          description: "A colorful mix of vegetables with ginger and garlic",
          ingredients: JSON.stringify(["bell peppers", "broccoli", "carrots", "snap peas", "ginger", "garlic", "olive oil"]),
          instructions: JSON.stringify(["Heat oil in wok", "Add ginger and garlic", "Stir-fry vegetables", "Season to taste"]),
          sugarContent: 3,
          prepTime: 15,
          tags: JSON.stringify(["Low Sugar", "Quick", "Vegetarian"]),
          imageUrl: "https://images.unsplash.com/photo-1512058564366-18510be2db19"
        },
        {
          name: "Mediterranean Quinoa Bowl",
          description: "Protein-packed quinoa with fresh vegetables and herbs",
          ingredients: JSON.stringify(["quinoa", "cherry tomatoes", "cucumber", "olives", "feta cheese", "herbs"]),
          instructions: JSON.stringify(["Cook quinoa", "Chop vegetables", "Combine ingredients", "Dress with olive oil"]),
          sugarContent: 4,
          prepTime: 20,
          tags: JSON.stringify(["High Protein", "Low Sugar", "Mediterranean"]),
          imageUrl: "https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38"
        },
        {
          name: "Green Goddess Smoothie Bowl",
          description: "Nutrient-dense smoothie bowl with natural sweetness",
          ingredients: JSON.stringify(["spinach", "banana", "avocado", "almond milk", "chia seeds", "berries"]),
          instructions: JSON.stringify(["Blend ingredients", "Pour into bowl", "Top with berries and seeds"]),
          sugarContent: 8,
          prepTime: 10,
          tags: JSON.stringify(["Breakfast", "Smoothie", "Quick"]),
          imageUrl: "https://images.unsplash.com/photo-1511690656952-34342bb7c2f2"
        }
      ];

      await db.insert(recipes).values(recipesData);
    } catch (error) {
      console.error("Error seeding recipes:", error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.firebaseUid, firebaseUid));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserSubscription(id: number, tier: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ subscriptionTier: tier })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStripeInfo(id: number, customerId: string, subscriptionId?: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId || null,
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async createSugarEntry(insertEntry: InsertSugarEntry): Promise<SugarEntry> {
    const [entry] = await db.insert(sugarEntries).values(insertEntry).returning();
    return entry;
  }

  async getUserSugarEntries(userId: number, startDate?: Date, endDate?: Date): Promise<SugarEntry[]> {
    if (startDate && endDate) {
      return await db
        .select()
        .from(sugarEntries)
        .where(
          and(
            eq(sugarEntries.userId, userId),
            gte(sugarEntries.date, startDate),
            lte(sugarEntries.date, endDate)
          )
        )
        .orderBy(desc(sugarEntries.date));
    } else {
      return await db
        .select()
        .from(sugarEntries)
        .where(eq(sugarEntries.userId, userId))
        .orderBy(desc(sugarEntries.date));
    }
  }

  async createMoodEntry(insertEntry: InsertMoodEntry): Promise<MoodEntry> {
    const [entry] = await db.insert(moodEntries).values(insertEntry).returning();
    return entry;
  }

  async getUserMoodEntries(userId: number, startDate?: Date, endDate?: Date): Promise<MoodEntry[]> {
    if (startDate && endDate) {
      return await db
        .select()
        .from(moodEntries)
        .where(
          and(
            eq(moodEntries.userId, userId),
            gte(moodEntries.date, startDate),
            lte(moodEntries.date, endDate)
          )
        )
        .orderBy(desc(moodEntries.date));
    } else {
      return await db
        .select()
        .from(moodEntries)
        .where(eq(moodEntries.userId, userId))
        .orderBy(desc(moodEntries.date));
    }
  }

  async createCravingEntry(insertEntry: InsertCravingEntry): Promise<CravingEntry> {
    const [entry] = await db.insert(cravingEntries).values(insertEntry).returning();
    return entry;
  }

  async getUserCravingEntries(userId: number, startDate?: Date, endDate?: Date): Promise<CravingEntry[]> {
    if (startDate && endDate) {
      return await db
        .select()
        .from(cravingEntries)
        .where(
          and(
            eq(cravingEntries.userId, userId),
            gte(cravingEntries.date, startDate),
            lte(cravingEntries.date, endDate)
          )
        )
        .orderBy(desc(cravingEntries.date));
    } else {
      return await db
        .select()
        .from(cravingEntries)
        .where(eq(cravingEntries.userId, userId))
        .orderBy(desc(cravingEntries.date));
    }
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db.insert(chatMessages).values(insertMessage).returning();
    return message;
  }

  async getUserChatMessages(userId: number, coachType?: string, limit: number = 50): Promise<ChatMessage[]> {
    if (coachType) {
      return await db
        .select()
        .from(chatMessages)
        .where(and(eq(chatMessages.userId, userId), eq(chatMessages.coachType, coachType)))
        .orderBy(desc(chatMessages.timestamp))
        .limit(limit);
    } else {
      return await db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.userId, userId))
        .orderBy(desc(chatMessages.timestamp))
        .limit(limit);
    }
  }

  async createFoodAnalysis(insertAnalysis: InsertFoodAnalysis): Promise<FoodAnalysis> {
    const [analysis] = await db.insert(foodAnalyses).values(insertAnalysis).returning();
    return analysis;
  }

  async getUserFoodAnalyses(userId: number, limit: number = 20): Promise<FoodAnalysis[]> {
    return await db
      .select()
      .from(foodAnalyses)
      .where(eq(foodAnalyses.userId, userId))
      .orderBy(desc(foodAnalyses.timestamp))
      .limit(limit);
  }

  async getRecipes(filters?: {
    mealType?: string;
    dietaryTypes?: string[];
    healthFocus?: string[];
    tags?: string[];
    limit?: number;
    offset?: number;
  }): Promise<Recipe[]> {
    let query = db.select().from(recipes);
    
    if (filters?.mealType) {
      query = query.where(eq(recipes.mealType, filters.mealType));
    }
    
    // Apply limit and offset
    const limit = filters?.limit || 20;
    const offset = filters?.offset || 0;
    
    const result = await query.limit(limit).offset(offset);
    
    // Filter by dietary types and health focus in JavaScript since SQL array filtering is complex
    let filteredResults = result;
    
    if (filters?.dietaryTypes && filters.dietaryTypes.length > 0) {
      filteredResults = filteredResults.filter(recipe => 
        recipe.dietaryTypes && filters.dietaryTypes!.some(diet => 
          recipe.dietaryTypes!.includes(diet)
        )
      );
    }
    
    if (filters?.healthFocus && filters.healthFocus.length > 0) {
      filteredResults = filteredResults.filter(recipe => 
        recipe.healthFocus && filters.healthFocus!.some(focus => 
          recipe.healthFocus!.includes(focus)
        )
      );
    }
    
    return filteredResults;
  }

  async getRecipeById(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe || undefined;
  }

  async getUserRecipeInteraction(userId: number, recipeId: number): Promise<UserRecipeInteraction | undefined> {
    const [interaction] = await db.select().from(userRecipeInteractions)
      .where(and(eq(userRecipeInteractions.userId, userId), eq(userRecipeInteractions.recipeId, recipeId)));
    return interaction || undefined;
  }

  async createRecipeInteraction(insertInteraction: InsertUserRecipeInteraction): Promise<UserRecipeInteraction> {
    const [interaction] = await db.insert(userRecipeInteractions)
      .values(insertInteraction)
      .returning();
    return interaction;
  }

  async updateRecipeInteraction(userId: number, recipeId: number, updates: Partial<InsertUserRecipeInteraction>): Promise<UserRecipeInteraction> {
    const [interaction] = await db.update(userRecipeInteractions)
      .set(updates)
      .where(and(eq(userRecipeInteractions.userId, userId), eq(userRecipeInteractions.recipeId, recipeId)))
      .returning();
    return interaction;
  }

  async getUserWeeklyGoal(userId: number, weekStart: Date): Promise<WeeklyGoal | undefined> {
    const [goal] = await db
      .select()
      .from(weeklyGoals)
      .where(
        and(
          eq(weeklyGoals.userId, userId),
          eq(weeklyGoals.weekStartDate, weekStart)
        )
      );
    return goal || undefined;
  }

  async createWeeklyGoal(insertGoal: InsertWeeklyGoal): Promise<WeeklyGoal> {
    const [goal] = await db.insert(weeklyGoals).values(insertGoal).returning();
    return goal;
  }

  async updateWeeklyGoalProgress(id: number, completed: number): Promise<WeeklyGoal> {
    const [goal] = await db
      .update(weeklyGoals)
      .set({ completed })
      .where(eq(weeklyGoals.id, id))
      .returning();
    return goal;
  }

  async checkAndUpdateServiceUsage(userId: number): Promise<{ canUse: boolean; servicesRemaining: number }> {
    // First reset services if a week has passed
    await this.resetWeeklyServicesIfNeeded(userId);
    
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) {
      throw new Error("User not found");
    }

    // Pro users have unlimited access
    if (user.subscriptionTier === 'pro' || user.subscriptionTier === 'gold' || user.subscriptionTier === 'platinum' || user.subscriptionTier === 'diamond') {
      return { canUse: true, servicesRemaining: -1 }; // -1 indicates unlimited
    }

    // Free users get 4 services per week (AI coaching, food scanning, advanced features)
    const maxServices = 4;
    const servicesUsed = user.weeklyServicesUsed || 0;
    const servicesRemaining = maxServices - servicesUsed;

    return { 
      canUse: servicesRemaining > 0, 
      servicesRemaining: Math.max(0, servicesRemaining)
    };
  }

  async resetWeeklyServicesIfNeeded(userId: number): Promise<User> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) {
      throw new Error("User not found");
    }

    const lastReset = user.lastServiceReset || user.createdAt;
    const now = new Date();
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    // Reset if more than a week has passed
    if (lastReset && lastReset < oneWeekAgo) {
      const [updatedUser] = await db.update(users)
        .set({ 
          weeklyServicesUsed: 0, 
          lastServiceReset: now 
        })
        .where(eq(users.id, userId))
        .returning();
      return updatedUser;
    }

    return user;
  }

  async incrementServiceUsage(userId: number): Promise<User> {
    const [updatedUser] = await db.update(users)
      .set({ 
        weeklyServicesUsed: sql`${users.weeklyServicesUsed} + 1`
      })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }

  async getUserGameProgress(userId: number): Promise<GameProgress[]> {
    const progress = await db
      .select()
      .from(gameProgress)
      .where(eq(gameProgress.userId, userId));
    
    return progress;
  }

  async updateGameProgress(userId: number, progressData: { 
    gameId: string; 
    score: number; 
    level?: number; 
    achievements?: string 
  }): Promise<GameProgress> {
    // Check if progress exists for this game
    const [existingProgress] = await db
      .select()
      .from(gameProgress)
      .where(and(
        eq(gameProgress.userId, userId),
        eq(gameProgress.gameId, progressData.gameId)
      ));

    if (existingProgress) {
      // Update existing progress
      const [updated] = await db
        .update(gameProgress)
        .set({
          score: existingProgress.score + progressData.score,
          level: progressData.level || existingProgress.level,
          achievements: progressData.achievements || existingProgress.achievements,
          totalSessions: existingProgress.totalSessions + 1,
          lastPlayed: new Date(),
          updatedAt: new Date()
        })
        .where(eq(gameProgress.id, existingProgress.id))
        .returning();
      
      return updated;
    } else {
      // Create new progress record
      const [newProgress] = await db
        .insert(gameProgress)
        .values({
          userId,
          gameId: progressData.gameId,
          score: progressData.score,
          level: progressData.level || 1,
          achievements: progressData.achievements || "[]",
          totalSessions: 1
        })
        .returning();
      
      return newProgress;
    }
  }

  // Wearable device methods
  async getUserWearableDevices(userId: number): Promise<WearableDevice[]> {
    const devices = await db
      .select()
      .from(wearableDevices)
      .where(and(
        eq(wearableDevices.userId, userId),
        eq(wearableDevices.isActive, true)
      ))
      .orderBy(desc(wearableDevices.connectedAt));
    
    return devices;
  }

  async connectWearableDevice(userId: number, deviceData: InsertWearableDevice): Promise<WearableDevice> {
    const [device] = await db
      .insert(wearableDevices)
      .values({
        ...deviceData,
        userId
      })
      .returning();
    
    return device;
  }

  async disconnectWearableDevice(userId: number, deviceId: string): Promise<void> {
    await db
      .update(wearableDevices)
      .set({ isActive: false, updatedAt: new Date() })
      .where(and(
        eq(wearableDevices.userId, userId),
        eq(wearableDevices.id, parseInt(deviceId))
      ));
  }

  async updateWearableDeviceTokens(deviceId: number, accessToken: string, refreshToken?: string, expiresAt?: Date): Promise<WearableDevice> {
    const [device] = await db
      .update(wearableDevices)
      .set({
        accessToken,
        refreshToken,
        tokenExpiresAt: expiresAt,
        lastSync: new Date(),
        updatedAt: new Date()
      })
      .where(eq(wearableDevices.id, deviceId))
      .returning();
    
    return device;
  }

  // Health metrics methods
  async storeHealthMetrics(userId: number, metricsData: InsertHealthMetric): Promise<HealthMetric> {
    const [metrics] = await db
      .insert(healthMetrics)
      .values({
        ...metricsData,
        userId
      })
      .returning();
    
    return metrics;
  }

  async getHealthMetrics(userId: number, filters?: {
    startDate?: Date;
    endDate?: Date;
    metricType?: string;
    deviceId?: number;
  }): Promise<HealthMetric[]> {
    let query = db
      .select()
      .from(healthMetrics)
      .where(eq(healthMetrics.userId, userId));

    if (filters?.startDate) {
      query = query.where(gte(healthMetrics.recordedAt, filters.startDate));
    }
    
    if (filters?.endDate) {
      query = query.where(lte(healthMetrics.recordedAt, filters.endDate));
    }
    
    if (filters?.deviceId) {
      query = query.where(eq(healthMetrics.deviceId, filters.deviceId));
    }

    const metrics = await query.orderBy(desc(healthMetrics.recordedAt));
    return metrics;
  }

  async getLatestHealthMetrics(userId: number): Promise<HealthMetric | undefined> {
    const [latest] = await db
      .select()
      .from(healthMetrics)
      .where(eq(healthMetrics.userId, userId))
      .orderBy(desc(healthMetrics.recordedAt))
      .limit(1);
    
    return latest;
  }
}

export const storage = new DatabaseStorage();