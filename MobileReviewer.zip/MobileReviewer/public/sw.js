// SOULFUEL Enhanced Service Worker v2.0
const CACHE_NAME = 'soulfuel-enhanced-v2';
const STATIC_CACHE = 'soulfuel-static-v2';
const DYNAMIC_CACHE = 'soulfuel-dynamic-v2';

const STATIC_ASSETS = [
  '/',
  '/manifest.json',
  '/offline.html'
];

const CACHE_STRATEGIES = {
  images: 'cache-first',
  api: 'network-first',
  static: 'cache-first'
};

// Enhanced install event
self.addEventListener('install', (event) => {
  console.log('SOULFUEL Service Worker installing...');
  event.waitUntil(
    Promise.all([
      caches.open(STATIC_CACHE).then(cache => {
        console.log('Caching static assets');
        return cache.addAll(STATIC_ASSETS).catch(err => {
          console.warn('Some static assets failed to cache:', err);
        });
      }),
      self.skipWaiting()
    ])
  );
});

// Enhanced activate event
self.addEventListener('activate', (event) => {
  console.log('SOULFUEL Service Worker activating...');
  event.waitUntil(
    Promise.all([
      // Clean up old caches
      caches.keys().then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
              console.log('Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      }),
      self.clients.claim()
    ])
  );
});

// Enhanced fetch event with intelligent caching
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  // API requests - network first with fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then(response => {
          if (response.ok) {
            const responseClone = response.clone();
            caches.open(DYNAMIC_CACHE).then(cache => {
              cache.put(request, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          return caches.match(request);
        })
    );
    return;
  }

  // Images - cache first
  if (request.destination === 'image') {
    event.respondWith(
      caches.match(request)
        .then(response => {
          if (response) {
            return response;
          }
          return fetch(request).then(fetchResponse => {
            const responseClone = fetchResponse.clone();
            caches.open(DYNAMIC_CACHE).then(cache => {
              cache.put(request, responseClone);
            });
            return fetchResponse;
          });
        })
    );
    return;
  }

  // Default strategy - network first with cache fallback
  event.respondWith(
    fetch(request)
      .then(response => {
        if (response.ok) {
          const responseClone = response.clone();
          caches.open(DYNAMIC_CACHE).then(cache => {
            cache.put(request, responseClone);
          });
        }
        return response;
      })
      .catch(() => {
        return caches.match(request);
      })
  );
});

// Enhanced push notification event
self.addEventListener('push', (event) => {
  console.log('SOULFUEL Push notification received:', event);
  
  const defaultOptions = {
    body: 'Your wellness journey continues...',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    vibrate: [200, 100, 200, 100, 200],
    requireInteraction: false,
    silent: false,
    renotify: false,
    tag: 'soulfuel-reminder',
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 'soulfuel',
      url: '/'
    }
  };

  let notificationData = defaultOptions;

  if (event.data) {
    try {
      const pushData = event.data.json();
      notificationData = { ...defaultOptions, ...pushData };
      console.log('Parsed push data:', pushData);
    } catch (e) {
      console.warn('Using default notification options, parse error:', e);
      notificationData = {
        ...defaultOptions,
        body: event.data.text() || defaultOptions.body
      };
    }
  }

  // Customize notification based on type
  const type = notificationData.type || 'general';
  const customizations = getNotificationCustomization(type);
  notificationData = { ...notificationData, ...customizations };

  const promiseChain = self.registration.showNotification(
    notificationData.title || 'SOULFUEL Wellness',
    notificationData
  );

  event.waitUntil(promiseChain);
});

// Get notification customization by type
function getNotificationCustomization(type) {
  const customizations = {
    mood: {
      icon: '🧘',
      badge: '🧘',
      tag: 'soulfuel-mood',
      vibrate: [100, 50, 100]
    },
    sugar: {
      icon: '📝',
      badge: '📝', 
      tag: 'soulfuel-sugar',
      vibrate: [150, 75, 150]
    },
    hydration: {
      icon: '💧',
      badge: '💧',
      tag: 'soulfuel-water',
      vibrate: [100, 100, 100]
    },
    exercise: {
      icon: '🏃‍♂️',
      badge: '🏃‍♂️',
      tag: 'soulfuel-exercise',
      vibrate: [200, 100, 200]
    },
    motivation: {
      icon: '✨',
      badge: '✨',
      tag: 'soulfuel-motivation',
      vibrate: [100, 50, 100, 50, 100]
    },
    craving: {
      icon: '🛡️',
      badge: '🛡️',
      tag: 'soulfuel-emergency',
      vibrate: [300, 100, 300, 100, 300],
      requireInteraction: true
    }
  };

  return customizations[type] || customizations.motivation;
}

// Notification click event
self.addEventListener('notificationclick', (event) => {
  console.log('Notification click received:', event);
  
  event.notification.close();

  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/')
    );
  } else if (event.action === 'close') {
    // Just close the notification
    return;
  } else {
    // Default action - open the app
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Background sync event
self.addEventListener('sync', (event) => {
  if (event.tag === 'background-sync') {
    event.waitUntil(doBackgroundSync());
  }
});

function doBackgroundSync() {
  console.log('Background sync triggered');
  // Implement background data sync here
  return Promise.resolve();
}