import { pgTable, text, serial, integer, timestamp, real, jsonb, boolean, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  firebaseUid: text("firebase_uid").notNull().unique(),
  username: text("username").notNull(),
  subscriptionTier: text("subscription_tier").notNull().default("free"), // free, pro
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  weeklyServicesUsed: integer("weekly_services_used").default(0),
  lastServiceReset: timestamp("last_service_reset").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sugarEntries = pgTable("sugar_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: real("amount").notNull(), // grams of sugar
  date: timestamp("date").notNull(),
  mealType: text("meal_type"), // breakfast, lunch, dinner, snack
  notes: text("notes"),
});

export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mood: text("mood").notNull(), // happy, okay, sad, stressed
  date: timestamp("date").notNull(),
  notes: text("notes"),
});

export const cravingEntries = pgTable("craving_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  intensity: integer("intensity").notNull(), // 1-100
  trigger: text("trigger"),
  date: timestamp("date").notNull(),
  notes: text("notes"),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  message: text("message").notNull(),
  response: text("response").notNull(),
  coachType: text("coach_type").default("general").notNull(), // fitness, eating, shopping, mindset, wellness, recovery, general
  timestamp: timestamp("timestamp").defaultNow(),
});

export const foodAnalyses = pgTable("food_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  foodName: text("food_name").notNull(),
  brandOwner: text("brand_owner"),
  barcode: text("barcode"),
  healthScore: text("health_score").notNull(), // A, B, C, D, F
  isUltraProcessed: boolean("is_ultra_processed").default(false).notNull(),
  ingredients: text("ingredients").array(), // Array of ingredients
  nutritionFacts: jsonb("nutrition_facts"), // JSON object of nutrition data
  redFlags: text("red_flags").array(), // Array of health concerns
  recommendations: text("recommendations").array(), // Array of suggestions
  analysisMethod: text("analysis_method").notNull(), // 'barcode', 'image', 'text'
  confidence: real("confidence"), // 0-1 confidence score
  sugarContent: real("sugar_content"), // Backward compatibility
  analysis: jsonb("analysis"), // detailed AI analysis - legacy field
  timestamp: timestamp("timestamp").defaultNow(),
});

export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  ingredients: jsonb("ingredients").notNull(),
  instructions: jsonb("instructions").notNull(),
  sugarContent: real("sugar_content").notNull(),
  prepTime: integer("prep_time").notNull(),
  cookTime: integer("cook_time").default(0),
  servings: integer("servings").default(1),
  mealType: text("meal_type").notNull(), // 'breakfast', 'lunch', 'dinner', 'snack'
  category: text("category").notNull(), // 'smoothie', 'salad', 'soup', etc.
  dietaryTypes: text("dietary_types").array(), // ['plant-based', 'gluten-free', 'mediterranean', 'low-carb']
  healthFocus: text("health_focus").array(), // ['heart-healthy', 'diabetes-friendly', 'anti-inflammatory', 'cancer-fighting', 'general-wellness']
  tags: jsonb("tags").notNull(),
  imageUrl: text("image_url"),
  benefits: text("benefits"), // Health benefits description
  nutritionFacts: jsonb("nutrition_facts"), // Calories, protein, carbs, etc.
});

export const weeklyGoals = pgTable("weekly_goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  weekStartDate: timestamp("week_start_date").notNull(),
  sugarGoal: real("sugar_goal").notNull(), // grams per day
  moodCheckInGoal: integer("mood_check_in_goal").notNull().default(7),
  completed: integer("completed").notNull().default(0),
});

export const withdrawalSymptoms = pgTable("withdrawal_symptoms", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  symptomType: text("symptom_type").notNull(), // 'craving', 'mood', 'energy', 'physical'
  intensity: integer("intensity").notNull(), // 1-10 scale
  description: text("description").notNull(),
  duration: integer("duration"), // minutes
  triggers: text("triggers").array(), // Array of potential triggers
  copingStrategies: text("coping_strategies").array(), // What helped
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const userStreaks = pgTable("user_streaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  streakType: text("streak_type").notNull(), // 'clean_eating', 'no_ultra_processed', 'sugar_free'
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  lastActiveDate: timestamp("last_active_date").defaultNow().notNull(),
  totalDays: integer("total_days").notNull().default(0),
});

export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  badgeId: text("badge_id").notNull(), // 'first_scan', 'week_streak', 'sugar_detective', etc.
  badgeName: text("badge_name").notNull(),
  badgeDescription: text("badge_description").notNull(),
  earnedAt: timestamp("earned_at").defaultNow().notNull(),
});

export const userRecipeInteractions = pgTable("user_recipe_interactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  recipeId: integer("recipe_id").notNull().references(() => recipes.id),
  isBookmarked: boolean("is_bookmarked").default(false),
  hasTriedIt: boolean("has_tried_it").default(false),
  rating: integer("rating"), // 1-5 star rating
  notes: text("notes"), // User personal notes
  triedAt: timestamp("tried_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dailyCheckIns = pgTable("daily_check_ins", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: date("date").notNull(),
  sugarFree: boolean("sugar_free").default(false),
  moodLogged: boolean("mood_logged").default(false),
  exercised: boolean("exercised").default(false),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const gameProgress = pgTable("game_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  gameId: text("game_id").notNull(), // 'cravingSudoku', 'soulMatch', etc.
  score: integer("score").notNull().default(0),
  level: integer("level").notNull().default(1),
  totalSessions: integer("total_sessions").notNull().default(0),
  lastPlayed: timestamp("last_played").defaultNow(),
  achievements: text("achievements").default("[]"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const wearableDevices = pgTable("wearable_devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  deviceType: text("device_type").notNull(), // 'fitbit', 'apple-health', 'google-fit', 'samsung-health'
  deviceName: text("device_name"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiresAt: timestamp("token_expires_at"),
  isActive: boolean("is_active").default(true),
  lastSync: timestamp("last_sync"),
  connectedAt: timestamp("connected_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const healthMetrics = pgTable("health_metrics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  deviceId: integer("device_id").references(() => wearableDevices.id),
  steps: integer("steps").default(0),
  heartRate: integer("heart_rate").default(0),
  sleepHours: real("sleep_hours").default(0),
  caloriesBurned: integer("calories_burned").default(0),
  activeMinutes: integer("active_minutes").default(0),
  stressLevel: integer("stress_level").default(0),
  bloodPressureSystolic: integer("blood_pressure_systolic"),
  bloodPressureDiastolic: integer("blood_pressure_diastolic"),
  weight: real("weight"),
  bodyFatPercentage: real("body_fat_percentage"),
  recordedAt: timestamp("recorded_at").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  firebaseUid: true,
  username: true,
  subscriptionTier: true,
});

export const insertSugarEntrySchema = createInsertSchema(sugarEntries).pick({
  userId: true,
  amount: true,
  date: true,
  mealType: true,
  notes: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).pick({
  userId: true,
  mood: true,
  date: true,
  notes: true,
});

export const insertCravingEntrySchema = createInsertSchema(cravingEntries).pick({
  userId: true,
  intensity: true,
  trigger: true,
  date: true,
  notes: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  userId: true,
  message: true,
  response: true,
  coachType: true,
});

export const insertFoodAnalysisSchema = createInsertSchema(foodAnalyses).pick({
  userId: true,
  foodName: true,
  sugarContent: true,
  isHealthy: true,
  analysis: true,
});

export const insertWeeklyGoalSchema = createInsertSchema(weeklyGoals).pick({
  userId: true,
  weekStartDate: true,
  sugarGoal: true,
  moodCheckInGoal: true,
});

export const insertRecipeSchema = createInsertSchema(recipes).pick({
  name: true,
  description: true,
  ingredients: true,
  instructions: true,
  sugarContent: true,
  prepTime: true,
  cookTime: true,
  servings: true,
  mealType: true,
  category: true,
  dietaryTypes: true,
  healthFocus: true,
  tags: true,
  imageUrl: true,
  benefits: true,
  nutritionFacts: true,
});

export const insertUserRecipeInteractionSchema = createInsertSchema(userRecipeInteractions).pick({
  userId: true,
  recipeId: true,
  isBookmarked: true,
  hasTriedIt: true,
  rating: true,
  notes: true,
  triedAt: true,
});

export const insertDailyCheckInSchema = createInsertSchema(dailyCheckIns).pick({
  userId: true,
  date: true,
  sugarFree: true,
  moodLogged: true,
  exercised: true,
  completed: true,
});

export const insertGameProgressSchema = createInsertSchema(gameProgress).pick({
  userId: true,
  gameId: true,
  score: true,
  level: true,
  totalSessions: true,
  achievements: true,
});

export const insertWearableDeviceSchema = createInsertSchema(wearableDevices).pick({
  userId: true,
  deviceType: true,
  deviceName: true,
  accessToken: true,
  refreshToken: true,
  tokenExpiresAt: true,
});

export const insertHealthMetricSchema = createInsertSchema(healthMetrics).pick({
  userId: true,
  deviceId: true,
  steps: true,
  heartRate: true,
  sleepHours: true,
  caloriesBurned: true,
  activeMinutes: true,
  stressLevel: true,
  bloodPressureSystolic: true,
  bloodPressureDiastolic: true,
  weight: true,
  bodyFatPercentage: true,
  recordedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type SugarEntry = typeof sugarEntries.$inferSelect;
export type InsertSugarEntry = z.infer<typeof insertSugarEntrySchema>;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type CravingEntry = typeof cravingEntries.$inferSelect;
export type InsertCravingEntry = z.infer<typeof insertCravingEntrySchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type FoodAnalysis = typeof foodAnalyses.$inferSelect;
export type InsertFoodAnalysis = z.infer<typeof insertFoodAnalysisSchema>;
export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type WeeklyGoal = typeof weeklyGoals.$inferSelect;
export type InsertWeeklyGoal = z.infer<typeof insertWeeklyGoalSchema>;
export type UserRecipeInteraction = typeof userRecipeInteractions.$inferSelect;
export type InsertUserRecipeInteraction = z.infer<typeof insertUserRecipeInteractionSchema>;
export type DailyCheckIn = typeof dailyCheckIns.$inferSelect;
export type InsertDailyCheckIn = z.infer<typeof insertDailyCheckInSchema>;
export type GameProgress = typeof gameProgress.$inferSelect;
export type InsertGameProgress = z.infer<typeof insertGameProgressSchema>;
export type WearableDevice = typeof wearableDevices.$inferSelect;
export type InsertWearableDevice = z.infer<typeof insertWearableDeviceSchema>;
export type HealthMetric = typeof healthMetrics.$inferSelect;
export type InsertHealthMetric = z.infer<typeof insertHealthMetricSchema>;
