import React, {createContext, useContext, useState} from 'react';

interface ThemeContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  colors: {
    primary: string;
    secondary: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
    accent: string;
    error: string;
    success: string;
    warning: string;
  };
}

const darkTheme = {
  primary: '#00FFB3', // Vibrant emerald green
  secondary: '#FF3C38', // Vibrant red
  background: '#000000', // Ultra-dark black
  surface: '#0A0A0A', // Ultra-dark charcoal
  text: '#FFFFFF', // Pure white
  textSecondary: '#C0C0C0', // Silver-gray
  accent: '#00FFB3', // Emerald green accent
  error: '#FF3C38', // Red for errors
  success: '#00FFB3', // Green for success
  warning: '#FFB800', // Amber warning
};

const lightTheme = {
  primary: '#8B5CF6',
  secondary: '#06B6D4',
  background: '#F8FAFC',
  surface: '#FFFFFF',
  text: '#0F172A',
  textSecondary: '#64748B',
  accent: '#F59E0B',
  error: '#EF4444',
  success: '#10B981',
  warning: '#F59E0B',
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({children}: {children: React.ReactNode}) {
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const colors = theme === 'dark' ? darkTheme : lightTheme;

  const value = {
    theme,
    toggleTheme,
    colors,
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}