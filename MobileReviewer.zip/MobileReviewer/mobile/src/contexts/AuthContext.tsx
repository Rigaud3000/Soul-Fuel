import React, {createContext, useContext, useEffect, useState} from 'react';
import auth, {FirebaseAuthTypes} from '@react-native-firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {apiClient} from '../services/api';

interface User {
  id: number;
  username: string;
  email: string;
  firebaseUid: string;
  subscriptionTier: string;
  weeklyScansUsed: number;
}

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseAuthTypes.User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, username: string) => Promise<void>;
  logout: () => Promise<void>;
  googleSignIn: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({children}: {children: React.ReactNode}) {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseAuthTypes.User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize auth state
  useEffect(() => {
    const unsubscribe = auth().onAuthStateChanged(async (firebaseUser) => {
      setFirebaseUser(firebaseUser);
      
      if (firebaseUser) {
        // Get or create user in our database
        try {
          const userData = await apiClient.get('/api/user');
          setUser(userData);
        } catch (error) {
          console.error('Failed to fetch user data:', error);
          // If user doesn't exist in our database, create one
          try {
            const newUser = await apiClient.post('/api/user', {
              email: firebaseUser.email,
              username: firebaseUser.displayName || 'User',
              firebaseUid: firebaseUser.uid,
            });
            setUser(newUser);
          } catch (createError) {
            console.error('Failed to create user:', createError);
          }
        }
      } else {
        setUser(null);
      }
      
      setIsLoading(false);
    });

    return unsubscribe;
  }, []);

  const login = async (email: string, password: string) => {
    try {
      await auth().signInWithEmailAndPassword(email, password);
    } catch (error) {
      throw error;
    }
  };

  const register = async (email: string, password: string, username: string) => {
    try {
      const result = await auth().createUserWithEmailAndPassword(email, password);
      
      // Update display name
      await result.user.updateProfile({
        displayName: username,
      });

      // Create user in our database
      const newUser = await apiClient.post('/api/user', {
        email,
        username,
        firebaseUid: result.user.uid,
      });
      
      setUser(newUser);
    } catch (error) {
      throw error;
    }
  };

  const googleSignIn = async () => {
    try {
      // Google Sign-In implementation would go here
      // This requires additional setup in React Native
      throw new Error('Google Sign-In not yet implemented');
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    try {
      await auth().signOut();
      await AsyncStorage.clear();
      setUser(null);
    } catch (error) {
      throw error;
    }
  };

  const refreshUser = async () => {
    if (firebaseUser) {
      try {
        const userData = await apiClient.get('/api/user');
        setUser(userData);
      } catch (error) {
        console.error('Failed to refresh user data:', error);
      }
    }
  };

  const value = {
    user,
    firebaseUser,
    isAuthenticated: !!firebaseUser,
    isLoading,
    login,
    register,
    logout,
    googleSignIn,
    refreshUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}