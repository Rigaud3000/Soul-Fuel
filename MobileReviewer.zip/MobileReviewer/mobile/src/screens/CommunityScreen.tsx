import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useTheme} from '../contexts/ThemeContext';

export default function CommunityScreen() {
  const {colors} = useTheme();

  return (
    <View style={[styles.container, {backgroundColor: colors.background}]}>
      <View style={[styles.header, {backgroundColor: colors.background}]}>
        <Text style={[styles.headerTitle, {color: colors.text}]}>
          Community
        </Text>
        <TouchableOpacity style={[styles.addButton, {backgroundColor: colors.primary}]}>
          <Icon name="add" size={24} color={colors.surface} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        <View style={[styles.comingSoon, {backgroundColor: colors.surface}]}>
          <Icon name="people" size={64} color={colors.primary} />
          <Text style={[styles.comingSoonTitle, {color: colors.text}]}>
            Community Features
          </Text>
          <Text style={[styles.comingSoonText, {color: colors.textSecondary}]}>
            Connect with others on their wellness journey. Share experiences, get support, and celebrate victories together.
          </Text>
          <Text style={[styles.comingSoonSubtext, {color: colors.textSecondary}]}>
            Coming soon in the mobile app!
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  comingSoon: {
    alignItems: 'center',
    padding: 40,
    borderRadius: 16,
    marginTop: 100,
  },
  comingSoonTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 16,
  },
  comingSoonText: {
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 20,
  },
  comingSoonSubtext: {
    fontSize: 14,
    fontStyle: 'italic',
  },
});