import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useTheme} from '../contexts/ThemeContext';
import {useAuth} from '../contexts/AuthContext';

export default function ProfileScreen() {
  const {colors} = useTheme();
  const {user, logout} = useAuth();

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        {text: 'Cancel', style: 'cancel'},
        {text: 'Logout', style: 'destructive', onPress: logout},
      ]
    );
  };

  const menuItems = [
    {icon: 'person', title: 'Account Settings', onPress: () => {}},
    {icon: 'notifications', title: 'Notifications', onPress: () => {}},
    {icon: 'security', title: 'Privacy & Security', onPress: () => {}},
    {icon: 'star', title: 'Upgrade to Pro', onPress: () => {}},
    {icon: 'help', title: 'Help & Support', onPress: () => {}},
    {icon: 'info', title: 'About SOULFUEL', onPress: () => {}},
  ];

  return (
    <View style={[styles.container, {backgroundColor: colors.background}]}>
      <View style={[styles.header, {backgroundColor: colors.background}]}>
        <Text style={[styles.headerTitle, {color: colors.text}]}>
          Profile
        </Text>
      </View>

      <ScrollView style={styles.content}>
        {/* User Info */}
        <View style={[styles.userCard, {backgroundColor: colors.surface}]}>
          <View style={[styles.avatar, {backgroundColor: colors.primary}]}>
            <Text style={[styles.avatarText, {color: colors.surface}]}>
              {user?.username?.charAt(0).toUpperCase() || 'U'}
            </Text>
          </View>
          <View style={styles.userInfo}>
            <Text style={[styles.userName, {color: colors.text}]}>
              {user?.username || 'User'}
            </Text>
            <Text style={[styles.userEmail, {color: colors.textSecondary}]}>
              {user?.email || 'user@example.com'}
            </Text>
            <View style={[styles.tierBadge, {backgroundColor: colors.primary}]}>
              <Text style={[styles.tierText, {color: colors.surface}]}>
                {user?.subscriptionTier?.toUpperCase() || 'FREE'}
              </Text>
            </View>
          </View>
        </View>

        {/* Stats */}
        <View style={[styles.statsCard, {backgroundColor: colors.surface}]}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, {color: colors.primary}]}>
              {user?.weeklyScansUsed || 0}
            </Text>
            <Text style={[styles.statLabel, {color: colors.textSecondary}]}>
              Scans Used
            </Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, {color: colors.secondary}]}>
              7
            </Text>
            <Text style={[styles.statLabel, {color: colors.textSecondary}]}>
              Days Active
            </Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, {color: colors.warning}]}>
              3
            </Text>
            <Text style={[styles.statLabel, {color: colors.textSecondary}]}>
              Achievements
            </Text>
          </View>
        </View>

        {/* Menu Items */}
        <View style={styles.menuContainer}>
          {menuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={[styles.menuItem, {backgroundColor: colors.surface}]}
              onPress={item.onPress}
            >
              <Icon name={item.icon} size={24} color={colors.primary} />
              <Text style={[styles.menuText, {color: colors.text}]}>
                {item.title}
              </Text>
              <Icon name="chevron-right" size={24} color={colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Logout Button */}
        <TouchableOpacity
          style={[styles.logoutButton, {backgroundColor: colors.secondary}]}
          onPress={handleLogout}
        >
          <Icon name="logout" size={24} color={colors.surface} />
          <Text style={[styles.logoutText, {color: colors.surface}]}>
            Logout
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingTop: 60,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  userCard: {
    flexDirection: 'row',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
    alignItems: 'center',
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  avatarText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    marginBottom: 8,
  },
  tierBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  tierText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  statsCard: {
    flexDirection: 'row',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    textAlign: 'center',
  },
  menuContainer: {
    marginBottom: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  menuText: {
    flex: 1,
    fontSize: 16,
    marginLeft: 12,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 40,
    gap: 8,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '600',
  },
});