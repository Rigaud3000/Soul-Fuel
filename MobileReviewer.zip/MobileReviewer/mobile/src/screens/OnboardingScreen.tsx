import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useTheme} from '../contexts/ThemeContext';

export default function OnboardingScreen() {
  const {colors} = useTheme();

  return (
    <View style={[styles.container, {backgroundColor: colors.background}]}>
      <View style={styles.content}>
        {/* Logo */}
        <View style={styles.logoContainer}>
          <View style={[styles.logo, {backgroundColor: colors.surface}]}>
            <Icon name="local-fire-department" size={60} color={colors.primary} />
            <View style={[styles.logoGlow, {backgroundColor: colors.primary}]} />
            <View style={[styles.logoGlow, styles.redGlow, {backgroundColor: colors.secondary}]} />
          </View>
          <Text style={[styles.appName, {color: colors.text}]}>
            SOULFUEL
          </Text>
          <Text style={[styles.tagline, {color: colors.textSecondary}]}>
            Fuel Your Mind, Transform Your Life
          </Text>
        </View>

        {/* Loading */}
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.loadingText, {color: colors.textSecondary}]}>
            Initializing your wellness journey...
          </Text>
        </View>

        {/* Features Preview */}
        <View style={styles.featuresContainer}>
          <Text style={[styles.featuresTitle, {color: colors.text}]}>
            Your Transformation Toolkit
          </Text>
          
          <View style={styles.featureList}>
            <View style={styles.featureItem}>
              <Icon name="camera-alt" size={24} color={colors.primary} />
              <Text style={[styles.featureText, {color: colors.textSecondary}]}>
                AI-Powered Food Scanner
              </Text>
            </View>
            
            <View style={styles.featureItem}>
              <Icon name="psychology" size={24} color={colors.secondary} />
              <Text style={[styles.featureText, {color: colors.textSecondary}]}>
                Craving Emergency Support
              </Text>
            </View>
            
            <View style={styles.featureItem}>
              <Icon name="trending-up" size={24} color={colors.warning} />
              <Text style={[styles.featureText, {color: colors.textSecondary}]}>
                Progress Tracking & Analytics
              </Text>
            </View>
            
            <View style={styles.featureItem}>
              <Icon name="people" size={24} color={colors.primary} />
              <Text style={[styles.featureText, {color: colors.textSecondary}]}>
                Supportive Community
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  logo: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    marginBottom: 24,
  },
  logoGlow: {
    position: 'absolute',
    width: 130,
    height: 130,
    borderRadius: 65,
    opacity: 0.3,
  },
  redGlow: {
    width: 140,
    height: 140,
    borderRadius: 70,
    opacity: 0.2,
  },
  appName: {
    fontSize: 36,
    fontWeight: 'bold',
    marginBottom: 8,
    letterSpacing: 2,
  },
  tagline: {
    fontSize: 16,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  loadingContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  loadingText: {
    fontSize: 14,
    marginTop: 16,
  },
  featuresContainer: {
    width: '100%',
    alignItems: 'center',
  },
  featuresTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
  },
  featureList: {
    width: '100%',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  featureText: {
    fontSize: 16,
    marginLeft: 16,
    flex: 1,
  },
});