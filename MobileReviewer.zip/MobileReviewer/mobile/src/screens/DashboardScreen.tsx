import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import {useQuery} from '@tanstack/react-query';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {LineChart} from 'react-native-chart-kit';
import {useTheme} from '../contexts/ThemeContext';
import {useAuth} from '../contexts/AuthContext';
import {trackingAPI} from '../services/api';

const screenWidth = Dimensions.get('window').width;

export default function DashboardScreen() {
  const {colors} = useTheme();
  const {user} = useAuth();

  // Fetch analytics data
  const {data: analytics, isLoading: analyticsLoading} = useQuery({
    queryKey: ['analytics'],
    queryFn: () => trackingAPI.getAnalytics(),
  });

  // Fetch recent entries
  const {data: sugarEntries, isLoading: sugarLoading} = useQuery({
    queryKey: ['sugar-entries'],
    queryFn: () => trackingAPI.getSugarEntries(),
  });

  const {data: moodEntries, isLoading: moodLoading} = useQuery({
    queryKey: ['mood-entries'],
    queryFn: () => trackingAPI.getMoodEntries(),
  });

  const chartConfig = {
    backgroundColor: colors.background,
    backgroundGradientFrom: colors.surface,
    backgroundGradientTo: colors.surface,
    decimalPlaces: 1,
    color: (opacity = 1) => colors.primary,
    labelColor: (opacity = 1) => colors.textSecondary,
    style: {
      borderRadius: 16,
    },
    propsForDots: {
      r: '6',
      strokeWidth: '2',
      stroke: colors.primary,
    },
  };

  const sugarData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        data: analytics?.weeklyStats?.sugarByDay || [0, 0, 0, 0, 0, 0, 0],
        color: (opacity = 1) => colors.error,
        strokeWidth: 2,
      },
    ],
  };

  return (
    <ScrollView style={[styles.container, {backgroundColor: colors.background}]}>
      {/* Header with Personalized Greeting */}
      <View style={[styles.header, {backgroundColor: colors.background}]}>
        <View style={styles.greetingContainer}>
          <Text style={[styles.greeting, {color: colors.primary}]}>
            Hey, {user?.username || 'User'}! 🔥
          </Text>
          <Text style={[styles.dateText, {color: colors.textSecondary}]}>
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              month: 'long', 
              day: 'numeric' 
            })}
          </Text>
        </View>
        <View style={[styles.soulFuelLogo, {backgroundColor: colors.surface}]}>
          <Text style={[styles.logoText, {color: colors.primary}]}>SF</Text>
          <View style={[styles.flameGlow, {backgroundColor: colors.primary}]} />
        </View>
      </View>

      {/* Weather Widget */}
      <View style={[styles.weatherWidget, {backgroundColor: colors.surface}]}>
        <Icon name="wb-sunny" size={24} color={colors.warning} />
        <Text style={[styles.weatherText, {color: colors.text}]}>
          Sunny, 28°C • Riverbank • 55% humidity
        </Text>
      </View>

      {/* SOULFUEL Feature Tiles */}
      <View style={styles.featureTilesContainer}>
        {/* Sugar Addiction Tracker */}
        <TouchableOpacity style={[styles.featureTile, styles.greenTile, {backgroundColor: colors.primary}]}>
          <View style={styles.tileHeader}>
            <Icon name="favorite" size={24} color="#000000" />
            <View style={styles.toggleContainer}>
              <Text style={[styles.toggleText, {color: '#000000'}]}>ON</Text>
              <View style={[styles.toggle, {backgroundColor: '#000000'}]} />
            </View>
          </View>
          <Text style={[styles.tileTitle, {color: '#000000'}]}>Sugar Addiction</Text>
          <Text style={[styles.tileSubtitle, {color: '#000000'}]}>Tracker Active</Text>
        </TouchableOpacity>

        {/* Impulse Log */}
        <TouchableOpacity style={[styles.featureTile, styles.darkTile, {backgroundColor: colors.surface}]}>
          <Icon name="edit" size={24} color={colors.textSecondary} />
          <Text style={[styles.tileTitle, {color: colors.text}]}>Impulse Log</Text>
          <Text style={[styles.tileSubtitle, {color: colors.textSecondary}]}>3 logs today</Text>
        </TouchableOpacity>

        {/* Craving Emergency */}
        <TouchableOpacity style={[styles.featureTile, styles.emergencyTile, {backgroundColor: '#000000', borderColor: colors.secondary}]}>
          <Icon name="emergency" size={24} color={colors.secondary} />
          <Text style={[styles.tileTitle, {color: colors.secondary}]}>Craving Emergency</Text>
          <Text style={[styles.tileSubtitle, {color: colors.textSecondary}]}>Tap for help</Text>
        </TouchableOpacity>

        {/* Dopamine Swaps */}
        <TouchableOpacity style={[styles.featureTile, styles.swapTile, {backgroundColor: colors.surface}]}>
          <Icon name="swap-horiz" size={24} color={colors.secondary} />
          <Text style={[styles.tileTitle, {color: colors.text}]}>Dopamine Swaps</Text>
          <Text style={[styles.tileSubtitle, {color: colors.textSecondary}]}>Quick access</Text>
        </TouchableOpacity>

        {/* SOULFUEL Logo Tile */}
        <TouchableOpacity style={[styles.featureTile, styles.logoTile, {backgroundColor: colors.surface}]}>
          <View style={styles.flameLogo}>
            <Icon name="local-fire-department" size={32} color={colors.primary} />
            <View style={[styles.flameAura, {backgroundColor: colors.primary}]} />
            <View style={[styles.flameAura, styles.redAura, {backgroundColor: colors.secondary}]} />
          </View>
          <Text style={[styles.tileTitle, {color: colors.text}]}>SOULFUEL</Text>
          <Text style={[styles.tileSubtitle, {color: colors.textSecondary}]}>Transform</Text>
        </TouchableOpacity>

        {/* Streak Counter */}
        <TouchableOpacity style={[styles.featureTile, styles.streakTile, {backgroundColor: colors.surface}]}>
          <Icon name="whatshot" size={24} color={colors.warning} />
          <Text style={[styles.tileTitle, {color: colors.text}]}>
            {analytics?.currentStreak || 0} Days
          </Text>
          <Text style={[styles.tileSubtitle, {color: colors.textSecondary}]}>Clean Streak</Text>
        </TouchableOpacity>
      </View>

      {/* Sugar Trend Chart */}
      <View style={[styles.chartCard, {backgroundColor: colors.surface}]}>
        <Text style={[styles.cardTitle, {color: colors.text}]}>
          Weekly Sugar Intake
        </Text>
        {!analyticsLoading && analytics?.weeklyStats ? (
          <LineChart
            data={sugarData}
            width={screenWidth - 60}
            height={220}
            chartConfig={chartConfig}
            style={styles.chart}
          />
        ) : (
          <View style={styles.loadingChart}>
            <Text style={[styles.loadingText, {color: colors.textSecondary}]}>
              Loading chart...
            </Text>
          </View>
        )}
      </View>

      {/* Quick Actions */}
      <View style={styles.actionsContainer}>
        <Text style={[styles.sectionTitle, {color: colors.text}]}>
          Quick Actions
        </Text>
        
        <View style={styles.actionGrid}>
          <TouchableOpacity style={[styles.actionCard, {backgroundColor: colors.surface}]}>
            <Icon name="camera-alt" size={28} color={colors.primary} />
            <Text style={[styles.actionText, {color: colors.text}]}>
              Scan Food
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.actionCard, {backgroundColor: colors.surface}]}>
            <Icon name="add-circle" size={28} color={colors.secondary} />
            <Text style={[styles.actionText, {color: colors.text}]}>
              Log Sugar
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.actionCard, {backgroundColor: colors.surface}]}>
            <Icon name="mood" size={28} color={colors.accent} />
            <Text style={[styles.actionText, {color: colors.text}]}>
              Track Mood
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.actionCard, {backgroundColor: colors.surface}]}>
            <Icon name="restaurant" size={28} color={colors.success} />
            <Text style={[styles.actionText, {color: colors.text}]}>
              Find Recipe
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Recent Activity */}
      <View style={styles.recentContainer}>
        <Text style={[styles.sectionTitle, {color: colors.text}]}>
          Recent Activity
        </Text>
        
        {!sugarLoading && sugarEntries?.slice(0, 3).map((entry: any, index: number) => (
          <View key={index} style={[styles.activityItem, {backgroundColor: colors.surface}]}>
            <Icon name="local-cafe" size={24} color={colors.primary} />
            <View style={styles.activityDetails}>
              <Text style={[styles.activityTitle, {color: colors.text}]}>
                Sugar logged: {entry.amount}g
              </Text>
              <Text style={[styles.activityTime, {color: colors.textSecondary}]}>
                {new Date(entry.createdAt).toLocaleDateString()}
              </Text>
            </View>
            <Text style={[styles.activityValue, {color: colors.error}]}>
              +{entry.amount}g
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 20,
    paddingTop: 60,
  },
  greetingContainer: {
    flex: 1,
  },
  greeting: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  dateText: {
    fontSize: 14,
    marginTop: 4,
  },
  soulFuelLogo: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  logoText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  flameGlow: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    opacity: 0.2,
  },
  weatherWidget: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    marginBottom: 20,
    padding: 16,
    borderRadius: 16,
    gap: 12,
  },
  weatherText: {
    fontSize: 14,
    flex: 1,
  },
  featureTilesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    gap: 12,
  },
  featureTile: {
    width: '48%',
    minHeight: 120,
    padding: 16,
    borderRadius: 16,
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  greenTile: {
    // Emerald green tile for Sugar Addiction tracker
  },
  darkTile: {
    // Dark mode tile for Impulse Log
  },
  emergencyTile: {
    borderWidth: 2,
    // Emergency tile with red border
  },
  swapTile: {
    // Dopamine swaps tile
  },
  logoTile: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  streakTile: {
    // Streak counter tile
  },
  tileHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  toggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toggleText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  toggle: {
    width: 20,
    height: 12,
    borderRadius: 6,
  },
  tileTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  tileSubtitle: {
    fontSize: 12,
  },
  flameLogo: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  flameAura: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    opacity: 0.3,
  },
  redAura: {
    width: 50,
    height: 50,
    borderRadius: 25,
    opacity: 0.2,
  },
  chartCard: {
    margin: 20,
    padding: 20,
    borderRadius: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  chart: {
    borderRadius: 16,
  },
  loadingChart: {
    height: 220,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
  },
  actionsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    width: '48%',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  actionText: {
    fontSize: 14,
    fontWeight: '500',
    marginTop: 8,
    textAlign: 'center',
  },
  recentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  activityDetails: {
    flex: 1,
    marginLeft: 12,
  },
  activityTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  activityTime: {
    fontSize: 12,
    marginTop: 4,
  },
  activityValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});