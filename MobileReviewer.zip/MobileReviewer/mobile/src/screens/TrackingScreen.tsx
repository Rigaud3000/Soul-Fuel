import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
} from 'react-native';
import {useQuery, useMutation, useQueryClient} from '@tanstack/react-query';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useTheme} from '../contexts/ThemeContext';
import {trackingAPI} from '../services/api';

export default function TrackingScreen() {
  const {colors} = useTheme();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState<'sugar' | 'mood' | 'craving'>('sugar');
  const [showAddModal, setShowAddModal] = useState(false);
  const [sugarAmount, setSugarAmount] = useState('');
  const [selectedMood, setSelectedMood] = useState<number>(3);
  const [cravingIntensity, setCravingIntensity] = useState<number>(5);
  const [cravingTrigger, setCravingTrigger] = useState('');

  // Fetch tracking data
  const {data: sugarEntries} = useQuery({
    queryKey: ['sugar-entries'],
    queryFn: () => trackingAPI.getSugarEntries(),
  });

  const {data: moodEntries} = useQuery({
    queryKey: ['mood-entries'],
    queryFn: () => trackingAPI.getMoodEntries(),
  });

  const {data: cravingEntries} = useQuery({
    queryKey: ['craving-entries'],
    queryFn: () => trackingAPI.getCravingEntries(),
  });

  // Mutations
  const addSugarMutation = useMutation({
    mutationFn: (data: any) => trackingAPI.createSugarEntry(data),
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['sugar-entries']});
      setShowAddModal(false);
      setSugarAmount('');
    },
  });

  const addMoodMutation = useMutation({
    mutationFn: (data: any) => trackingAPI.createMoodEntry(data),
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['mood-entries']});
      setShowAddModal(false);
      setSelectedMood(3);
    },
  });

  const addCravingMutation = useMutation({
    mutationFn: (data: any) => trackingAPI.createCravingEntry(data),
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['craving-entries']});
      setShowAddModal(false);
      setCravingIntensity(5);
      setCravingTrigger('');
    },
  });

  const handleAddEntry = () => {
    switch (activeTab) {
      case 'sugar':
        if (sugarAmount) {
          addSugarMutation.mutate({
            amount: parseFloat(sugarAmount),
            meal: 'snack',
          });
        }
        break;
      case 'mood':
        addMoodMutation.mutate({
          mood: selectedMood,
          note: '',
        });
        break;
      case 'craving':
        addCravingMutation.mutate({
          intensity: cravingIntensity,
          trigger: cravingTrigger,
        });
        break;
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'sugar':
        return (
          <View style={styles.tabContent}>
            <Text style={[styles.tabTitle, {color: colors.text}]}>
              Sugar Intake Tracking
            </Text>
            {sugarEntries?.map((entry: any, index: number) => (
              <View key={index} style={[styles.entryCard, {backgroundColor: colors.surface}]}>
                <Icon name="local-cafe" size={24} color={colors.secondary} />
                <View style={styles.entryDetails}>
                  <Text style={[styles.entryAmount, {color: colors.text}]}>
                    {entry.amount}g sugar
                  </Text>
                  <Text style={[styles.entryTime, {color: colors.textSecondary}]}>
                    {new Date(entry.createdAt).toLocaleTimeString()}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        );
      
      case 'mood':
        return (
          <View style={styles.tabContent}>
            <Text style={[styles.tabTitle, {color: colors.text}]}>
              Mood Tracking
            </Text>
            {moodEntries?.map((entry: any, index: number) => (
              <View key={index} style={[styles.entryCard, {backgroundColor: colors.surface}]}>
                <Icon name="emoji-emotions" size={24} color={colors.primary} />
                <View style={styles.entryDetails}>
                  <Text style={[styles.entryAmount, {color: colors.text}]}>
                    Mood: {entry.mood}/5
                  </Text>
                  <Text style={[styles.entryTime, {color: colors.textSecondary}]}>
                    {new Date(entry.createdAt).toLocaleTimeString()}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        );
      
      case 'craving':
        return (
          <View style={styles.tabContent}>
            <Text style={[styles.tabTitle, {color: colors.text}]}>
              Craving Tracking
            </Text>
            {cravingEntries?.map((entry: any, index: number) => (
              <View key={index} style={[styles.entryCard, {backgroundColor: colors.surface}]}>
                <Icon name="psychology" size={24} color={colors.warning} />
                <View style={styles.entryDetails}>
                  <Text style={[styles.entryAmount, {color: colors.text}]}>
                    Intensity: {entry.intensity}/10
                  </Text>
                  <Text style={[styles.entryTime, {color: colors.textSecondary}]}>
                    {entry.trigger}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        );
    }
  };

  const renderAddModal = () => {
    switch (activeTab) {
      case 'sugar':
        return (
          <View style={[styles.modalContent, {backgroundColor: colors.surface}]}>
            <Text style={[styles.modalTitle, {color: colors.text}]}>
              Add Sugar Intake
            </Text>
            <TextInput
              style={[styles.input, {backgroundColor: colors.background, color: colors.text}]}
              placeholder="Amount in grams"
              placeholderTextColor={colors.textSecondary}
              value={sugarAmount}
              onChangeText={setSugarAmount}
              keyboardType="numeric"
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.cancelButton, {backgroundColor: colors.background}]}
                onPress={() => setShowAddModal(false)}
              >
                <Text style={[styles.buttonText, {color: colors.textSecondary}]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.addButton, {backgroundColor: colors.secondary}]}
                onPress={handleAddEntry}
              >
                <Text style={[styles.buttonText, {color: colors.surface}]}>
                  Add Entry
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      
      case 'mood':
        return (
          <View style={[styles.modalContent, {backgroundColor: colors.surface}]}>
            <Text style={[styles.modalTitle, {color: colors.text}]}>
              Track Your Mood
            </Text>
            <View style={styles.moodSelector}>
              {[1, 2, 3, 4, 5].map((mood) => (
                <TouchableOpacity
                  key={mood}
                  style={[
                    styles.moodButton,
                    {backgroundColor: selectedMood === mood ? colors.primary : colors.background}
                  ]}
                  onPress={() => setSelectedMood(mood)}
                >
                  <Text style={[
                    styles.moodButtonText,
                    {color: selectedMood === mood ? colors.surface : colors.text}
                  ]}>
                    {mood}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.cancelButton, {backgroundColor: colors.background}]}
                onPress={() => setShowAddModal(false)}
              >
                <Text style={[styles.buttonText, {color: colors.textSecondary}]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.addButton, {backgroundColor: colors.primary}]}
                onPress={handleAddEntry}
              >
                <Text style={[styles.buttonText, {color: colors.surface}]}>
                  Add Entry
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      
      case 'craving':
        return (
          <View style={[styles.modalContent, {backgroundColor: colors.surface}]}>
            <Text style={[styles.modalTitle, {color: colors.text}]}>
              Track Craving
            </Text>
            <Text style={[styles.inputLabel, {color: colors.textSecondary}]}>
              Intensity (1-10): {cravingIntensity}
            </Text>
            <View style={styles.intensitySlider}>
              {[...Array(10)].map((_, i) => (
                <TouchableOpacity
                  key={i}
                  style={[
                    styles.intensityDot,
                    {backgroundColor: i < cravingIntensity ? colors.warning : colors.background}
                  ]}
                  onPress={() => setCravingIntensity(i + 1)}
                />
              ))}
            </View>
            <TextInput
              style={[styles.input, {backgroundColor: colors.background, color: colors.text}]}
              placeholder="What triggered this craving?"
              placeholderTextColor={colors.textSecondary}
              value={cravingTrigger}
              onChangeText={setCravingTrigger}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.cancelButton, {backgroundColor: colors.background}]}
                onPress={() => setShowAddModal(false)}
              >
                <Text style={[styles.buttonText, {color: colors.textSecondary}]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.addButton, {backgroundColor: colors.warning}]}
                onPress={handleAddEntry}
              >
                <Text style={[styles.buttonText, {color: colors.surface}]}>
                  Add Entry
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        );
    }
  };

  return (
    <View style={[styles.container, {backgroundColor: colors.background}]}>
      {/* Header */}
      <View style={[styles.header, {backgroundColor: colors.background}]}>
        <Text style={[styles.headerTitle, {color: colors.text}]}>
          Tracking
        </Text>
        <TouchableOpacity
          style={[styles.addButton, {backgroundColor: colors.primary}]}
          onPress={() => setShowAddModal(true)}
        >
          <Icon name="add" size={24} color={colors.surface} />
        </TouchableOpacity>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        {(['sugar', 'mood', 'craving'] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[
              styles.tab,
              {backgroundColor: activeTab === tab ? colors.primary : colors.surface}
            ]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[
              styles.tabText,
              {color: activeTab === tab ? colors.surface : colors.text}
            ]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Tab Content */}
      <ScrollView style={styles.content}>
        {renderTabContent()}
      </ScrollView>

      {/* Add Entry Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowAddModal(false)}
      >
        <View style={styles.modalOverlay}>
          {renderAddModal()}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    gap: 8,
  },
  tab: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  tabContent: {
    paddingBottom: 100,
  },
  tabTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  entryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  entryDetails: {
    flex: 1,
    marginLeft: 12,
  },
  entryAmount: {
    fontSize: 16,
    fontWeight: '600',
  },
  entryTime: {
    fontSize: 12,
    marginTop: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    padding: 24,
    borderRadius: 16,
    minHeight: 200,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
    fontSize: 16,
  },
  inputLabel: {
    fontSize: 14,
    marginBottom: 8,
  },
  moodSelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  moodButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  moodButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  intensitySlider: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  intensityDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  cancelButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '600',
  },
});