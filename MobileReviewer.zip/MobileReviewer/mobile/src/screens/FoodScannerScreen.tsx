import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Modal,
  TextInput,
  ScrollView,
  Image,
} from 'react-native';
import {useMutation, useQuery, useQueryClient} from '@tanstack/react-query';
import {launchImageLibrary, launchCamera, ImagePickerResponse} from 'react-native-image-picker';
import {request, PERMISSIONS, RESULTS} from 'react-native-permissions';
import QRCodeScanner from 'react-native-qrcode-scanner';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useTheme} from '../contexts/ThemeContext';
import {foodAPI} from '../services/api';

export default function FoodScannerScreen() {
  const {colors} = useTheme();
  const queryClient = useQueryClient();
  
  const [scanMode, setScanMode] = useState<'camera' | 'text' | 'barcode' | 'upload'>('camera');
  const [showCamera, setShowCamera] = useState(false);
  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  // Get scan usage
  const {data: scanUsage} = useQuery({
    queryKey: ['scan-usage'],
    queryFn: () => foodAPI.getScanUsage(),
  });

  // Image analysis mutation
  const imageAnalysisMutation = useMutation({
    mutationFn: (imageUri: string) => foodAPI.analyzeFoodImage(imageUri),
    onSuccess: (data) => {
      setAnalysisResult(data);
      queryClient.invalidateQueries({queryKey: ['scan-usage']});
    },
    onError: (error) => {
      Alert.alert('Error', 'Failed to analyze image. Please try again.');
      console.error('Image analysis error:', error);
    },
  });

  // Text analysis mutation
  const textAnalysisMutation = useMutation({
    mutationFn: (description: string) => foodAPI.analyzeFoodText(description),
    onSuccess: (data) => {
      setAnalysisResult(data);
      setTextInput('');
      queryClient.invalidateQueries({queryKey: ['scan-usage']});
    },
    onError: (error) => {
      Alert.alert('Error', 'Failed to analyze text. Please try again.');
      console.error('Text analysis error:', error);
    },
  });

  // Barcode analysis mutation
  const barcodeAnalysisMutation = useMutation({
    mutationFn: (barcode: string) => foodAPI.analyzeFoodBarcode(barcode),
    onSuccess: (data) => {
      setAnalysisResult(data);
      setShowBarcodeScanner(false);
      queryClient.invalidateQueries({queryKey: ['scan-usage']});
    },
    onError: (error) => {
      Alert.alert('Error', 'Failed to analyze barcode. Please try again.');
      console.error('Barcode analysis error:', error);
    },
  });

  const requestCameraPermission = async () => {
    try {
      const result = await request(PERMISSIONS.ANDROID.CAMERA);
      return result === RESULTS.GRANTED;
    } catch (error) {
      console.error('Camera permission error:', error);
      return false;
    }
  };

  const handleCameraCapture = async () => {
    const hasPermission = await requestCameraPermission();
    if (!hasPermission) {
      Alert.alert('Permission Required', 'Camera permission is required to take photos.');
      return;
    }

    launchCamera(
      {
        mediaType: 'photo',
        quality: 0.8,
        includeBase64: false,
      },
      (response: ImagePickerResponse) => {
        if (response.assets && response.assets[0]) {
          const imageUri = response.assets[0].uri;
          if (imageUri) {
            setSelectedImage(imageUri);
            imageAnalysisMutation.mutate(imageUri);
          }
        }
      }
    );
  };

  const handleImageUpload = () => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        quality: 0.8,
        includeBase64: false,
      },
      (response: ImagePickerResponse) => {
        if (response.assets && response.assets[0]) {
          const imageUri = response.assets[0].uri;
          if (imageUri) {
            setSelectedImage(imageUri);
            imageAnalysisMutation.mutate(imageUri);
          }
        }
      }
    );
  };

  const handleTextAnalysis = () => {
    if (textInput.trim()) {
      textAnalysisMutation.mutate(textInput.trim());
    }
  };

  const handleBarcodeRead = (e: any) => {
    barcodeAnalysisMutation.mutate(e.data);
  };

  const canScan = scanUsage?.canScan && scanUsage?.scansRemaining > 0;

  const renderScanModeButtons = () => (
    <View style={styles.modeContainer}>
      <TouchableOpacity
        style={[
          styles.modeButton,
          {backgroundColor: scanMode === 'camera' ? colors.primary : colors.surface},
        ]}
        onPress={() => setScanMode('camera')}
      >
        <Icon 
          name="camera-alt" 
          size={24} 
          color={scanMode === 'camera' ? colors.surface : colors.text} 
        />
        <Text style={[
          styles.modeButtonText,
          {color: scanMode === 'camera' ? colors.surface : colors.text}
        ]}>
          Camera
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[
          styles.modeButton,
          {backgroundColor: scanMode === 'text' ? colors.primary : colors.surface},
        ]}
        onPress={() => setScanMode('text')}
      >
        <Icon 
          name="text-fields" 
          size={24} 
          color={scanMode === 'text' ? colors.surface : colors.text} 
        />
        <Text style={[
          styles.modeButtonText,
          {color: scanMode === 'text' ? colors.surface : colors.text}
        ]}>
          Text
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[
          styles.modeButton,
          {backgroundColor: scanMode === 'barcode' ? colors.primary : colors.surface},
        ]}
        onPress={() => setScanMode('barcode')}
      >
        <Icon 
          name="qr-code-scanner" 
          size={24} 
          color={scanMode === 'barcode' ? colors.surface : colors.text} 
        />
        <Text style={[
          styles.modeButtonText,
          {color: scanMode === 'barcode' ? colors.surface : colors.text}
        ]}>
          Barcode
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[
          styles.modeButton,
          {backgroundColor: scanMode === 'upload' ? colors.primary : colors.surface},
        ]}
        onPress={() => setScanMode('upload')}
      >
        <Icon 
          name="upload" 
          size={24} 
          color={scanMode === 'upload' ? colors.surface : colors.text} 
        />
        <Text style={[
          styles.modeButtonText,
          {color: scanMode === 'upload' ? colors.surface : colors.text}
        ]}>
          Upload
        </Text>
      </TouchableOpacity>
    </View>
  );

  const renderScanContent = () => {
    if (!canScan) {
      return (
        <View style={[styles.limitCard, {backgroundColor: colors.surface}]}>
          <Icon name="block" size={48} color={colors.error} />
          <Text style={[styles.limitTitle, {color: colors.text}]}>
            Scan Limit Reached
          </Text>
          <Text style={[styles.limitText, {color: colors.textSecondary}]}>
            You've used {scanUsage?.scansUsed || 0} of {scanUsage?.scansUsed + (scanUsage?.scansRemaining || 0)} weekly scans.
          </Text>
          <Text style={[styles.limitText, {color: colors.textSecondary}]}>
            Upgrade to Pro for unlimited scans!
          </Text>
          <TouchableOpacity style={[styles.upgradeButton, {backgroundColor: colors.primary}]}>
            <Text style={[styles.upgradeButtonText, {color: colors.surface}]}>
              Upgrade Now
            </Text>
          </TouchableOpacity>
        </View>
      );
    }

    switch (scanMode) {
      case 'camera':
        return (
          <View style={[styles.scanCard, {backgroundColor: colors.surface}]}>
            <Icon name="camera-alt" size={64} color={colors.primary} />
            <Text style={[styles.scanTitle, {color: colors.text}]}>
              Camera Capture
            </Text>
            <Text style={[styles.scanDescription, {color: colors.textSecondary}]}>
              Take a photo of your food for instant analysis
            </Text>
            <TouchableOpacity
              style={[styles.actionButton, {backgroundColor: colors.primary}]}
              onPress={handleCameraCapture}
              disabled={imageAnalysisMutation.isPending}
            >
              <Text style={[styles.actionButtonText, {color: colors.surface}]}>
                {imageAnalysisMutation.isPending ? 'Analyzing...' : 'Take Photo'}
              </Text>
            </TouchableOpacity>
          </View>
        );

      case 'text':
        return (
          <View style={[styles.scanCard, {backgroundColor: colors.surface}]}>
            <Icon name="text-fields" size={64} color={colors.secondary} />
            <Text style={[styles.scanTitle, {color: colors.text}]}>
              Text Description
            </Text>
            <Text style={[styles.scanDescription, {color: colors.textSecondary}]}>
              Describe what you're eating
            </Text>
            <TextInput
              style={[styles.textInput, {
                backgroundColor: colors.background,
                color: colors.text,
                borderColor: colors.textSecondary,
              }]}
              placeholder="e.g., Chocolate chip cookies, 2 pieces"
              placeholderTextColor={colors.textSecondary}
              value={textInput}
              onChangeText={setTextInput}
              multiline
            />
            <TouchableOpacity
              style={[
                styles.actionButton,
                {backgroundColor: textInput.trim() ? colors.secondary : colors.textSecondary}
              ]}
              onPress={handleTextAnalysis}
              disabled={!textInput.trim() || textAnalysisMutation.isPending}
            >
              <Text style={[styles.actionButtonText, {color: colors.surface}]}>
                {textAnalysisMutation.isPending ? 'Analyzing...' : 'Analyze'}
              </Text>
            </TouchableOpacity>
          </View>
        );

      case 'barcode':
        return (
          <View style={[styles.scanCard, {backgroundColor: colors.surface}]}>
            <Icon name="qr-code-scanner" size={64} color={colors.accent} />
            <Text style={[styles.scanTitle, {color: colors.text}]}>
              Barcode Scanner
            </Text>
            <Text style={[styles.scanDescription, {color: colors.textSecondary}]}>
              Scan product barcode for detailed nutrition info
            </Text>
            <TouchableOpacity
              style={[styles.actionButton, {backgroundColor: colors.accent}]}
              onPress={() => setShowBarcodeScanner(true)}
              disabled={barcodeAnalysisMutation.isPending}
            >
              <Text style={[styles.actionButtonText, {color: colors.surface}]}>
                {barcodeAnalysisMutation.isPending ? 'Analyzing...' : 'Start Scanner'}
              </Text>
            </TouchableOpacity>
          </View>
        );

      case 'upload':
        return (
          <View style={[styles.scanCard, {backgroundColor: colors.surface}]}>
            <Icon name="upload" size={64} color={colors.success} />
            <Text style={[styles.scanTitle, {color: colors.text}]}>
              Upload Image
            </Text>
            <Text style={[styles.scanDescription, {color: colors.textSecondary}]}>
              Select a photo from your gallery
            </Text>
            <TouchableOpacity
              style={[styles.actionButton, {backgroundColor: colors.success}]}
              onPress={handleImageUpload}
              disabled={imageAnalysisMutation.isPending}
            >
              <Text style={[styles.actionButtonText, {color: colors.surface}]}>
                {imageAnalysisMutation.isPending ? 'Analyzing...' : 'Choose Photo'}
              </Text>
            </TouchableOpacity>
          </View>
        );

      default:
        return null;
    }
  };

  const renderAnalysisResult = () => {
    if (!analysisResult) return null;

    return (
      <View style={[styles.resultCard, {backgroundColor: colors.surface}]}>
        <View style={styles.resultHeader}>
          <Text style={[styles.resultTitle, {color: colors.text}]}>
            Analysis Result
          </Text>
          <TouchableOpacity onPress={() => setAnalysisResult(null)}>
            <Icon name="close" size={24} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <View style={[styles.healthScore, {backgroundColor: getHealthScoreColor(analysisResult.healthScore)}]}>
          <Text style={styles.healthScoreText}>
            Health Score: {analysisResult.healthScore}
          </Text>
        </View>

        <Text style={[styles.foodName, {color: colors.text}]}>
          {analysisResult.foodName}
        </Text>

        {analysisResult.isUltraProcessed && (
          <View style={[styles.warningBadge, {backgroundColor: colors.error}]}>
            <Icon name="warning" size={16} color={colors.surface} />
            <Text style={[styles.warningText, {color: colors.surface}]}>
              Ultra-Processed
            </Text>
          </View>
        )}

        {analysisResult.redFlags?.length > 0 && (
          <View style={styles.redFlagsContainer}>
            <Text style={[styles.redFlagsTitle, {color: colors.error}]}>
              Red Flags:
            </Text>
            {analysisResult.redFlags.map((flag: string, index: number) => (
              <Text key={index} style={[styles.redFlag, {color: colors.textSecondary}]}>
                • {flag}
              </Text>
            ))}
          </View>
        )}

        <Text style={[styles.coachingMessage, {color: colors.text}]}>
          {analysisResult.coachingMessage}
        </Text>

        {analysisResult.healthySuggestions?.length > 0 && (
          <View style={styles.suggestionsContainer}>
            <Text style={[styles.suggestionsTitle, {color: colors.success}]}>
              Healthy Alternatives:
            </Text>
            {analysisResult.healthySuggestions.map((suggestion: string, index: number) => (
              <Text key={index} style={[styles.suggestion, {color: colors.textSecondary}]}>
                • {suggestion}
              </Text>
            ))}
          </View>
        )}
      </View>
    );
  };

  const getHealthScoreColor = (score: string) => {
    switch (score) {
      case 'A': return colors.success;
      case 'B': return colors.accent;
      case 'C': return '#FFA500';
      case 'D': return '#FF6B35';
      case 'F': return colors.error;
      default: return colors.textSecondary;
    }
  };

  return (
    <ScrollView style={[styles.container, {backgroundColor: colors.background}]}>
      {/* Header */}
      <View style={[styles.header, {backgroundColor: colors.surface}]}>
        <Text style={[styles.headerTitle, {color: colors.text}]}>
          Food Scanner
        </Text>
        <View style={styles.scanCounter}>
          <Text style={[styles.scanCounterText, {color: colors.textSecondary}]}>
            {scanUsage?.scansRemaining || 0} scans left
          </Text>
        </View>
      </View>

      {/* Scan Mode Selection */}
      {renderScanModeButtons()}

      {/* Scan Content */}
      {renderScanContent()}

      {/* Analysis Result */}
      {renderAnalysisResult()}

      {/* Barcode Scanner Modal */}
      <Modal
        visible={showBarcodeScanner}
        animationType="slide"
        onRequestClose={() => setShowBarcodeScanner(false)}
      >
        <QRCodeScanner
          onRead={handleBarcodeRead}
          topContent={
            <Text style={[styles.centerText, {color: colors.text}]}>
              Point your camera at a barcode
            </Text>
          }
          bottomContent={
            <TouchableOpacity
              style={[styles.buttonTouchable, {backgroundColor: colors.error}]}
              onPress={() => setShowBarcodeScanner(false)}
            >
              <Text style={[styles.buttonText, {color: colors.surface}]}>
                Cancel
              </Text>
            </TouchableOpacity>
          }
        />
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  scanCounter: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
  },
  scanCounterText: {
    fontSize: 12,
    fontWeight: '500',
  },
  modeContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    gap: 8,
  },
  modeButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
  },
  modeButtonText: {
    fontSize: 12,
    fontWeight: '500',
  },
  scanCard: {
    margin: 20,
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
  },
  scanTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  scanDescription: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  textInput: {
    width: '100%',
    minHeight: 80,
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    textAlignVertical: 'top',
  },
  actionButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    minWidth: 120,
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  limitCard: {
    margin: 20,
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
  },
  limitTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  limitText: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 8,
  },
  upgradeButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 16,
  },
  upgradeButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  resultCard: {
    margin: 20,
    padding: 20,
    borderRadius: 16,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  healthScore: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginBottom: 12,
  },
  healthScoreText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
  },
  foodName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  warningBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 12,
    gap: 4,
  },
  warningText: {
    fontSize: 12,
    fontWeight: '600',
  },
  redFlagsContainer: {
    marginBottom: 16,
  },
  redFlagsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  redFlag: {
    fontSize: 14,
    marginBottom: 4,
  },
  coachingMessage: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 16,
  },
  suggestionsContainer: {
    marginTop: 8,
  },
  suggestionsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  suggestion: {
    fontSize: 14,
    marginBottom: 4,
  },
  centerText: {
    fontSize: 18,
    padding: 32,
    textAlign: 'center',
  },
  buttonTouchable: {
    padding: 16,
    borderRadius: 8,
    margin: 20,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
});