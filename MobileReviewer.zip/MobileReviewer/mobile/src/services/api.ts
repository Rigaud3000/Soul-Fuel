import axios, {AxiosResponse, AxiosError} from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Platform} from 'react-native';

// API Configuration
const API_BASE_URL = Platform.select({
  ios: 'http://localhost:5000',
  android: 'http://10.0.2.2:5000', // Android emulator localhost
  default: 'http://localhost:5000',
});

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  async (config) => {
    try {
      const token = await AsyncStorage.getItem('auth_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      console.error('Error getting auth token:', error);
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response: AxiosResponse) => {
    return response;
  },
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      // Handle unauthorized access
      AsyncStorage.removeItem('auth_token');
      // Navigate to login screen
    }
    return Promise.reject(error);
  }
);

// API client methods
export const apiClient = {
  // GET request
  get: async <T = any>(url: string, params?: any): Promise<T> => {
    const response = await api.get(url, {params});
    return response.data;
  },

  // POST request
  post: async <T = any>(url: string, data?: any): Promise<T> => {
    const response = await api.post(url, data);
    return response.data;
  },

  // PUT request
  put: async <T = any>(url: string, data?: any): Promise<T> => {
    const response = await api.put(url, data);
    return response.data;
  },

  // DELETE request
  delete: async <T = any>(url: string): Promise<T> => {
    const response = await api.delete(url);
    return response.data;
  },

  // Upload file
  uploadFile: async <T = any>(url: string, formData: FormData): Promise<T> => {
    const response = await api.post(url, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },
};

// Food Analysis API
export const foodAPI = {
  analyzeFoodImage: async (imageUri: string) => {
    const formData = new FormData();
    formData.append('image', {
      uri: imageUri,
      type: 'image/jpeg',
      name: 'food-image.jpg',
    } as any);

    return apiClient.uploadFile('/api/analyze-food-image', formData);
  },

  analyzeFoodText: async (description: string) => {
    return apiClient.post('/api/analyze-food-text', {
      foodDescription: description,
    });
  },

  analyzeFoodBarcode: async (barcode: string) => {
    return apiClient.post('/api/analyze-food-barcode', {
      barcode,
    });
  },

  getScanUsage: async () => {
    return apiClient.get('/api/scan-usage');
  },
};

// Tracking API
export const trackingAPI = {
  getSugarEntries: async (startDate?: string, endDate?: string) => {
    return apiClient.get('/api/sugar-entries', {
      startDate,
      endDate,
    });
  },

  createSugarEntry: async (data: any) => {
    return apiClient.post('/api/sugar-entries', data);
  },

  getMoodEntries: async (startDate?: string, endDate?: string) => {
    return apiClient.get('/api/mood-entries', {
      startDate,
      endDate,
    });
  },

  createMoodEntry: async (data: any) => {
    return apiClient.post('/api/mood-entries', data);
  },

  getCravingEntries: async (startDate?: string, endDate?: string) => {
    return apiClient.get('/api/craving-entries', {
      startDate,
      endDate,
    });
  },

  createCravingEntry: async (data: any) => {
    return apiClient.post('/api/craving-entries', data);
  },

  getAnalytics: async () => {
    return apiClient.get('/api/analytics');
  },
};

// Recipes API
export const recipesAPI = {
  getRecipes: async (filters?: any) => {
    return apiClient.get('/api/recipes', filters);
  },

  getRecipeById: async (id: number) => {
    return apiClient.get(`/api/recipes/${id}`);
  },

  toggleBookmark: async (recipeId: number) => {
    return apiClient.post(`/api/recipes/${recipeId}/bookmark`);
  },

  markAsTried: async (recipeId: number, rating?: number) => {
    return apiClient.post(`/api/recipes/${recipeId}/tried`, {rating});
  },
};

// Chat API
export const chatAPI = {
  getChatHistory: async (limit = 50) => {
    return apiClient.get('/api/chat', {limit});
  },

  sendMessage: async (message: string) => {
    return apiClient.post('/api/chat', {message});
  },
};

export default api;