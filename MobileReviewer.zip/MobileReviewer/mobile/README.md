# SOULFUEL Mobile App 📱

The React Native mobile application for SOULFUEL - your comprehensive wellness transformation platform.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- React Native CLI
- Android Studio (for Android)
- Xcode (for iOS, macOS only)
- CocoaPods (for iOS dependencies)

### Installation

```bash
# Install dependencies
npm install

# iOS specific setup
cd ios && pod install && cd ..

# Start Metro bundler
npm start

# Run on iOS (macOS only)
npm run ios

# Run on Android
npm run android
```

## 📱 App Store Deployment

### iOS App Store

1. **Configure Xcode Project**
   ```bash
   cd ios
   open SOULFUELMobile.xcworkspace
   ```

2. **Update Info.plist**
   - Set display name: "SOULFUEL"
   - Configure privacy descriptions for camera, microphone, photos
   - Set minimum iOS version: 12.0

3. **Build Archive**
   ```bash
   npm run build:ios
   ```

4. **Upload to App Store Connect**
   - Use Xcode Organizer
   - Submit for review

### Google Play Store

1. **Generate Signed APK**
   ```bash
   # Generate keystore
   keytool -genkey -v -keystore my-upload-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000

   # Build release APK
   npm run build:android
   ```

2. **Upload to Google Play Console**
   - Create app listing
   - Upload APK/AAB bundle
   - Configure store listing
   - Submit for review

## 🎨 App Assets

### Required Icons & Images
- App Icon: 1024x1024px (iOS), 512x512px (Android)
- Splash Screen: Multiple resolutions for different devices
- Store Screenshots: 
  - iPhone: 6.5" and 5.5" displays
  - Android: Phone and tablet variations

### Screenshot Requirements
1. **Dashboard** - Main wellness overview
2. **Food Scanner** - AI-powered food analysis
3. **Tracking** - Sugar, mood, craving monitoring
4. **Community** - Social features and challenges
5. **AI Coach** - Personalized coaching interface

## 🔧 Configuration

### Environment Variables
Create `.env` file in mobile directory:
```
API_BASE_URL=https://your-deployed-backend.replit.app
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_API_KEY=your-api-key
FIREBASE_APP_ID=your-app-id
```

### Firebase Configuration

1. **iOS Setup**
   - Download `GoogleService-Info.plist`
   - Add to `ios/SOULFUELMobile/` directory

2. **Android Setup**
   - Download `google-services.json`
   - Add to `android/app/` directory

## 📊 Features

### Core Functionality
- ✅ Multi-modal food scanning (camera, barcode, text, voice)
- ✅ AI-powered nutrition analysis with Gemini integration
- ✅ Comprehensive health tracking (sugar, mood, cravings)
- ✅ 6 specialized AI coaches with chat histories
- ✅ Community challenges and social features
- ✅ Withdrawal symptom monitoring and coping tools
- ✅ Emergency craving toolkit with mini-games
- ✅ Recipe recommendations and meal planning
- ✅ Progress analytics and achievement system
- ✅ Multi-language support (10 languages)

### Premium Features (Subscription Tiers)
- **Silver (Free)**: Basic tracking, 3 scans/week, 3 AI sessions
- **Gold ($20/month)**: Advanced scanner, community posting, 10 AI sessions
- **Platinum ($40/month)**: Unlimited scans, habit scoring, AI predictions
- **Diamond ($100/month)**: 24/7 AI coach, expert consultations, family accounts

## 🏪 Store Listing Content

### App Title
"SOULFUEL - Wellness Tracker"

### Subtitle
"Transform Your Relationship with Food"

### Description
Transform your wellness journey with SOULFUEL, the AI-powered platform that helps you break free from ultra-processed foods and sugar addiction. Our comprehensive app combines cutting-edge technology with proven wellness methodologies to create lasting health transformations.

**Key Features:**
🤖 AI-Powered Food Analysis - Instant nutrition insights with camera scanning
📊 Comprehensive Tracking - Monitor sugar, mood, and cravings in one place
👥 Expert AI Coaches - 6 specialized coaches for personalized guidance
🎮 Gamified Progress - Achievements, challenges, and community support
🚨 Emergency Support - Crisis intervention tools and coping strategies
🌍 Global Access - Support for 10 languages worldwide

**Why SOULFUEL?**
- Science-backed approach to breaking food addiction
- Real-time AI analysis of food choices with health scoring
- Community-driven challenges and social support
- Expert consultations with certified nutritionists
- Comprehensive withdrawal symptom management
- Family account management and parental controls

Start your transformation today. Your healthiest self awaits.

### Keywords
wellness, nutrition, food tracking, sugar addiction, AI coach, health tracker, meal planning, community support, mindful eating, habit change

### Category
Health & Fitness

### Age Rating
- iOS: 4+ (suitable for all ages)
- Android: Everyone

## 🔒 Privacy & Compliance

### Data Collection
- Health and fitness data (with user consent)
- Usage analytics (anonymized)
- Camera access for food scanning
- Microphone for voice logging
- Location for personalized recommendations

### Privacy Policy
Comprehensive privacy policy covering:
- Data collection and usage
- Third-party integrations
- User rights and data deletion
- GDPR and CCPA compliance
- Child privacy protections

## 🧪 Testing

### Pre-Release Testing
1. **Internal Testing** - Development team validation
2. **Alpha Testing** - Closed user group feedback
3. **Beta Testing** - Public beta via TestFlight/Play Console
4. **Performance Testing** - Load testing and optimization

### Test Coverage
- Core functionality across all features
- Subscription flow and payments
- Offline capabilities and data sync
- Cross-platform compatibility
- Accessibility compliance
- Security and privacy validation

## 📈 Marketing Strategy

### Launch Plan
1. **Soft Launch** - Limited regions for feedback
2. **Feature Updates** - Regular content and feature releases
3. **Community Building** - Social media and influencer partnerships
4. **Health Professional Network** - Expert endorsements
5. **Corporate Wellness** - B2B partnerships

### ASO (App Store Optimization)
- Keyword optimization for health and wellness terms
- Regular screenshot and description updates
- Seasonal promotional campaigns
- User review management and responses
- Featured app opportunities

## 🛠️ Development Workflow

### Build Process
```bash
# Development build
npm run start

# Production iOS build
npm run build:ios

# Production Android build  
npm run build:android

# Bundle JavaScript
npm run bundle:ios
npm run bundle:android
```

### Release Management
- Semantic versioning (1.0.0, 1.1.0, etc.)
- Staged rollouts for major updates
- Hotfix procedures for critical issues
- Automated testing and deployment pipelines
- Rollback capabilities for failed releases

---

**Ready to transform wellness tracking? Deploy SOULFUEL and help users fuel their minds and transform their lives.** 🌟